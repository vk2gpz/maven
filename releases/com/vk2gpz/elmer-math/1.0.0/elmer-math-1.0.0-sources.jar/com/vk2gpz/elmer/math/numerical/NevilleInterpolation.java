/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
             Implementation of class NevilleInterpolation             
====================================================================*/
/**
 * Implement Neville interpolation method.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Interpolation
 */

public final class NevilleInterpolation extends Interpolation {
	public NevilleInterpolation() {
		super();
	}
		
	public static double interpolate(double t, double[] x, double[] y, double[] w) {
		int N = x.length;
		System.arraycopy(y, 0, w, 0, N);
		for (int i = 0; i < N; i++) {
			for (int j = i - 1; j >= 0; j--) {
				w[j] = w[j + 1] + (w[j + 1] - w[j]) * (t - x[i]) / (x[i] - x[j]);
			}
		}
		return w[0];
	}

	public double interpolate(double t) {
		return interpolate(t, this.x, this.y, this.w);
	}
}
