/*
 * Copyright (c) 2000-2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.math.MathException;
import com.vk2gpz.elmer.math.MismatchedSizeException;
import com.vk2gpz.elmer.math.SingularMatrixException;
import com.vk2gpz.elmer.math.VecMath;

/*====================================================================
                      Implementation of class LU                      
====================================================================*/
/**
 * LU provides LU decomposition method and a method to solve a system of
 * linear equations.  The parameter matrix must be a square matrix;
 * The matrix LU will be the combination of a lower diagonal
 * and upper diagonal matrix decompostion of the given matrix; the diagonal
 * elements of L (unity) are not stored. The vector parameter records
 * the row permutation effected by the partial pivoting.
 * equations. This method returns +/- 1 depending on whether the number of
 * row interchanges was even or odd, respectively.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public class LU {
	private LU() {
		super();
	}

	/**
	 * Computes an LU decomposition of a matrix.
	 * 
	 * @param a a matrix to be decomposed.
	 * @param lu a matrix to store decomposed LU matrix.
	 * @param ipvt an array to store pivot information.
	 * @return determinant of the matrix <code>a</code>
	 * @exception IllegalArgumentException
	 * @exception MathException
	*/
	public static double decompose(double[][] a, double[][] lu, int[] ipvt) {
		int[] row = new int[1]; int[] col = new int[1];
		int nRow = row[0];
		int nCol = col[0];
		VecMath.checkMatrix(a, row, col);
		nRow = row[0];
		nCol = col[0];
		VecMath.checkMatrix(lu, row, col);
		if (nRow != nCol) {
            throw new MismatchedSizeException("row permutation must be same dimension as matrix");
		}
        if (nRow != row[0]) {
			throw new MismatchedSizeException("row permutation must be same dimension as matrix");
		}
        if (nCol != col[0]) {
			throw new MismatchedSizeException("row permutation must be same dimension as matrix");
		}

		int n = nRow;
		double[] weight = new double[n];
		double t, u;
		int i, j, k, ii, ik;
		j = 0;
		VecMath.copy(a, lu);
		double determinant = 0;
		
		for (k = 0; k < n; k++) {
			ipvt[k] = k;
			u = 0;
			for (j = 0; j < n; j++) {
				t = Math.abs(lu[k][j]);
				if (t > u) {
					u = t;
				}
			}
			if (u == 0) {
				throw new SingularMatrixException("cannot invert matrix");
			}
			weight[k] = 1.0 / u;
		}
		determinant = 1.0;
		for (k = 0; k < n; k++) {
			u = -1.0;
			//j = 0;
			for (i = k; i < n; i++) { 
				ii = ipvt[i];
				t = Math.abs(lu[ii][k]) * weight[ii];
				if (t > u) {
					u = t;
					j = i;
				}
			}
			ik = ipvt[j];
			if (j != k) {
				ipvt[j] = ipvt[k];
				ipvt[k] = ik;
				determinant = -determinant;
			}
			u = lu[ik][k];
			determinant *= u;
			if (u == 0.0) {
				throw new SingularMatrixException("cannot invert matrix");
			}

			for (i = k + 1; i < n; i++) {
				ii = ipvt[i];
				t = (lu[ii][k] /= u);
				for (j = k + 1; j < n; j++) {
					lu[ii][j] -= t*lu[ik][j];
				}
			}
		}

		return determinant;
	}

	/**
	* solves Ax = b using LU decomposition.
	* 
	* @param lu a LU matrix of the matrix a the left hand side of Ax = b.
	* @param b a vector corresponds to the right hand side of Ax = b.
	 * @param ipvt an array containing pivot information.
	* @param x a vector to store answer.
	* @return a vector <i>x</i> containing answer.
	*/
	private static double[] solve(double[][] lu, double[] b, int[] ipvt, double[] x) {
		int i, j, ii;
		double t;
		int n = lu.length;
		if (x == null) {
			x = new double[n];
		}
		for (i = 0; i < n; i++){
			ii = ipvt[i];
			t = b[ii];
			for (j = 0; j < i; j++) {
				t-= lu[ii][j] * x[j];
			}
			x[i] = t;
		}
		for (i = n - 1; i >= 0; i--) {
			t = x[i];
			ii=ipvt[i];
			for (j = i + 1; j < n; j++) {
				t-= lu[ii][j] * x[j];
			}
			x[i] = t/lu[ii][i];
		}
		return x;
	}

	/**
	* solves Ax = b using LU decomposition.
	* 
	* @param a a matrix in the left hand side of Ax = b.
	* @param b a vector corresponds to the right hand side of Ax = b.
	* @param x a vector to store answer.
	* @return a vector <i>x</i> containing answer.
	*/
	public static double[] solve(double[][] a, double[] b, double[] x) {
		int n = a.length;
		int[] ipvt = new int[n];
		double[][] lu = new double[n][n];
		double det = LU.decompose(a, lu, ipvt);

		return solve(lu, b, ipvt, x);
	}
}
