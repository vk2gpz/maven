/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/*====================================================================
                Implementation of class Interpolation                 
====================================================================*/
/**
 * Interpolation defines a interpolation method.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public abstract class Interpolation {
    private final transient List<NumericalListener> listeners = new CopyOnWriteArrayList<>();

	double[] x;
	double[] y;
	int N;						// number of samples
	double[] w;					// working array

	Interpolation() {
		this.N = 0;
		this.x = new double[this.N];
		this.y = new double[this.N];
		this.w = new double[this.N];
	}
	
	/**
	* Sets sample data.  It copies sample data into internal arrays.
	*/
	public void setSamples(double[] x, double[] y) {
        if(x.length != y.length) {
            throw new IllegalArgumentException("samples must have the same length.");
		}
		this.N = x.length;
		this.x = new double[this.N];
		this.y = new double[this.N];
		this.w = new double[this.N];		
		System.arraycopy(x, 0, this.x, 0, this.N);
		System.arraycopy(y, 0, this.y, 0, this.N);		
	}
	
	public abstract double interpolate(double t);

	public void addNumericalListener(NumericalListener l) {
        this.listeners.add(l);
    }

    /**
     * Removes a ChangeListener from the slider.
     *
     * @param l the ChangeListener to remove
     */
    public void removeNumericalListener(NumericalListener l) {
        this.listeners.remove(l);
    }

    /**
     * Send a ChangeEvent, whose source is this Slider, to
     * each listener.  This method method is called each time 
     * a ChangeEvent is received from the model.
     * 
     */
    protected void fireEvaluated(double value) {
        // newest listener first
        for (int i = this.listeners.size() - 1; i >= 0; i--) {
            NumericalEvent event = new NumericalFunctionEvent(this, NumericalFunctionEvent.SINGLE_VALUED, value);
            this.listeners.get(i).evaluated(event);
        }
    }   
}
