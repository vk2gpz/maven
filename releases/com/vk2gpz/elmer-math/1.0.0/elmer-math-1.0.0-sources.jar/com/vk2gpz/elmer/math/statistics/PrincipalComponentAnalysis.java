/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.statistics;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.math.ConvergenceException;
import com.vk2gpz.elmer.math.MathException;
import com.vk2gpz.elmer.math.numerical.QR;
import com.vk2gpz.elmer.math.VecMath;

/*====================================================================
          Implementation of class PrincipalComponentAnalysis          
====================================================================*/
/**
 * PrincipalComponentAnalysis carries out principal component analysis
 * on a given data.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class PrincipalComponentAnalysis {
	private PrincipalComponentAnalysis() {
		super();
	}
											
	public static final int PREPROCESS0 = 0; // no preprocessing
	public static final int PREPROCESS1 = 1;	
	public static final int PREPROCESS2 = 2;	

	/**
	* Conducts Principal Component Analysis on a given matrix <code>x</code> and return
	* a transformation matrix <code>Q</code> and a vector <code>lambda</code> containing
	* eigenvalues.  <p>
	* <pre>
	* Preprocess flag 0: no preprocessing.
	* Preprocess flag 1: Subtract the mean from all variables.
	* Preprocess flag 2: All variables are further divided by the standard deviation.
	* </pre>
	*/
	public static void analyze(double[][] x, double[][] q, double[] lambda, int preprocess) throws MathException {
		int n = x.length;		// n row
		int m = x[0].length;	// m column
		int ndf = n - ((preprocess != PREPROCESS0) ? 1 : 0);
		double s, t, percent;
		
		for (int j = 0; j < m; j++) {
			t = 0.0;
			for (int i = 0; i < n; i++) {
				t += x[j][i];
			}
			t /= n;
			if (preprocess != PREPROCESS0) {
				for (int i = 0; i < n; i++) {
					x[j][i] -= t;
				}
			}
			q[j][j] = VecMath.dot(x[j], x[j]) / ndf;
			s = Math.sqrt(q[j][j]);
			if (preprocess == PREPROCESS2) {
				q[j][j] = 1;
				for (int i = 0; i < n; i++) {
					x[j][i] /= s;
				}
			}
		}
		for (int j = 0; j < m; j++) {
			for (int k = 0; k < j; k++) {
				q[j][k] = q[k][j] = VecMath.dot(x[j], x[k]) / ndf;
			}
		}
		double[][] qq = new double[n][m];
		if (QR.eigen(q, lambda, qq)) {
			throw new ConvergenceException("PrincipalComponentAnalysis.analyze() did not converge.");
		}
	}
}

