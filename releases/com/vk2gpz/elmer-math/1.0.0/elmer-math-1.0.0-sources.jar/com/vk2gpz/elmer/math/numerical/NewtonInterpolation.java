/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
             Implementation of class NewtonInterpolation              
====================================================================*/
/**
 * Implement Newton interpolation method.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Interpolation
 */

public final class NewtonInterpolation extends Interpolation {
	public NewtonInterpolation() {
		super();
	}
		
	public static void makeTable(double[] x, double[] y, double[] w) {
		int N = x.length;
		double[] tmp = new double[N];
		System.arraycopy(y, 0, tmp, 0, N);
		for (int i = 0; i < N; i++) {
			for (int j = i - 1; j >= 0; j--) {
				tmp[j] = (tmp[j + 1] - tmp[j]) / (x[i] - x[j]);
			}
			w[i] = tmp[0];
		}
	}

	private void makeTable() {
		makeTable(this.x, this.y, this.w);
	}
	
	public void setSamples(double[] x, double[] y) {
		super.setSamples(x, y);
		makeTable();
	}
	
	public static double interpolate(double t, double[] x, double[] y, double[] w) {
		int N = x.length;
		double p = w[N - 1];
		for (int i = N - 2; i >= 0; i--) {
			p = p * (t - x[i]) + w[i];
		}
		return p;
	}

	public double interpolate(double t) {
		return interpolate(t, this.x, this.y, this.w);
	}
}
