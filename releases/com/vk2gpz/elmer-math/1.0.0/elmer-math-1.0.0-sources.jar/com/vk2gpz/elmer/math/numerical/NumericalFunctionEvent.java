/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
import java.util.*;

/*====================================================================
           Implementation of class NumericalFunctionEvent                
====================================================================*/
/**
 * generally describe NumericalFunctionEvent in here
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see EventObject
 */

public class NumericalFunctionEvent extends NumericalEvent {
    /**
     * This event id indicates that the functino is a single-valued.
     */
    public static final int SINGLE_VALUED = 0;

    /**
     * This event id indicates that the functino is a multi-valued.
     */
    public static final int MULTI_VALUED = 1;

	/**
	 * A value being computed.
	 */
	private final double value;

	/**
	 * A number of multi values.
	*/
	private final int numberOfValues;

	/**
	 * A multi values being computed.
	 */
	private final double[] values;
	
	/**
     * Constructs a NumericalFanctionEvent object.
     * source, event type and value.
	 * 
     * @param source the MtDial object where the event originated
     * @param id     the event type
     * @param value  the computed value.
     * @param values  the computed values.
     */
    public NumericalFunctionEvent(Object source, int id, double value, double[] values) {
        super(source, id);
		double[] dummy = new double[1];
		switch (id) {
		default:
		case SINGLE_VALUED:
			this.numberOfValues = 1;
			this.value = value;
			dummy[0] = this.value;
			this.values = dummy;
			break;
		case MULTI_VALUED:
			this.numberOfValues = values.length;
			this.values = values;
			this.value = this.values[0];
			break;
		}
    }

    /**
     * Constructs a NumericalFanctionEvent object.
     * source, event type and value.
	 * 
     * @param source the MtDial object where the event originated
     * @param id     the event type
     * @param value  the computed value.
     */
    public NumericalFunctionEvent(Object source, int id, double value) {
        this(source, SINGLE_VALUED, value, null);
    }

    /**
     * Constructs a NumericalFanctionEvent object.
     * source, event type and value.
	 * 
     * @param source the MtDial object where the event originated
     * @param id     the event type
     * @param values  the computed values.
     */
    public NumericalFunctionEvent(Object source, int id, double[] values) {
        this(source, MULTI_VALUED, values[0], values);
    }

    /**
     * The number of values.
     *
     * @return   The number of values.
     */
    public int getNumberOfValues() {
        return this.numberOfValues;
    }

    /**
     * The value.
     *
     * @return   The value.
     */
    public double getValue() {
        return this.value;
    }

    /**
     * The values.
     *
     * @return   The values.
     */
    public double[] getValues() {
		return this.values;
    }
	
    /**
     * Returns a String representation of this MtDialEvent object.
     *
     * @return  a String representation of this MtDialEvent object.
     */
    public String toString() {
        return getClass().getName() + "[source=" + this.source + ", id=" + this.id + ", value=" + Arrays.toString(this.values) + "]";
    }
}
