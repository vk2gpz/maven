/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.math;

import com.vk2gpz.elmer.math.numerical.LU;

public class VecMath {
	private VecMath() {
		super();
	}
	
 	/* ------------------------- vector math -------------------------- */
	/**
	 * Subtracts a vector 'v2' from a vector 'v1'.
	 * ans = v1 - v2.
	 */
    public static double[] subtract(double[] v1, double[] v2) {
        if (v1.length != v2.length) {
            throw new IllegalArgumentException("Vectors must have the same length.");
		}
        double[] ans = new double[v1.length];
        for (int i = 0; i < v1.length; i++) {
            ans[i] = v1[i] - v2[i];
		}
        return ans;
    }
	
	/**
	 * Computes a product of a vector 'v'.
	 * ans *= v[i].
	 */
    public static double product(double[] v) {
        double ans = 1.0;
		for (double value : v) {
			ans *= value;
		}
        return ans;
    }
	
	/**
	 * Adds a scalar 'd' to a vector 'v'.
	 * ans = v + d.
	 */
    public static double[] add(double d, double[] v) {
        double[] ans = new double[v.length];
        for (int i = 0; i < v.length; i++) {
            ans[i] = d + v[i];
		}
        return ans;
    }
	
	/**
	 * Adds two vectors 'v1' and 'v2'.
	 * ans = v1 + v2.
	 */
    public static double[] add(double[] v1, double[] v2) {
        if (v1.length != v2.length) {
            throw new IllegalArgumentException("Vectors must have the same length.");
		}
        double[] ans = new double[v1.length];
        for (int i = 0; i < v1.length; i++) {
            ans[i] = v1[i] + v2[i];
		}
        return ans;
    }
	
	/**
	 * Multiplies two vectors 'v1' and 'v2'.
	 * ans = v1 * v2.
	 */
    public static double[] multiply(double[] v1, double[] v2) {
        if (v1.length != v2.length) {
            throw new IllegalArgumentException("Vectors must have the same length.");
		}
        double[] ans = new double[v1.length];
        for (int i = 0; i < v1.length; i++) {
            ans[i] = v1[i] * v2[i];
		}
        return ans;
    }
	
	/**
	 * Computs a sum of a vector 'v'.
	 * ans += v[i].
	 */
    public static double sum(double[] v) {
        double sum = 0.0;
		for (double value : v) {
			sum += value;
		}
        return sum;
    }
	
	/**
	 * Makes a copy of a vector 'v'.
	 */
    public static double[] copy(double[] v) {
        double[] ans = new double[v.length];
        System.arraycopy(v, 0, ans, 0, v.length);
        return ans;
    }
	
	/**
	 * Copies a vector 'v1' into a vector 'v2'.
	 */
    public static void copy(double[] v1, double[] v2) {
        System.arraycopy(v1, 0, v2, 0, v1.length);
    }

	/**
	 * Copies a sub-section (from i to end) of a vector 'v1'
	 * into a vector 'v2'.
	 */
    public static double[] copySub(int start, double[] v) {
		double[] ans = new double[v.length-start];
        System.arraycopy(v, start, ans, 0, v.length-start);
		return ans;
    }

	/**
	 * Copies a sub-section (from i to end) of a vector 'v1'
	 * into a vector 'v2'.
	 */
    public static void copySub(int start, double[] v1, double[] v2) {
        System.arraycopy(v1, start, v2, 0, v1.length-start);
    }
	
	/**
	 * Copies a vector 'v1' into a vector 'v2' at 'start'.
	 */
    public static void copySub(double[] v1, int start, double[] v2) {
        System.arraycopy(v1, 0, v2, start, v1.length);
    }
	
	/*
	 * Returns the sum of the squares of this vector (its length 
	 * sqaured in n-dimensional space).
	 */
	public static double normSquared(double[] v) {
		double s = 0.0;
		for (double value : v) {
			s += value * value;
		}
		return s;
	}

	/*
	 * Returns the square root of the sum of the squares of this 
	 * vector (its length in n-dimensional space). 
	 */
	public static double norm(double[] v) {
		return Math.sqrt(normSquared(v));
	}

	/*
	 * Normalizes this vector in place. 
	 */
	public static double[] normalize(double[] v) {
		double len = norm(v);
		
		if (Double.compare(len, 0.0) == 0) {	/* to avoid zero-div. */
			return v;
		}
		for (int i = 0; i < v.length; i++) {
			v[i] /= len;
		}
		return v;
	}
	
	/**
	 * Scales a vector 'v' by a scalar 'd'.
	 * ans = d * v.
	 */
    public static double[] scale(double d, double[] v, double[] ans) {
		if (ans == null) {
			ans = new double[v.length];
		}
		
        if (v.length != ans.length) {
            throw new IllegalArgumentException("Vectors must have the same length.");
		}
        for (int i = 0; i < v.length; i++) {
            ans[i] = d * v[i];
		}
		return ans;
    }
	
	/*
	 * Scales a vector 'v' by a scalar vaue 'd'.
	 * v *= d.
	 */
    public static void scale(double d, double[] v) {
        for (int i = 0; i < v.length; i++) {
            v[i] *= d;
		}
    }

	/*
	 * Negate a vector 'v'.
	 * v = -v.
	 */
    public static void negate(double[] v) {
        for (int i = 0; i < v.length; i++) {
            v[i] *= -1;
		}
    }

	/*
	 * Negate a vector 'v'.
	 * v = -v.
	 */
    public static void negate(double[] v1, double[] v2) {
        if (v1.length != v2.length) {
            throw new IllegalArgumentException("Vectors must have the same length.");
		}
        for (int i = 0; i < v1.length; i++) {
            v2[i] = -1 * v1[i];
		}
    }
	
	/*
	 * Computes an innerproduct of two vectors 'v1' and 'v2'.
	 * ip = v1.v2 .
	 */
    public static double dot(double[] v1, double[] v2) {
        if (v1.length != v2.length) {
            throw new IllegalArgumentException("Vectors must have the same length.");
		}
		final int n = v1.length;
		final int n8 = n & ~7;  // Fast mod 8
		double ans = 0.0;
		
		// Process 8 elements at a time for better JIT optimization
		for (int i = 0; i < n8; i += 8) {
			ans += v1[i]*v2[i] + v1[i+1]*v2[i+1] + v1[i+2]*v2[i+2] + v1[i+3]*v2[i+3] +
				   v1[i+4]*v2[i+4] + v1[i+5]*v2[i+5] + v1[i+6]*v2[i+6] + v1[i+7]*v2[i+7];
		}
		
		// Handle remaining elements
		for (int i = n8; i < n; i++) {
			ans += v1[i] * v2[i];
		}
		
		return ans;
    }

	/*
	 * Computes a crossproduct of two 3-D vectors 'v1' and 'v2'.
	 * ans = v1xv2.
	 */
    public static double[] cross(double[] v1, double[] v2){
        if (v1.length != 3 || v2.length!=3) {
            throw new IllegalArgumentException("Vectors must be 3-D.");
		}
		int len = v1.length;
		double[] ans = new double[len];
		ans[0] = v1[1]*v2[2]-v1[2]*v2[1];
		ans[1] = v1[2]*v2[0]-v1[0]*v2[2];
		ans[2] = v1[0]*v2[1]-v1[1]*v2[0];
		return ans;
    }

	/*
	 * Computes an angle between two vectors 'v1' and 'v2'.
	 * ans = v1xv2.
	 */
	public static double angle(double[] v1, double[]v2) {
		return Math.acos(dot(v1, v2)/(norm(v1)*norm(v2)));
	}

	/*
	 * Computes distance between two vectors 'v1' and 'v2'.
	 */
	public static double distance(double[] v1, double[] v2) {
		final double dist = distanceSquared(v1, v2);
		return (dist > 0.0) ? Math.sqrt(dist) : 0.0;
	}

	/*
	 * Computes squared distance between two vectors 'v1' and 'v2'.
	 */
	public static double distanceSquared(double[] v1, double[] v2) {
        if (v1.length != v2.length) {
            throw new IllegalArgumentException("Vectors must have the same length.");
		}
		double sum = 0.0;
		for (int i = 0; i < v1.length; i++){
			final double d = v1[i] - v2[i];
			if (d != 0.0) {
				sum += d * d;
			}
		}
		return sum;
	}
	
    /**
     * Sets the value of this vector to the mean vector of the spcified
     * vector array.
     * 
     * @param vectors the array of vector.
    */
    public static double[] mean(double[][] vectors) {
		int veclen = vectors[0].length;
		int vecnum = vectors.length;		
		double[] mean = new double[veclen];
		double tmpMean = 0;

		// accurate method
		for (int i = 0; i < vecnum; i++) {
			for (int j = 0; j < veclen; j++) {
				tmpMean = vectors[i][j] - mean[i];
				mean[i] += tmpMean / (j + 1);
			}
		}

		return mean;
    }

    /**
     * Sets the value of this vector to the mean vector of the spcified
     * vector array.
     * 
     * @param vectors the array of vector.
    */
    public static double[] mean(double[][] vectors, double[] mean) {
		int[] row = new int[1];
		int[] col = new int[1];
		checkMatrix(vectors, row, col);
		if(col[0]!=mean.length)
			throw new IllegalArgumentException("The lengths of each vector is not the same as that of mean");
		int veclen = col[0];
		int vecnum = row[0];
		
		for(int i = 0; i < vecnum; i++) {
			for(int j = 0; j < veclen; j++) {
				mean[j] += vectors[i][j];
			}
		}
		VecMath.scale(1.0 / vecnum, mean);
		return mean;
    }

	/**
	* checks whether two vector is the same or no.
	* 
	* @param v1 a vectr.
	* @param v2 a vectr.	
	* @return true if both vector are the same, otherwise false.
	* @exception IllegalArgumentException if two vectors are not
	* the same length.
	*/
	public static boolean equal(double[] v1, double[] v2) throws IllegalArgumentException	{
        if (v1.length != v2.length) {
            throw new IllegalArgumentException("Vectors must have the same length.");
		}
		int len = v1.length;
		boolean ret = true;
		for (int i = 0; i < len; i++) {
			if (v1[i] != v2[i]){
				ret = false;
				break;
			}
		}
		return ret;
	}

	/**
	   |- vmin:vlist| 
	   Make a Vector which consists of smallest elements
	   in the List of Vectors.
	   All vectors in vlist must have same dimension.
                                        vk2gpz/1993-Dec-08
	 */
	public static double[] getMinVector(double[][] vlist) {
		if (vlist.length == 0) {
			return null;
		}
		double[] newVector = VecMath.copy(vlist[0]);
		for (int i = 1; i < vlist.length; i++) {
			for (int j = 0; j < newVector.length; j++) {
				if(vlist[i][j] < newVector[j]) {
					newVector[j] = vlist[i][j];
				}
			}
		}

		return newVector;
	}
	
	/**
	   |- vmax:vlist| 
	   Make a Vector which consists of largest elements
	   in the List of Vectors.
	   All vectors in vlist must have same dimension.
	   vk2gpz/1993-Dec-08
	*/
	public static double[] getMaxVector(double[][] vlist) {
		if (vlist.length == 0) {
			return null;
		}
		double[] newVector = VecMath.copy(vlist[0]);
		for (int i = 1; i < vlist.length; i++) {
			for (int j = 0; j < newVector.length; j++) {
				if(vlist[i][j] > newVector[j]) {
					newVector[j] = vlist[i][j];
				}
			}
		}
		
		return newVector;
	}

	public static double[] getMidPointOf(double[] pointA, double[] pointB, double ratio, double[] result) {
		double	ratio2 = 1.0 - ratio;
		
		if (pointA.length != pointB.length) {
			return null;
		}
		
		int vsize = pointA.length;
		if ((result == null) || (result.length != vsize)) {
			result = new double[vsize];
		}
		for (int i = 0; i < vsize; i++) {
			result[i] = pointA[i] * ratio2 + pointB[i] * ratio;
		}
		
		return result;
	}

	/**
	   |- (BOOL)isLessThan:aVector| 
	   
	   vk2gpz/1993-Dec-09
	*/
	public static boolean isLessThan(double[] a, double[] b) {
		if (a.length != b.length) {
			return false;
		}

		for (int i = 0; i < a.length; i++) {
			if (a[i] > b[i]) {
				return false;
			}
		}
		return true;
	}

	/**
	   |- (BOOL)isGreaterThan:aVector| 
	   
	   vk2gpz/1993-Dec-09
	*/
	public static boolean isGreaterThan(double[] a, double[] b) {
		if (a.length != b.length) {
			return false;
		}

		for (int i = 0; i < a.length; i++) {
			if (a[i] < b[i]) {
				return false;
			}
		}
		return true;
	}
	
	/* ------------------------- matrix math -------------------------- */
	/**
	 * Checks matrix size.
	 */
	public static void checkMatrix(double[][] m, int[] row, int[] col) throws IllegalArgumentException {
        row[0] = m.length;
        col[0] = m[0].length;
        for (int i = 1; i < row[0]; i++) {
            if(m[i].length != col[0]) {
                throw new IllegalArgumentException("The lengths of the rows of the input matrix are not consistent.");
			}
		}
	}
		
	/**
	 * Computes a trace of a matrix m.
	 */
    public static double trace(double[][] m) throws MathException {
        double ans = 0.0;
        if (m.length != m[0].length) {
            throw new MathException("Matrix is not square.");
		}
        for (int i = 0; i < m.length; i++) {
            ans += m[i][i];
		}
        return ans;
    }

	/**
	 * Creates a zero matrix.
	 */
	public static double[][] zero(int r, int c) {
		double[][] ans = new double[r][c];
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                ans[i][j] = 0.0;
			}
		}
        return ans;
    }

    /**
     * Returns an identity matrix.
     */
    public static double[][] identity(int r, int c) {
		double[][] ans = new double[r][c];
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                ans[i][j] = (i == j) ? 1.0 : 0.0;
			}
		}
        return ans;
    }
	
	/**
	 * Multiplies a vector 'v' and a matrix 'm'.
	 * ans = v * m.
	 */
    public static double[] multiply(double[] v, double[][] m) throws IllegalArgumentException {
        int j, k;
        int i = v.length;
		int[] row = new int[1];
		int[] col = new int[1];
		checkMatrix(m, row, col);
		k = row[0];
		j = col[0];
		if (i != k) {
            throw new IllegalArgumentException("The number of elements in the input vector is not equal to the number of rows in the input matrix.");
		}
		double[] ans = new double[j];
        for (int i1 = 0; i1 < j; i1++) {
            for (int i2 = 0; i2 < i; i2++) {
                ans[i1] += v[i2] * m[i2][i1];
			}
		}
        return ans;
    }
	
	/**
	 * Multiplies a matrix 'm' and a vector 'v'.
	 * ans = m * v.
	 */
    public static double[] multiply(double[][] m, double[] v) throws IllegalArgumentException {
        int j, k;
        int i = v.length;
		int[] row = new int[1];
		int[] col = new int[1];
		checkMatrix(m, row, col);
		j = row[0];
		k = col[0];
		if (k != i) {
            throw new IllegalArgumentException("The number of columns in the input matrix is not equal to the number of elements in the input vector.");
		}
		double[] ans = new double[j];
        for (int i1 = 0; i1 < j; i1++) {
            for (int i2 = 0; i2 < i; i2++) {
                ans[i1] += m[i1][i2] * v[i2];
			}
		}
        return ans;
    }

	/**
	 * Multiplies matrices 'm1' and 'm2'.
	 * ans = m1 * m2.
	 */
    public static double[][] multiply(double[][] m1, double[][] m2) throws IllegalArgumentException {
        int r1, c1, r2, c2;
		int[] row = new int[1];
		int[] col = new int[1];
		checkMatrix(m1, row, col);
		r1 = row[0];
		c1 = col[0];
		checkMatrix(m2, row, col);
		r2 = row[0];
		c2 = col[0];
		if (c1 != r2) {
            throw new IllegalArgumentException("The number of columns in the input matrix A is not equal to the number of rows in the input matrix B.");
		}
		double[][] ans = new double[r1][c2];
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c2; j++) {
                for (int k = 0; k < c1; k++) {
                    ans[i][j] += m1[i][k] * m2[k][j];
				}
			}
		}
        return ans;
    }
	
	/**
	 * Adds matrices 'm1' and 'm2'.
	 * ans = m1 + m2.
	 */
    public static double[][] add(double[][] m1, double[][] m2) throws IllegalArgumentException {
        int r1, c1, r2, c2;
		int[] row = new int[1];
		int[] col = new int[1];
		checkMatrix(m1, row, col);
		r1 = row[0];
		c1 = col[0];
		checkMatrix(m2, row, col);
		r2 = row[0];
		c2 = col[0];
		if (r1!=r2 || c1!=c2) {
            throw new IllegalArgumentException("Matrices A and B must have similar dimensions.");
		}
		double[][] ans = new double[r1][c1];
        for (int i = 0; i < r1; i++) {
			for (int j = 0; j < c1; j++) {
                ans[i][j] = m1[i][j] + m2[i][j];
			}
		}
        return ans;
    }

	/**
	 * Computes a transpose of a matrix 'm'.
	 * ans = m1^T.
	 */
    public static double[][] transpose(double[][] m) throws IllegalArgumentException {
        int r;
        int c;
        double[][] ans = null;
		int[] row = new int[1];
		int[] col = new int[1];
		checkMatrix(m, row, col);
		r = row[0];
		c = col[0];
		ans = new double[c][r];
		for (int i = 0; i < c; i++) {
            for (int j = 0; j < r; j++) {
                ans[i][j] = m[j][i];
			}
		}
        return ans;
    }
	
	/**
	 * Creates a copy of a matrix 'm'.
	 */
    public static double[][] copy(double[][] m) {
        int r = m.length;
        int c = m[0].length;
		double[][] ans = new double[r][c];
        for (int i = 0; i < r; i++) {
            System.arraycopy(m[i], 0, ans[i], 0, c);
		}
        return ans;
    }

	/**
	 * Creates a copy of a matrix 'm1' in 'm2'.
	 */
    public static void copy(double[][] m1, double[][] m2) {
        int r = m1.length;
        int c = m1[0].length;
        for (int i = 0; i < r; i++) {
            System.arraycopy(m1[i], 0, m2[i], 0, c);
		}
    }
	
	/**
	 * Checks whether a matrix is symmetric or not.
	 */
    static boolean isSymmetric(double[][] m) {
        int r = m.length;
        int c = m[0].length;
        if (r!=c) {
            return false;
		}
        for (int i = 1; i < r; i++) {
            for (int j = 0; j < c; j++) {
                if (m[i][j] != m[i][i]) {
                    return false;
				}
			}
		}
        return true;
    }
	
	/**
	 * Subtractss matrices 'm2' from 'm1'.
	 * ans = m1 - m2.
	 */
    public static double[][] subtract(double[][] m1, double[][] m2) throws IllegalArgumentException {
        int r1, c1, r2, c2;
		int[] row = new int[1];
		int[] col = new int[1];
		checkMatrix(m1, row, col);
		r1 = row[0];
		c1 = col[0];
		checkMatrix(m2, row, col);
		r2 = row[0];
		c2 = col[0];
		if ((r1 != r2) || (c1 != c2)) {
            throw new IllegalArgumentException("Matrices A and B must have similar dimensions.");
		}
		double[][] ans = new double[r1][c1];
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c1; j++) {
                ans[i][j] = m1[i][j] - m2[i][j];
			}
		}
        return ans;
    }

	/**
	 * Computes an inverse matrix.
	 */
    public static double[][] invert(double[][] m) {
		return invert(m, null);
    }

	/**
	 * Computes an inverse matrix.
	 */
    public static double[][] invert(double[][] m, double[][] m_inv) {
		int[] row = new int[1];
		int[] col = new int[1];
		checkMatrix(m, row, col);
		if (row[0] != col[0]) {
            throw new MismatchedSizeException("row permutation must be same dimension as matrix");
		}
		int n = row[0];
        if (m_inv == null) {
			m_inv = new double[n][n];
		}
		int[] ipvt = new int[n];
		double[][] lu = new double[n][n];
		double det = LU.decompose(m, lu, ipvt);
		double t;
		int i, j, k, ii;
		
		if (det != 0) {
			for (k = 0; k < n; k++) {
				for (i = 0; i < n; i++) {
					ii = ipvt[i];
					t = (ii == k) ? 1 : 0;
					for (j = 0; j < i; j++) {
						t -= lu[ii][j] * m_inv[j][k];
					}
					m_inv[i][k] = t;
				}
				for (i = n-1; i >= 0; i--) {
					t = m_inv[i][k];
					ii = ipvt[i];
					for (j = i + 1; j < n; j++) {
						t -= lu[ii][j] * m_inv[j][k];
					}
					m_inv[i][k] = t / lu[ii][i];
				}
			}
		}
		return m_inv;
    }
	
	/**
	 * Compute determinant of 2x2 matrix. Two columns of matrix are input.
	 * (this is for fast computation);
	 */
	public static double determinant2x2(double[] c1, double[] c2) {
		return (c1[0] * c2[1] - c2[0] * c1[1]);
	}

	/**
	 * Calculate the determinant of a 2x2 matrix: | a b | | c d |
	 * (this is for fast computation);
	 */
	public static double determinant2x2(double a, double b, double c, double d) {
		return (a * d - b * c);
	}
	
	/*
	 * Compute determinant of 3x3 matrix. Three columns of matrix are input.
	 */
	public static double determinant3x3(double[] c1, double[] c2, double[] c3) {
		return c1[0]*c2[1]*c3[2] + c2[0]*c3[1]*c1[2] + c3[0]*c1[1]*c2[2] -
			c1[0]*c3[1]*c2[2] - c2[0]*c1[1]*c3[2] - c3[0]*c2[1]*c1[2];
	}

	/**
	 * Calculate the determinent of a 3x3 matrix in the form:
	 *     | a1,  b1,  c1 | <p>
	 *     | a2,  b2,  c2 | <p>
	 *     | a3,  b3,  c3 | <p>
	 */
	public static double determinant3x3(double a1, double a2, double a3,
										double b1, double b2, double b3,
										double c1, double c2, double c3) {
		return (a1 * determinant2x2( b2, b3, c2, c3 )
				- b1 * determinant2x2( a2, a3, c2, c3 )
				+ c1 * determinant2x2( a2, a3, b2, b3 ) );
	}

	/**
	 * Computes a determinant fo a matrix.
	 */
    public static double determinant(double[][] m) throws IllegalArgumentException, MathException {
        double ans;
		int[] row = new int[1];
		int[] col = new int[1];
		checkMatrix(m, row, col);
		if (row[0] != col[0]) {
			throw new MathException("Matrix is not square.");
		}
		if (row[0] == 2) {
			return determinant2x2(m[0][0], m[1][0], m[0][1], m[1][1]);
		}
		if (row[0] == 3) {
			return determinant3x3(m[0][0], m[1][0], m[2][0],
								  m[0][1], m[1][1], m[2][1],
								  m[0][2], m[1][2], m[2][2]);
		}
		int n = row[0];
		int[] ipvt = new int[n];
		double[][] lu = new double[n][n];
		ans = LU.decompose(m, lu, ipvt);
		return ans;
	}
	
	/**
	* solves mx = b using LU decomposition.
	* 
	* @param b a vector corresponds to the left hand side of mx = b.
	* @return a vector <i>x</i> containing answer.
	*/
	public static double[] solve(double[][] m, double[] b) throws IllegalArgumentException, MathException {
        double[] ans;
		int[] row = new int[1];
		int[] col = new int[1];
		checkMatrix(m, row, col);
		if (row[0]!=col[0])
			throw new MathException("Matrix is not square.");
		if (col[0]!=b.length)
			throw new IllegalArgumentException("The number of rows in the input matrix 'm' is not equal to the number of elements in the input vector 'b'.");
		ans = LU.solve(m, b, null);
		return ans;
	}

    /**
     * Returns the covariance matrix of the specified vectors.
     * 
     * @param vectors the array of n-dimension arrays.
     * @param mean the n-dimension vector into which the mean vector will
     * be placed.
	 * @return the covariance matrix of the specified vectors.
    */
    public final double[][] covariance(double[][] vectors, double[] mean) {
		int[] row = new int[1];
		int[] col = new int[1];
		checkMatrix(vectors, row, col);
		if (mean.length<col[0])
			throw new IllegalArgumentException("The length of input vectors is not equal to the length of the mean vector.");
		
		int n = col[0];
		int vecnum = row[0];
		double[][] cov = new double[n][n];

		VecMath.copy(VecMath.mean(vectors), mean);
		for(int i=0; i<vecnum; i++){
			double[] tmpV = VecMath.subtract(vectors[i], mean);
			double[][] tmpM = VecMath.getMatrix(tmpV);
			cov = VecMath.add(cov, tmpM);
		}
		VecMath.scale(1.0/vecnum, cov);
		return cov;
    }

    public static void scale(double d, double[][] A) {
        for (int i = 0; i < A.length; i++)
			for (int j = 0; j < A[0].length; j++)			
				A[i][j] *= d;
    }

    public static void scale(double d, double[][] A, double[][] ans) {
		if (ans == null) {
			ans = new double[A.length][A[0].length];
		}
		for (int i = 0; i < A.length; i++)
			for (int j = 0; j < A[0].length; j++)			
				ans[i][j] *= d;
    }
	
	/**
	 * Returns a covariance matrix.
	 */
	static double[][] getMatrix(double[] v) {
		int n = v.length;
		double[][] mat = new double[n][n];
		
		for(int i=0; i<n; i++)
			for(int j=0; j<n; j++)
				mat[i][j] = v[i]*v[j];
		
		return mat;
	}

	static double[][] getMatrix(int row, int col) {
		return new double[row][col];
	}	

	/* ------------------------ float version ------------------------- */
	/* no Float matrix methods are available at this stage */
	/* ------------------------- vector math -------------------------- */
	/**
	 * Subtracts a vector 'v2' from a vector 'v1'.
	 * ans = v1 - v2.
	 */
    public static float[] subtract(float[] v1, float[] v2) {
        if(v1.length != v2.length)
            throw new IllegalArgumentException("Vectors must have the same length.");
        float[] ans = new float[v1.length];
        for(int i=0; i < v1.length; i++)
            ans[i] = v1[i] - v2[i];
        return ans;
    }
	
	/**
	 * Computes a product of a vector 'v'.
	 * ans *= v[i].
	 */
    public static float product(float[] v) {
        float ans = 1.0f;
		for (float value : v) ans *= value;
        return ans;
    }
	
	/**
	 * Adds a scalar 'd' to a vector 'v'.
	 * ans = v + d.
	 */
    public static float[] add(float d, float[] v) {
        float[] ans = new float[v.length];
        for(int i = 0; i < v.length; i++)
            ans[i] = d + v[i];
        return ans;
    }
	
	/**
	 * Adds two vectors 'v1' and 'v2'.
	 * ans = v1 + v2.
	 */
    public static float[] add(float[] v1, float[] v2) {
        if(v1.length != v2.length)
            throw new IllegalArgumentException("Vectors must have the same length.");
        float[] ans = new float[v1.length];
        for (int i = 0; i < v1.length; i++)
            ans[i] = v1[i] + v2[i];
        return ans;
    }
	
	/**
	 * Multiplies two vectors 'v1' and 'v2'.
	 * ans = v1 * v2.
	 */
    public static float[] multiply(float[] v1, float[] v2) {
        if(v1.length != v2.length)
            throw new IllegalArgumentException("Vectors must have the same length.");
        float[] ans = new float[v1.length];
        for (int i = 0; i < v1.length; i++)
            ans[i] = v1[i] * v2[i];
        return ans;
    }
	
	/**
	 * Computs a sum of a vector 'v'.
	 * ans += v[i].
	 */
    public static float sum(float[] v) {
        float sum = 0.0f;
		for (float value : v) sum += value;
        return sum;
    }
	
	/**
	 * Makes a copy of a vector 'v'.
	 */
    public static float[] copy(float[] v) {
        float[] ans = new float[v.length];
        System.arraycopy(v, 0, ans, 0, v.length);
        return ans;
    }

	/**
	 * Copies a vector 'v1' into a vector 'v2'.
	 */
    public static void copy(float[] v1, float[] v2) {
        System.arraycopy(v1, 0, v2, 0, v1.length);
    }

	/**
	 * Copies a sub-section (from i to end) of a vector 'v1'
	 * into a vector 'v2'.
	 */
    public static float[] copySub(int start, float[] v) {
		float[] ans = new float[v.length-start];
        System.arraycopy(v, start, ans, 0, v.length-start);
		return ans;
    }

	/**
	 * Copies a sub-section (from i to end) of a vector 'v1'
	 * into a vector 'v2'.
	 */
    public static void copySub(int start, float[] v1, float[] v2) {
        System.arraycopy(v1, start, v2, 0, v1.length-start);
    }
	
	/**
	 * Copies a vector 'v1' into a vector 'v2' at 'start'.
	 */
    public static void copySub(float[] v1, int start, float[] v2) {
        System.arraycopy(v1, 0, v2, start, v1.length);
    }
	
	/*
	 * Returns the sum of the squares of this vector (its length 
	 * sqaured in n-dimensional space).
	 */
	public static float normSquared(float[] v) {
		float s = 0.0f;
		for (float value : v) s += value * value;
		return s;
	}

	/*
	 * Returns the square root of the sum of the squares of this 
	 * vector (its length in n-dimensional space). 
	 */
	public static float norm(float[] v) {
		return (float)(Math.sqrt(normSquared(v)));
	}

	/*
	 * Normalizes this vector in place. 
	 */
	public static float[] normalize(float[] v) {
		float len = norm(v);
		
		if(len==0)	/* to avoid zero-div. */
			return v;
		for(int i=0; i<v.length; i++)
			v[i] /= len;

		return v;
	}
	
	/**
	 * Scales a vector 'v' by a scalar 'd'.
	 * ans = d * v.
	 */
    public static void scale(float d, float[] v, float[] ans) {
        if(v.length != ans.length)
            throw new IllegalArgumentException("Vectors must have the same length.");
        for(int i = 0; i < v.length; i++)
            ans[i] = d * v[i];
    }
	
	/*
	 * Scales a vector 'v' by a scalar vaue 'd'.
	 * v *= d.
	 */
    public static void scale(float d, float[] v) {
        for (int i = 0; i < v.length; i++)
            v[i] *= d;
    }

	/*
	 * Negate a vector 'v'.
	 * v = -v.
	 */
    public static void negate(float[] v) {
        for(int i = 0; i < v.length; i++)
            v[i] *= -1;
    }

	/*
	 * Negate a vector 'v'.
	 * v = -v.
	 */
    public static void negate(float[] v1, float[] v2) {
        if(v1.length != v2.length)
            throw new IllegalArgumentException("Vectors must have the same length.");
        for(int i = 0; i < v1.length; i++)
            v2[i] = -1*v1[i];
    }

	/*
	 * Computes an innerproduct of two vectors 'v1' and 'v2'.
	 * ip = v1.v2 .
	 */
    public static float innerproduct(float[] v1, float[] v2) {
        if(v1.length != v2.length)
            throw new IllegalArgumentException("Vectors must have the same length.");
		final int n = v1.length;
		final int n8 = n & ~7;
		float ans = 0.0f;
		for(int i = 0; i < n8; i += 8) {
			ans += v1[i]*v2[i] + v1[i+1]*v2[i+1] + v1[i+2]*v2[i+2] + v1[i+3]*v2[i+3] +
				   v1[i+4]*v2[i+4] + v1[i+5]*v2[i+5] + v1[i+6]*v2[i+6] + v1[i+7]*v2[i+7];
		}
		for(int i = n8; i < n; i++)
			ans += v1[i]*v2[i];
		return ans;
    }

	/*
	 * Computes a crossproduct of two 3-D vectors 'v1' and 'v2'.
	 * ans = v1xv2.
	 */
    public static float[] cross(float[] v1, float[] v2){
        if(v1.length != 3 || v2.length!=3)
            throw new IllegalArgumentException("Vectors must be 3-D.");
		int len = v1.length;
		float[] ans = new float[len];
		ans[0] = v1[1]*v2[2]-v1[2]*v2[1];
		ans[1] = v1[2]*v2[0]-v1[0]*v2[2];
		ans[2] = v1[0]*v2[1]-v1[1]*v2[0];
		return ans;
    }

	/*
	 * Computes an angle between two vectors 'v1' and 'v2'.
	 * ans = v1xv2.
	 */
	public static double angle(float[] v1, float[]v2) {
		return Math.acos(innerproduct(v1, v2)/(norm(v1)*norm(v2)));
	}

	/*
	 * Computes an angle between two vectors 'v1' and 'v2'.
	 * ans = v1xv2.
	 */
	public static float distance(float[] v1, float[] v2) {
		final float dist = distanceSquared(v1, v2);
		return (dist > 0.0f) ? (float)(Math.sqrt(dist)) : 0.0f;
	}

	/*
	 * Computes an angle between two vectors 'v1' and 'v2'.
	 * ans = v1xv2.
	 */
	public static float distanceSquared(float[] v1, float[] v2) {
        if(v1.length != v2.length)
            throw new IllegalArgumentException("Vectors must have the same length.");
		float sum = 0.0f;
		float d = 0;
		for(int i=0; i<v1.length; i++){
			d = v1[i]-v2[i];
			if(d!=0)
				sum += d*d;
		}
		
		return (sum != 0) ? sum : 0.0f;
	}
	
    /**
     * Sets the value of this vector to the mean vector of the spcified
     * vector array.
     * 
     * @param vectors the array of vector.
    */
    public static float[] mean(float[][] vectors) {
		int veclen = vectors[0].length;
		int vecnum = vectors.length;		
		float[] mean = new float[veclen];
	
		for (float[] vector : vectors)
			for (int j = 0; j < veclen; j++)
				mean[j] += vector[j];
		VecMath.scale(1.0f/vecnum, mean);
		return mean;
    }

    /**
     * Sets the value of this vector to the mean vector of the spcified
     * vector array.
     * 
     * @param vectors the array of vector.
    */
    public static float[] mean(float[][] vectors, float[] mean) {
		int[] row = new int[1];
		int[] col = new int[1];
		checkMatrix(vectors, row, col);
		if(col[0]!=mean.length)
			throw new IllegalArgumentException("The lengths of each vector is not the same as that of mean");
		int veclen = col[0];
		int vecnum = row[0];
		
		for(int i=0; i<vecnum; i++)
			for(int j=0; j<veclen; j++)
				mean[j] += vectors[i][j];
		VecMath.scale(1.0f/vecnum, mean);
		return mean;
    }

		
	/**
	* checks whether two vector is the same or no.
	* 
	* @param v1 a vectr.
	* @param v2 a vectr.	
	* @return true if both vector are the same, otherwise false.
	* @exception IllegalArgumentException if two vectors are not
	* the same length.
	*/
	public static boolean equal(float[] v1, float[] v2) throws IllegalArgumentException	{
        if(v1.length != v2.length)
            throw new IllegalArgumentException("Vectors must have the same length.");
		int len = v1.length;
		boolean ret = true;
		for(int i=0; i<len; i++)
			if(v1[i]!=v2[i]){
				ret = false;
				break;
			}
		return ret;
	}

	/* ------------------------- matrix math -------------------------- */
	/* no Float matrix methods are available at this stage */
	/**
	 * Checks matrix size.
	 */
	static void checkMatrix(float[][] m, int[] row, int[] col) throws IllegalArgumentException {
        row[0] = m.length;
        col[0] = m[0].length;
        for(int i=1; i<row[0]; i++)
            if(m[i].length != col[0])
                throw new IllegalArgumentException("The lengths of the rows of the input matrix are not consistent.");
    }

    /*
     * Sets the value of the sub-vector to the its Householder transformed
	 * vector.
     * 
     * @param x the double array.
	 */
    public static double householder(double[] x) throws IllegalArgumentException {
		int n = x.length;
		double s, t;
		
		s = Math.sqrt(VecMath.dot(x, x));
		if(s!=0){
			if(x[0]<0.0) s = -s;
			x[0] += s; t = 1.0/Math.sqrt(x[0]*s);
			for(int i=0; i<n; i++) x[i] *= t;
		}
		return -s;
    }

	/**
     * Computes the tridiagonalized matrix of the specified matrix.
     * This matrix will be replaced by the tridiagonalized matrix.
     * The MGVector d will be set to the diagonal elements of the
     * transformed matrix.  The MGVector e will be set to the next of
     * diagonal elements.
     * 
     * @param a the matrix to be tridiagonalized.
     * @param d the vector to store diagonal elements.
     * @param e the vector to store next of diagonal elements.
    */
    public static void tridiagonalize(double[][] a, double[] d, double[] e) throws IllegalArgumentException, MathException {
		int[] row = new int[1];
		int[] col = new int[1];
		checkMatrix(a, row, col);
		
		if (row[0] != col[0])
            throw new MathException("Matrix is not square.");
		int n = row[0];
		int i, j, k;
		double s, t, p, q;
		double[] v;
		double[] w;
		double[] h_v;
		double[] h_d;
		double[] h_w;				
		
		for(k=0; k<n-2; k++){
			v = a[k];	d[k] = v[k];
			h_v = copySub(k+1, v); // get sub copy
			e[k] = householder(h_v);
			copySub(h_v, k+1, v);	// put h_v back to v
			if(e[k]==0)	continue;
			for(i=k+1; i<n; i++){
				s = 0.0;
				for(j=k+1; j<i; j++)	s += a[j][i]*v[j];
				for(j=i  ; j<n; j++)	s += a[i][j]*v[j];
				d[i] = s;
			}
			h_v = copySub(k+1, v);
			h_d = copySub(k+1, d);			
			t = dot(h_v, h_d)/2;
			for(i=n-1; i>k; i--){
				p = v[i];	q = d[i]-t*p;	d[i] = q;
				for(j=i; j<n; j++)
					a[i][j] -= p*d[j] + q*v[j];
			}
		}
		if(n>=2){	d[n-2] = a[n-2][n-2];
					e[n-2] = a[n-2][n-1];}
		if(n>=1)	d[n-1] = a[n-1][n-1];
		for(k=n-1; k>=0; k--){
			v = a[k];
			if(k<n-2){
				for(i=k+1; i<n; i++){
					w = a[i];
					h_v = copySub(k+1, v);
					h_w = copySub(k+1, w);			
					t = dot(h_v, h_w);
					for(j=k+1; j<n; j++)
						w[j] -= t*v[j];
				}
			}
			for(i=0; i<n; i++)
				v[i] = 0;
			v[k] = 1;
		}
    }
	
	/*************
	 *
	 ************/
	public static double[] intersectPoint(double[] rayVector, double[] rayPoint, double[] planeNormal, double[] planePoint) {
		double[] diff = subtract(rayPoint, planePoint);
		double prod1 = dot(diff, planeNormal);
		double prod2 = dot(rayVector, planeNormal);
		double prod3 = prod1 / prod2;
		scale(prod3, rayVector);
		return subtract(rayPoint, rayVector);
	}
 
}
