/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
                 Implementation of class BetaFunction                 
====================================================================*/
/**
 * BetaFunction provides methods to compute Beta function.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class BetaFunction {
	private BetaFunction() {
		super();
	}
	
	public static double beta(double x, double y) {
		return Math.exp(GammaFunction.logGamma(x) +
						GammaFunction.logGamma(y) -
						GammaFunction.logGamma(x + y));
	}
}

