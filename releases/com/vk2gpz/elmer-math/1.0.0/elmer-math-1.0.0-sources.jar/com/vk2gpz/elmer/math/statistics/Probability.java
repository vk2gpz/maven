/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.statistics;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.math.numerical.GammaFunction;

/*====================================================================
                 Implementation of class Probability                  
====================================================================*/
/**
 * Probability provides methods to compute probabilities of various
 * distributions.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class Probability {
	private Probability() {
		super();
	}
	
	/**
	 * Computes the lower probability integral of the Gamma distribution with
	 * a parameter <code>a</code>.
	 * <p>
	 * <pre>
	 *   1   x  -x  a-1 
	 * ---- S  e   t   dt,   S: Integral
	 * G(a)  0       
	 * </pre>
	 * <p>
	 * Ref: Henrici, P. Applied and Computational Complex Analysis. Vol 2:
	 * Special Functions - Integral Transforms - Asymptotics -
	 * Comtinued Fractions.  John Wiley &amp; Sons, 1977 pp.628--630
	 * <p>
	 * Ref: Graham, R. L., Knuth, D. E. and Patashnik, O.
	 * Concrete Mathematics.  Addison-Wesley, 1989 pp.47--48
	 *
	 * @param a the parameter a
	 * @param x
	 * @return the lower probability integral of the Gamma distribution with
	 * a parameter <code>a</code>.
	 */
	public static double getPOfGamma(double a, double x) {
		double loggamma_a = GammaFunction.logGamma(a);
		return getPOfGamma(a, x, loggamma_a);
	}
	
	private static double getPOfGamma(double a, double x, double loggamma_a) {
		double result, term, previous;

		if (x >= 1 + a) {
			return 1 - getQOfGamma(a, x, loggamma_a);
		}
		if (x == 0) {
			return 0;
		}
		result = term = Math.exp(a * Math.log(x) - x - loggamma_a) / a;
		// I cannot sumup until infinity!
		// So I'm useing 1000.
		for (int k = 1; k < 1000; k++) { 
			term *= x / (a + k);
			previous = result;
			result += term;
			if (result == previous) {
				return result;
			}
		}
		return result;			// no conversion;
	}

	/**
	 * Computes the upper probability integral of the Gamma distribution with
	 * a parameter <code>a</code>.
	 * <p>
	 * <pre>
	 *   1   OO  -x  a-1 
	 * ---- S   e   t   dt,   S: Integral
	 * G(a)  x       
	 * </pre>
	 *
	 * @param a the parameter a
	 * @param x 
	 * @return the upper probability integral of the Gamma distribution with
	 * a parameter <code>a</code>.
	 */
	public static double getQOfGamma(double a, double x) {
		double loggamma_a = GammaFunction.logGamma(a);
		return getQOfGamma(a, x, loggamma_a);
	}

	private static double getQOfGamma(double a, double x, double loggamma_a) {
		double result, w, temp, previous;
		double la = 1;			// these la and lb are 
		double lb = 1 + x - a;	// for Laguerre's polynomial

		if (x < 1 + a) {
			return 1 - getPOfGamma(a, x, loggamma_a);
		}
		w = Math.exp(a * Math.log(x) - x - loggamma_a);
		result = w / lb;
		for (int k = 2; k < 1000; k++) {
			temp = ((k - 1 - a) * (lb - la) + (k + x) * lb) / k;
			la = lb;
			lb = temp;
			w *= (k - 1 - a) / k;
			temp = w / (la * lb);
			previous = result;
			result += temp;
			if (result == previous) {
				return result;
			}
		}
		return result;		// no conversion;		
	}

	/**
	 * Computes the lower probability integral of the ChiSquare distribution
	 * with a degree of freedom <code>df</code>.  It uses "getPOfGamma" to
	 * increase accuracy.
	 * <p>
	 *
	 * @param df the degree of freedom
	 * @param chisq 
	 * @return the lower probability integral of the ChiSquare distribution
	 * with a degree of freedom <code>df</code>.
	 */
	public static double getPOfChiSquare(int df, double chisq) {
		return getPOfGamma(0.5 * df, 0.5 * chisq);
	}

	/**
	 * Computes the upper probability integral of the ChiSquare distribution
	 * with a degree of freedom <code>df</code>.
	 * <p>
	 *
	 * @param df the degree of freedom
	 * @param chisq 
	 * @return the upper probability integral of the ChiSquare distribution
	 * with a degree of freedom <code>df</code>.
	*/
	public static double getQOfChiSquare(int df, double chisq) {
		return getQOfGamma(0.5 * df, 0.5 * chisq);
	}

	private static final double LOG_PI = Math.log(Math.PI);
	/**
	 * Computes the Gaussian error function.
	 * It uses "get{P|Q}OfGamma" to increase accuracy.
	 * accuracy.
	 * <p>
	 * <pre>
	 *                 2
	 *            x  -t
	 * Sqrt(2PI) S  e   dt,   S: Integral
	 *            0
	 * </pre>
	 *
	 * @param x
	 * @return the Gaussian error function.
	 */
	public static double gaussianErrorFunction(double x) {
		if (x >= 0) {
			return  getPOfGamma(0.5, x * x, LOG_PI / 2.0);
		} else {
			return -getPOfGamma(0.5, x * x, LOG_PI / 2.0);
		}
	}

	/**
	 * Computes the complement of the Gaussian error function.
	 * <p>
	 * <pre>
	 *                     2
	 *                x  -t
	 * 1 - Sqrt(2PI) S  e   dt,   S: Integral
	 *                0
	 * </pre>
	 *
	 * @param x
	 * @return the complement of the Gaussian error function.
	 */
	public static double gaussianErrorFunctionC(double x) {
		if (x >= 0) {
			return getQOfGamma(0.5, x * x, LOG_PI / 2.0);
		} else {
			return 1 + getPOfGamma(0.5, x * x, LOG_PI / 2.0);
		}
	}

	/**
	 * Computes the lower probability integral of the Normal distribution.
	 * It internally uses "get{P|Q}OfGamma".
	 * <p>
	 *
	 * @param x
	 * @return the lower probability integral of the Normal distribution.
	*/
	public static double getPOfNormal(double x) {
		if (x >= 0) {
			return 0.5 * (1 + getPOfGamma(0.5, 0.5 * x * x, LOG_PI / 2.0));
		} else {
			return 0.5 * getQOfGamma(0.5, 0.5 * x * x, LOG_PI / 2.0);
		}
	}

	/**
	 * Computes the upper probability integral of the Normal distribution.
	 * It internally uses "get{P|Q}OfGamma".
	 * <p>
	 *
	 * @param x
	 * @return the upper probability integral of the Normal distribution.
	*/
	public static double getQOfNormal(double x) {
		if (x >= 0) {
			return 0.5 * getQOfGamma(0.5, 0.5 * x * x, LOG_PI / 2.0);
		} else {
			return 0.5 * (1 + getPOfGamma(0.5, 0.5 * x * x, LOG_PI / 2.0));
		}
	}

	/**
	 * Computes the lower probability integral of the Beta distribution with
	 * parameters <code>a</code> and <code>b</code>.
	 * It computes <code>Ix(a,b)</code> as continued fraction.
	 * <p>
	 * <pre>
	 *             x  a-1 1    b-1
	 * B (a, b) = S  t    (1-t)    dt,   S: Integral
	 *  x          0
	 *
	 *            B (a, b)
	 *             x 	 
	 * I (a, b) = -------- = 1 - I   (b, a)
	 *  x         B (a, b)        1-x
	 * </pre>
	 *
	 * @param a the parameter a
	 * @param b the parameter b
	 * @param x
	 * @return the lower probability integral of the Beta distribution with
	 * parameters <code>a</code> and <code>b</code>.
	*/
	public static double getPOfBeta(double a, double b, double x) {
		double p1, q1, p2, q2, d, previous;

		if (a <= 0) {
			return Double.NaN;
		}
		if (b <= 0) {
			if (x <  1) {
				return 0;
			}
			if (x == 1) {
				return 1;
			}
			return Double.NaN;
		}
		if (x > (a + 1) / (a + b + 2)) {
			return 1 - getPOfBeta(b, a, 1 - x);
		}
		if (x <= 0) {
			return 0;
		}
		p1 = 0;
		q1 = 1;
		p2 = Math.exp(a * Math.log(x) + b * Math.log(1 - x)
					  + GammaFunction.logGamma(a + b)
					  - GammaFunction.logGamma(a)
					  - GammaFunction.logGamma(b)) / a;
		q2 = 1;
		for (int k = 0; k < 200; ) {
			previous = p2;
			d = - (a + k) * (a + b + k) * x
				/ ((a + 2 * k) * (a + 2 * k + 1));
			p1 = p1 * d + p2;
			q1 = q1 * d + q2;
			k++;
			d = k * (b - k) * x / ((a + 2 * k - 1) * (a + 2 * k));
			p2 = p2 * d + p1;
			q2 = q2 * d + q1;
			if (q2 == 0) {
				p2 = Double.MAX_VALUE;
				continue;
			}
			p1 /= q2;
			q1 /= q2;
			p2 /= q2;
			q2 = 1;
			if (p2 == previous) {
				return p2;
			}
		}
		return p2;				// no conversion
	}

	/**
	 * Computes the upper probability integral of the Beta distribution with
	 * parameters <code>a</code> and <code>b</code>.
	 * <p>
	 *
	 * @param a the parameter a
	 * @param b the parameter b	 
	 * @param x
	 * @return the upper probability integral of the Beta distribution with
	 * parameters <code>a</code> and <code>b</code>.
	*/
	public static double getQOfBeta(double a, double b, double x) {
		return 1 - getPOfBeta(a, b, x);
	}

	/**
	 * Computes the lower probability integral of the t-distribution with
	 * the degree of freedom <code>df</code>.  It internally uses the
	 * incomplete Beta function <code>Ix(a, b)</code>.
	 * <p>
	 * <pre>
	 *     1    1     1         df 
	 * 1 - - I (- df, -), x = -------
	 *     2  x 2     2             2
	 *                        df + t
	 * </pre>
	 *
	 * @param df the degree of freedom
	 * @param t
	 * @return the lower probability integral of the t-distribution with
	 * the degree of freedom <code>df</code>.
	 */
	public static double getPOfT(int df, double t) {
		return 1 - 0.5 * getPOfBeta(0.5 * df, 0.5, df / (df + t * t));
	}

	/**
	 * Computes the upper probability integral of the t-distribution with
	 * the degree of freedom <code>df</code>.  It internally uses the
	 * incomplete Beta function <code>Ix(a, b)</code>.
	 * <p>
	 * <pre>
	 * 1    1     1         df 
	 * - I (- df, -), x = -------
	 * 2  x 2     2             2
	 *                    df + t
	 * </pre>
	 *
	 * @param df the degree of freedom
	 * @param t
	 * @return the upper probability integral of the t-distribution with
	 * the degree of freedom <code>df</code>.
	*/
	public static double getQOfT(int df, double t) {
		return 0.5 * getPOfBeta(0.5 * df, 0.5, df / (df + t * t));		
	}

	/**
	 * Computes the upper probability integral of the f-distribution with
	 * the degrees of freedom <code>df1</code> and <code>df2</code>.
	 * It internally uses the incomplete Beta function <code>Ix(a, b)</code>.
	 * <p>
	 * <pre>
	 *    1      1               df2 
	 * I (- df2, - df1), x = -----------
	 *  x 2      2           df2 + df1 f
	 * </pre>
	 *
	 * @param df1 a degree of freedom
	 * @param df2 a degree of freedom	
	 * @param f
	 * @return the upper probability integral of the f-distribution with
	 * the degrees of freedom <code>df1</code> and <code>df2</code>.
	 */
	public static double getQOfF(int df1, int df2, double f) {
		if (f <= 0) {
			return 1;
		}
		return getPOfBeta(0.5 * df2, 0.5 * df1, df2 / (df2 + df1 * f));
	}

	/**
	 * Computes the lower probability integral of the f-distribution with
	 * the degrees of freedom <code>df1</code> and <code>df2</code>.
	 * It internally uses the incomplete Beta function <code>Ix(a, b)</code>.
	 * <p>
	 * <pre>
	 *    1      1               df2 
	 * I (- df1, - df2), x = -------------
	 *  x 2      2           df2 + df1 / f
	 * </pre>
	 *
	 * @param df1 a degree of freedom
	 * @param df2 a degree of freedom	
	 * @param f
	 * @return the upper probability integral of the f-distribution with
	 * the degrees of freedom <code>df1</code> and <code>df2</code>.
	 */
	public static double getPOfF(int df1, int df2, double f) {
		if (f <= 0) {
			return 0;
		}
		return getPOfBeta(0.5 * df1, 0.5 * df2, df1 / (df1 + df2 / f));
	}

	/**
	 * Computes the lower probability integral of the binomial distribution
	 * <code>B(n, p)</code>.
	 * It internally uses the incomplete Beta function <code>Ix(a, b)</code>.
	 * <p>
	 * <pre>
	 * I (k, n-k+1)
	 *  p 
	 * </pre>
	 *
	 * @param n
	 * @param p
	 * @param k
	 * @return the lower probability integral of the binomial distribution
	 * <code>B(n, p)</code>.
	 */
	public static double getPOfBinomial(int n, double p, int k) {
		if (k <  0) {
			return 0;
		}
		if (k >= n) {
			return 1;
		}
		return getPOfBeta(k + 1, n - k, 1 - p);
	}

	/**
	 * Computes the upper probability integral of the binomial distribution
	 * <code>B(n, p)</code>.
	 * It internally uses the incomplete Beta function <code>Ix(a, b)</code>.
	 * <p>
	 *
	 * @param n
	 * @param p
	 * @param k
	 * @return the lower probability integral of the binomial distribution
	 * <code>B(n, p)</code>.
	 */
	public static double getQOfBinomial(int n, double p, int k) {
		if (k <= 0) {
			return 1;
		}
		if (k >  n) {
			return 0;
		}
		return getPOfBeta(k, n - k + 1, p);
	}
}

