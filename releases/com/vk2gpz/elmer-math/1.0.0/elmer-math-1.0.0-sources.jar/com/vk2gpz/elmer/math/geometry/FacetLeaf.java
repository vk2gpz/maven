/*
 * Copyright (c) 1993-2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.geometry;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
                  Implementation of class FacetLeaf                   
====================================================================*/
/**
 * generally describe FacetLeaf in here
 * 
 * @version $Revision: 1.4 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Facet
 */

public class FacetLeaf extends Facet {
}
