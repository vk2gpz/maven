/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.geometry;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.math.VecMath;

/*====================================================================
                Implementation of class SurroundingBox                
====================================================================*/
/**
 * generally describe SurroundingBox in here
 * 
 * @version $Revision: 1.5 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

class SurroundingBox {
    double[] minPoint;
    double[] maxPoint;

	SurroundingBox() {
		this.minPoint = new double[3];
		this.maxPoint = new double[3];		
	}

	SurroundingBox(double[] vecA, double[] vecB, double tolerance) {
		this(new double[][] {vecA, vecB}, tolerance);
	}

	SurroundingBox(double[][] vlist, double tolerance) {
		this.minPoint = VecMath.getMinVector(vlist);
		this.maxPoint = VecMath.getMaxVector(vlist);

		if (tolerance != 0) {
			growWithRate(tolerance, false);
		}
	}

	SurroundingBox getBox() {
		return this;
	}

	SurroundingBox getBoxWithTolerance(double tolerance) {
		if (tolerance != 0) {
			growWithRate(tolerance, false);
		}
		return this;
	}

	double[] getMinPoint() {
		return this.minPoint;
	}

	double[] getMaxPoint() {
		return this.maxPoint;
	}

	double[] getCenter() {
		return VecMath.getMidPointOf(this.minPoint, this.maxPoint, 0.5, null);
	}

	double[] getDiagonal() {
		return VecMath.subtract(this.maxPoint, this.minPoint);
	}

	/**
	   |- (BOOL)inner:aPoint| 
	 */
	boolean contains(double[] point) {
		return (VecMath.isLessThan(point, this.maxPoint) &&
				VecMath.isGreaterThan(point, this.minPoint));
	}

	/**
	   |- intersectionWithBox:aBox tolerance:(double)tol| 
	   returns common minimal box for aBox and self.
	   returns nil, if no intersection.
	   vk2gpz/1994-Feb-07
	*/
	SurroundingBox getIntersectionWith(SurroundingBox box, double tolerance) {
		double[][] vlist1 = new double[][] {this.minPoint, box.getMinPoint()};
		double[][] vlist2 = new double[][] {this.maxPoint, box.getMaxPoint()};
		
		double[] v1 = VecMath.getMaxVector(vlist1);
		double[] v2 = VecMath.getMinVector(vlist2);
		if (tolerance != 0 ){
			double[] vtol = new double[]{tolerance, tolerance, tolerance};
			v1 = VecMath.subtract(v1, vtol);
			v2 = VecMath.add(v2, vtol);
		}
		SurroundingBox result = null;
		if (VecMath.isLessThan(v1, v2)) {
			result = new SurroundingBox(v1, v2, 0.0);
		}
		return result;
	}

	/**
	   |- unitonWithBox:aBox tolerance:(double)tol| 
	   
	   vk2gpz/1994-Feb-07
	*/
	SurroundingBox getUnionWith(SurroundingBox box, double tolerance) {
		double[][] vlist1 = new double[][] {this.minPoint, box.getMinPoint()};
		double[][] vlist2 = new double[][] {this.maxPoint, box.getMaxPoint()};
		
		double[] v1 = VecMath.getMinVector(vlist1);
		double[] v2 = VecMath.getMaxVector(vlist2);

		return new SurroundingBox(v1, v2, tolerance);
	}

	/**
	   |- (BOOL)intersectionalWithBox:aBox| 
	   
	   vk2gpz/1994-Feb-07
	*/
	boolean intersectWith(SurroundingBox box) {
		double[][] vlist1 = new double[][] {this.minPoint, box.getMinPoint()};
		double[][] vlist2 = new double[][] {this.maxPoint, box.getMaxPoint()};
		double[] v1 = VecMath.getMaxVector(vlist1);
		double[] v2 = VecMath.getMinVector(vlist2);
		
		return VecMath.isLessThan(v1, v2);
	}
	
	/**
	   |- (BOOL)boxintp:aBox| 
	   
	   vk2gpz/1994-Feb-24
	*/
	boolean boxintp(SurroundingBox box) {
		double[] minp1 = this.minPoint;
		double[] maxp1 = this.maxPoint;
		double[] minp2 = box.getMinPoint();
		double[] maxp2 = box.getMaxPoint();
		
		if (minp1[0] > maxp2[0])
			return false;
		else if(minp1[1] > maxp2[1])
			return false;
		else if(minp1[2] > maxp2[2])
			return false;
		else if(minp2[0] > maxp1[0])
			return false;
		else if(minp2[1] > maxp1[1])
			return false;
		else return !(minp2[2] > maxp1[2]);
	}

	/**
	   |- growWith:(double)rate :(BOOL)abs| 
	   
	   vk2gpz/1993-Dec-08
	*/
	SurroundingBox growWithRate(double rate, boolean abs) {
		double[] scaleVec = null;
		if (abs) {
			scaleVec = new double[]{rate, rate, rate};
		} else {
			scaleVec = VecMath.scale(rate, VecMath.subtract(this.maxPoint, this.minPoint), null);
		}
		
		this.minPoint = VecMath.subtract(this.minPoint, scaleVec);
		this.maxPoint = VecMath.add(this.maxPoint, scaleVec);
    
		return this;
	}

	/**
	   |- (double)volume| 
	   
	   vk2gpz/1993-Dec-08
	*/
	double getVolume() {
		double[] volVec = VecMath.subtract(this.maxPoint, this.minPoint);

		return volVec[0] * volVec[1] * volVec[2];
	}

	/**
	   |- extreamPointWith:aDir| 
	   
	   vk2gpz/1994-Feb-07
	*/
	double[] getExtreamPointWith(double[] aDir) {
		int dim = this.minPoint.length;
		double[] p = new double[dim];
		
		for (int i = 0; i < dim; i++) {
			p[i] = (aDir[i] > 0.0) ? this.maxPoint[i] : this.minPoint[i];
		}
		
		return p;
	}

	/**
	   |- (BOOL)below:aBox in:aDir| 
	   is this box below aBox?
	   vk2gpz/1994-Feb-07
	*/
	boolean isBelow(SurroundingBox box) {
		double[] aDir = new double[] {0.0, 0.0, 1.0};
		double[] ex1 = getExtreamPointWith(aDir);
		double[] ex2 = box.getExtreamPointWith(VecMath.scale(-1.0, aDir, null));
		
		return VecMath.isLessThan(ex1, ex2);
	}

	/**
	   |- corners| 
	   
	   vk2gpz/1994-Feb-07
	*/
	double[][] getCorners() {
		int dim = this.minPoint.length;
		int num = (int) Math.pow(2, dim);
		double[][] r = new double[num][dim];
		
		for (int i = 0; i < num; i++) {
			double[] v = new double[dim];
			for (int j = 0; j < dim; j++) {
				if (((i>>j) & 1) != 0)
					v[j] = this.maxPoint[j];
				else
					v[j] = this.minPoint[j];
			}
			r[num - 1 - i] = v;
		}
		
		return r;
	}

	/**
	   |- body| 
	   (let ((v0 (copy-seq minPoint)) (v1 (copy-seq minPoint))
	   (v2 (copy-seq minPoint)) (v3 (copy-seq minPoint)) )
       (setf (aref v1 1) (aref maxPoint 1)
	   (aref v2 1) (aref maxPoint 1)
	   (aref v2 0) (aref maxPoint 0)
	   (aref v3 0) (aref maxPoint 0))
       (make-prism (list v0 v1 v2 v3) (- (aref maxPoint 2) (aref minPoint 2))))
	   
	   vk2gpz/1994-Feb-07
	*/
	SurroundingBox getBody() {
		return this;
	}

	/**
	   |- (double)vectorsAccordingTo:vlist| 
	   
	   vk2gpz/1993-Dec-08
	*/
	SurroundingBox set(double[][] vlist) {
		this.minPoint = VecMath.getMinVector(vlist);
		this.maxPoint = VecMath.getMaxVector(vlist);
		
		return this;
	}

	/**
	   |- vectors2:aVector1 :aVector2| 
	   
	   vk2gpz/1993-Dec-08
	*/
	SurroundingBox set(double[] v1, double[] v2) {
		double[][] vlist = new double[][]{v1, v2};
		return set(vlist);
	}
}
