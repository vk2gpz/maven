/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
               Implementation of class EulerianNumbers                
====================================================================*/
/**
 * EulerianNumbers implements a method to compute Eulerian numbers.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class EulerianNumbers {
	private EulerianNumbers() {
		super();
	}
	
	/**
	 * Returns Eulerian numbers of given parameters <code>n</code> and <code>k</code>.
	 */
	public static int getEulerian(int n, int k) {
		if (k == 0) {
			return 1;
		}
		if (k < 0 || k >= n) {
			return 0;
		}
		return (k + 1) * getEulerian(n - 1, k)
			+ (n -k) * getEulerian(n - 1, k - 1);
	}
}

