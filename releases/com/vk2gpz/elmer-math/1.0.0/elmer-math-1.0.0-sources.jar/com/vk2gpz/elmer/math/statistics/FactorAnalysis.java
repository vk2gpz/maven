/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.statistics;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.math.ConvergenceException;
import com.vk2gpz.elmer.math.MathException;
import com.vk2gpz.elmer.math.numerical.QR;
import com.vk2gpz.elmer.math.VecMath;

/*====================================================================
                Implementation of class FactorAnalysis                
====================================================================*/
/**
 * FactorAnalysis carries out factor analysis on a given data.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class FactorAnalysis {
	private FactorAnalysis() {
		super();
	}
	
	/**
	* Conducts Factor analysis on a given matrix <code>x</code>.
	*
	* @param maxiter The maximum iteration number.
	* @param nfac The number of factor.
	* @param r The correlation coefficient matrix.
	* @param q The matrix to store factor loading.
	* @param comm The vector to store communality values.
	*/
	public static void analyze(int maxiter, int nfac, double[][] r, double[][] q, double[] comm) throws MathException {
		int m = r.length;
		double[] lambda = new double[m];
		double[][] rr = new double[m][m];		
		VecMath.copy(r, rr);
		double s;

		for (int iter = 0; iter < maxiter; iter++) {
			VecMath.copy(rr, q);
			if (QR.eigen(q, lambda, q)) {
				throw new ConvergenceException("PrincipalComponentAnalysis.analyze() did not converge.");
			}
			//			s = VecMath.innerproduct(, , );
			for (int j = 0; j < m; j++) {
				s = 0;
				for (int k = 0; k < nfac; k++) {
					s += lambda[k] * q[k][j] * q[k][j];
				}
				rr[j][j] = s;
			}
		}
		for (int j = 0; j < m; j++) {
			comm[j] = rr[j][j];
		}
	}
}

