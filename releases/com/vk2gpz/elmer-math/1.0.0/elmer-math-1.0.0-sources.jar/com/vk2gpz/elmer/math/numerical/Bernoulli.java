/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
// import com.vk2gpz.elmer.math.*;

/*====================================================================
                  Implementation of class Bernoulli                   
====================================================================*/
/**
 * Bernoulli provides methods to compute Bernoulli numbers.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class Bernoulli {
	private Bernoulli() {
		super();
	}
	
	/**
	* Computes Bernoulli numbers.  B0 = 1, B1 = B3 = B5 = B2m+1 = 0.
	* It only computes B2, B4, B6, ...B2m.
	*/
	public static double[] getBernoulliNumbers(int num, double[] b) {
		double q = 1.0;
		double b1 = 0;
		double b2 = 0;
		double d = 0;
		double[] t = new double[num + 1];

		t[1] = 1.0;
		b[0] = 1.0;				// B0 is always 1.0.
		for (int n = 2; n <= num; n++) {
			for (int i = 1; i < n; i++) {
				t[i - 1] = i * t[i];
			}
			t[n - 1] = 0.0;
			for (int i = n; i >= 2; i--) {
				t[i] += t[i - 2];
			}
			if (n % 2 == 0) {
				q *= 4;
				b1 = n * t[0];
				b2 = q * (q - 1);
				b[n] = b1 / b2;
			} else {			// B(2m+1) is always 0.0.
				b[n] = 0.0;
			}
		}
		return b;
	}
}

