/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.math;

/**
 * MathException is used for all com.vk2gpz.math package related exceptions.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see RuntimeException
 */

public class MathException extends RuntimeException {
    public MathException(){
        super();
    }

    public MathException(String string) {
        super(string);
    }
}
