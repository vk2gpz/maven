/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math;

/* ------------------ Import classes (packages) ------------------- */

/*====================================================================
                  Implementation of class RandomUtil                  
====================================================================*/

import java.util.concurrent.ThreadLocalRandom;

/**
 * Random defines several random number generator. <p>
 * Gaussian, Gamma, Beta, Poisson
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class RandomUtil {
	private RandomUtil() {
	}
	
	/**
	 * Shuffles a given array using normally distributed random numbers.
	 *
	 * @param v an array of double values.
	 */
	public static void shuffle(double[] v) {
		int i, j;
		double t;
		int n = v.length;
		
		for (i = n - 1; i > 0; i--) {
			j = (int)((i + 1) * Math.random());
			t = v[i];
			v[i] = v[j];
			v[j] = t;
		}
	}

	/**
	 * Shuffles a given array using normally distributed random numbers.
	 *
	 * @param v an array of int values.
	 */
	public static void shuffle(int[] v) {
		int i, j, t;
		int n = v.length;
		
		for (i = n - 1; i > 0; i--) {
			j = (int)((i + 1) * Math.random());
			t = v[i];
			v[i] = v[j];
			v[j] = t;
		}
	}

	/**
	 * Generates random permutations of <code>n</code> integer numbers.
	 *
	 * @param n the number of integer numbers.
	 * @return random permutations of <code>n</code> integer numbers.
	 */
	public static int[] randomPermutations(int n) {
		int[] v = new int[n];
		
		for (int i = 0; i < n; i++) {
			v[i] = i + 1;
		}
		shuffle(v);
		return v;
	}

	/**
	 * Returns a random number from {@code min} to {@code max}, both included, with one decimal place.
	 * Same as {@code random(min, max, 1)}.
	 */
	public static double random(double min, double max) {
		return random(min, max, 1);
	}

	/**
	 * Returns a random number from {@code min} to {@code max}, <b>both included</b>, in steps of
	 * {@code 10^-scale} counted from {@code min}. Every step is equally likely.
	 * <p>
	 * {@code random(3, 7, 0)} returns one of 3, 4, 5, 6, 7; {@code random(0, 1, 1)} one of 0.0, 0.1, …, 1.0.
	 * If {@code max - min} is not a whole number of steps, the last step below {@code max} is the largest value.
	 *
	 * @param scale number of decimal places (0 = whole numbers; negative values are treated as 0, values above 9 as 9)
	 */
	public static double random(double min, double max, int scale) {
		if (max < min) {
			double t = min;
			min = max;
			max = t;
		}
		scale = Math.max(0, Math.min(scale, 9));
		final double denominator = Math.pow(10, scale);
		final long steps = (long) Math.floor((max - min) * denominator + 1e-9);
		final long k = ThreadLocalRandom.current().nextLong(steps + 1);
		final double value = min + k / denominator;
		// When min is itself a multiple of the step, snap to the grid to remove noise such as 0.30000000000000004.
		final boolean minOnGrid = Math.abs(min * denominator - Math.rint(min * denominator)) < 1e-6;
		return minOnGrid ? Math.rint(value * denominator) / denominator : value;
	}

	/*
	 * global parameters used in gaussianRandom
	 */
	private static boolean flag_gaussian = false;
	private static double k, q;
	
	/**
     * Returns the next pseudorandom, Gaussian ("normally") distributed
     * <code>double</code> value with mean <code>0.0</code> and standard
     * deviation <code>std</code> from this random number generator's sequence.
     * <p>
	 *
	 * @param std standard deviation.
     * @return  the next pseudorandom, Gaussian ("normally") distributed
     *          <code>double</code> value with mean <code>0.0</code> and
     *          standard deviation <code>std</code> from this random number
     *          generator's sequence.
	*/
	public static double gaussianRandom(double std) {
		if (flag_gaussian) {
			flag_gaussian = false;
			return std * k * Math.sin(q);
		}
		flag_gaussian = true;
		k = Math.sqrt(-2 * Math.log(1 - Math.random()));
		q = 2* Math.PI * Math.random();
		return std * k * Math.cos(q);
	}

	/**
     * Returns the next pseudorandom, Gamma distributed <code>double</code> value.
     * <p>
	 * <pre>
	 *          (p-1) -x
	 *         x     e
	 * f(x) = ---------- , x > 0
	 *           G(p)
	 * </pre>
	 *
	 * @param p parameter <code>p</code>.
     * @return Returns the next pseudorandom, Gamma distributed <code>double</code> value.
	*/
	public static double gammaRandom(double p) {
		double t, u, x, y;
		if (p > 1) {
			t = Math.sqrt(2 * p - 1);
			do {
				do {
					do {		// next 4 lines == y = Math.tan(Math.PI * Math.random());
						x = 1 - Math.random();
						y = 2 * Math.random() - 1;
					} while (x * x + y * y > 1);
					y /= x;
					x = t * y + p - 1;
				} while(x <= 0);
				u = (p - 1) * Math.log(x / (p - 1)) - t * y;
			} while(u < -50 || Math.random() > (1 + y * y) * Math.exp(u));
		} else {
			t = Math.E / (p + Math.E);
			do {
				if (Math.random() < t) {
					x = Math.pow(Math.random(), 1 / p);
					y = Math.exp(-x);
				} else {
					x = 1 - Math.log(Math.random());
					y = Math.pow(x, p - 1);
				}
			} while (Math.random() >= y);
		}
		return x;
	}

	/**
     * Returns the next pseudorandom, beta distributed <code>double</code> value.	   
     * <p>
	 * <pre>
	 *         G(p+q)   (p-1)     (q-1)
	 * f(x) = -------- x     (1-x)      , 0&lt;=x&lt;=1, p&gt;0, q&gt;0
	 *        G(p)G(q)
	 *
	 *         p               pq
	 * mean = ---,  dev = ------------
	 *        p+q              2
	 *                    (p+q) (p+q+1)
	 * </pre>
	 *
	 * @param p parameter <code>p</code>.
	 * @param q parameter <code>q</code>.	 
     * @return  Returns the next pseudorandom, beta distributed <code>double</code> value.
	*/
	public static double betaRandom(double p, double q) {
		double t = gammaRandom(p);
		return t / (t + gammaRandom(q));
	}

	/**
     * Returns the next number of events occurring randomly in a fixed time at an average
	 * rate of <code>a</code>.
     * <p>
	 *
	 * @param n an average rate.
     * @return  Returns the next number of events occurring randomly in a fixed time at
	 * an average rate of <code>a</code>.
	*/
	public static int poissonRandom(double n) {
		int k = 0;
		n = Math.exp(n) * Math.random();
		while (n > 1) { 
			n *= Math.random();
			k++;
		}
		return k;
	}

	/**
     * Returns the next pseudorandom, Weibull distributed <code>double</code>
	 * value.	   
     * <p>
	 * <pre>
	 *               alpha
	 *             -x    
	 * f(x) = 1 - e      ,
	 *
	 *            1                   2               1      2
	 * mean = G(----- + 1), dev = G(----- + 1) - (G(----- +1))
	 *          alpha               alpha           alpha 
	 * </pre>
	 *
	 * @param alpha parameter <code>alpha</code>.
     * @return  Returns the next pseudorandom, Weibull distributed
	 * <code>double</code> value.
	*/
	public static double weibullRandom(double alpha) {
		return Math.pow(-Math.log(1 - Math.random()), 1 / alpha);
	}

	/**
     * Returns the next pseudorandom, <code>chi-square</code> distributed
	 * <code>double</code> value.
     * <p>
	 * <pre>
	 * </pre>
	 *
	 * @param n degree of freedom <code>n</code>.
     * @return  Returns the next pseudorandom, <code>chi-square</code>
	 * distributed <code>double</code> value.
	*/
	public static double chiSquareRandom(double n) {
		return 2 * gammaRandom(0.5 * n);
	}

	/**
     * Returns the next pseudorandom, <code>t</code> distributed
	 * <code>double</code> value. <p>
	 * Ref: George Marsaglia, Generating random variable with t-distribution.
	 * Mathematics of Computation 34:235--236, 1980
     * <p>
	 * <pre>
	 * </pre>
	 *
	 * @param n degree of freedom <code>n</code>.
     * @return  Returns the next pseudorandom, <code>t</code> distributed
	 * <code>double</code> value.
	*/
	public static double tRandom(double n) {
		double a, b, c;

		if (n <= 2) {
			return Math.random() / Math.sqrt(chiSquareRandom(n) / n);
		}
		if (n < 6) {			// when n < 6, this seems faster.
			do {
				a = Math.random();
				b = a * a / (n - 2);
				c = Math.log(1 - Math.random()) / (1 - 0.5 * n);
			} while (b >= 1 || Math.exp(-b - c) > 1 - b);
		} else {
			do {
				a = Math.random();
				b = a * a / (n - 2);
				c = Math.log(1 - Math.random()) / (1 - 0.5 * n);
			} while (Math.exp(-b - c) > 1 - b);
		}
		return a / Math.sqrt((1 - 2.0 / n) * (1 - b));
	}
	
	/**
     * Returns the next pseudorandom, <code>F</code> distributed
	 * <code>double</code> value.
     * <p>
	 * <pre>
	 * </pre>
	 *
	 * @param n1 degree of freedom <code>n1</code>.
	 * @param n2 degree of freedom <code>n2</code>.	 
     * @return  Returns the next pseudorandom, <code>F</code> distributed
	 * <code>double</code> value.
	*/
	public static double fRandom(double n1, double n2) {
		return (chiSquareRandom(n1) * n2) / (chiSquareRandom(n2) * n1);
	}

	/**
     * Returns the next pseudorandom, <code>logistic</code> distributed
	 * <code>double</code> value.
     * <p>
	 * <pre>
	 *           1      
	 * f(x) = ------- ,
	 *             -x
	 *        1 - e
	 *
	 *                   2
	 *                 Pi 
	 * mean = 0, dev = --
	 *                 3
	 * </pre>
	 *
     * @return  Returns the next pseudorandom, <code>logistic</code>
	 * distributed <code>double</code> value.
	*/
	public static double logisticRandom() {
		double r = Math.random();
		return Math.log(r / (1 - r));
	}
	
	/**
     * Returns the next pseudorandom, <code>power</code> distributed
	 * <code>double</code> value.
     * <p>
	 * <pre>
	 *                n
	 * f(x) = (n + 1)x
	 *
	 * </pre>
	 *
	 * @param n the power.
     * @return  Returns the next pseudorandom, <code>power</code>
	 * distributed <code>double</code> value.
	*/
	public static double powerRandom(int n) {
		return Math.pow(Math.random(), 1.0 / (n + 1));
	}

	/**
     * Returns the next pseudorandom, <code>binormally</code>
	 * (<code>bivariate normal</code>) distributed <code>double</code> values.
     * <p>
	 * Given two normally distributed random numbers <code>X</code> and
	 * <code>Y</code> (mean = 0, variance 1), a new random numbers
	 * <code>Q = aX + bY</code> and <code>R = aX - bY</code> have a variance
	 * <code>a*a + b*b</code> and a correlation coefficent
	 * <code>a*a - b*b</code>.
	 * <pre>
	 * </pre>
	 *
	 * @param c the correlation coefficient
     * @return  Returns a set of <code>binormally</code> distributed
	 * <code>double</code> values.
	*/
	public static double[] binormalRandom(double c) {
		double[] xy = new double[2];
		double r1, r2, s;

		do {
			r1 = 2 * Math.random() - 1;
			r2 = 2 * Math.random() - 1;
			s = r1 * r1 + r2 * r2;
		} while (s > 1 || s == 0);
		s = - Math.log(s) / s;
		r1 = Math.sqrt((1 + c) * s) * r1;
		r2 = Math.sqrt((1 - c) * s) * r2;
		xy[0] = r1 + r2;
		xy[1] = r1 - r2;
		return xy;
	}

	/**
     * Returns the next pseudorandom, <code>binomial</code> distributed
	 * <code>double</code> values.
     * <p>
	 * <pre>
	 * </pre>
	 *
	 * @param n the number of the event.
	 * @param p the probability of the event.
     * @return  Returns the next pseudorandom, <code>binomial</code> distibuted
	 * <code>double</code> values.
	*/
	public static int binomialRandom(int n, double p) {
		int r = 0;

		for (int i = 0; i < n; i++) {
			if (Math.random() < p) {
				r++;
			}
		}
		return r;
	}

	/**
     * Returns a randomly selected location on the <code>n</code> dimensional
	 * unit sphere.  
     * <p>
	 * <pre>
	 * </pre>
	 *
	 * @param n the dimension.
     * @return  a <code>n</code> dimensional array of double values
	 * representing the randomly selected location on the <code>n</code>
	 * dimensional unit sphere.
	*/
	public static double[] unitSphereRandom(int n) {
		double[] v = new double[n];
		double r = 0;		

		if (n < 5) {
			do {
				for (int i = 0; i < n; i++) {
					v[i] = 2 * Math.random() - 1;
					r += v[i] * v[i];
				}
			} while (r > 1);
		} else {				// when n >= 5, this is faster.
			for (int i = 0; i < n; i++) {
				v[i] = gaussianRandom(1.0);
				r += v[i] * v[i];
			}
		}
		r = Math.sqrt(r);
		for (int i = 0; i < n; i++) {
			v[i] /= r;
		}
		return v;
	}
	
	/**
     * Returns the next pseudorandom, exponentially distributed
	 * <code>double</code> value.
     * <p>
	 * <pre>
	 * </pre>
	 *
	 * @param m a mean value.
     * @return Returns the next pseudorandom, exponentially distributed
	 * <code>double</code> value.
	*/
	public static double exponentialRandom(double m) {
		return m * (-Math.log(1 - Math.random()));
	}

	/**
     * Returns the next pseudorandom, geometrically distributed
	 * <code>double</code> value.
     * <p>
	 * <pre>
	 * </pre>
	 *
	 * @param p a probability of the event.
     * @return Returns the next pseudorandom, geometrically distributed
	 * <code>double</code> value.
	*/
	public static double geometricRandom(double p) {
		if (p > 0.2) {
			int n = 1;
			while (Math.random() > p) {
				n++;
			}
			return n;
		} else {
			return Math.ceil(Math.log(1 - Math.random()) / Math.log(1 - p));
		}
	}

	/**
     * Returns the next pseudorandom, Cauchy distributed
	 * <code>double</code> value.
     * <p>
	 * <pre>
	 *             1  
	 * f(x) = ---------- ,
	 *              2
	 *        (1 + x )Pi
	 * </pre>
	 *
     * @return Returns the next pseudorandom, Cauchy distributed
	 * <code>double</code> value.
	*/
	public static double cauchyRandom() {
		double X, Y;
		
		do {
			X = Math.random();
			Y = 2 * Math.random() - 1;
		} while (!(Math.sqrt(X) + Math.sqrt(Y) <= 1));
		return Y / X;
	}

	/**
     * Returns the next pseudorandom, triangular distributed
	 * <code>double</code> value.
     * <p>
	 *
     * @return Returns the next pseudorandom, triangular distributed
	 * <code>double</code> value.
	*/
	public static double triangularRandom() {
		return Math.random() - Math.random();
	}
}

