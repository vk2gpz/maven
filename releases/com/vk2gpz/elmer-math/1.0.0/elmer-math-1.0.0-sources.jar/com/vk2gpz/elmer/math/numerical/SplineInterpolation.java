/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
             Implementation of class SplineInterpolation              
====================================================================*/
/**
 * SplineInterpolation provides cubic spline interpolation for non
 * periodic function.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Interpolation
 */

public final class SplineInterpolation extends Interpolation {
	public SplineInterpolation() {
		super();
	}

	public static void makeTable(double[] x, double[] y, double[] z) {
		int N = x.length;
		z[0] = 0.0;
		z[N - 1] = 0.0;

		double[] h = new double[N];
		double[] d = new double[N];
		for (int i = 0; i < N - 1; i++) {
			h[i    ] =  x[i + 1] - x[i];
			d[i + 1] = (y[i + 1] - y[i]) / h[i];
		}
		z[1] = d[2] - d[1] - h[0] * z[0];
		double t;
		for (int i = 1; i < N - 2; i++) {
			t = h[i] / d[i];
			z[i + 1] = d[i + 2] - d[i + 1] - z[i] * t;
			d[i + 1] = 2 * (x[i + 2] - x[i]) - h[i] * t;
		}
		z[N - 2] -= h[N - 2] * z[N - 1];
		for (int i = N - 2; i > 0; i--) {
			z[i] = (z[i] - h[i] * z[i + 1]) / d[i];
		}
	}

	private void makeTable() {
		makeTable(this.x, this.y, this.w);
	}
	
	public void setSamples(double[] x, double[] y) {
		super.setSamples(x, y);
		makeTable();
	}
	
	public static double interpolate(double t, double[] x, double[] y, double[] z) {
		int N = x.length;
		int i = 0;
		int j = N - 1;
		int k = 0;
		while (i < j) {
			k = (i + j) / 2;
			if (x[k] < t) {
				i = k + 1;
			} else {
				j = k;
			}
		}
		if (i > 0) {
			i--;
		}
		double h = x[i + 1] - x[i];
		double d = t - x[i];
		return (((z[i + 1] - z[i]) * d / h + z[i] * 3) * d
				+ ((y[i + 1] - y[i]) / h
				   - (z[i] * 2 + z[i + 1]) * h)) * d + y[i];
	}

	public double interpolate(double t) {
		return interpolate(t, this.x, this.y, this.w);
	}

	public static void makeTable2(double[] p, double[] x, double[] y, double[] a, double[] b) {
		int N = x.length;
		double t1, t2;

		p[0] = 0.0;
		for (int i = 1; i < N; i++) {
			t1 = x[i] - x[i - 1];
			t2 = y[i] - y[i - 1];
			p[i] = p[i - 1] + Math.sqrt(t1 * t1 + t2 * t2);
		}
		for (int i = 1;i < N; i++) {
			p[i] /= p[N - 1];
		}
		makeTable(p, x, a);
		makeTable(p, y, b);
	}

	public static double[] interpolate(double t, double[] p, double[] x, double[] y,
									   double[] a, double[] b, double[] result) {
		if (result == null || result.length < 2) {
			result = new double[2];
		}
		result[0] = interpolate(t, p, x, a);
		result[1] = interpolate(t, p, y, b);

		return result;
	}
}
