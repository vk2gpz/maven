/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.math;
/**
 * Thrown when the sizes of two target objects does not match.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see MathException
 */

public class MismatchedSizeException extends MathException {
    public MismatchedSizeException() {
		super();
    }

    public MismatchedSizeException(String s) {
        super(s);
    }
}
