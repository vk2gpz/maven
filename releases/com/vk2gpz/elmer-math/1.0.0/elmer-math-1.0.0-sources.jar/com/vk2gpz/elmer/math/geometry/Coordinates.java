/*
 * Copyright (c) 1994-2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.geometry;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.debug.DebugHandler;
import com.vk2gpz.elmer.math.VecMath;

/*====================================================================
                 Implementation of class Coordinates                  
====================================================================*/
/**
 * generally describe Coordinates in here
 * 
 * @version $Revision: 1.4 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

class Coordinates {
	/**
	 * debug flag
	 */
	private static final boolean DEBUG = DebugHandler.isDebugged(Coordinates.class);

 	static Coordinates WORLD_COORDS;
	
    double[][]	rotation; // 3x3 matrix (VMatrix) which represents rotation
    double[] position; // 3D Vector which represents original coordinate

	Coordinates() {
		super();

		if (DEBUG) {
			System.out.println("Coordinates: after super()");
		}
		
		this.position = new double[3];
		this.rotation = VecMath.identity(3, 3);

		if (WORLD_COORDS == null) {
			WORLD_COORDS = this; // this is to stop infinite loop.
			WORLD_COORDS = new Coordinates();
		}
	}
	
	Coordinates(double[] position, double[][] rotation,
				double[] euler, double[] rpy,
				double[] axis, double[][] angles,
				Coordinates coords,
				double[][] mat44, int cods, Coordinates wrt) {
		this();

		if (rotation != null) 
			setRotation(rotation);

		if (position != null)
			if (wrt != null)
				setPosition(wrt.transformVector(position));
			else
				setPosition(position);

		if (euler != null) 
			setEuler(euler[0], euler[1], euler[2]);
		
		if (rpy != null) 
			setRollPitchYow(rpy[0], rpy[1], rpy[2]);

		if (coords != null) 
			set(coords);
		
		if (angles != null)
			rotate(angles, (int)axis[0], cods, wrt);
		if (mat44 != null)
			m44(mat44);
	}

	Coordinates(double[] position, double[][] rotation,
				double[] euler, double[] rpy,
				double[] axis, double[] angles,
				Coordinates coords,
				double[][] mat44, int cods, Coordinates wrt) {
		this();

		if (rotation != null) 
			setRotation(rotation);

		if (position != null)
			if (wrt != null)
				setPosition(wrt.transformVector(position));
			else
				setPosition(position);

		if (euler != null) 
			setEuler(euler[0], euler[1], euler[2]);
		
		if (rpy != null) 
			setRollPitchYow(rpy[0], rpy[1], rpy[2]);

		if (coords != null) 
			set(coords);
		
		if (angles != null)
			if(angles.length > 1){
				int cnt = Math.min(angles.length, axis.length);
				for (int i = 0; i < cnt; i++)
					rotate(angles[i], (int) axis[i], cods, wrt);
			} else
				rotate(angles[0], (int) axis[0], cods, wrt);
		if (mat44 != null)
			m44(mat44);
	}

	/**
	   |- rotation| 
	   
	   vk2gpz/1994-Feb-01
	*/
	double[][] getRotation() {
		return this.rotation;
	}

	/**
	   |- position| 
	   
	   vk2gpz/1994-Feb-01
	*/
	double[] getPosition() {
		return this.position;
	}

	/**
	   |- (int)dimension| 
	   
	   vk2gpz/1994-Jan-31
	*/
	int getDimension() {
		return this.position.length;
	}

	/**
	   |- xAxis| 
	   
	   vk2gpz/1994-Feb-01
	*/
	double[] getXAxis() {
		return this.rotation[0];
	}

	/**
	   |- yAxis| 
	   
	   vk2gpz/1994-Feb-01
	*/
	double[] getYAxis() {
		return this.rotation[1];
	}

	/**
	   |- zAxis| 
	   
	   vk2gpz/1994-Feb-01
	*/
	double[] getZAxis() {
		return this.rotation[2];
	}
	
	/**
	   |- newCoordsWithRot:newrot pos:newpos|
	   |- replaceCoordsWithRot:newrot pos:newpos| 	   
	   
	   vk2gpz/1994-Feb-01
	*/
	Coordinates set(double[][] rotation, double[] position) {
		setRotation(rotation);
		setPosition(position);

		return this;
	}

	/**
	   |- replaceRotationWith:newrot| 
	   
	   vk2gpz/1994-Feb-01
	*/
	Coordinates setRotation(double[][] rotation) {
		VecMath.copy(rotation, this.rotation);
		
		return this;
	}
	
	/**
	   |- replacePositionWith:newpos| 
	   
	   vk2gpz/1994-Feb-01
	*/
	Coordinates setPosition(double[] position) {
		VecMath.copy(position, this.position);

		return this;
	}

	/**
	   |- replaceCoordsWith:newcoords| 
	   
	   vk2gpz/1994-Feb-01
	*/
	Coordinates set(Coordinates newcoords) {
		return set(newcoords.getRotation(), newcoords.getPosition());
	}

	/**
	   |- copyRotation| 

	   vk2gpz/1994-Feb-01
	*/
	double[][] copyRotation() {
		return VecMath.copy(this.rotation);
	}

	/**
	   |- copyPosition| 
	   
	   vk2gpz/1994-Feb-01
	*/
	double[] copyPosition() {
		return VecMath.copy(this.position);
	}

	/**
	   |- copyCoords| 
	   
	   vk2gpz/1994-Feb-01
	*/
	Coordinates copy() {
		Coordinates c = new Coordinates();
		return set(this.rotation, this.position);
	}

	/**
	   |- coords| 
	   
	   vk2gpz/1994-Feb-01
	*/
	Coordinates getCoordinates() {
		return copy();
	}

	/**
	   |- worldRotation| 
	   
	   vk2gpz/1994-Feb-01
	*/
	double[][] getWorldRotation() {
		return this.rotation;
	}

	/**
	   |- worldPosition| 
	   
	   vk2gpz/1994-Feb-01
	*/
	double[] getWorldPosition() {
		return this.position;
	}

	/**
	   |- worldCoords| 
	   
	   vk2gpz/1994-Feb-01
	*/
	Coordinates getWorldCoordinates() {
		return this;
	}

	/**
	   |- copyWorldCoords| 
	   
	   vk2gpz/1994-Feb-01
	*/
	Coordinates copyWorldCoordinates() {
		return getCoordinates();
	}

	/**
	   |- parentCoords| 
	   
	   vk2gpz/1994-Feb-01
	*/
	Coordinates getParentCoordinates() {
		return WORLD_COORDS;
	}

	/**
	   |- resetCoords| 
	   
	   vk2gpz/1994-Feb-01
	*/
	Coordinates reset() {
		int dim = this.position.length;
		this.position = new double[dim];
		this.rotation = VecMath.identity(3, 3);

		return this;
	}

	/**
	   |- moveTo:trans in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-01
	*/
	Coordinates move(Coordinates trans, int cods, Coordinates wrt) {
		Coordinates cc = null;
		if (cods == GeometryUtil.LOCAL_SYSTEM){
			cc = transformCoordinates(this, trans, null);
			set(cc);
		} else if (cods == GeometryUtil.WORLD_SYSTEM || cods == GeometryUtil.PARENT_SYSTEM)
			set(trans);
		else if (wrt != null) {
			cc = transformCoordinates(wrt.getWorldCoordinates(), trans, null);
			cc = transformCoordinates(getParentCoordinates().inverseTransformation(), cc, cc);
			set(cc);
		}
		
		return this;
	}

	/**
	   |- rotateVector:aVector| 
	   
	   vk2gpz/1994-Feb-02
	*/
	double[] rotateVector(double[] aVector) {
		return VecMath.multiply(this.rotation, aVector);
	}

	/**
	   |- transformVector:aVector| 
	   a vector given in the local coords is converted to world representation
	   vk2gpz/1994-Feb-02
	*/
	double[] transformVector(double[] aVector) {
		double[] vec = VecMath.multiply(this.rotation, aVector);
		return VecMath.add(vec, this.position);
	}

	/**
	   |- inverseTransformVector:aVector| 
	   A vector in the world is inversely transformed to the representation
	   in this local coordinate system.
	   vk2gpz/1994-Feb-02
	*/
	double[] inverseTransformVector(double[] aVector) {
		double[][] invRot = VecMath.transpose(this.rotation);
		return  VecMath.subtract(VecMath.multiply(invRot, aVector),
								 VecMath.multiply(invRot, this.position));
	}

	/**
	   |- inverseTransformation:result| 

	   vk2gpz/1994-Feb-02
	*/
	Coordinates inverseTransformation() {
		Coordinates result = new Coordinates();
		result.setRotation(VecMath.transpose(this.rotation));
		result.setPosition(VecMath.multiply(result.getRotation(), this.position));
		VecMath.scale(-1.0, result.getPosition());
		
		return result;
	}

	/**
	   |- transformation:aCoords in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates transformation(Coordinates aCoords, int cods, Coordinates wrt) {
		Coordinates c2 = aCoords.getWorldCoordinates();
		Coordinates c1 = getWorldCoordinates();
		Coordinates inv = c1.inverseTransformation();
		if (cods == GeometryUtil.LOCAL_SYSTEM)
			transformCoordinates(inv, c2, inv);
		else if (cods == GeometryUtil.WORLD_SYSTEM || cods == GeometryUtil.PARENT_SYSTEM ||
				 wrt == WORLD_COORDS)
			transformCoordinates(c2, inv, inv);
		else if (wrt != null) {
			Coordinates xw = wrt.getWorldCoordinates();
			transformCoordinates(c2, inv, inv);
			transformCoordinates(xw.inverseTransformation(), inv, inv);
			transformCoordinates(inv, xw, inv);
		}
		
		return inv;
	}
	
	/**
	   |- transform:aCoords in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates transform(Coordinates aCoords, int cods, Coordinates wrt) {
		if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this)
			/* multiply aCoords from the right */
			transformCoordinates(this, aCoords, this);
		else if (cods == GeometryUtil.PARENT_SYSTEM || cods == GeometryUtil.WORLD_SYSTEM ||
				 wrt == WORLD_COORDS)
			/* multiply aCoords from the left */
			transformCoordinates(aCoords, this, this);
		else if (wrt != null) {
			transformCoordinates(wrt.inverseTransformation(),
								 this, this);
			transformCoordinates(aCoords, this, this);
			transformCoordinates(wrt.getWorldCoordinates(),
								 this,
								 this);
		}
		set(this.rotation, this.position);
		
		return this;
	}
	
	/**
	   |- rotateWithMatrix:aMatrix in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates rotate(double[][] aMatrix, int cods, Coordinates wrt) {
		if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this)
			setRotation(VecMath.multiply(this.rotation, aMatrix));
		else if (cods == GeometryUtil.PARENT_SYSTEM ||
				 cods == GeometryUtil.WORLD_SYSTEM ||
				 wrt == WORLD_COORDS)
			setRotation(VecMath.multiply(aMatrix, this.rotation));
		else if (wrt != null) {
			double[][] r2 = wrt.getWorldRotation();
			double[][] r2t = VecMath.transpose(r2);
			r2t = VecMath.multiply(aMatrix, r2t);
			r2t = VecMath.multiply(r2, r2t);
			setRotation(VecMath.multiply(r2t, this.rotation));
		}
		
		return this;
	}

	/**
	   |- rotateBy:(double)theta around:(int)axis in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates rotate(double theta, int axis, int cods, Coordinates wrt) {
		if(this.position.length == 2)	/* 2-dimension */
			setRotation(GeometryUtil.rotateMatrix(this.rotation,
												  theta,
												  GeometryUtil.NON_AXIS,
												  GeometryUtil.NON_SYSTEM));
		else {
			if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this)
				setRotation(GeometryUtil.rotateMatrix(this.rotation,
													  theta,
													  axis,
													  GeometryUtil.LOCAL_SYSTEM));
			else if (cods == GeometryUtil.PARENT_SYSTEM ||
					 cods == GeometryUtil.WORLD_SYSTEM ||
					 wrt == WORLD_COORDS)
				setRotation(GeometryUtil.rotateMatrix(this.rotation,
													  theta,
													  axis,
													  GeometryUtil.WORLD_SYSTEM));
			else {
				/* C1'=C2*R*C2(-1)*C1 */
				rotate(GeometryUtil.getRotationMatrix(theta, axis), cods, wrt);
			}
		}

		return this;
	}
	
	/**
	   |- rotateBy:(double)theta aroundVector:axisVec in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates rotate(double theta, double[] axisVec,
					   int cods, Coordinates wrt) {
		if (this.position.length == 2)	/* 2-dimension */
			setRotation(GeometryUtil.rotateMatrix(this.rotation, theta,
												  GeometryUtil.NON_AXIS,
												  GeometryUtil.NON_SYSTEM));
		else 
			rotate(GeometryUtil.getRotationMatrix(theta, axisVec),
				   cods, wrt);

		return this;
	}
	
	/**
	   |- rotateByMatrix:theta around:(int)axis in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates rotate(double[][] theta, int axis, int cods, Coordinates wrt) {
		if (this.position.length == 2)	/* 2-dimension */
			setRotation(VecMath.multiply(theta, this.rotation));
		else {
			rotate(theta, cods, wrt);
		}

		return this;
	}

	/**
	   |- orientWithMatrix:aMatrix in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates orient(double[][] aMatrix, int cods, Coordinates wrt) {
		if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this) 
			setRotation(VecMath.multiply(this.rotation, aMatrix));
		else if (cods == GeometryUtil.PARENT_SYSTEM || cods == GeometryUtil.WORLD_SYSTEM ||
				 wrt == WORLD_COORDS)
			setRotation(aMatrix);
		else if (wrt != null) {
			double[][] r2 = wrt.getWorldRotation();
			setRotation(VecMath.multiply(r2, aMatrix));
		}
		
		return this;
	}

	/**
	   |- orientBy:(double)theta aroundVector:axisVec in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates orient(double theta, double[] axisVec, int cods, Coordinates wrt) {
		return orient(GeometryUtil.getRotationMatrix(theta, axisVec), cods, wrt);
	}

	/**
	   |- orientByMatrix:theta around:(int)axis in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates orient(double[][] theta, int axis, int cods, Coordinates wrt) {
		return orient(theta, cods, wrt);
	}
	
	/**
	   |- orientBy:(double)theta around:(int)axis in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates orient(double theta, int axis, int cods, Coordinates wrt) {
		if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this)
			setRotation(GeometryUtil.rotateMatrix(this.rotation, theta, axis, cods));
		else if (cods == GeometryUtil.PARENT_SYSTEM || cods == GeometryUtil.WORLD_SYSTEM ||
				 wrt == WORLD_COORDS)
			setRotation(GeometryUtil.getRotationMatrix(theta, axis));
		else {
			/* C1'=C2*R*C2(-1)*C1 */
			orient(GeometryUtil.getRotationMatrix(theta, axis), cods, wrt);
		}
		
		return this;
	}

	/**
	   |- parentVector:aVector in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-03
	*/
	double[] parentVector(double[] aVector, int cods, Coordinates wrt) {
		if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this)
			return transformVector(aVector);
		else if (cods == GeometryUtil.WORLD_SYSTEM || cods == GeometryUtil.PARENT_SYSTEM ||
				 wrt == WORLD_COORDS)
			return aVector;
		else if (wrt != null) 
			return wrt.transformVector(aVector);
		return null;
	}

	/**
	   |- parentOrientation:aVector in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-03
	*/
	double[] parentOrientation(double[] aVector, int cods, Coordinates wrt) {
		if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this)
			return  VecMath.multiply(this.rotation, aVector);
		else if (cods == GeometryUtil.PARENT_SYSTEM || cods == GeometryUtil.WORLD_SYSTEM ||
				 wrt == WORLD_COORDS)
			return aVector;
		else if (wrt != null) 
			return VecMath.multiply(wrt.getWorldRotation(), aVector);
		return null;
	}
	
	/**
	   |- translate:aVector in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates translate(double[] aVector, int cods, Coordinates wrt) {
		return set(this.rotation, 
				   VecMath.add(parentOrientation(aVector, cods, wrt), this.position));
		
	}
	
	/**
	   |- locate:aVector in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates locate(double[] aVector, int cods, Coordinates wrt) {
		return set(this.rotation, parentVector(aVector, cods, wrt));
	}
	
	/**
	   |- scaleBy:(double)scale| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates scale(double scale) {
		if (Double.compare(scale, 0.0) != 0) {
			VecMath.scale(scale, this.rotation, this.rotation);
			return set(this);
		}
		//this.rotation[0] rowSlice:0] norm];
		return null;
	}
	
	/**
	   |- euler:(double)az :(double)ay :(double)az2| 
	   be carefull with the angle order
	   vk2gpz/1994-Feb-03
	*/
	Coordinates setEuler(double az, double ay, double az2) {
		set(GeometryUtil.getEulerMatrix(az, ay, az2), this.position);
		
		return this;
	}
	
	/**
	   |- eulerAngle| 
	   
	   vk2gpz/1994-Feb-03
	*/
	double[][] getEulerAngles() {
		return GeometryUtil.getEulerAnglesOf(this.rotation);
	}

	/**
	   |- rpy:(double)roll :(double)pitch :(double)yow| 

	   vk2gpz/1994-Feb-03
	*/
	Coordinates setRollPitchYow(double roll, double pitch, double yow) {
		set(GeometryUtil.getRollPitchYouMatrix(roll, pitch, yow), this.position);
		return this;
	}

	/**
	   |- rpyAngle| 
	   
	   vk2gpz/1994-Feb-03
	*/
	double[][] getRollPichYowAngles() {
		return GeometryUtil.getRollPichYowAnglesOf(this.rotation);
	}

	/**
	   |- m44:mat44| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates m44(double[][] mat44) {
		if (mat44 != null && mat44[0] != null &&
			mat44.length == 4 && mat44[0].length == 4) {
			for (int i = 0; i < 3; i++) {
				System.arraycopy(mat44[i], 0, this.rotation[i], 0, 3);
				this.position[i] = mat44[i][3];
			}
		} else {
			/* makes 4x4 matrix representation */
			/* all zero elements */
			mat44 = new double[4][4];
			mat44[3][3] = 1.0;
			for (int i = 0; i < 3; i++) {
				System.arraycopy(this.rotation[i], 0, mat44[i], 0, 3);
				mat44[i][3] = this.position[i];
			}
		}
		return this;		
	}

	/**
	   |- createWithDimension:(int)dimension| 
	   
	   vk2gpz/1994-Feb-03
	*/
	Coordinates set(int dimension) {
		setRotation(VecMath.identity(dimension, dimension));
		setPosition(new double[dimension]);
		
		return this;
	}
	
	/**
	   |- transformCoords:c1 :c2 :c3| 
	   
	   vk2gpz/1994-Feb-04
	*/
	static Coordinates transformCoordinates(Coordinates c1,
											Coordinates c2,
											Coordinates c3) {
		if (c3 == null) {
			int dim = c1.getDimension();
			c3 = new Coordinates();
			c3.set(VecMath.identity(dim, dim), new double[dim]);
		}
		if (c1 == c3)
			c3.setPosition(VecMath.add(c1.getPosition(), VecMath.multiply(c1.getRotation(), c2.getPosition())));
		else
			c3.setPosition(VecMath.add(c1.getPosition(), VecMath.multiply(c1.getRotation(), c2.getPosition())));
		
		c3.setRotation(VecMath.multiply(c1.getRotation(),
										c2.getRotation()));
		
		return c3;
	}

	/**
	   |- coordinatesDistance:c1 :c2| 
	   
	   vk2gpz/1994-Feb-04
	*/
	static double[] distance(Coordinates c1, Coordinates c2) {
		double [] dislist = new double[2];
		Coordinates c = c1.transformation(c2, GeometryUtil.LOCAL_SYSTEM, null);
		dislist[0] = VecMath.norm(c.getWorldPosition());
		dislist[1] = GeometryUtil.getRotationAnglesOf(c.getWorldRotation())[0][0];
		
		return dislist;
	}
}
