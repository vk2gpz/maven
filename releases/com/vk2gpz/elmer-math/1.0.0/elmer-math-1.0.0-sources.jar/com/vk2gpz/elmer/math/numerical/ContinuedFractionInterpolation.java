/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
        Implementation of class ContinuedFractionInterpolation        
====================================================================*/
/**
 * Implements continued-fraction interpolation method.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Interpolation
 */

public final class ContinuedFractionInterpolation extends Interpolation {
	public ContinuedFractionInterpolation() {
		super();
	}

	public static void makeTable(double[] x, double[] y, double[] w) {
		int N = x.length;
		System.arraycopy(y, 0, w, 0, N);
		for (int j = 0; j < N - 1; j++) {
			for (int i = j + 1; i < N; i++) {
				w[i] = (x[i] - x[j]) / (w[i] - w[j]);
			}
		}
	}

	private void makeTable() {
		makeTable(this.x, this.y, this.w);
	}
	
	public void setSamples(double[] x, double[] y) {
		super.setSamples(x, y);
		makeTable();
	}
	
	public static double interpolate(double t, double[] x, double[] y, double[] w) {
		int N = x.length;
		double r = w[N - 1];
		for (int i = N - 2; i >= 0; i--) {
			r = (t - x[i]) / r + w[i];
		}
		return r;
	}
	
	public double interpolate(double t) {
		return interpolate(t, this.x, this.y, this.w);
	}
}
