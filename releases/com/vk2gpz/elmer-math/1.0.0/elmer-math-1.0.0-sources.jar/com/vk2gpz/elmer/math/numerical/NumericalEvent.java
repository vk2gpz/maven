/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
import java.util.*;

/*====================================================================
                Implementation of class NumericalEvent                
====================================================================*/
/**
 * generally describe NumericalEvent in here
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see EventObject
 */

public class NumericalEvent extends EventObject {
	protected Object source;
	protected final int id;
	
    /**
     * Constructs a NumericalEvent object.
	 * 
     * @param source the object where the event originated
     * @param id     the event type
     */
    public NumericalEvent(Object source, int id) {
        super(source);
		this.id = id;
    }

    /**
     * Returns the ID.
     *
     * @return   ID.
     */
    public int getID() {
        return this.id;
    }
	
    /**
     * Returns a String representation of this NumericalEvent object.
     *
     * @return  a String representation of this NumericalEvent object.
     */
    public String toString() {
        return getClass().getName() + "[source=" + this.source + ", id=" + this.id + "]";
    }
}
