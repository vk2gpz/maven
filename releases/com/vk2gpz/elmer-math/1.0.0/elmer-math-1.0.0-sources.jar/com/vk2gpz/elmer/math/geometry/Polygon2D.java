/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.math.geometry;

public class Polygon2D {
	private final double[][] vertices; // an array of double[2]
	private final double[] constant;
	private final double[] multiple;
	
	
	public Polygon2D() {
		this(0);
	}
	
	public Polygon2D(int numOfVertices) {
		this.vertices = new double[numOfVertices][2];
		this.constant = new double[numOfVertices];
		this.multiple = new double[numOfVertices];
	}
	
	public Polygon2D(double... valuepairs) {
		this(valuepairs.length / 2);
		for (int i = 0; i < valuepairs.length / 2; i++) {
			int idx0 = 2 * i;
			int idx1 = idx0 + 1;
			this.vertices[i][0] = valuepairs[idx0];
			this.vertices[i][1] = valuepairs[idx1];
		}
		init();
	}
	
	public Polygon2D(double[] x, double[] y) {
		this(Math.min(x.length, y.length));
		int num = Math.min(x.length, y.length);
		for (int i = 0; i < num; i++) {
			this.vertices[i][0] = x[i];
			this.vertices[i][1] = y[i];
		}
		init();
	}
	
	public void init() {
		for (int i = 0, j = this.vertices.length - 1; i < this.vertices.length; i++) {
			if (this.vertices[j][1] == this.vertices[i][1]) {
				constant[i] = this.vertices[i][0];
				multiple[i] = 0;
			} else {
				constant[i] = this.vertices[i][0] - (this.vertices[i][1] * this.vertices[j][0]) / (this.vertices[j][1] - this.vertices[i][1]) + (this.vertices[i][1] * this.vertices[i][0]) / (this.vertices[j][1] - this.vertices[i][1]);
				multiple[i] = (this.vertices[j][0] - this.vertices[i][0]) / (this.vertices[j][1] - this.vertices[i][1]);
			}
			j = i;
		}
	}
	
	public boolean isInside(double x, double y) {
		boolean oddNodes = false;
		boolean current = this.vertices[this.vertices.length - 1][1] > y;
		boolean previous;
		for (int i = 0; i < this.vertices.length; i++) {
			previous = current;
			current = this.vertices[i][1] > y;
			if (current != previous)
				oddNodes ^= y * multiple[i] + constant[i] < x;
		}
		return oddNodes;
	}
}
