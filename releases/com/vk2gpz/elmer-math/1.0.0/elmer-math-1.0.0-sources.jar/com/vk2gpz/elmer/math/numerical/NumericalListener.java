/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
import java.util.*;

/*====================================================================
              Implementation of class NumericalListener               
====================================================================*/
/**
 * generally describe NumericalListener in here
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public interface NumericalListener extends EventListener {
	
	/**
     * Invoked when the function is evaluated.
	* <PRE>
	* </PRE>
	* 
	* @param e NumericalEvent.
	*/
	void evaluated(NumericalEvent e);
}
