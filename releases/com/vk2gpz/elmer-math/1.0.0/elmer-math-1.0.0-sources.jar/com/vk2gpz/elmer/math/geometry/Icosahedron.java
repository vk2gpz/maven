/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.geometry;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

import com.vk2gpz.elmer.debug.DebugHandler;

/*====================================================================
                 Implementation of class Icosahedron                  
====================================================================*/
/**
 * Generate a set of Facets representing an icosahedron.
 * 
 * @version $Revision: 1.6 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

class Icosahedron implements Serializable {
	/**
	 * debug flag
	 */
	private static final boolean DEBUG = DebugHandler.isDebugged(Icosahedron.class);

	/**
	 * Sets of vertex indices for each facet (triangle).
	 *
	 * vk2gpz (vk2gpz@gmail.com)/2003-Sep-16
	 */
	private static final int[][] VERTICES = {
		{1, 9, 3},{1, 3, 11},{11, 3, 8},{11, 8, 12},{12, 8, 4},
		{12, 4, 2},{2, 4, 10},{2, 10, 5},{5, 10, 9},{5, 9, 1},
		{7, 1, 11},{7, 11, 12},{7, 12, 2},{7, 2, 5},{7, 5, 1},
		{6, 3, 9},{6, 8, 3},{6, 4, 8},{6, 10, 4},{6, 9, 10}
	};

	/**
	 * Sets of neighbouring facet indices for each facet (triangle).
	 *
	 * vk2gpz (vk2gpz@gmail.com)/2003-Sep-16
	 */
	private static final int[][] NEIGHBOURS = {
		{10, 16, 2},{1, 3, 11},{2, 17, 4},{3, 5, 12},{4, 18, 6},
		{5, 7, 13},{6, 19, 8},{7, 9, 14},{8, 20, 10},{9, 1, 15},
		{15, 2, 12},{11, 4, 13},{12, 6, 14},{13, 8, 15},{14, 10, 11},
		{17, 1, 20},{18, 3, 16},{19, 5, 17},{20, 7, 18},{16, 9, 19}
	};
	
	private static double[][] initVertices() {
		/* source:Computer Graphics , F.S. Hill Jr. */
		double a = 1.0;
		double b = (Math.sqrt(5.0) - 1.0) / 2.0;
		double[][] vertices = new double[12][];
		
		for(int i = 0; i < 12; i++){
			double[] vec = new double[3];
			switch(i){
			case	0:
				vec[0] = b;		vec[1] = 0.0;	vec[2] = a;
				break;
			case	1:
				vec[0] = b;		vec[1] = 0.0;	vec[2] = -a;
				break;
			case	2:
				vec[0] = -b;	vec[1] = 0.0;	vec[2] = a;
				break;
			case	3:
				vec[0] = -b;	vec[1] = 0.0;	vec[2] = -a;
				break;
			case	4:
				vec[0] = a;		vec[1] = b;		vec[2] = 0.0;
				break;
			case	5:
				vec[0] = -a;	vec[1] = b;		vec[2] = 0.0;
				break;
			case	6:
				vec[0] = a;		vec[1] = -b;	vec[2] = 0.0;
				break;
			case	7:
				vec[0] = -a;	vec[1] = -b;	vec[2] = 0.0;
				break;
			case	8:
				vec[0] = 0.0;	vec[1] = a;		vec[2] = b;
				break;
			case	9:
				vec[0] = 0.0;	vec[1] = a;		vec[2] = -b;
				break;
			case	10:
				vec[0] = 0.0;	vec[1] = -a;	vec[2] = b;
				break;
			case	11:
				vec[0] = 0.0;	vec[1] = -a;	vec[2] = -b;
				break;
			}
			vertices[i] = vec;
		}
		
		return vertices;
	}

	private Icosahedron () {
		super();
	}

	
	/**
	 * Generate an Icosahedron.
	 * Returns a list of 20 facets.
	 *
	 * vk2gpz (vk2gpz@gmail.com)/2003-Sep-16
	*/
	static Facet[] getFacets() {
		double[][] vertices = initVertices();

		/* ------------------------ create facets ------------------------- */
		Facet[] facets = new Facet[20];		
		for (int i = 0; i < 20; i++) {
			facets[i] = new Facet();
		}
		
		for (int i = 0; i < 20; i++) {
			/* ------------------------ set vertex ------------------------ */
			facets[i].setVertices(vertices[VERTICES[i][0] - 1],
								  vertices[VERTICES[i][1] - 1],
								  vertices[VERTICES[i][2] - 1]);
			
			/* ---------------------- set neighbours ---------------------- */
			facets[i].setNeighbours(facets[NEIGHBOURS[i][0] - 1],
									facets[NEIGHBOURS[i][1] - 1],
									facets[NEIGHBOURS[i][2] - 1]);
			
		}
		return facets;
	}
}
