/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.geometry;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;
import java.util.*;

import com.vk2gpz.elmer.math.VecMath;

/*====================================================================
                    Implementation of class Facet                     
====================================================================*/
/**
 * Facet is a unit polygon to build a geodesic dome.
 * 
 * @version $Revision: 1.10 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public class Facet implements Serializable {
	int	facetNumber;				// serial number
	GeodesicDome gdome;	// instance of gdome which this facet belongs to
    final double[][] vertices;			// vertex (3 Vector)
    Facet parent;				// parent facet (1 Facet)
    final Facet[] children;			// child facets (4 Facet)
    final Facet[] neighbours;			// neighbor facets (3 Facet)
    boolean mark;
    final double[] normal;  // surface normal Vector ;is not unit vector.
    final boolean displayNormal;		// true:display surface normal

	Facet() {
		super();
		this.facetNumber = -1;
		this.gdome = null;
		this.vertices = new double[][] {{0.0, 0.0, 0.0},
										{0.0, 0.0, 0.0},
										{0.0, 0.0, 0.0}};
		this.parent = null;
		this.children = new Facet[4];
		this.neighbours = new Facet[3];
		this.mark = false;
		this.normal = new double[3];
		this.displayNormal = false;
	}
	
	Facet setVertices(double[] v0, double[] v1, double[] v2) {
		this.vertices[0] = v0;
		this.vertices[1] = v1;
		this.vertices[2] = v2;

		return this;
	}

	Facet setVertices(double[][] v) {
		return setVertices(v[0], v[1], v[2]);
	}
	
	double[][] getVertices(int coordinateSystem) {
		double[][] vlist = new double[3][3];
		if (coordinateSystem == GeometryUtil.WORLD_SYSTEM) {
			double[] position = this.gdome.getPosition();
			double radius = this.gdome.getRadius();
			vlist[0] = VecMath.add(position, VecMath.scale(radius, this.vertices[0], new double[3]));
			vlist[1] = VecMath.add(position, VecMath.scale(radius, this.vertices[1], new double[3]));
			vlist[2] = VecMath.add(position, VecMath.scale(radius, this.vertices[2], new double[3]));			
		} else {
			vlist[0] = this.vertices[0];
			vlist[1] = this.vertices[1];
			vlist[2] = this.vertices[2];
		}
		return vlist;
	}

	Facet setNeighbours(Facet f1, Facet f2, Facet f3) {
		this.neighbours[0] = f1;
		this.neighbours[1] = f2;
		this.neighbours[2] = f3;
		
		return this;
	}

	Facet setNeighbours(Facet[] f) {
		return setNeighbours(f[0], f[1], f[2]);
	}

	Facet[] getNeighbours() {
		return this.neighbours;
	}

	Facet setChildren(Facet f1, Facet f2, Facet f3, Facet f4) {
		this.children[0] = f1;
		this.children[1] = f2;
		this.children[2] = f3;
		this.children[3] = f4;

		return this;
	}

	Facet setChildren(Facet[] f) {
		return setChildren(f[0], f[1], f[2], f[3]);
	}

	boolean isLeaf() {
		for (Facet child : this.children) {
			if (child != null) {
				return false;
			}
		}
		return true;
	}
	
	Facet[] getChildren() {
		return this.children;
	}

	Facet setMark(boolean m) {
		this.mark = m;
		return this;
	}

	boolean getMark() {
		return this.mark;
	}

	Facet getParent() {
		return this.parent;
	}

	Facet setParent(Facet parent) {
		this.parent = parent;
		return this;
	}

	Facet setGeodesicDome(GeodesicDome gdome) {
		this.gdome = gdome;
		return this;
	}

	GeodesicDome getGeodesicDome() {
		return this.gdome;
	}
	
	Facet setFacetNumber(int number) {
		this.facetNumber = number;
		return this;
	}

	int getFacetNumber() {
		return this.facetNumber;
	}

	/**
	 * Returns a vertex which is part of child facets.
	 * This function reduces redundant vertex data by pasing the pointer.
	 * 
	 * vk2gpz (vk2gpz@gmail.com)/1993-Dec-08
	 */
	double[] getChildVertex(double[] aVertex) {
		for (int i = 0; i < 4; i++) {
			Facet child = this.children[i];
			if (child == null) {
				continue;
			}
			double[][] v1 = child.getVertices(GeometryUtil.NON_SYSTEM);
			for (int j = 0; j < 3; j++) {
				if (VecMath.equal(v1[j], aVertex)) {
					return v1[j];
				}
			}
		}
		return aVertex;
	}

	/**
	 * Returns a neighbor facet which is son of nfacet
	 * and is conncted at aVertex1 and aVertex2.
	 * nfacet		: neighboring facet
	 * aVertex1,2	: vertex (Vector)
	 * 
	 * previously known as - sonVx:aVertex1 :aVertex2
	 *                                        vk2gpz/1993-Dec-08
	 */
	Facet getNeighbourChild(double[] aVertex1, double[] aVertex2) {
		for (int i = 0; i < 3; i++) {
			Facet child = this.children[i];
			if (child == null) {
				continue;
			}
			int icnt = 0;
			double[][] v1 = child.getVertices(GeometryUtil.NON_SYSTEM);
			for (int j = 0; j < 3; j++) {
				if (VecMath.equal(v1[j], aVertex1)) {
					icnt++;
				} else if (VecMath.equal(v1[j], aVertex2)) {
					icnt++;
				}
			}
			if (icnt == 2) {
				return child;
			}
		}
		return null;
	}

	/**
	   |- subdiv1:limitbox :pos :(double)radius :(int)isw :facetList| 
	   Subdivision of a facet into four small facets
	   (1st phase)
	   isw : switch to select facet (isw=0) or facetl (isw=1)
	   New son facets are stored in facetList
	   which is a list of facetlist.
	   vk2gpz/1993-Dec-08
	*/
	Facet subdiv1(SurroundingBox limitbox, double[] pos, double radius, int isw, Vector facetList) {
		setMark(true); // this mark is used to indicate already visited

		/* ----------------- Get vertex data of the facet ----------------- */
		double[][] a = getVertices(GeometryUtil.NON_SYSTEM);
		Vector a1 = new Vector();
		a1.add(VecMath.copy(a[0]));
		a1.add(VecMath.copy(a[1]));
		a1.add(VecMath.copy(a[2]));		
		
		Facet[] ns = getNeighbours();
		Vector vs = new Vector();
		vs.add(VecMath.scale(radius, VecMath.normalize(VecMath.add(a[0], a[1])), null));
		vs.add(VecMath.scale(radius, VecMath.normalize(VecMath.add(a[1], a[2])), null));
		vs.add(VecMath.scale(radius, VecMath.normalize(VecMath.add(a[2], a[0])), null));
		
		for (int i = 0; i < 3; i++){
			Facet n1 = ns[i];
			double[] v = (double[]) vs.get(i);
			double[] v1 = v;
			if (n1.getMark()) {	/* n1 was already visited */
				v1 = n1.getChildVertex(v);
			}
			a1.add(v1);
		}
		
		SurroundingBox tempbox = new SurroundingBox();
		Vector b1 = new Vector();
		double[][] tempList = new double[3][];
		
		for (Object o : a1) {
			double[] vec = (double[]) o;
			VecMath.normalize(vec);
			b1.add(VecMath.add(pos, VecMath.scale(radius, vec, null)));
		}
		
		tempList[0] = (double[]) b1.get(0);
		tempList[1] = (double[]) b1.get(3);
		tempList[2] = (double[]) b1.get(5);
		tempbox.set(tempList);
		this.children[0] = null;
		if (tempbox.intersectWith(limitbox)) {
			if (isw == 0)
				this.children[0] = new Facet();
			else
				this.children[0] = new FacetLeaf();
			this.children[0].setVertices((double[]) a1.get(0),
							 (double[]) a1.get(3),
							 (double[]) a1.get(5));
			this.children[0].setParent(this);
			facetList.add(0, this.children[0]);
		}
		
		tempList[0] = (double[]) b1.get(3);
		tempList[1] = (double[]) b1.get(1);
		tempList[2] = (double[]) b1.get(4);				
		tempbox.set(tempList);
		this.children[1] = null;		
		if (tempbox.intersectWith(limitbox)) {
			if (isw == 0)
				this.children[1] = new Facet();
			else
				this.children[1] = new FacetLeaf();
			this.children[1].setVertices((double[]) a1.get(3),
							 (double[]) a1.get(1),
							 (double[]) a1.get(4));
			this.children[1].setParent(this);
			facetList.add(0, this.children[1]);
		}
		
		tempList[0] = (double[]) b1.get(5);
		tempList[1] = (double[]) b1.get(4);
		tempList[2] = (double[]) b1.get(2);				
		tempbox.set(tempList);
		this.children[2] = null;
		if (tempbox.intersectWith(limitbox)) {
			if (isw == 0)
				this.children[2] = new Facet();
			else
				this.children[2] = new FacetLeaf();
			this.children[2].setVertices((double[]) a1.get(5),
							 (double[]) a1.get(4),
							 (double[]) a1.get(2));
			this.children[2].setParent(this);
			facetList.add(0, this.children[2]);
		}
		
		tempList[0] = (double[]) b1.get(3);
		tempList[1] = (double[]) b1.get(4);
		tempList[2] = (double[]) b1.get(5);				
		tempbox.set(tempList);
		this.children[3] = null;
		if (tempbox.intersectWith(limitbox)) {
			if (isw == 0)
				this.children[3] = new Facet();
			else
				this.children[3] = new FacetLeaf();
			this.children[3].setVertices((double[]) a1.get(3),
							 (double[]) a1.get(4),
							 (double[]) a1.get(5));
			this.children[3].setParent(this);
			facetList.add(0, this.children[3]);
		}
		
		/* ----------------- Store neighbor facet of SON4 ----------------- */
		if (this.children[3] != null) 
			this.children[3].setNeighbours(this.children[1], this.children[2], this.children[0]);
		
		return this;
	}

	/**
	   |- subdiv2:facetList| 
	   2nd phase of subdivision, find neighboring facets.
	   vk2gpz/1993-Dec-08
	*/
	Facet subdiv2(Vector facetList) {
		/* id for neighbor facets */
		Facet n1 = this.neighbours[0];
		Facet n2 = this.neighbours[1];
		Facet n3 = this.neighbours[2];
		Facet dn1, dn2, dn3;	/* id for neighbor facets */
		
		/* --------------------------- for son1 --------------------------- */
		if (this.children[0] != null) {
			double[][] v = this.children[0].getVertices(GeometryUtil.NON_SYSTEM);
			if (n1 == null) 
				dn1 = null;
			else
				dn1 = n1.getNeighbourChild(v[0], v[1]);
			dn2 = this.children[3];
			if (n3 == null)
				dn3 = null;
			else
				dn3 = n3.getNeighbourChild(v[0], v[2]);
			this.children[0].setNeighbours(dn1, dn2,dn3);
		}
		/* --------------------------- for son2 --------------------------- */
		if (this.children[1] != null) {
			double[][] v = this.children[1].getVertices(GeometryUtil.NON_SYSTEM);
			if (n1 == null) 
				dn1 = null;
			else
				dn1 = n1.getNeighbourChild(v[0], v[1]);
			if (n2 == null)
				dn2 = null;
			else
				dn2 = n2.getNeighbourChild(v[1], v[2]);
			dn3 = this.children[3];
			this.children[1].setNeighbours(dn1, dn2,dn3);
		}
		/* --------------------------- for son3 --------------------------- */
		if (this.children[2] != null) {
			double[][] v = this.children[2].getVertices(GeometryUtil.NON_SYSTEM);
			dn1 = this.children[3];			
			if (n2 == null) 
				dn2 = null;
			else
				dn2 = n2.getNeighbourChild(v[1], v[2]);
			if (n3 == null)
				dn3 = null;
			else
				dn3 = n3.getNeighbourChild(v[0], v[2]);
			this.children[2].setNeighbours(dn1, dn2,dn3);
		}
		
		return this;
	}

	/**
	   |- normal| 
	   
	   vk2gpz/1993-Dec-08
	*/
	double[] getNormal() {
		double[][] vs = getVertices(GeometryUtil.NON_SYSTEM);
		double[] v0 = VecMath.add(VecMath.add(vs[0], vs[1]), vs[2]);
		VecMath.normalize(v0);
		
		return v0;
	}

	/**
	   |- centroid| 
	   
	   vk2gpz/1993-Dec-08
	*/
	double[] getCentroid() {
		double[][] vs = getVertices(GeometryUtil.WORLD_SYSTEM);
		double[] cv = VecMath.add(VecMath.add(vs[0], vs[1]), vs[2]);
		VecMath.scale(1.0 / 3.0, cv);

		return cv;
	}
	
	/**
	   |- (BOOL)visible:aVector| 
	   
	   vk2gpz/1993-Dec-08
	*/
	boolean isVisibleFrom(double[] point) {
		double[] normal = getNormal();
		double[] vec1 = VecMath.subtract(point, getCentroid());
		return VecMath.dot(normal, vec1) >= 0.0;
	}

	/**
	   |- nineNeighbor| 
	   
	   vk2gpz/1993-Dec-08
	*/
	Facet[] getNineNeighbours() {
		Vector neib9 = new Vector();
		Facet[] neibl = getNeighbours();
		
		for (int i = 0; i < 3; i++) {
			Facet nf = neibl[i];
			if (nf != null) {
				neib9.add(0, nf);
				Facet[] neibl2 = nf.getNeighbours();
				for (Facet facet : neibl2) {
					if (facet != this)
						neib9.add(facet);
				}
			}
		}
		return (Facet[]) neib9.toArray(new Facet[0]);
	}
	
	/**
	   |- (double)edgeLength| 
	   
	   vk2gpz/1994-May-27
	*/
	double getEdgeLength() {
		double tmp = VecMath.distance(this.vertices[0], this.vertices[1]);
		tmp += VecMath.distance(this.vertices[0], this.vertices[2]);
		tmp += VecMath.distance(this.vertices[1], this.vertices[3]);

		return (tmp / 3.0);
	}
}
