/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
               Implementation of class StirlingNumbers                
====================================================================*/
/**
 * StirlingNumbers provides a methods to compute Stirling numbers of
 * the first and second kinds.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class StirlingNumbers {
	private StirlingNumbers() {
		super();
	}
	
	/**
	* Returns a Stirling numbers of the first kind.
	*/
	public static double getStirling1(int n, int k) {
		if (k < 1 || k > n) {
			return 0;
		}
		if (k == n) {
			return 1;
		}
		return (n - 1) * getStirling1(n - 1, k) + getStirling1(n - 1, k - 1);
	}

	/**
	* Returns a Stirling numbers of the second kind.
	*/
	public static double getStirling2(int n, int k) {
		if (k < 1 || k > n) {
			return 0;
		}
		if (k == 1 || k == n) {
			return 1;
		}
		return k * getStirling2(n - 1, k) + getStirling2(n - 1, k - 1);
	}
}

