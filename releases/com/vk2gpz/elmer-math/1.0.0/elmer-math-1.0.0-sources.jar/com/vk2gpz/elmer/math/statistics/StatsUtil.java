/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.statistics;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
                  Implementation of class StatsUtil                   
====================================================================*/
/**
 * StatsUtils provides various useful methods.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class StatsUtil {
	private StatsUtil() {
		super();
	}
	
	/**
	 * Computes the mean and standard deviation of a given array.
	 * This methods tries to minimize rounding error.
	 */
	public static double[] getMeanAndStdDev(double[] a, double[] ans) {
		// ans[0] = mean, ans[1] = std.
		if (ans == null) {
			ans = new double[2];
		}
		int n = 0;
		double x;
		
		for (int i = a.length - 1; i >= 0; i--) {
			n++;
			x = a[i];
			x -= ans[0];
			ans[0] += x / n;
			ans[1] += (n - 1) * x * x / n;
		}
		ans[1] = Math.sqrt(ans[1] / (n - 1));
		return ans;
	}

	/**
	 * Returns a correlation coefficient of two arrays.
	 */
	public static double getCorrelationCoefficient(double[] x, double[] y) {
		int n = x.length;
		double sx, sy, sxx, syy, sxy, dx, dy;
		sx = sy = sxx = syy = sxy = 0.0;
		for (int i = 0; i < n; i++) {
			dx = x[i] - sx;
			sx += dx / (i + 1);
			dy = y[i] - sy;
			sy += dy / (i + 1);
			sxx += i * dx * dx / (i + 1);
			syy += i * dy * dy / (i + 1);
			sxy += i * dx * dy / (i + 1);
		}
		sxx = Math.sqrt(sxx / (n - 1));
		syy = Math.sqrt(syy / (n - 1));
		sxy /= (n - 1) * sxx * syy;

		return sxy;
	}

	/**
	* Returns a correlation coefficient matrix.
	*/
	public static double[][] getCorrelationCoefficientMatrix(double[][] x, double[][] r, double[] mean, double[] sdev) {
		int n = x.length;		// n row
		int m = x[0].length;	// m column
		double t;
		
		for (int i = 0; i < n; i++) {
			for (int j= 0; j < m; j++) {
				t = x[n][m];
				sdev[j] = t - mean[j];
				mean[j] += sdev[j] / (i + 1);
				for (int k = 0; k <= j; k++) {
					r[j][k] += i * sdev[j] * sdev[k] / (i + 1);
				}
			}
		}
		t = 1.0 / Math.sqrt(n - 1.0);		
		for (int j = 0; j < m; j++) {
			sdev[j] = Math.sqrt(r[j][j]);
			r[j][j] = 1;
			for (int k = 0; k < j; k++) {
				r[j][k] /= sdev[j] * sdev[k];
				r[k][j] = r[j][k];
			}
			sdev[j] = t * sdev[j]; // standard deviation.
		}
		return r;
	}
}

