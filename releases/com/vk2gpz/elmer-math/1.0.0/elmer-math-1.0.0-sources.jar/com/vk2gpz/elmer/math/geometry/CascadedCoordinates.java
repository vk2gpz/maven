/*
 * Copyright (c) 1994-2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.geometry;

/* ------------------ Import classes (packages) ------------------- */
import java.util.*;

import com.vk2gpz.elmer.debug.DebugHandler;
import com.vk2gpz.elmer.math.VecMath;

/*====================================================================
             Implementation of class CascadedCoordinates              
====================================================================*/
/**
 * generally describe CascadedCoordinates in here
 * 
 * @version $Revision: 1.4 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Coordinates
 */

class CascadedCoordinates extends Coordinates {
	/**
	 * debug flag
	 */
	private static final boolean DEBUG = DebugHandler.isDebugged(CascadedCoordinates.class);

	CascadedCoordinates parent;	// a coordinates id of parent 
	Vector descendants;			// a list id of childs
	Coordinates worldcoords;	// a coordinates id of worldcoords 
	Coordinates manager;	
	boolean changed;

	CascadedCoordinates() {
		super();
		this.manager = this;
		this.changed = true;
		if (DEBUG) {
			System.out.println("CascadedCoordinates: before new Coordinates");
		}
		this.worldcoords = new Coordinates();
		this.worldcoords.set(this.rotation, this.position);
		this.parent = null;
		if (DEBUG) {
			System.out.println("CascadedCoordinates: after new Coordinates");
		}
		this.descendants = new Vector();
	}

	CascadedCoordinates(double[] position, double[][] rotation,
						double[] euler, double[] rpy,
						double[] axis, double[][] angles,
						Coordinates coords,
						double[][] mat44, int cods, Coordinates wrt,
						CascadedCoordinates parent, Coordinates atCods) {
		super(position, rotation, euler, rpy, axis, angles, coords, mat44, cods, wrt);
		this.manager = this;
		this.changed = true;
		this.worldcoords = new Coordinates();
		this.worldcoords.set(this.rotation, this.position);
		this.parent = parent;
		this.descendants = new Vector();
		if (this.parent != null) 
			this.parent.associateWith(this, atCods);
	}

	/**
	   |- reset| 
	   
	   vk2gpz/1994-Feb-10
	*/
	Coordinates reset() {
		super.reset();
    
		this.manager = this;
		this.changed = true;
		this.worldcoords = new Coordinates();
		this.worldcoords.set(this.rotation, this.position);
		this.parent = null;
		this.descendants = new Vector();

		return this;
	}

	/**
	   |- parent| 
	   
	   vk2gpz/1994-Feb-04
	*/
	CascadedCoordinates getParent() {
		return this.parent;
	}

	/**
	   |- descendants| 
	   
	   vk2gpz/1994-Feb-04
	*/
	Vector getDescendants() {
		return this.descendants;
	}

	/**
	   |- inheritance| 

	   vk2gpz/1994-Feb-04
	*/
	Vector getInheritance() {
		Vector inheriList = new Vector();
		int size = this.descendants.size();
		for (Object descendant : this.descendants) {
			Vector inlist = new Vector();
			CascadedCoordinates cc = (CascadedCoordinates) descendant;
			inheriList.add(cc);
			inheriList.addAll(cc.getInheritance());
		}
		
		return inheriList;
	}

	/**
	   |- leaves:leavesList| 

	   vk2gpz/1994-Feb-04
	*/
	CascadedCoordinates getLeaves(Vector leaves) {
		if (this.descendants.size() > 0) {
			int size = this.descendants.size();
			for (Object descendant : this.descendants) {
				((CascadedCoordinates) descendant).getLeaves(leaves);
			}
		} else {
			leaves.add(this);
		}
		return this;
	}
	
	/**
	   |- associateWith:aChild :aRelative| 
	   
	   vk2gpz/1994-Feb-04
	*/
	CascadedCoordinates associateWith(CascadedCoordinates aChild, Coordinates aRelative) {
		if (! this.descendants.contains(aChild)) {
			if (aRelative == null)
				aRelative = getWorldCoordinates().transformation(aChild.getWorldCoordinates(), GeometryUtil.LOCAL_SYSTEM, null);
			aChild.obey(this);
			aChild.set(aRelative.getRotation(), aRelative.getPosition());
			this.descendants.add(0, aChild);
		}
		
		return aChild;
	}

	/**
	   |- dissociate:aChild| 

	   vk2gpz/1994-Feb-04
	*/
	CascadedCoordinates dissociate(CascadedCoordinates aChild) {
		if (this.descendants.contains(aChild)) {
			Coordinates c = aChild.getWorldCoordinates().copy();
			this.descendants.remove(aChild);
			aChild.disobey(this);
			aChild.set(c.getRotation(), c.getPosition());

			return aChild;
		}
        
		return this;
	}
	
	/**
	   |- clearAssociation| 
	   remove all the association
	   vk2gpz/1994-Feb-04
	*/
	CascadedCoordinates clearAssociation() {
		while( this.descendants.size() > 0) {
			dissociate((CascadedCoordinates) this.descendants.get(0));
		}
		
		return this;
	}
	
	/**
	   |- obey:aMother| 
	   only for internal use
	   vk2gpz/1994-Feb-04
	*/
	CascadedCoordinates obey(CascadedCoordinates aMother) {
		if (this.parent != null) 
			this.parent.dissociate(this);
		this.parent = aMother;
		
		return this;
	}

	/**
	   |- disobey:aMother| 
	   only for internal use
	   vk2gpz/1994-Feb-04
	*/
	CascadedCoordinates disobey(CascadedCoordinates aMother) {
		if (aMother == this.parent)
			this.parent = null;
		
		return this.parent;
	}

	/**
	   |- newcoordsWithRot:newrot pos:newpos| 
	  
	  vk2gpz/1994-Feb-04
	*/
	Coordinates set(double[][] newrot, double[] newpos) {
		super.set(newrot, newpos);
		changed();
    
		return this;
	}

	/**
	   |- newcoordsWithCoords:newcoords| 
	   
	   vk2gpz/1994-Feb-04
	*/
	Coordinates set(Coordinates newcoords) {
		super.set(newcoords);
		changed();
    
		return this;
	}

	/**
	   |- changed| 
	   
	   vk2gpz/1994-Feb-04
	*/
	CascadedCoordinates changed() {
		if (! this.changed){	// is this the first change? 
			this.changed = true; //Then, propagate changed signal.
			int size = this.descendants.size();
			for (Object descendant : this.descendants) {
				Coordinates c = (Coordinates) descendant;
				if (c instanceof CascadedCoordinates)
					((CascadedCoordinates) c).changed();
			}
		}
		
		return this;
	}

	/**
	   |- worldRotation| 
	   
	   vk2gpz/1994-Feb-04
	*/
	double[][] getWorldRotation() {
		return getWorldCoordinates().getRotation();
	}

	/**
	   |- worldPosition| 
	   
	   vk2gpz/1994-Feb-04
	*/
	double[] getWorldPosition() {
		return getWorldCoordinates().getPosition();
	}

	/**
	   |- worldCoords| 
	   calculate rot and pos in the world
	   vk2gpz/1994-Feb-04
	*/
	Coordinates getWorldCoordinates() {
		if (this.changed) {
			if (this.parent != null) {
				transformCoordinates(this.parent.getWorldCoordinates(),
									 this,
									 this.worldcoords);
				this.worldcoords.set(this);
			}
			this.update();
			this.changed = false;
		}
		
		return this.worldcoords;
	}

	/**
	   |- copyWorldCoords:result| 
	   
	   vk2gpz/1994-Feb-04
	*/
	Coordinates copyWorldCoordinates(Coordinates result) {
		if (result == null) {
			result = new Coordinates();
			result.set(this.position.length);
		}
		getWorldCoordinates();
		result.setPosition(this.worldcoords.getPosition());
		result.setRotation(this.worldcoords.getRotation());
		
		return result;
	}
	
	/**
	   |- update| 
	   
	   vk2gpz/1994-Feb-04
	*/
	CascadedCoordinates update() {
		return this;
	}
	
	/**
	   |- parentCoords| 
	   
	   vk2gpz/1994-Feb-04
	*/
	Coordinates getParentCoordinates() {
		if (this.parent != null) 
			return this.parent.getWorldCoordinates();

		return WORLD_COORDS;
	}

	/**
	   |- transformVector:aVector| 
	   
	   vk2gpz/1994-Feb-04
	*/
	double[] transformVector(double[] aVector) {
		return getWorldCoordinates().transformVector(aVector);
	}
	
	/**
	   |- rotateVector:aVector| 
	   
	   vk2gpz/1994-Feb-04
	*/
	double[] rotateVector(double[] aVector) {
		return getWorldCoordinates().rotateVector(aVector);
	}
	
	/**
	   |- inverseTransformVector:aVector| 
	   
	   vk2gpz/1994-Feb-04
	*/
	double[] inverseTransformVector(double[] aVector) {
		return getWorldCoordinates().inverseTransformVector(aVector);
	}
	
	/**
	   |- inverseTransformation:result| 
	   
	   vk2gpz/1994-Feb-04
	*/
	Coordinates inverseTransformation() {
		return getWorldCoordinates().inverseTransformation();
	}
	
	/**
	   |- transformation:aCoords in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-04
	*/
	Coordinates transformation(Coordinates aCoords, int cods, Coordinates wrt) {
		Coordinates w2 = aCoords.getWorldCoordinates();
		Coordinates w1 = getWorldCoordinates();
		Coordinates w1inv = w1.inverseTransformation();
		Coordinates result = null;
		
		if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this) 
			result = transformCoordinates(w1inv, w2, w1inv);
		else if(cods == GeometryUtil.PARENT_SYSTEM || wrt == this.parent) {
			Coordinates c1inv =  super.inverseTransformation();
			transformCoordinates(w2, c1inv, c1inv);
			transformCoordinates(w1inv, c1inv, c1inv);
			result = transformCoordinates(this, c1inv, c1inv);
		} else if (cods == GeometryUtil.WORLD_SYSTEM || wrt == WORLD_COORDS)
			result = transformCoordinates(w2, w1inv, w1inv);
		else if (wrt != null) {
			Coordinates xw = wrt.getWorldCoordinates();
			transformCoordinates(w1inv, xw, w1inv);
			transformCoordinates(w2, w1inv, w1inv);
			result = transformCoordinates(xw.inverseTransformation(),
										  w1inv,
										  w1inv);
		} else
			return null;
		
		return result;
	}
	
	/**
	  |- transform:aCoords in:(int)cods wrt:aWrt| 

	  vk2gpz/1994-Feb-04
	*/
	Coordinates transform(Coordinates aCoords, int cods, Coordinates wrt) {
		if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this)
			/* multiply  aCoords from the right */
			transformCoordinates(this, aCoords, this);
		else if (cods == GeometryUtil.PARENT_SYSTEM || wrt == this.parent)
			/* multiply aCoords from the left */
			transformCoordinates(aCoords, this, this);
		else if (cods == GeometryUtil.WORLD_SYSTEM || wrt == WORLD_COORDS) {
			Coordinates pc = getParentCoordinates();
			transformCoordinates(pc, this, this);
			transformCoordinates(aCoords, this, this);
			transformCoordinates(pc.inverseTransformation(), this, this);
		} else if (wrt != null) {
			Coordinates pc = getParentCoordinates();
			transformCoordinates(pc, this, this);
			transformCoordinates(wrt.inverseTransformation(), this, this);
			transformCoordinates(aCoords, this, this);
			transformCoordinates(wrt.getWorldCoordinates(), this, this);
			transformCoordinates(pc.inverseTransformation(), this, this);
		}
		else{
			return null;
		}
		set(this.rotation, this.position);

		return this;
	}

	/**
	   |- moveTo:trans in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-04
	*/
	Coordinates move(Coordinates trans, int cods, Coordinates wrt) {
		if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this) {
			Coordinates cc = transformCoordinates(this, trans, null);
			set(cc);
		}
		else if (cods == GeometryUtil.PARENT_SYSTEM || wrt == this.parent)
			set(trans);
		else if (cods == GeometryUtil.WORLD_SYSTEM || wrt == WORLD_COORDS) {
			Coordinates cc = transformCoordinates(getParentCoordinates().inverseTransformation(), trans, null);
			set(cc);
		} else if (wrt != null) {
			Coordinates cc =  transformCoordinates(wrt.getWorldCoordinates(),
												   trans, null);
			transformCoordinates(getParentCoordinates().inverseTransformation(), cc, cc);
			set(cc);
		}
		
		return this;
	}

	/**
	   |- rotateWithMatrix:aMatrix in:(int)cods wrt:aWrt| 
	   only for internal use
	   vk2gpz/1994-Feb-04
	*/
	Coordinates rotate(double[][] aMatrix, int cods, Coordinates wrt) {
		if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this) {
			setRotation(VecMath.multiply(this.rotation, aMatrix));
		} else if (cods == GeometryUtil.PARENT_SYSTEM || wrt == this.parent){
			setRotation(VecMath.multiply(aMatrix, this.rotation));
		} else {
			Coordinates pc = getParentCoordinates();
			double[][] pr = pc.getRotation();
			if (wrt != null) {
				double[][] wrtrot = wrt.getWorldRotation();
				aMatrix = VecMath.multiply(wrtrot, aMatrix);
				aMatrix = VecMath.multiply(aMatrix, VecMath.transpose(wrtrot));
			}
			aMatrix = VecMath.multiply(aMatrix, pr);
			aMatrix = VecMath.multiply(VecMath.transpose(pr), aMatrix);
			setRotation(VecMath.multiply(aMatrix, this.rotation));
		}
		
		return this;
	}

	/**
	   |- rotateBy:(double)theta around:(int)axis in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-04
	*/
	Coordinates rotate(double theta, int axis, int cods, Coordinates wrt) {
		if (this.position.length == 2)	/* 2-dimension */
			super.rotate(theta, axis, cods, wrt);
		else{
			if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this) {
				setRotation(GeometryUtil.rotateMatrix(this.rotation,
													  theta,
													  axis,
													  GeometryUtil.LOCAL_SYSTEM));
			} else if (cods == GeometryUtil.PARENT_SYSTEM || wrt == this.parent){
				setRotation(GeometryUtil.rotateMatrix(this.rotation,
													  theta,
													  axis,
													  GeometryUtil.WORLD_SYSTEM));
			} else
				rotate(GeometryUtil.getRotationMatrix(theta, axis), cods,  wrt);
		}
		
		return this;
	}
	
	/**
	   |- rotateBy:(double)theta aroundVector:axisVec in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-04
	*/
	Coordinates rotate(double theta, double[] axisVec, int cods, Coordinates wrt) {
		if (this.position.length == 2)	/* 2-dimension */
			super.rotate(theta, axisVec, cods, wrt);
		else 
			rotate(GeometryUtil.getRotationMatrix(theta, axisVec), cods, wrt);
		
		return this;
	}

	/**
	   |- rotateByMatrix:theta around:(int)axis in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-04
	*/
	Coordinates rotate(double[][] theta, int axis, int cods, Coordinates wrt) {
		if (this.position.length == 2)	/* 2-dimension */
			super.rotate(theta, axis, cods, wrt);
		else 
			rotate(theta, cods, wrt);
		
		return this;
	}

	/**
	   |- orientWithMatrix:aMatrix in:(int)cods wrt:aWrt| 
	   only for internal use
	   vk2gpz/1994-Feb-04
	*/
	Coordinates orient(double[][] aMatrix, int cods, Coordinates wrt) {
		if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this) {
			setRotation(VecMath.multiply(this.rotation, aMatrix));
		} else if (cods == GeometryUtil.PARENT_SYSTEM || wrt == this.parent){
			setRotation(aMatrix);
		} else {
			Coordinates pc = getParentCoordinates();
			double[][] pr = pc.getRotation();
			if (wrt != null) {
				double[][] wrtrot = wrt.getWorldRotation();
				aMatrix = VecMath.multiply(wrtrot, aMatrix);
			}
			setRotation(VecMath.multiply(VecMath.transpose(pr), aMatrix));
		}
		
		return this;
	}

	/**
	   |- orientBy:(double)theta aroundVector:axisVec in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-04
	*/
	Coordinates orient(double theta, double[] axisVec, int cods, Coordinates wrt) {
		if (axisVec != null) 
			orient(GeometryUtil.getRotationMatrix(theta, axisVec), cods, wrt);
		else{
			return null;
		}
		
		return this;
	}

	/**
	   |- orientByMatrix:theta around:(int)axis in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-04
	*/
	Coordinates orient(double[][] theta, int axis, int cods, Coordinates wrt) {
		if (theta != null)
			orient(theta, cods, wrt);
		else {
			return null;
		}
		return this;
	}

	/**
	   |- orientBy:(double)theta around:(int)axis in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-04
	*/
	Coordinates orient(double theta, int axis, int cods, Coordinates wrt) {
		if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this) {
			setRotation(GeometryUtil.rotateMatrix(this.rotation,
												  theta,
												  axis,
												  GeometryUtil.LOCAL_SYSTEM));
		} else if (cods == GeometryUtil.PARENT_SYSTEM || wrt == this.parent) {
			setRotation(GeometryUtil.getRotationMatrix(theta, axis));
		} else
			orient(GeometryUtil.getRotationMatrix(theta, axis), cods, wrt);
		
		return this;
	}
	
	/**
	   |- parentVector:aVector in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-04
	*/
	double[] parentVector(double[] aVector, int cods, Coordinates wrt) {
		if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this)
			return super.transformVector(aVector);
		else if (cods == GeometryUtil.PARENT_SYSTEM || wrt == this.parent)
			return aVector;
		else {
			if (wrt != null)
				aVector = wrt.transformVector(aVector);
			if (this.parent != null)
				return this.parent.inverseTransformVector(aVector);
			else
				return aVector;
		}
	}

	/**
	   |- parentOrientation:aVector in:(int)cods wrt:aWrt| 
	   
	   vk2gpz/1994-Feb-04
	*/
	double[] parentOrientation(double[] aVector, int cods, Coordinates wrt) {
		double[] result = null;
		if (cods == GeometryUtil.LOCAL_SYSTEM || wrt == this)
			result = VecMath.multiply(this.rotation, aVector);
		else if (cods == GeometryUtil.PARENT_SYSTEM || wrt == this.parent)
			result = aVector;
		else {
			if (wrt != null)
				aVector = VecMath.multiply(wrt.getWorldRotation(), aVector);
			if (this.parent != null) 
				result = VecMath.multiply(VecMath.transpose(this.parent.getWorldRotation()), aVector);
			else
				result = aVector;
		}
		
		return result;
	}
	
	/**
	   |- manager:aManager| 
	   
	   vk2gpz/1994-Feb-04
	   --------------------------------------------------------------------*/
	Coordinates setManager(CascadedCoordinates aManager) {
		
		if (aManager != null) 
			this.manager = aManager;
		
		return this.manager;
	}
}
