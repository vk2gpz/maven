/*
 * Copyright (c) 1993-2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.geometry;

/* ------------------ Import classes (packages) ------------------- */
import java.util.*;

import com.vk2gpz.elmer.debug.DebugHandler;
import com.vk2gpz.elmer.math.VecMath;

/*====================================================================
                 Implementation of class GeodesicDome                 
====================================================================*/
/**
 * generally describe GeodesicDome in here
 * 
 * @version $Revision: 1.9 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public class GeodesicDome extends CascadedCoordinates {
	/**
	 * debug flag
	 */
	private static final boolean DEBUG = DebugHandler.isDebugged(GeodesicDome.class);

	static final int LAST = -1;		// last level
	
	double radius;				// radius
	int maxLevel;				// maximum level of subdivision
	final Vector facets;				// a Vector of Vectors
	
	GeodesicDome() {
		super();
		this.radius = 1.0;
		this.maxLevel = 0;
		this.facets = new Vector();
	}

	/**
	   |- initWithPosition:posi Radius:(double)radi Level:(int)level Limit:limitbox| 
	   initialize of a geodesic dome
	   posi : = (x,y,z) position of the dome (Vector)
	   radi : radius of the dome
	   level : maximum level of subdivision
	   limitbox : bounding box to limit Facet (must be defined)
	   only facets which intersects with limitbox are created.
	   vk2gpz/1993-Dec-08
	*/
	
	public GeodesicDome(double[] position, double radius, int level, SurroundingBox limitbox) {
		this();
		SurroundingBox glimitbox = null;
		if (limitbox == null) {
			glimitbox = new SurroundingBox();
			double largeval = 1000000;
			double[][] vlist = new double[2][];
			vlist[0] = new double[]{largeval, largeval, largeval};
			double nlargeval = -1 * largeval;
			vlist[1] = new double[]{nlargeval, nlargeval, nlargeval};	
			glimitbox.set(vlist);
		} else
			glimitbox = limitbox;

		if (position != null && position.length == 3) {
			setPosition(VecMath.copy(position));
		} else {
			setPosition(new double[]{0, 0, 0});
		}
		this.radius = radius;
		this.maxLevel = level;
		Facet[] tmpfs = Icosahedron.getFacets();

		/* scale every vertex by radius */
		for (Facet tmpf : tmpfs) {
			double[][] vlst = tmpf.getVertices(GeometryUtil.NON_SYSTEM);
			for (double[] doubles : vlst) {
				VecMath.normalize(doubles);
				VecMath.scale(this.radius, doubles);
			}
		}
		
		SurroundingBox tmpbox = new SurroundingBox();
		Vector fs = new Vector();
		for (Facet tmpf : tmpfs) {
			tmpf.setGeodesicDome(this);
			tmpbox.set(tmpf.getVertices(GeometryUtil.WORLD_SYSTEM));
			tmpf.setMark(false);
			if (tmpbox.boxintp(glimitbox)) {
				fs.add(0, tmpf);
				tmpf.setMark(true);
			}
		}
		
		for (Facet tmpf : tmpfs) {
			Facet[] nl = tmpf.getNeighbours();
			Facet n1 = nl[0];
			Facet dn1 = null;
			if (!n1.getMark())
				dn1 = null;
			else
				dn1 = n1;
			Facet n2 = nl[1];
			Facet dn2 = null;
			if (!n2.getMark())
				dn2 = null;
			else
				dn2 = n2;
			Facet n3 = nl[2];
			Facet dn3 = null;
			if (!n3.getMark())
				dn3 = null;
			else
				dn3 = n3;
			tmpf.setNeighbours(dn1, dn2, dn3);
		}
		
		this.facets.add(fs);
		if (this.maxLevel > 0) {
			for (int i = 0; i < this.maxLevel; i++) {
				int fsSize = fs.size();
				for (int j = 0; j < fsSize; j++)
					((Facet) fs.get(j)).setMark(false);
				Vector facetList = new Vector();
				/* ------------------- first phase ------------------------ */
				int flag = (i == (this.maxLevel - 1)) ? 1 : 0;
				for (int j = 0; j < fsSize; j++)
					((Facet) fs.get(j)).subdiv1(glimitbox,
												this.position,
												radius,
												flag,
												facetList);
				/* -------------------- second phase ----------------------- */
				for (int j = 0; j < fsSize; j++)
					((Facet) fs.get(j)).subdiv2(facetList);
				fs = facetList;
				fsSize = fs.size();
				for (int j = 0; j < fsSize; j++)
					((Facet) fs.get(j)).setGeodesicDome(this);
				this.facets.add(fs);
			}
		}
		setFacetNumbers();
	}
	
	/**
	   |- (double)radius| 
	   
	   vk2gpz/1993-Dec-11
	*/
	double getRadius() {
		return this.radius;
	}
	
	/**
	   |- (double)angleToNext| 
	   
	   vk2gpz/1993-Dec-11
	*/
	double getAngleToNext() {
		double	angle = 0.0;
		
		Facet fct = getFacet(0);
		Facet[] neib = fct.getNeighbours();
		
		for (Facet facet : neib) angle += VecMath.angle(fct.getNormal(), facet.getNormal());
		angle = Math.toDegrees(angle / neib.length);
		
		return angle;
	}
	
	/**
	   |- (int)level| 
	   
	   vk2gpz/1994-Feb-24
	*/
	int level() {
		return this.maxLevel;
	}
	
	/**
	   |- allVertex| 
	   
	   vk2gpz/1993-Dec-11
	*/
	Vector getAllVertices() {
		Vector va = new Vector();
		
		for (int i = 0; i < this.maxLevel + 1; i++) {
			Vector fl = (Vector) this.facets.get(i);
			int size = fl.size();
			for (Object o : fl) {
				Facet f = (Facet) o;
				double[][] vl = f.getVertices(GeometryUtil.NON_SYSTEM);
				va.add(0, vl[0]);
				va.add(0, vl[1]);
				va.add(0, vl[2]);
			}
		}
		
		return va;
	}

	/**
	   |- allVertexAtLevel:(int)level| 
	   
	   vk2gpz/1994-Mar-03
	*/
	Vector getAllVerticesAt(int level) {
		Vector nfl = null;

		if (level == LAST)
			nfl = (Vector) this.facets.lastElement();
		else if (level <= this.maxLevel)
			nfl = (Vector) this.facets.get(level);
		else
			return null;
		int size = nfl.size();
		Vector va = new Vector();
		for (Object o : nfl) {
			Facet f = (Facet) o;
			double[][] vl = f.getVertices(GeometryUtil.NON_SYSTEM);
			va.add(0, vl[0]);
			va.add(0, vl[1]);
			va.add(0, vl[2]);
		}
    
		return va;
	}
	
	/**
	   |- allFacet| 
	   
	   vk2gpz/1994-Feb-10
	*/
	Vector getAllFacets() {
		Vector flist = new Vector();

		for (int i = 0; i < this.maxLevel + 1; i++) {
			Vector nfl = (Vector) this.facets.get(i);
			flist.addAll(nfl);
		}
		
		return flist;
	}

	/**
	   |- allFacetAtLevel:(int)level| 
	   
	   vk2gpz/1994-Mar-03
	*/
	Vector getAllFacetsAt(int level) {
		Vector nfl = null;
		if (level == LAST)
			nfl = (Vector) this.facets.lastElement();
		else if (level <= this.maxLevel)
			nfl = (Vector) this.facets.get(level);
		else
			return new Vector();
		return nfl;
	}
	
	/**
	   |- allNormal| 
	   
	   vk2gpz/1994-Mar-03
	*/
	Vector getAllNormals() {
		Vector nlist = new Vector();
		
		for (int i = 0; i < this.maxLevel + 1; i++) {
			Vector nfl = (Vector) this.facets.get(i);
			int size = nfl.size();
			for (Object o : nfl) nlist.add(0, ((Facet) o).getNormal());
		}
		
		return nlist;
	}
	
	/**
	   |- allNormalAtLevel:(int)level| 
	   
	   vk2gpz/1994-Mar-03
	*/
	Vector getAllNormalsAt(int level) {
		Vector nlist = new Vector();
		Vector nfl = getAllFacetsAt(level);
		
		int size = nfl.size();
		for (Object o : nfl) nlist.add(0, ((Facet) o).getNormal());
		
		return nlist;
	}
	
	private Facet findFacetFacing(double[] aDir, Facet[] facets) {
		Facet result = facets[0];
		double cp2 = VecMath.dot(aDir, result.getNormal());
		for (int i = 1; i < facets.length; i++) {
			Facet f = facets[i];
			double cp1 = VecMath.dot(aDir, f.getNormal());
			if ( cp1 > cp2) {
				cp2 = cp1;
				result = f;
			}
		}
		return result;
	}
	
	/**
	   |- getFacetForDirection:aDir|
	   find a facet whose normal is closest to aDir(Vector)
	   returns facet and stores No. of the facet in aFacetNo
	   
	   vk2gpz/1994-May-05
	*/
 	Facet getFacetFacing(double[] aDir) {
		Facet[] facets = (Facet[]) getAllFacetsAt(0).toArray(new Facet[0]);
		Facet best = findFacetFacing(aDir, facets);

		while (! best.isLeaf()) {
			facets = best.getChildren();
			best = findFacetFacing(aDir, facets);
		}
		return best;
	}
	
	/**
	   |- setFacetNumbers| 
	   
	   vk2gpz/1994-May-26
	*/
	GeodesicDome setFacetNumbers() {
		Vector allfs = getAllFacetsAt(LAST);
		int size = allfs.size();
		for (int i = 0; i < size; i++)
			((Facet) allfs.get(i)).setFacetNumber(i);
		
		return this;
	}
	
	/**
	   |- getFacetWithFacetNo:(const int)aFacetNo| 
	   
	   vk2gpz/1994-May-12
	*/
	Facet getFacet(int aFacetNo) {
		Vector allfs = getAllFacetsAt(LAST);
		return (Facet) allfs.get(aFacetNo);
	}
}
