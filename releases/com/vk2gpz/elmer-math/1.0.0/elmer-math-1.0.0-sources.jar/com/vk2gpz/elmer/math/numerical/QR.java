/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.math.MathException;
import com.vk2gpz.elmer.math.VecMath;

/*====================================================================
                      Implementation of class QR                      
====================================================================*/
/**
 * QR provides TQRI (Tridiagonal QR Implicit) method and
 * QR decomposition method.  
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class QR {
	private QR() {
		super();
	}
	
    /**
     * TQRI (Tridiagonal QR Implicit) method; this matrix must be a
     * tridiagonalized matrix; TQRI sets eigen vectors of this matrix
	 * <code>a</code> into row vectors of the matrix <code>a</code>,
	 * and corresponding eigen values into the <code>d</code>.
     * 
     * @param a the matrix into where eigen vectors will be placed.
     * @param d the vector into where eigen values will be placed.
     * @return true if eigen vectors and values are successfully computed,
     * false otherwise.
	 */
    public static boolean TQRI(double[][] a, double[] d) throws IllegalArgumentException, MathException {
        int[] row = new int[1];
		int[] col = new int[1];
		VecMath.checkMatrix(a, row, col);
		if (row[0] != col[0]) {
            throw new MathException("Matrix is not square.");
		}
		int n = row[0];
		int i, j, k, h, iter;
		double c, s, t, w, x, y;
		double[] v = new double[n];
		double[] v2 = new double[n];	
		double EPS = 1E-6;
		int MAX_ITER = 100;
		double[] e = new double[n];
		double[] t_e = new double[n-1];
		
		VecMath.tridiagonalize(a, d, t_e);
        System.arraycopy(t_e, 0, e, 1, t_e.length);
		e[0] = 0;
		/* --------------- redusing the size of the matrix ---------------- */
		for (h = n-1; h > 0; h--) {
			/* ------------------ find e.v[j] != 0 -------------------- */
			for (j = h; j > 0; j--)
				if(Math.abs(e[j]) < EPS*(Math.abs(d[j-1])+Math.abs(d[j])))
					break;
			if(j==h)	continue;
			iter = 0;
			do{
				if(++iter>MAX_ITER)
					return false;
				w = (d[h-1]-d[h])/2;
				t = e[h]*e[h];
				s = Math.sqrt(w*w+t); if(w<0) s = -s;
				x = d[j]-d[h]+t/(w+s); y = e[j+1];
				for(k=j; k<h; k++){
					if(Math.abs(x) > Math.abs(y)){
						t = -y/x; c = 1/Math.sqrt(t*t+1);
						s = t*c;
					}else{
						t = -x/y; s = 1/Math.sqrt(t*t+1);
						c = t*s;
					}
					w = d[k]-d[k+1];
					t = (w*s + 2*c*e[k+1])*s;
					d[k] -= t; d[k+1] += t;
					if(k>j) e[k] = c*e[k]-s*y;
					e[k+1] += s*(c*w - 2*s*e[k+1]);
					/* finding eigen vectors */
					for(i=0; i<n; i++){
						x = a[k][i]; y = a[k+1][i];
						a[k  ][i] = c*x-s*y;	
						a[k+1][i] = s*x+c*y;
					}
					if(k<h-1){
						x = e[k+1]; y = -s*e[k+2];
						e[k+2] *= c;
					}
				}
			}while(Math.abs(e[h])>EPS*(Math.abs(d[h-1])+Math.abs(d[h])));
		}
		for(k=0; k<n-1; k++){
			h = k; t = d[h];
			for(i=k+1; i<n; i++)
				if(d[i]>t){ h = i; t = d[h]; }
			d[h] = d[k]; d[k] = t;
			v = a[h];	a[h] = a[k];	a[k] = v;
		}
		
		return true;
    }

    /**
     * eigen method; this matrix must be a symmetric
     * matrix, for example a covariance matrix; the MGMatrix <i>a</i> must be
     * the same size as this matrix.  TQRI sets eigen vectors of this matrix
     * into row vectors of the MGMatrix <i>a</i>, and corresponding eigen
     * values into the MGVector <i>d</i>.
     * <PRE>
     *  MGVector[] vectors;
     *  for(int i=0; i&lt;m; i++){
     * 	    vectors[i] = new MGVector(n);
     *	    vectors[i].set(array);
     *  }
     *  MGMatrix cov = new MGMatrix(n,n);
     *  MGVector mean = new MGVector(n);
     * 	cov.covariance(vectors, mean);
     *  MGMatrix eigenVec = new MGMatrix(n,n);
     *  MGVector eigenVal = new MGVector(n);
     *  cov.eigen(eigenVec, eigenVal);
     * </PRE>
     * 
     * @param eval the vector into where eigen values will be placed.
     * @param evec the matrix into where eigen vectors will be placed.
     * @return true if eigen vectors and values are successfully computed,
     * false otherwise.
    */
    public static boolean eigen(double[][] a, double[] eval, double[][] evec) throws IllegalArgumentException, MathException {

		VecMath.copy(a, evec);
		return TQRI(evec, eval);
    }

	/**
	* Computes QR decomposition.  It computes <code>R</code> matrix.
	* By calling this method with a transpose of a matrix <code>X</code>,
	* it returns a transpose of a matrix <code>R</code>, where <p>
	* <pre>
	* X = QR.
	* </pre>
	*/
	public static void decompose(double[][] X, double[][] Q, double[][] R) throws IllegalArgumentException {
		int i, j, r;
		double s, t, u;
		int[] row = new int[1];        int[] col = new int[1];
		VecMath.checkMatrix(X, row, col);
		VecMath.copy(X, R);
		int m = row[0];
		int n = col[0];		
		double[] v, w;
		double[] tmpv = null;
		double[] tmpw = null;		
		for (r = 0; r < m; r++) {
			v = R[r];
			tmpv = new double[n - r];
			System.arraycopy(v, r, tmpv, 0, n - r);
			u = Math.sqrt(VecMath.dot(tmpv, tmpv));
			if (v[r] < 0) {
				u = -u;
			}
			v[r] += u;
			t = 1.0 / (v[r] * u);
			for (j = r + 1; j < m; j++) {
				w = R[j];
				tmpv = new double[n - r];
				System.arraycopy(w, r, tmpw, 0, n - r);
				s = t * VecMath.dot(tmpv, tmpw);
				for (i = r; i < n; i++) {
					w[i] -= s * v[i];
				}
			}
			v[r] = -u;
		}
		VecMath.copy(X, Q);
		getQ(Q, R);
	}

	private static void getQ(double[][] x, double[][] r) {
		int[] row = new int[1];        int[] col = new int[1];
        try {
            VecMath.checkMatrix(x, row, col);
        }catch (IllegalArgumentException ignore) {
        }
		int m = row[0];
		int n = col[0];

		for (int k = 0; k < m; k++) {
			for (int i = 0; i < n; i++) {
				x[k][i] /= r[k][k];
			}
			for (int j = k + 1; j < m; j++) {
				for (int i = 0; i < n; i++) {
					x[j][i] -= r[j][k] * x[k][i];
				}
			}
		}
	}
}


