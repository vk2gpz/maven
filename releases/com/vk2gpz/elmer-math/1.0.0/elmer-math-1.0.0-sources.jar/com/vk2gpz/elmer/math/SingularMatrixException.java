/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
           Implementation of class SingularMatrixException            
====================================================================*/
/**
 * Thrown when a matrix is singular.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see MathException
 */

public class SingularMatrixException extends MathException {
    public SingularMatrixException() {
		super();
	}
	
    public SingularMatrixException(String s) {
        super(s);
    }
}
