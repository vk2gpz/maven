/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
                   Implementation of class Complex                    
====================================================================*/
/**
 * generally describe Complex in here
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class Complex {
	public double re;			// real part
	public double im;			// imaginary part

	public Complex(double re, double im) {		
		super();
		this.re = re;
		this.im = im;
	}

	public Complex() {
		this(0.0, 0.0);
	}
	
	@Override
	public String toString() {
		return this.re + "+i" + this.im;
	}

	public static Complex conjugate(Complex z) {
		return new Complex(z.re, -z.im);
	}

	public static double abs(Complex z) {
		final double absRe = Math.abs(z.re);
		final double absIm = Math.abs(z.im);
		
		if (absRe == 0.0) return absIm;
		if (absIm == 0.0) return absRe;
		
		if (absIm > absRe) {
			final double t = z.re / z.im;
			return absIm * Math.sqrt(1.0 + t * t);
		} else {
			final double t = z.im / z.re;
			return absRe * Math.sqrt(1.0 + t * t);
		}
	}

	public static double arg(Complex z) {
		return Math.atan2(z.im, z.re);
	}

	public static Complex add(Complex x, Complex y) {
		return new Complex(x.re + y.re, x.im + y.im);
	}

	public static Complex sub(Complex x, Complex y) {
		return new Complex(x.re - y.re, x.im - y.im);
	}		

	public static Complex mul(Complex x, Complex y) {
		return new Complex(x.re * y.re - x.im * y.im,
							x.re * y.im + x.im * y.re);
	}		

	public static Complex div(Complex x, Complex y) {
		final double absYre = Math.abs(y.re);
		final double absYim = Math.abs(y.im);
		final Complex z = new Complex();

		if (absYre >= absYim) {
			final double w = y.im / y.re;
			final double d = y.re + y.im * w;
			z.re = (x.re + x.im * w) / d;
			z.im = (x.im - x.re * w) / d;
		} else {
			final double w = y.re / y.im;
			final double d = y.re * w + y.im;
			z.re = (x.re * w + x.im) / d;
			z.im = (x.im * w - x.re) / d;
		}
		return z;
	}

	public static Complex exp(Complex x) {
		final double a = Math.exp(x.re);
		return new Complex(a * Math.cos(x.im), a * Math.sin(x.im));
	}

	public static Complex log(Complex x) {
		return new Complex(0.5 * Math.log(x.re * x.re + x.im * x.im),
							Math.atan2(x.im, x.re));
	}

	public static Complex pow(Complex x, Complex y) {
		return exp(mul(y, log(x)));
	}

	public static Complex sin(Complex x) {
		final double e = Math.exp(x.im);
		final double f = 1.0 / e;
		return new Complex(0.5 * Math.sin(x.re) * (e + f),
						  0.5 * Math.cos(x.re) * (e - f));
	}

	public static Complex cos(Complex x) {
		final double e = Math.exp(x.im);
		final double f = 1.0 / e;
		return new Complex(0.5 * Math.cos(x.re) * (f + e),
						  0.5 * Math.sin(x.re) * (f - e));
	}

	public static Complex tan(Complex x) {
		final double e = Math.exp(2 * x.im);
		final double f = 1.0 / e;
		final double d = Math.cos(2 * x.re) + 0.5 * (e + f);
		return new Complex(Math.sin(2 * x.re) / d,
						  0.5 * (e - f) / d);
	}

	public static Complex sinh(Complex x) {
		final double e = Math.exp(x.re);
		final double f = 1.0 / e;
		return new Complex(0.5 * (e - f) * Math.cos(x.im),
						  0.5 * (e + f) * Math.sin(x.im));
	}

	public static Complex cosh(Complex x) {
		final double e = Math.exp(x.re);
		final double f = 1.0 / e;
		return new Complex(0.5 * (e + f) * Math.cos(x.im),
						  0.5 * (e - f) * Math.sin(x.im));
	}

	public static Complex tanh(Complex x) {
		final double e = Math.exp(x.re);
		final double f = 1.0 / e;
		final double d = 0.5 * (e + f) + Math.cos(2 * x.im);
		return new Complex(0.5 * (e - f) / d,
						  Math.sin(2 * x.im) / d);
	}
	
	private static final double SQRT05 = 0.707106781186547524;

	public static Complex sqrt(Complex x) {
		final double r = abs(x);
		final double w = Math.sqrt(r + Math.abs(x.re));
		final Complex z = new Complex();
		if (x.re >= 0) {
			z.re = SQRT05 * w;
			z.im = SQRT05 * x.im / w;
		} else {
			z.re = SQRT05 * Math.abs(x.im) / w;
			z.im = (x.im >= 0) ? SQRT05 * w: -SQRT05 * w;
		}
		return z;
	}
}

