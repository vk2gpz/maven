/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
                  Implementation of class Constants                   
====================================================================*/
/**
 * Constants defines various mathematical constants.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class Constants {
	private Constants() {
		super();
	}
	
	public static final double EPS = 1e-10;

	/**
	 * Euler constant.
	 */
	public static final double EULER = 0.577215664901532860606512090082;

	/**
	 * 0th Bernoulli number.
	 */
	public static final double B0 = 1.0;
	/**
	 * 1st Bernoulli number.
	 */
	public static final double B1 = (-1.0 / 2.0);
	/**
	 * 2nd Bernoulli number.
	 */
	public static final double B2 = ( 1.0 / 6.0);
	/**
	 * 4th Bernoulli number.
	 */
	public static final double B4 = (-1.0 / 30.0);
	/**
	 * 6th Bernoulli number.
	 */
	public static final double B6 = ( 1.0 / 42.0);
	/**
	 * 8th Bernoulli number.
	 */
	public static final double B8 = (-1.0 / 30.0);
	/**
	 * 10th Bernoulli number.
	 */
	public static final double B10 = ( 5.0 / 66.0);
	/**
	 * 12th Bernoulli number.
	 */
	public static final double B12 = (-691.0 / 2730.0);
	/**
	 * 14th Bernoulli number.
	 */
	public static final double B14 = ( 7.0 / 6.0);
	/**
	 * 16th Bernoulli number.
	 */
	public static final double B16 = (-3617.0 / 510.0);
}

