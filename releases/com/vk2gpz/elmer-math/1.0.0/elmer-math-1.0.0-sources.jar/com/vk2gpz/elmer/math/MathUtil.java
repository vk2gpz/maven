/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
                   Implementation of class MathUtil                   
====================================================================*/


import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * MathUtils provides various useful methods.
 *
 * @author vk2gpz (vk2gpz@gmail.com)
 * @version $Revision: 1.3 $
 */

public final class MathUtil {
    private MathUtil() {
        super();
    }

    private static final double EULER = Constants.EULER;

    /**
     * Returns the smallest and largest values of a given array.  It stores the min and max
     * values in array[0] and array[1] respectively.  The number of comparison made by this
     * method is about 2/3 of ordinary min/max search method.
     */
    public static double[] getMinMax(double[] a, double[] minmax) {
        int n = a.length;
        double max, min, a1, a2;
        if (minmax == null) {
            minmax = new double[2];
        }

        if ((n & 1) != 0) {
            max = min = a[0];
        } else if (a[0] > a[1]) {
            max = a[0];
            min = a[1];
        } else {
            max = a[1];
            min = a[0];
        }
        for (int i = 2 - (n & 1); i < n; i += 2) {
            a1 = a[i];
            a2 = a[i + 1];
            if (a1 > a2) {
                if (a1 > max) {
                    max = a1;
                }
                if (a2 < min) {
                    min = a2;
                }
            } else {
                if (a2 > max) {
                    max = a2;
                }
                if (a1 < min) {
                    min = a1;
                }
            }
        }
        minmax[0] = min;
        minmax[1] = max;
        return minmax;
    }

    /**
     * Computes a greatest common divisor (GCD) of two values.
     */
    public static double getGCD(double x, double y) {
        double t = 1;
        while (y != 0) {
            t = x % y;
            x = y;
            y = t;
        }
        return t;
    }

    /**
     * Computes a greatest common divisor (GCD) of a given array.
     */
    public static double getGCD(double[] a) {
        double d = a[0];
        for (int i = 1; i < a.length && d != 1.0; i++) {
            d = getGCD(a[i], d);
        }
        return d;
    }

    /**
     * Computes a least common multiple (LCM) of two values.
     */
    public static double getLCM(double x, double y) {
        return Math.abs(x * y) / getGCD(x, y);
    }

    /**
     * Computes a least common multiple (LCM) of a given array.
     */
    public static double getLCM(double[] a) {
        double d = a[0];
        for (int i = 1; i < a.length; i++) {
            d = getLCM(a[i], d);
        }
        return d;
    }

    /**
     * Computes a cosine integral.
     */
    public static double getCosineIntegral(double x) throws ConvergenceException {
        if (x < 0) {
            return -getCosineIntegral(-x);
        }
        if (x < 18) {
            return ci_series(x);
        }
        return ci_asympt(x);
    }

    private static double ci_series(double x) throws ConvergenceException {
        double u;
        double s = EULER + Math.log(x);
        x = -x * x;
        double t = 1.0;
        for (int k = 2; k < 1000; k += 2) {
            t *= x / ((k - 1) * k);
            u = s;
            s += t / k;
            if (s == u) {
                return s;
            }
        }
        throw new ConvergenceException();
        // return s;
    }
    
    private static double asympt(double x, boolean si) {
        double fmax, gmax;
        double fmin, gmin;
        double f, g;
        int k, flag;
        double t = 1.0 / x;
        fmax = gmax = 2.0;
        fmin = gmin = 0.0;
        f = g = 0.0;
        k = flag = 0;
        while (flag != 15) {
            f += t;
            t *= ++k / x;
            if (f < fmax) {
                fmax = f;
            } else {
                flag |= 1;
            }
            g += t;
            t *= ++k / x;
            if (g < gmax) {
                gmax = g;
            } else {
                flag |= 2;
            }
            f -= t;
            t *= ++k / x;
            if (f > fmin) {
                fmin = f;
            } else {
                flag |= 4;
            }
            g -= t;
            t *= ++k / x;
            if (g > gmin) {
                gmin = g;
            } else {
                flag |= 8;
            }
        }
        if (si) {
            return 0.5 * (Math.PI - (fmax + fmin) * Math.cos(x) - (gmax + gmin) * Math.sin(x));
        } else {
            return 0.5 * ((fmax + fmin) * Math.sin(x) - (gmax + gmin) * Math.cos(x));
        }
    }
    
    private static double ci_asympt(double x) {
        return asympt(x, false);
    }
    
    private static double si_asympt(double x) {
        return asympt(x, true);
    }


    /**
     * Computes a sine integral.
     */
    public static double getSineIntegral(double x) throws ConvergenceException {
        if (x < 0) {
            return -getSineIntegral(-x);
        }
        if (x < 18) {
            return si_series(x);
        }
        return si_asympt(x);
    }

    private static double si_series(double x) throws ConvergenceException {
        double s, t, u;
        s = t = x;
        x = -x * x;
        for (int k = 3; k < 1000; k += 2) {
            t *= x / ((k - 1) * k);
            u = s;
            s += t / k;
            if (s == u) {
                return s;
            }
        }
        throw new ConvergenceException();
        // return s;
    }

    /**
     * Computes a hypotenuse.  This methods handles overflow.
     * It is fast because it does not use Math.sqrt. <p>
     * <p>
     * Ref: Moler, C. B. and Morrison, D. IBM Journal of Research and Development
     * 27 (6), pp.577--581, 1983.
     */
    public static double hypotenuse(double x, double y) {
        double t;

        x = Math.abs(x);
        y = Math.abs(y);
        if (x < y) {
            t = x;
            x = y;
            y = t;
        }
        if (y == 0) {
            return x;
        }
        for (int i = 0; i < 3; i++) {
            t = y / x;
            t *= t;
            t /= 4 + t;
            x += 2 * x * t;
            y *= t;
        }
        return x;
    }


    public static double sinh(double t) {
        final double exp_t = Math.exp(t);
        return (exp_t - 1.0 / exp_t) * 0.5;
    }

    public static double cosh(double t) {
        final double exp_t = Math.exp(t);
        return (exp_t + 1.0 / exp_t) * 0.5;
    }

    public static double tanh(double t) {
        final double exp_2t = Math.exp(2.0 * t);
        return (exp_2t - 1.0) / (exp_2t + 1.0);
    }

    public static double sec(double t) {
        return 1.0 / Math.cos(t);
    }

    public static double cosec(double t) {
        return 1.0 / Math.sin(t);
    }

    public static double cot(double t) {
        return 1.0 / Math.tan(t);
    }

    //(double)Math.round(centimeters * 100) / 100
    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    public static int floor(double value) {
        int i = (int) value;
        return value < i ? i - 1 : i;
    }

    public static float sqrt(double value) {
        return (float) Math.sqrt(value);
    }
    
    /**
     * Number of decimal places needed to write {@code value} exactly: 0.25 → 2, 0.5 → 1, 3.0 → 0, 100 → 0.
     * Handy as the {@code scale} for {@link RandomUtil#random(double, double, int)}, e.g. for a 0.25% chance.
     */
    public static int decimalPlaces(double value) {
        return decimalPlaces(BigDecimal.valueOf(value));
    }

    /** Same as {@link #decimalPlaces(double)} for a number written as text, e.g. "0.250" → 2. */
    public static int decimalPlaces(String number) {
        return decimalPlaces(new BigDecimal(number.trim()));
    }

    private static int decimalPlaces(BigDecimal value) {
        return Math.max(0, value.stripTrailingZeros().scale());
    }
}

