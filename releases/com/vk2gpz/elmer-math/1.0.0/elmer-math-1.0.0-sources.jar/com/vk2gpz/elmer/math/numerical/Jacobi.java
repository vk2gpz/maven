/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.math.MathException;
import com.vk2gpz.elmer.math.VecMath;

/*====================================================================
                    Implementation of class Jacobi                    
====================================================================*/
/**
 * Jacobi method.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class Jacobi {
    /*
     * the function used in eigen.
	 */
    private static void rotate(double[][] a, int i, int j, int k, int l, double c, double s) {
		double x = a[i][j];
		double y = a[k][l];
		a[i][j] = x*c - y*s;
		a[k][l] = x*s + y*c;
    }
	
    /**
	 * Returns eigen vectors of this matrix and sets corresponding eigen
     * values into the eigenvalues.
     * <PRE>
     *  double[][] vectors = new double[m][n];
     *  for(int i=0; i&lt;m; i++){
	 *      for(in tj=0; j&lt;n; j++)
     * 	    	vectors[i][j] = xx;
     *  }
     *  double[] mean = new double[n];
     * 	double[][] cov = VecMath.covariance(vectors, mean);
     *  double[][] eigenVec = new double[n][n];
     *  double[] eigenVal = new double[n];
     *  Jacobi.jacobi(cov, eigenVec, eigenVal);
     * </PRE>
     * 
     * @param a the matrix whose eigen(values, vectors) are to be computed.
	 *	diagonal elements of this matrix are eigenvalues.
     * @param w the array into where eigenvectors will be placed.
     * @return true if eigen vectors and values are successfully computed,
     * false otherwise.
    */
    public static boolean jacobi(double[][] a, double[][] w) throws IllegalArgumentException, MathException {
		int[] row = new int[1];
		int[] col = new int[1];
		int a_r, a_c;
		VecMath.checkMatrix(a, row, col);
		a_r = row[0];
		a_c = col[0];
		if (row[0]!=col[0])
			throw new MathException("Matrix is not square.");
		VecMath.checkMatrix(w, row, col);
		if (row[0]!=a_r || col[0]!=a_c)
			throw new IllegalArgumentException("The size of the matrix A is not equal to the size of the matrix E.");
		
		double EPS = 1E-6;
		double TINY = 1E-20;
		int MAX_ITER = 100;
		int n = row[0];
		int i, j, k, iter;
		double t, c, s, tolerance, offdiag;
		double[] v;

		s = offdiag = 0.0;
		for(j=0; j<n; j++){
			for(k=0; k<n; k++)
				w[j][k] = 0.0;
			w[j][j] = 1.0; 	s += a[j][j]*a[j][j];
			for(k=j+1; k<n; k++)
				offdiag += a[j][k]*a[j][k];
		}
		tolerance = EPS *EPS *(s/2+offdiag);
		for(iter=1; iter <= MAX_ITER; iter++){
			offdiag = 0;
			for(j=0; j<n-1; j++)
				for(k=j+1; k<n; k++)
					offdiag += a[j][k]*a[j][k];
			if(offdiag <tolerance) break;
			for(j=0; j<n-1; j++){
				for(k=j+1; k<n; k++){
					if(Math.abs(a[j][k])<TINY) continue;
					t = (a[k][k]- a[j][j])/(2*a[j][k]);
					if(t>=0) 	t = 1/(t+Math.sqrt(t*t+1));
					else	t = 1/(t-Math.sqrt(t*t+1));
					c = 1/Math.sqrt(t*t+1);
					s = t*c; t *= a[j][k];
					a[j][j] -= t; a[k][k] += t; a[j][k] = 0;
					for(i=0  ; i<j; i++)	rotate(a, i, j, i, k, c, s);
					for(i=j+1; i<k; i++)	rotate(a, j, i, i, k, c, s);
					for(i=k+1; i<n; i++)	rotate(a, j, i, k, i, c, s);
					for(i=0  ; i<n; i++)	rotate(w, j, i, k, i, c, s);
				}
			}
		}
		if(iter>MAX_ITER) return false;
		for(i=0; i<n-1; i++){
			k = i; t = a[k][k];
			for(j=i+1; j<n; j++)
				if(a[j][j]>t){ k=j; t=a[k][k];}
			a[k][k] = a[i][i]; a[i][i] = t;
			v = w[k]; w[k] = w[i]; w[i] = v;
		}
		
		return true;
    }

    /**
     * The matrix <i>A</i> must be a symmetric matrix,
	 * for example a covariance matrix.  This method returns an array
	 * containing eigen vectors and sets corresponding eigen
     * values into the array <i>B</i>.
     * <PRE>
     *  double[][] vectors = new double[m][n];
     *  for(int i=0; i&lt;m; i++){
	 *      for(in tj=0; j&lt;n; j++)
     * 	    	vectors[i][j] = xx;
     *  }
     *  double[] mean = new double[n];
     * 	double[][] cov = VecMath.covariance(vectors, mean);
     *  double[][] eigenVec = new double[n][n];
     *  double[] eigenVal = new double[n];
     *  Jacobi.eigen(cov, eigenVec, eigenVal);
     * </PRE>
     * 
     * @param a the matrix whose eigen(values, vectors) are to be computed.
     * @param eval the array into where eigenvalues will be placed.	 
     * @param evec the array into where eigenvectors will be placed.
     * @return true if eigen vectors and values are successfully computed,
     * false otherwise.
    */
    public static boolean eigen(double[][] a, double[] eval, double[][] evec) throws IllegalArgumentException, MathException {
		boolean ret = false;
		double[][] tmpa = VecMath.copy(a);
		ret = jacobi(tmpa, evec);
		for(int i=0; i<a.length; i++)
			eval[i] = tmpa[i][i];
		return ret;
    }
}


