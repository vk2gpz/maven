/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math;

/* ------------------ Import classes (packages) ------------------- */
import java.util.*;

/*====================================================================
                 Implementation of class Combination                  
====================================================================*/
/**
 * Combination defines methods to compute combinations.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class Combination {
	private static final Map<String, Long> COMB_CACHE = new HashMap<>();

	private Combination() {
		super();
	}
	
	/**
	 * Compute a number of combinations: nCk with memoized caching.
	 */
	public static long getNumberOfCombination(int n, int k) {
		if (k == 0 || k == n) return 1;
		if (k > n) return 0;
		if (k > n - k) k = n - k;  // Optimize: k <= n/2
		
		final String cacheKey = n + "," + k;
		Long cached = COMB_CACHE.get(cacheKey);
		if (cached != null) return cached;
		
		if (k == 1) return n;
		if (k <= 17) {
			long result = computeIterative(n, k);
			COMB_CACHE.put(cacheKey, result);
			return result;
		}
		
		// For large k, use dynamic programming
		long result = computeDP(n, k);
		COMB_CACHE.put(cacheKey, result);
		return result;
	}

	private static long computeIterative(int n, int k) {
		long[] a = new long[k];
		for (int i = 0; i < k; i++) {
			a[i] = i + 2;
		}
		for (int i = 3; i <= n - k + 1; i++) {
			for (int j = k - 1; j > 0; j--) {
				a[j] += a[j - 1];
			}
			a[0] = i;
		}
		return a[k - 1];
	}

	private static long computeDP(int n, int k) {
		if (k == 0 || k == n) return 1;
		return getNumberOfCombination(n - 1, k - 1) + getNumberOfCombination(n - 1, k);
	}

	/**
	 * Generates combinations: nCk.
	 */
	private static long first(int n) {
		return (1L << (n)) - 1L;
	}
	private static long nextset(long x) {
		long smallest, ripple, new_smallest, ones;

		smallest = x & -x;
		ripple = x + smallest;
		new_smallest = ripple & -ripple;
		ones = ((new_smallest / smallest) >> 1) - 1;
		return ripple | ones;
	}
	private static int[] convertset(int n, int k, long s) {
		int[] ans = new int[k];
		int cnt = 0;
		for (int i = 1; i <= n; i++) {
			if ((s & 1) != 0) {
				ans[cnt++] = i;
			}
			s >>= 1;
		}
		return ans;
	}
	
	public static int[][] getCombinations(int n, int k) {
		Vector vec = new Vector();
		long x = first(k);
		while ((x & ~first(n)) == 0) {
			vec.addElement(convertset(n, k, x));
			x = nextset(x);
		}
		int size = vec.size();
		int[][] ans = new int[size][k];
		for (int i = 0; i < size; i++) {
			System.arraycopy(vec.elementAt(i), 0, ans[i], 0, k);
		}
		return ans;
	}
}

