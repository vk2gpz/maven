/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
             Implementation of class AitkenInterpolation              
====================================================================*/
/**
 * Implement Aitken interpolation method.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Interpolation
 */

public final class AitkenInterpolation extends Interpolation {
	public AitkenInterpolation() {
		super();
	}
		
	public static double interpolate(double t, double[] x, double[] y, double[] w) {
		int N = x.length;
		System.arraycopy(y, 0, w, 0, N);
		for (int j = 1; j <= N - 1; j++) {
			for (int i = N - 1; i >= j; i--) {
				w[i] = (w[i - 1] * (x[i] - t) - w[i] * (x[i - j] - t)) / (x[i] - x[i - j]);
			}
		}
		return w[N - 1];
	}
	
	public double interpolate(double t) {
		double value = interpolate(t, this.x, this.y, this.w);
		fireEvaluated(value);
		return value;
	}
}
