/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.math.VecMath;

/*====================================================================
               Implementation of class ImplicitFunction               
====================================================================*/
/**
 * ImplicitFunction is an abstract class for implicit functions.  
 * Implicit functions are of the form F(x0, x1, ..., xN) = 0.
 * It provides a method to evaluate the function and the function
 * graradient at the given point. <p>
 *
 * ImplicitFunction provides a mechanism to transform the implicit
 * function(s) via a transformation matrix. This capability can be used to 
 * translate, orient, or scale implicit functions.  The transformation
 * matrix should be <code>(dim+1) x (dim+1)</code> matrix, where
 * <code>dim</code> is the dimension of the function.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public abstract class ImplicitFunction {
	final int dimension;
	double[][] transform;		// (dim+1) x (dim+1) matrix
	
	public ImplicitFunction() {
		super();
		this.transform = null;
		this.dimension = -1;
	}

	/**
	 * Evaluate function at position x0-x1-..-xN and return value.
	 */
	public double functionValue(double[] x) {
		if (this.transform == null) {
			return this.evaluateFunction(x);
		} else {				//pass point through transform
			double[] pt = new double[this.dimension + 1];
			int i = 0;
			for (i = 0; i < this.dimension; i++) {
				pt[i] = x[i];
			}
			pt[i] = 1.0;
			pt = VecMath.multiply(this.transform, pt);
			if (pt[this.dimension] != 1.0) {
				for (i = 0; i < this.dimension; i++) {
					pt[i] /= pt[this.dimension];
				}
			}
			return this.evaluateFunction(pt);
		}
	}

	/**
	 * Evaluate function gradient at position x0-x1-..-xN and pass
	 * back vector. 
	 */
	public void functionGradient(double[] x, double[] g) {
		if (this.transform == null) {
			this.evaluateGradient(x, g);
		} else {				//pass point through transform
			double[] pt = new double[this.dimension + 1];		
			int i = 0;
			for (i = 0; i < this.dimension; i++) {
				pt[i] = x[i];
			}
			pt[i] = 1.0;
			pt = VecMath.multiply(this.transform, pt);
			if (pt[this.dimension] != 1.0) {
				for (i = 0; i < this.dimension; i++) {
					pt[i] /= pt[this.dimension];
				}
			}
			this.evaluateGradient(pt, g);			
		}
    }

	/**
	 * Evaluate function at position x0-x1-..-xN and return value.
	 * Must be implemented by derived class.
	 */
	public abstract double evaluateFunction(double[] x);

	/**
	 * Evaluate function gradient at position x0-x1-..-xN and pass
	 * back vector. 
	 */
	public abstract void evaluateGradient(double[] x, double[] g);

	/**
	 * Set transformation matrix to transform implicit function.
	 */
	public void setTransform(double[][] transform) {
		this.transform = VecMath.copy(transform);
	}
	
	/**
	 * Get transformation matrix to transform implicit function.
	 */
	public double[][] getTransform() {
		return this.transform;
	}
}
