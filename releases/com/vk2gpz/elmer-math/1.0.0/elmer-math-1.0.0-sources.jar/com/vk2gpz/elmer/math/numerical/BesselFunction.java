/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.math.Constants;

/*====================================================================
                Implementation of class BesselFunction                
====================================================================*/
/**
 * BesselFunction computes Bessel function of the first kind
 * <code>J_n(x)</code> and the second kind <code>Y_n(x)</code>.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class BesselFunction {
	private BesselFunction() {
		super();
	}

	private static final double EPS = Constants.EPS;
	
	private static boolean odd(int x) {
		return (x & 1) != 0;
	}
	
	/**
	* Returns a Bessel functino of the first kind  <code>J_n(x)</code>.
	*/
	public static double getBesselJ(int n, double x) {
		if (x < 0) {
			if (odd(n)) {
				return -getBesselJ(n, -x);
			}
				return  getBesselJ(n, -x);
		}
		if (n < 0) {
			if (odd(n)) {
				return -getBesselJ(-n, x);
			}
				return  getBesselJ(-n, x);
		}
		if (x == 0) {
			return (n == 0) ? 1.0 : 0.0;
		}
		double a = 0.0;
		double s = 0.0;
		double b = 1.0;
		double r = 0.0;
		int k = n;
		double x_2 = x / 2.0;
		
		if (k < x) {
			k = (int) x;
		}
		do {
			k++;
		} while ((b *= x_2 / k) > EPS);
		if (odd(k)) {
			k++;
		}
		while (k > 0) {
			s += b;
			a = 2 * k * b / x - a;
			k--;
			if (n == k) {
				r = a;
			}
			b = 2 * k * a / x - b;
			k--;
			if (n == k) {
				r = b;
			}
		}
		return r / (2 * s + b);
	}

	/**
	* Returns a Bessel functino of the second kind  <code>Y_n(x)</code>.
	*/
	public static double getBesselY(int n, double x) {
		if (x <= 0) {
			return 0;			// x must be positive.
		}
		if (n < 0) {
			if (odd(n)) {
				return -getBesselJ(-n, x);
			}
				return  getBesselJ(-n, x);
		}
		int k = (int) x;
		double b = 1;
		double x_2 = x / 2;
		double log_x_2 = Math.log(x_2);
		do {
			k++;
		} while ((b *= x_2 / k) > EPS);
		if (odd(k)) {
			k++;
		}
		double a = 0.0;
		double s = 0.0;
		double t = 0.0;
		double u = 0.0;
		while (k > 0) {
			s += b;
			t = b / (k / 2.0) - t;
			a = 2 * k * b / x - a;
			k--;
			if (k > 2) {
				u = (k * a) / ((k / 2.0) * (k / 2.0 + 1)) - u;
			}
			b = 2 * k * a / x - b;
			k--;
		}
		s = 2 * s + b;
		a /= s;
		b /= s;
		t /= s;
		u /= s;
		double EULER = Constants.EULER;
		t = (2 / Math.PI) * (2 * t + (log_x_2 + EULER) * b);
		if (n == 0) {
			return t;
		}
		u = (2 / Math.PI) * (u + ((EULER - 1) + log_x_2) * a - b / x);
		for (k = 1; k < n; k++) {
			s = (2 * k) * u / x - t;
			t = u;
			u = s;
		}
		return u;
	}
}

