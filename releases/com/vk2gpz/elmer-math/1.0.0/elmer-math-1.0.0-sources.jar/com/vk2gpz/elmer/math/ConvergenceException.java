/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
             Implementation of class ConvergenceException             
====================================================================*/
/**
 * ConvergenceException is used when a process did not converge.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see MathException
 */

public final class ConvergenceException extends MathException {
    public ConvergenceException(){}

    public ConvergenceException(String string) {
        super(string);
    }
}
