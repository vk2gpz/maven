/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.math.Constants;

/*====================================================================
                Implementation of class GammaFunction                 
====================================================================*/
/**
 * GammaFunction provides methods to compute Gamma function and
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class GammaFunction {
	private GammaFunction() {
		super();
	}
	
	private static final double LOG_2PI = Math.log(2 * Math.PI);
	private static final int N = 8;
	/* Bernoulli constants. */
	private static final double B0 = Constants.B0;
	private static final double B1 = Constants.B1;
	private static final double B2 = Constants.B2;
	private static final double B4 = Constants.B4;
	private static final double B6 = Constants.B6;
	private static final double B8 = Constants.B8;
	private static final double B10 = Constants.B10;
	private static final double B12 = Constants.B12;
	private static final double B14 = Constants.B14;
	private static final double B16 = Constants.B16;

	/**
	 * Returns the natural logarithm (base <i>e</i>) of Gamma(x) value.
	*/
	public static double logGamma(double x) {
		double v = 1.0;
		while (x < N) {
			v *= x;
			x++;
		}
		double w = 1.0 / (x * x);
		return ((((((((B16 / (16 * 15))  * w + (B14 / (14 * 13))) * w
					 +(B12 / (12 * 11))) * w + (B10 / (10 *  9))) * w
				   +  (B8  / ( 8 *  7))) * w + (B6  / ( 6 *  5))) * w
				 +    (B4  / ( 4 *  3))) * w + (B2  / (2))) / x
			+ 0.5 * LOG_2PI - Math.log(v) - x + (x - 0.5) * Math.log(x);
	}

	/**
	 * Returns the Gamma(x) value.
	*/
	public static double gamma(double x) {
		if (x < 0) {
			return Math.PI / (Math.sin(Math.PI * x) * Math.exp(logGamma(1 - x)));
		}
		return Math.exp(logGamma(x));
	}

	public static double psi(double x) {
		double v = 0.0;
		while (x < N) {
			v += 1.0 / x;
			x++;
		}
		double w = 1.0 / (x * x);
		v += ((((((((B16 / 16)  * w + (B14 / 14)) * w
				   +(B12 / 12)) * w + (B10 / 10)) * w
				 +  (B8  /  8)) * w + (B6  /  6)) * w
			   +    (B4  /  4)) * w + (B2  /  2)) * w + 0.5 / x;
		return Math.log(x) - v;
	}

	public static double polyGamma(int n, double x) {
		double u = 1.0;
		for (int k = 1 - n; k < 0; k++) {
			u *= k;
		}
		double v = 0.0;
		while (x < N) {
			v += 1.0 / Math.pow(x, n + 1);
			x++;
		}
		double w = x * x;
		double t = (((((((B16
						  * (n + 15.0) * (n + 14) / (16 * 15 * w) + B14)
						  * (n + 13.0) * (n + 12) / (14 * 13 * w) + B12)
						  * (n + 11.0) * (n + 10) / (12 * 11 * w) + B10)
						  * (n +  9.0) * (n +  8) / (10 *  9 * w) + B8)
						  * (n +  7.0) * (n +  6) / ( 8 *  7 * w) + B6)
						  * (n +  5.0) * (n +  4) / ( 6 *  5 * w) + B4)
						  * (n +  3.0) * (n +  2) / ( 4 *  3 * w) + B2)
						  * (n +  1.0) *  n       / ( 2 *  1 * w)
						  + 0.5 * n / x + 1;
		return u * (t / Math.pow(x, n) + n * v);
	}
}

