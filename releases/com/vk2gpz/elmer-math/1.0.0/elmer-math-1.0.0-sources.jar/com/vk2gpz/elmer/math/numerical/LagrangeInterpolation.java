/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
            Implementation of class LagrangeInterpolation             
====================================================================*/
/**
 * Implement Lagrange interpolation method.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Interpolation
 */

public final class LagrangeInterpolation extends Interpolation {
	public LagrangeInterpolation() {
		super();
	}
		
	public static double interpolate(double t, double[] x, double[] y, double[] w) {
		int N = x.length;
		double sum = 0.0;
		double prod = 0.0;
		
		for (int i = 0; i < N; i++) {
			prod = y[i];
			for (int j = 0; j < N; j++) {
				if (j != i) {
					prod *= (t - x[j]) / (x[i] - x[j]);
				}
			}
			sum += prod;
		}
		return sum;
	}

	public double interpolate(double t) {
		return interpolate(t, this.x, this.y, this.w);
	}
}
