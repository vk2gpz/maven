/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.math.MathException;

/*====================================================================
                     Implementation of class SVD                      
====================================================================*/
/**
 * Finds the singular value decomposition (SVD) of a given matrix such that 
 * m = U*W*transpose(V); and returns the rank of this matrix; the values 
 * of U,W,V are all overwritten. Note that the matrix V is output as V,
 * and not transpose(V). If this matrix is mxn, then U is mxm, W is a 
 * diagonal matrix that is mxn, and V is nxn. Using the notation W = diag(w),
 * then the inverse of this matrix is: invert(this) = V*diag(1/w)*tranpose(U),
 * where diag(1/w) is the same matrix as W except that the reciprocal of each 
 * of the diagonal components is used. 
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class SVD {
	private SVD() {
		super();
	}
	
	private static double SIGN(double a, double b) {
		return (b >= 0.0) ? Math.abs(a) : -Math.abs(a);
	}
	
	private static double dpythag(double a, double b) {
		double absa = Math.abs(a);
		double absb = Math.abs(b);
		double term;
		if (absa > absb){
			term = absb / absa;
			return absa * Math.sqrt(1.0 + term * term);
		} else {
			term = absa / absb;
			return (absb == 0.0) ? 0.0: absb * Math.sqrt(1.0 + term * term);
		}
	}
	
	/**
	 * Computes an SVD decomposition of a matrix. m = U*W*transpose(V)
	 * 
	 * @param a a matrix to be decomposed.
	 * @param u a matrix where U matrix of a = U*W*transpose(V) will be stored.
	 * @param w a vector where V vector of a = U*W*transpose(V) will be stored.
	 * @param v a matrix where V matrix of a = U*W*transpose(V) will be stored.
	 * @return the rank of the matrix.
	 * @exception IllegalArgumentException
	 * @exception MathException
	 */
	public static int decompose(double[][] a, double[][] u, double[] w, double[][] v) throws IllegalArgumentException, MathException {
		int m = a.length;
		int n = a[0].length;
		int imax = Math.max(m, n);
		int imin = Math.min(m, n);
		int flag, i,its,j,jj,k,l=0,nm=0;
		double anorm,c,f,g,h,s,scale,x,y,z;
		double a1;
		double[] rv1 = new double[n];
		
		// copy a to u.
		for(i = 0; i < m; i++)
			for(j = 0; j < n; j++)
				u[i][j] = a[i][j];
		// pad 0.0 to w
		for (i = 0; i < n; i++)
			w[i] = 0;

		g = scale = anorm = 0.0;
		for (i=0;i<n;i++) {
			l=i+1;
			rv1[i]=scale*g;
			g=s=scale=0.0;
			if(i < m){
				for(k=i; k<m; k++) scale += Math.abs(u[k][i]);
				if(scale!=0.0) {
					for(k=i;k<n;k++) {
						u[k][i] /= scale;
						s += u[k][i]* u[k][i];
					}
					f= u[i][i];
					g = -SIGN(Math.sqrt(s),f);
					h=f*g-s;
					u[i][i]=f-g;
					for(j=l;j<n;j++) {
						for(s=0.0,k=i;k<m;k++) s += u[k][i]* u[k][j];
						f=s/h;
						for(k=i;k<m;k++) u[k][j] += f* u[k][i];
					}
					for(k=i;k<m;k++) u[k][i] *= scale;
				}
			}
			w[i] = scale*g;
			g=s=scale=0.0;
			if(i < m && i != n-1) {
				for(k=l;k<n;k++) scale += Math.abs(u[i][k]);
				if(scale != 0.0) {
					for(k=l;k<n;k++) {
						u[i][k] /= scale;
						s += u[i][k]* u[i][k];
					}
					f= u[i][l];
					g = -SIGN(Math.sqrt(s),f);
					h=f*g-s;
					u[i][l]=f-g;
					for(k=l;k<n;k++) rv1[k]= u[i][k]/h;
					for(j=l;j<m;j++) {
						for(s=0.0,k=l;k<n;k++) s += u[j][k]* u[i][k];
						for(k=l;k<n;k++) u[j][k] += s*rv1[k];
					}
					for(k=l;k<n;k++) u[i][k] *= scale;
				}
			}
			a1 = Math.abs(w[i])+Math.abs(rv1[i]);
			if(a1 > anorm)
				anorm = a1;
		}
		for(i=n-1;i>=0;i--) {
			if(i < n-1) {
				if(g != 0.0) {
					for(j=l;j<n;j++)
						v[j][i]=(u[i][j]/ u[i][l])/g;
					for(j=l;j<n;j++) {
						for(s=0.0,k=l;k<n;k++) s += u[i][k]* v[k][j];
						for(k=l;k<n;k++) v[k][j] += s* v[k][i];
					}
				}
				for(j=l;j<n;j++) v[i][j]= v[j][i]=0.0;
			}
			v[i][i]=1.0;
			g=rv1[i];
			l=i;
		}
		for(i=imin-1;i>=0;i--) {
			l=i+1;
			g=w[i];
			for(j=l;j<n;j++) u[i][j]=0.0;
			if(g != 0.0) {
				g=1.0/g;
				for(j=l;j<n;j++) {
					for(s=0.0,k=l;k<m;k++) s += u[k][i]* u[k][j];
					f=(s/ u[i][i])*g;
					for(k=i;k<m;k++) u[k][j] += f* u[k][i];
				}
				for(j=i;j<m;j++) u[j][i] *= g;
			}else for(j=i;j<m;j++) u[j][i]=0.0;
			++u[i][i];
		}
		for(k=n-1;k>=0;k--) {
			for(its=1;its<=30;its++) {
				flag=1;
				for(l=k;l>=0;l--) {
					nm=l-1;
					if((Math.abs(rv1[l])+anorm) == anorm) {
						flag=0;
						break;
					}
					if((Math.abs(w[nm])+anorm) == anorm) break;
				}
				if(flag!=0) {
					c=0.0;
					s=1.0;
					for(i=l;i<=k;i++) {
						f=s*rv1[i];
						rv1[i]=c*rv1[i];
						if((Math.abs(f)+anorm) == anorm) break;
						g=w[i];
						h=dpythag(f,g);
						w[i] = h;
						h=1.0/h;
						c=g*h;
						s = -f*h;
						for(j=0;j<m;j++) {
							y= u[j][nm];
							z= u[j][i];
							u[j][nm]=y*c+z*s;
							u[j][i]=z*c-y*s;
						}
					}
				}
				z=w[k];
				if(l == k) {
					if(z < 0.0) {
						w[k] = -z;
						for(j=0;j<n;j++) v[j][k] = -v[j][k];
					}
					break;	/* NORMAL EXIT */
				}
				if (its == 30) {
					throw new MathException("Sigular Value Decomposition (SVD) did not converge in 30 iterations.");
				}
				x=w[l];
				nm=k-1;
				y=w[nm];
				g=rv1[nm];
				h=rv1[k];
				f=((y-z)*(y+z)+(g-h)*(g+h))/(2.0*h*y);
				g=dpythag(f,1.0);
				f=((x-z)*(x+z)+h*((y/(f+SIGN(g,f)))-h))/x;
				c=s=1.0;
				for(j=l;j<=nm;j++) {
					i=j+1;
					g=rv1[i];
					y=w[i];
					h=s*g;
					g=c*g;
					z=dpythag(f,h);
					rv1[j]=z;
					c=f/z;
					s=h/z;
					f=x*c+g*s;
					g = g*c-x*s;
					h=y*s;
					y *= c;
					for(jj=0;jj<n;jj++) {
						x= v[jj][j];
						z= v[jj][i];
						v[jj][j]=x*c+z*s;
						v[jj][i]=z*c-x*s;
					}
					z=dpythag(f,h);
					w[j] = z;
					if(z != 0.0) {
						z=1.0/z;
						c=f*z;
						s=h*z;
					}
					f=c*g+s*y;
					x=c*y-s*g;
					for(jj=0;jj<m;jj++) {
						y= u[jj][j];
						z= u[jj][i];
						u[jj][j]=y*c+z*s;
						u[jj][i]=z*c-y*s;
					}
				}
				rv1[l]=0.0;
				rv1[k]=f;
				w[k] = x;
			}
		}
		// find the number of non-zero w which is the rank of this matrix
		int rank = 0;
		for(i = 0; i < n; i++)
			if(w[i] > 0.0)
				rank++;

		return rank;
	}

	/**
	 * Solves for x in Ax = b, where x is this vector (nx1), 
	 * A is mxn, b is mx1, and A = U*W*transpose(V); 
	 * U,W,V must be precomputed and can be found by taking the 
	 * singular value decomposition (SVD) of A using the method 
	 * SVD found in the GMatrix class.
	 * @param u the U matrix produced by the SVD.decompose method.
	 * @param w the W vector produced by the SVD.decompose method.
	 * @param v the V matrix produced by the SVD.decompose method.
	 * @param b the b vector in the linear equation Ax = b
	 * @param x the vector to store answer of the linear equation Ax = b
	 * @return the vector containing the answer of the linear equation Ax = b
	 */
	public static double[] solve(double[][] u, double[] w, double[][] v, double[] b, double[] x) {
		int m = u.length;
		int n = u[0].length;
		double s;
		double[] tmp = new double[n];
		if (x == null) {
			x = new double[n];
		}
		for (int j = 0; j < n; j++) {
			s = 0.0;	
			if(w[j] != 0.0) {
				for(int i = 0; i < m; i++) {
					s += u[i][j]*b[i];
				}
				s /= w[j];
			}
			tmp[j] = s;
		}
		for(int j = 0; j < n; j++) {
			s = 0.0;
			for(int jj = 0; jj < n; jj++) {
				s += v[j][jj]*tmp[jj];
			}
			x[j] = s;
		}

		return x;
	}

	/**
	* solves Ax = b using SVD.
	* 
	* @param a a matrix in the left hand side of Ax = b.
	* @param b a vector corresponds to the right hand side of Ax = b.
	* @param x a vector to store answer.
	* @return a vector <i>x</i> containing answer.
	*/
	public static double[] solve(double[][] a, double[] b, double[] x) throws IllegalArgumentException, MathException {
		int m = a.length;
		int n = a[0].length;
		double[][] u = new double[m][m];
		double[] w = new double[n];
		double[][] v = new double[n][n];
		decompose(a, u, w, v);
		return solve(u, w, v, b, x);
	}
}
