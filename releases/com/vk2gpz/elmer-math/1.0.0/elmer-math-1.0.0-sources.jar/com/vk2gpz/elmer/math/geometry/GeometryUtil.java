/*
 * Copyright (c) 1994-2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.geometry;

/* ------------------ Import classes (packages) ------------------- */

import com.vk2gpz.elmer.math.VecMath;

/*====================================================================
                 Implementation of class GeometryUtil                 
====================================================================*/

/**
 * generally describe GeometryUtil in here
 *
 * @author vk2gpz (vk2gpz@gmail.com)
 * @version $Revision: 1.5 $
 */

public class GeometryUtil {
	/*
	 * Reference coordinate system.
	 *
	 * vk2gpz (vk2gpz@gmail.com)/2003-Sep-16
	 */
	public static final int NON_SYSTEM = 0;
	public static final int WORLD_SYSTEM = 1;
	public static final int LOCAL_SYSTEM = 2;
	public static final int PARENT_SYSTEM = 3;
	
	/*
	 * Axis index.
	 * vk2gpz (vk2gpz@gmail.com)/2003-Sep-16
	 */
	public static final int NON_AXIS = 0;
	public static final int X_AXIS = 1;
	public static final int Y_AXIS = 2;
	public static final int Z_AXIS = 3;
	
	/*
	 * Seed polyhedra for geodesic dome.
	 * vk2gpz (vk2gpz@gmail.com)/2003-Sep-16
	 */
	public static final int ICOSAHEDRON = 0;
	public static final int DODECAHEDRON = 1;
	
	
	/**
	 * |- rotationMatrixBy:(double)theta aroundVector:aVector :result|
	 * Make a rotation matrix which rotate around axis (aVector)
	 * by angle theta.
	 * Axis (aVector) need not to be unit vector.
	 * vk2gpz/1993-Dec-08
	 */
	public static double[][] getRotationMatrix(double theta,
											   double[] aVector) {
		if ((aVector == null) || (aVector.length != 3)) {
			return null;
		}
		double[][] result = new double[aVector.length][aVector.length];
		double[] unitVec = VecMath.normalize(VecMath.copy(aVector));
		
		double u = unitVec[0];
		double v = unitVec[1];
		double w = unitVec[2];
		
		double c = Math.cos(theta);
		double s = Math.sin(theta);
		
		result[0][0] = u * u + (1 - u * u) * c;
		result[0][1] = u * v * (1 - c) + w * s;
		result[0][2] = v * w * (1 - c) - v * s;
		
		result[1][0] = u * v * (1 - c) - w * s;
		result[1][1] = v * v + (1 - v * v) * c;
		result[1][2] = v * w * (1 - c) + u * s;
		
		result[2][0] = v * w * (1 - c) + v * s;
		result[2][1] = v * w * (1 - c) - u * s;
		result[2][2] = w * w + (1 - w * w) * c;
		
		return result;
	}
	
	/**
	 * |- rotationMatrixBy:(double)theta around:(int)axis :result|
	 * <p>
	 * vk2gpz/1993-Dec-08
	 */
	public static double[][] getRotationMatrix(double theta,
											   int axis) {
		double u, v, w;
		switch (axis) {
			case X_AXIS:
			default:
				u = 1.0;
				v = 0.0;
				w = 0.0;
				break;
			case Y_AXIS:
				u = 0.0;
				v = 1.0;
				w = 0.0;
				break;
			case Z_AXIS:
				u = 0.0;
				v = 0.0;
				w = 1.0;
				break;
		}
		double[] axisVec = new double[]{u, v, w};
		
		return getRotationMatrix(theta, axisVec);
	}
	
	/**
	 * |- rotateMatrix:aMatrix by:(double)theta around:(int)axis in:(int)cods :result|
	 * <p>
	 * vk2gpz/1994-Jan-31
	 * --------------------------------------------------------------------
	 */
	public static double[][] rotateMatrix(double[][] aMatrix,
										  double theta,
										  int axis,
										  int coords) {
		
		if ((aMatrix == null) || (aMatrix[0] == null)) {
			return null;
		}
		int size = aMatrix[0].length;    // column size
		double c = Math.cos(theta);
		double s1 = Math.sin(theta);
		double[][] result = VecMath.copy(aMatrix);
		
		double s2, m0, m1, m2, m3, f1, f2;
		
		if (size == 2) {
			m0 = c * aMatrix[0][0] - s1 * aMatrix[1][0];
			m1 = c * aMatrix[0][1] - s1 * aMatrix[1][1];
			m2 = s1 * aMatrix[0][0] + c * aMatrix[1][0];
			m3 = s1 * aMatrix[0][1] + c * aMatrix[1][1];
			result[0][0] = m0;
			result[0][1] = m1;
			result[1][0] = m2;
			result[1][1] = m3;
			return result;
		}
		int k1, k2;
		switch (axis) {
			case X_AXIS:
				k1 = 1;
				k2 = 2;
				if (coords == WORLD_SYSTEM) {
					s2 = s1;
					s1 = -s1;
				} else {
					s2 = -s1;
				}
				break;
			case Y_AXIS:
				k1 = 0;
				k2 = 2;
				if (coords == WORLD_SYSTEM) {
					s2 = -s1;
				} else {
					s2 = s1;
					s1 = -s1;
				}
				break;
			case Z_AXIS:
				k1 = 0;
				k2 = 1;
				if (coords == WORLD_SYSTEM) {
					s2 = s1;
					s1 = -s1;
				} else {
					s2 = -s1;
				}
				break;
			default:
				return null;
		}
		
		for (int i = 0; i < size; i++) {
			if (coords == WORLD_SYSTEM) {
				m1 = aMatrix[k1][i];
				m2 = aMatrix[k2][i];
			} else {
				m1 = aMatrix[i][k1];
				m2 = aMatrix[i][k2];
			}
			f1 = m1 * c + m2 * s1;
			f2 = m1 * s2 + m2 * c;
			if (coords == WORLD_SYSTEM) {
				result[k1][i] = m1;
				result[k2][i] = m2;
			} else {
				result[i][k1] = m1;
				result[i][k2] = m2;
			}
		}
		return result;
	}
	
	/**
	 * |- eulerMatrix:(double)az :(double)ay :(double)az2|
	 * eulerMatrix(az ay az2) creates a rotation matrix which has been
	 * rotated az, ay, and az2 radian around local z, y, and again z axes.
	 * eulerAngleOf extrancts these angles out of a matrix.
	 * vk2gpz/1993-Dec-08
	 */
	public static double[][] getEulerMatrix(double az,
											double ay,
											double az2) {
		
		double[][] rotMatrix = getRotationMatrix(az, Z_AXIS);
		rotMatrix = rotateMatrix(rotMatrix, ay, Y_AXIS, LOCAL_SYSTEM);
		rotMatrix = rotateMatrix(rotMatrix, az2, Z_AXIS, LOCAL_SYSTEM);
		
		return rotMatrix;
	}
	
	/**
	 * |- rpyMatrix:(double)roll :(double)pitch :(double)yow|
	 * rpyMatrix(roll pitch yow) creates a new rotation matrix which has been
	 * rotated ax radian around x-axis in WORLD,
	 * ay radian around y-axis in WORLD and az radian arouund z-axis in WORLD,
	 * in this order.
	 * vk2gpz/1993-Dec-08
	 */
	public static double[][] getRollPitchYouMatrix(double roll, double pitch, double yow) {
		/*    
			  id	rotMatrix;
			  
			  rotMatrix = [[VMatrix alloc] initWithRow:3 column:3];
			  
			  [rotMatrix setValue:cos(yow)*cos(pitch) atRow:0 column:0];
			  [rotMatrix setValue:sin(yow)*cos(pitch) atRow:0 column:1];
			  [rotMatrix setValue:-1*sin(pitch) atRow:0 column:2];
			  [rotMatrix setValue:cos(yow)*sin(pitch)*sin(roll)-sin(yow)*cos(roll)
			  AtRow:1 column:0];
			  [rotMatrix setValue:sin(yow)*sin(pitch)*sin(roll)+cos(yow)*cos(roll)
			  AtRow:1 column:1];
			  [rotMatrix setValue:cos(pitch)*sin(roll) atRow:1 column:2];
			  [rotMatrix setValue:cos(yow)*sin(pitch)*cos(roll)+sin(yow)*sin(roll)
			  AtRow:2 column:0];
			  [rotMatrix setValue:sin(yow)*sin(pitch)*cos(roll)-cos(yow)*sin(roll)
			  AtRow:2 column:1];
			  [rotMatrix setValue:cos(pitch)*cos(roll) atRow:2 column:2];
			  
			  return rotMatrix;
			  
		*/
		double[][] rotMatrix = getRotationMatrix(yow, X_AXIS);
		rotMatrix = rotateMatrix(rotMatrix, pitch, Y_AXIS, WORLD_SYSTEM);
		rotMatrix = rotateMatrix(rotMatrix, roll, Z_AXIS, WORLD_SYSTEM);
		
		return rotMatrix;
	}
	
	/**
	 * |- eulerAngleOf:aMatrix|
	 * <p>
	 * vk2gpz/1993-Dec-08
	 */
	public static double[][] getEulerAnglesOf(double[][] aMatrix) {
		if (aMatrix == null || aMatrix.length == 0 ||
				aMatrix[0] == null || aMatrix[0].length != 3) {
			return null;
		}
		
		double a = (-0.00001 < aMatrix[1][2] && aMatrix[1][2] < 0.00001 &&
				-0.00001 < aMatrix[0][2] && aMatrix[0][2] < 0.00001) ? 0.0 : Math.atan2(aMatrix[1][2], aMatrix[0][2]);
		double sa = Math.sin(a);
		double ca = Math.cos(a);
		double b = Math.atan2(ca * aMatrix[0][2] + sa * aMatrix[1][2], aMatrix[2][2]);
		double c = Math.atan2(-sa * aMatrix[0][0] + ca * aMatrix[1][0],
				-sa * aMatrix[0][1] + ca * aMatrix[1][1]);
		double[] res1 = new double[]{a, b, c};
		a = a + Math.PI;
		sa = Math.sin(a);
		ca = Math.cos(a);
		b = Math.atan2(ca * aMatrix[0][2] + sa * aMatrix[1][2], aMatrix[2][2]);
		c = Math.atan2(-sa * aMatrix[0][0] + ca * aMatrix[1][0],
				-sa * aMatrix[0][1] + ca * aMatrix[1][1]);
		double[] res2 = new double[]{a, b, c};
		return new double[][]{res1, res2};
	}
	
	/**
	 * |- rpyAngleOf:aMatrix|
	 * vk2gpz/1993-Dec-08
	 */
	public static double[][] getRollPichYowAnglesOf(double[][] aMatrix) {
		if (aMatrix == null || aMatrix.length == 0 ||
				aMatrix[0] == null || aMatrix[0].length != 3) {
			return null;
		}
		double a = Math.atan2(aMatrix[1][0], aMatrix[0][0]);
		double sa = Math.sin(a);
		double ca = Math.cos(a);
		double b = Math.atan2(-1 * aMatrix[2][0], ca * aMatrix[0][0] + sa * aMatrix[1][0]);
		double c = Math.atan2(sa * aMatrix[0][2] - ca * aMatrix[1][2],
				-1 * sa * aMatrix[0][1] + ca * aMatrix[1][1]);
		double[] res1 = new double[]{a, b, c};
		a = a + Math.PI;
		sa = Math.sin(a);
		ca = Math.cos(a);
		b = Math.atan2(-1 * aMatrix[2][0], ca * aMatrix[0][0] + sa * aMatrix[1][0]);
		c = Math.atan2(sa * aMatrix[0][2] - ca * aMatrix[1][2],
				-1 * sa * aMatrix[0][1] + ca * aMatrix[1][1]);
		double[] res2 = new double[]{a, b, c};
		return new double[][]{res1, res2};
	}
	
	/**
	 * |- rotationAngleOf:aMatrix|
	 * <p>
	 * vk2gpz/1993-Dec-08
	 */
	public static double[][] getRotationAnglesOf(double[][] aMatrix) {
		if (aMatrix == null || aMatrix.length == 0 || aMatrix[0] == null)
			return null;
		int size = aMatrix[0].length;
		double[] th = new double[1];
		double[][] result = new double[2][];
		
		if (size == 2) {    /*2D rotation*/
			th[0] = Math.atan2(aMatrix[1][0], aMatrix[0][0]);
			result[0] = th;
			return result;
		}
		
		double kx, ky, kz;
		double t1 = aMatrix[2][1] - aMatrix[1][2];
		double t2 = aMatrix[0][2] - aMatrix[2][0];
		double t3 = aMatrix[1][0] - aMatrix[0][1];
		double cs2 = aMatrix[0][0] + aMatrix[1][1] + aMatrix[2][2] - 1.0;
		double cs = cs2 / 2.0;
		double vers = 1.0 - cs;
		double sn2 = Math.sqrt(t1 * t1 + t2 * t2 + t3 * t3);
		th[0] = Math.atan2(sn2, cs2);
		if (th[0] < 1e-10)
			return null;
		else if (th[0] < 2.6) {
			kx = (aMatrix[2][1] - aMatrix[1][2]) / sn2;
			ky = (aMatrix[0][2] - aMatrix[2][0]) / sn2;
			kz = (aMatrix[1][0] - aMatrix[0][1]) / sn2;
		} else {
			kx = Math.sqrt((aMatrix[0][0] - cs) / vers);
			if (aMatrix[2][1] - aMatrix[1][2] < 0)
				kx = -kx;
			ky = Math.sqrt((aMatrix[1][1] - cs) / vers);
			if (aMatrix[0][2] - aMatrix[2][0] < 0)
				ky = -ky;
			kz = Math.sqrt((aMatrix[2][2] - cs) / vers);
			if (aMatrix[1][0] - aMatrix[0][1] < 0)
				kz = -kz;
		}
		
		if ((Math.abs(kx) > Math.abs(ky)) && (Math.abs(kx) > Math.abs(kz))) {
			ky = (aMatrix[1][0] + aMatrix[0][1]) / (2 * kx * vers);
			kz = (aMatrix[0][2] + aMatrix[2][0]) / (2 * kx * vers);
		} else if ((Math.abs(ky) > Math.abs(kx)) &&
				(Math.abs(ky) > Math.abs(kz))) {
			kx = (aMatrix[1][0] + aMatrix[0][1]) / (2 * ky * vers);
			kz = (aMatrix[1][2] + aMatrix[2][1]) / (2 * ky * vers);
		} else {
			kx = (aMatrix[0][2] + aMatrix[2][0]) / (2 * kz * vers);
			ky = (aMatrix[1][2] + aMatrix[2][1]) / (2 * kz * vers);
		}
		/**/
		double norm = Math.sqrt(kx * kx + ky * ky + kz * kz);
		double[] kr = new double[]{kx / norm,
				ky / norm,
				kz / norm}; /*axis vector*/
		result[0] = th;
		result[1] = kr;
		
		return result;
	}
	
	/**
	 * |- polarToOrthogonal:result|
	 * <p>
	 * vk2gpz/1994-Mar-30
	 */
	public static double[] polarToOrthogonal(double[] vector) {
		// check size of vector == 3
		
		double r = vector[0];
		double q = vector[1];
		double p = vector[2];
		
		double cosQ = (Double.compare(Math.abs(q), 90.0) == 0) ? 0.0 : Math.cos(Math.toRadians(q));
		double cosP = (Double.compare(Math.abs(p), 90.0) == 0) ? 0.0 : Math.cos(Math.toRadians(p));
		double sinQ = (Double.compare(Math.abs(q), 180.0) == 0) ? 0.0 : Math.sin(Math.toRadians(q));
		double sinP = (Double.compare(Math.abs(p), 180.0) == 0) ? 0.0 : Math.sin(Math.toRadians(p));
		
		return new double[]{r * sinQ * sinP, r * cosQ, r * sinQ * cosP};
	}
	
	/**
	 * |- globeToOrthogonal:result|
	 * <p>
	 * vk2gpz/1994-Mar-30
	 */
	public static double[] globeToOrthogonal(double[] vector) {
		vector[1] = 90.0 - vector[1];
		return polarToOrthogonal(vector);
	}
	
	/**
	 * |- orthogonalToPolar:result|
	 * <p>
	 * vk2gpz/1994-Mar-30
	 */
	public static double[] orthogonalToPolar(double[] vector) {
		double x = vector[0];
		double y = vector[1];
		double z = vector[2];
		
		double p, q;
		double r = x * x + z * z;        /* >= 0 */
		double rr = Math.sqrt(r); /* >= 0 */
		if (Double.compare(rr, 0.0) == 0 && Double.compare(y, 0.0) == 0)
			q = 0.0;            /* this point is the origine. */
		else
			q = Math.toDegrees(Math.atan2(rr, y)); /* 0 - 180 */
		r = Math.sqrt(r + y * y);
		
		if (Double.compare(x, 0.0) == 0 && Double.compare(z, 0.0) == 0)
			p = 0.0;            /* this point is on the Y axis. */
		else
			p = Math.toDegrees(Math.atan2(x, z)); /* -180 - 180 */
		if (p < 0.0)
			p = 360.0 - Math.abs(p);
		
		return new double[]{r, q, p};
	}
	
	/**
	 * |- orthogonalToSpherical:result|
	 * <p>
	 * vk2gpz/1994-Aug-02
	 */
	public static double[] orthogonalToSpherical(double[] vector) {
		double x = vector[0];
		double y = vector[1];
		double z = vector[2];
		
		double r = Math.sqrt(x * x + y * y + z * z);        /* >= 0 */
		double p = (Double.compare(r, 0.0) == 0) ? 0.0 : Math.toDegrees(Math.acos(z / r));    /* 0 <= t <= 180 */
		
		double t = Math.toDegrees(Math.atan2(y, x));        /* -180 <= t <= 180 */
		if (t < 0)
			t = 360.0 - Math.abs(t);
		
		return new double[]{r, t, p};
	}
}
