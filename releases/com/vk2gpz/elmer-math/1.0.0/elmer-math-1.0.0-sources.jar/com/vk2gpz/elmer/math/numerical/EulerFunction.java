/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.math.numerical;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
                Implementation of class EulerFunction                 
====================================================================*/
/**
 * EulerFunction implements a method to compute Euler's function.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class EulerFunction {
	private EulerFunction() {
		super();
	}
	
	/**
	* Returns Euler's Function <code>Phi(x)</code>.
	*/
	public static int getPhi(int x) {
		int t = x;
		if (x % 2 == 0) {
			t /= 2;
			do {
				x /= 2;
			} while (x % 2 == 0);
		}
		int d = 3;
		while (x / d >= d) {
			if (x % d == 0) {
				t = t / d * (d - 1);
				do {
					x /= d;
				} while (x % d == 0);
			}
			d += 2;
		}
		if (x > 1) {
			t = t / x * (x - 1);
		}
		return t;
	}
}

