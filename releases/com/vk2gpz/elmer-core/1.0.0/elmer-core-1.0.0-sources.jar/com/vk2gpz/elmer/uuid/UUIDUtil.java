/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.uuid;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.nio.ByteBuffer;
import java.util.Base64;
import java.util.UUID;

public class UUIDUtil {
    private static final Base64.Encoder ENCODER = Base64.getEncoder();
    private static final Base64.Decoder DECODER = Base64.getDecoder();
    // Base64 encoding of 16 bytes always produces 24 characters with exactly 2 padding chars
    private static final int BASE64_ENCODED_LENGTH = 22; // 24 - 2 padding chars

    private static byte[] asByteArray(UUID uuid) {
        ByteBuffer buffer = ByteBuffer.wrap(new byte[16]);
        buffer.putLong(uuid.getMostSignificantBits());
        buffer.putLong(uuid.getLeastSignificantBits());
        return buffer.array();
    }

    private static @NotNull UUID toUUID(byte[] byteArray) {
        ByteBuffer buffer = ByteBuffer.wrap(byteArray);
        long msb = buffer.getLong();
        long lsb = buffer.getLong();
        return new UUID(msb, lsb);
    }

    public static String uuidToString(UUID uuid) {
        try {
            byte[] uuidarr = asByteArray(uuid);
            String encoded = ENCODER.encodeToString(uuidarr);
            // Remove padding: Base64 of 16 bytes always has exactly 2 padding chars
            return encoded.substring(0, BASE64_ENCODED_LENGTH);
        } catch (Throwable e) {
            return uuid.toString();
        }
    }

    public static @Nullable UUID stringToUUID(String str) {
        try {
            // Add padding back: 16-byte UUID always has exactly 2 padding chars in Base64
            byte[] backArr = DECODER.decode(str + "==");
            return toUUID(backArr);
        } catch (Throwable e) {
            return null; // don't care what sort of error/exception, we will simply return null.
        }
    }
}
