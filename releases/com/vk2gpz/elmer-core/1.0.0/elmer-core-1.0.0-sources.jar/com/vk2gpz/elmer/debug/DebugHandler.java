/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.debug;

import com.vk2gpz.elmer.logging.ColorConsoleLogger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * This interface defines methods to turn on/off debug mode and also
 * managing debug "label" class implements this interface w
 */
@SuppressWarnings("unused")
public class DebugHandler {
	private static final class ActiveKeySet extends AbstractSet<String> {
		private final Set<String> delegate;
		
		private ActiveKeySet() {
			this.delegate = new HashSet<>();
		}
		
		private ActiveKeySet(int initialCapacity) {
			this.delegate = new HashSet<>(initialCapacity, 1.0f);
		}
		
		@Override
		public Iterator<String> iterator() {
			final Iterator<String> iterator = delegate.iterator();
			return new Iterator<String>() {
				@Override
				public boolean hasNext() {
					return iterator.hasNext();
				}
				
				@Override
				public String next() {
					return iterator.next();
				}
				
				@Override
				public void remove() {
					iterator.remove();
					invalidateGlobalLookupCache();
				}
			};
		}
		
		@Override
		public int size() {
			return delegate.size();
		}
		
		@Override
		public boolean contains(Object o) {
			return delegate.contains(o);
		}
		
		@Override
		public boolean add(String key) {
			final boolean changed = delegate.add(key);
			if (changed) {
				invalidateGlobalLookupCache();
			}
			return changed;
		}
		
		@Override
		public boolean remove(Object o) {
			final boolean changed = delegate.remove(o);
			if (changed) {
				invalidateGlobalLookupCache();
			}
			return changed;
		}
		
		@Override
		public void clear() {
			if (!delegate.isEmpty()) {
				delegate.clear();
				invalidateGlobalLookupCache();
			}
		}
		
		@Override
		public boolean addAll(Collection<? extends String> c) {
			final boolean changed = delegate.addAll(c);
			if (changed) {
				invalidateGlobalLookupCache();
			}
			return changed;
		}
		
		@Override
		public boolean retainAll(Collection<?> c) {
			final boolean changed = delegate.retainAll(c);
			if (changed) {
				invalidateGlobalLookupCache();
			}
			return changed;
		}
		
		@Override
		public boolean removeAll(Collection<?> c) {
			final boolean changed = delegate.removeAll(c);
			if (changed) {
				invalidateGlobalLookupCache();
			}
			return changed;
		}
	}
	
	private static final String WILDCARD_KEY = "*";
	private static final Map<Class<?>, Set<String>> DEBUG_KEYS = new ConcurrentHashMap<>();
	private static final Map<Class<?>, Boolean> DEBUG_STATUS = new ConcurrentHashMap<>();
	private static final Map<Class<?>, Set<String>> ACTIVE_KEYS = new ConcurrentHashMap<>();
	private static final Map<String, Boolean> GLOBAL_DEBUG_LOOKUP_CACHE = new ConcurrentHashMap<>();
	private static final Map<Class<?>, Set<String>> EXTRACTED_DEBUG_KEYS_CACHE = new ConcurrentHashMap<>();
	/** Used for elmer's own messages, and by {@code debug(...)} when no logger is given. */
	private static final Logger DEFAULT_LOGGER = ColorConsoleLogger.getLogger("elmer");
	
	public static Logger getLogger(String name) {
		return ColorConsoleLogger.getLogger(name);
	}
	
	/**
	 * @return true if the debug mode is turned on, false otherwise
	 */
	private static boolean debug(Class<?> klazz) {
		return DEBUG_STATUS.getOrDefault(klazz, false);
	}
	
	/**
	 * @param state the debug state to be set.
	 */
	private static void setDebug(Class<?> klazz, boolean state) {
		DEBUG_STATUS.put(klazz, state);
	}
	
	private static void invalidateGlobalLookupCache() {
		GLOBAL_DEBUG_LOOKUP_CACHE.clear();
	}
	
	private static @NotNull Set<String> normalizeKeys(String... keys) {
		if (keys == null || keys.length == 0) {
			return new ActiveKeySet();
		}
		final Set<String> active = new ActiveKeySet(keys.length);
		for (final String key : keys) {
			if (WILDCARD_KEY.equals(key)) {
				active.clear();
				active.add(WILDCARD_KEY);
				return active;
			}
			active.add(key);
		}
		return active;
	}
	
	private static void setActiveKeys(Class<?> klazz, String... keys) {
		ACTIVE_KEYS.put(klazz, normalizeKeys(keys));
		invalidateGlobalLookupCache();
	}
	
	private static void clearActiveKeys(Class<?> klazz) {
		if (ACTIVE_KEYS.remove(klazz) != null) {
			invalidateGlobalLookupCache();
		}
	}
	
	public static Set<String> getActiveKeys(Class<?> klazz) {
		ACTIVE_KEYS.computeIfAbsent(klazz, k -> new ActiveKeySet());
		return ACTIVE_KEYS.get(klazz);
	}
	
	/**
	 * Registeres a new key.
	 *
	 * @param newkeys new debug keys to be registered.
	 * @return the updated set of keys.
	 */
	public static Set<String> registerKeys(Class<?> klazz, Set<String> newkeys) {
		Set<String> keys = DEBUG_KEYS.computeIfAbsent(klazz, k -> new HashSet<>());
		keys.addAll(newkeys);
		return keys;
	}
	
	private static Set<String> registerKey(Class<?> klazz, String key) {
		Set<String> keys = DEBUG_KEYS.computeIfAbsent(klazz, k -> new HashSet<>());
		keys.add(key);
		return keys;
	}
	
	/**
	 * @return a list of registered debug keys for the specified class.
	 */
	public static Set<String> getKeys(Class<?> klazz) {
		return DEBUG_KEYS.computeIfAbsent(klazz, k -> new HashSet<>());
	}
	
	/**
	 *
	 */
	public static void debugOn(Class<?> klazz, String... keys) {
		setActiveKeys(klazz, keys);
		setDebug(klazz, true);
	}
	
	public static void debugOff(Class<?> klazz) {
		clearActiveKeys(klazz);
		setDebug(klazz, false);
	}
	
	public static boolean isDebugged(String key) {
		if (key == null) {
			return false;
		}
		return GLOBAL_DEBUG_LOOKUP_CACHE.computeIfAbsent(key, DebugHandler::isGloballyDebugged);
	}
	
	/**
	 * Debug switch for a whole class (replaces the old {@code DebugUtil.getDebug}). True after
	 * {@link #debugOn(Class, String...)} for {@code klazz}, or when the system property {@code elmer.debug}
	 * or {@code <fully.qualified.ClassName>.debug} is {@code true} (e.g. {@code -Delmer.debug=true}).
	 */
	public static boolean isDebugged(Class<?> klazz) {
		if (klazz == null) {
			return false;
		}
		return debug(klazz) || systemFlag("elmer.debug") || systemFlag(klazz.getName() + ".debug");
	}

	private static boolean systemFlag(String property) {
		try {
			return Boolean.getBoolean(property);
		} catch (SecurityException e) {
			return false;
		}
	}

	/** @return the name of the method that calls this one (replaces the old {@code DebugUtil.getMethodName}). */
	public static String currentMethodName() {
		StackTraceElement[] stack = new Throwable().getStackTrace();
		return stack.length > 1 ? stack[1].getMethodName() : "";
	}

	public static boolean isDebugged(Class<?> klazz, String key) {
		if (klazz == null) {
			return isDebugged(key);
		}
		if (key == null) {
			return false;
		}
		if (!debug(klazz)) {
			return false;
		}
		final Set<String> keys = ACTIVE_KEYS.get(klazz);
		return keys != null && (keys.contains(WILDCARD_KEY) || keys.contains(key));
	}
	
	private static boolean isGloballyDebugged(String key) {
		for (final Set<String> keys : ACTIVE_KEYS.values()) {
			if (keys.contains(WILDCARD_KEY) || keys.contains(key)) {
				return true;
			}
		}
		return false;
	}
	
	public static Set<String> extractDebugKeys(Class<?> handler) {
		final Set<String> cached = EXTRACTED_DEBUG_KEYS_CACHE.get(handler);
		if (cached != null) {
			return cached;
		}
		final Set<String> result = new HashSet<>();
		try {
			final Method[] methods = handler.getDeclaredMethods();
			for (final Method method : methods) {
				// Do not register bridge or synthetic methods to avoid event duplication
				// Fixes SPIGOT-893
				if (method.isBridge() || method.isSynthetic()) {
					continue;
				}
				final DebugLabel dl = method.getAnnotation(DebugLabel.class);
				if (dl != null) {
					result.add(dl.key());
				}
			}
		} catch (NoClassDefFoundError e) {
			DEFAULT_LOGGER.severe("Class " + handler.getSimpleName() + " has failed to register debug keys");
			return getKeys(handler);
		}
		final Set<String> cachedResult = result.isEmpty() ? Collections.emptySet() : Collections.unmodifiableSet(result);
		final Set<String> previous = EXTRACTED_DEBUG_KEYS_CACHE.putIfAbsent(handler, cachedResult);
		return previous != null ? previous : cachedResult;
	}
	
	/**
	 * This method should be invoked when an object is instantiated.
	 */
	public static Set<String> registerKeys(Class<?> owner, Class<?> handler) {
		return registerKeys(owner, extractDebugKeys(handler));
	}
	
	public static void unregister(Class<?> owner) {
		DEBUG_KEYS.remove(owner);
		DEBUG_STATUS.remove(owner);
		clearActiveKeys(owner);
	}
	
	public static void debug(@Nullable Logger logger, @Nullable Class<?> mainClass, @NotNull String key, @NotNull String msg) {
		if (mainClass != null ? isDebugged(mainClass, key) : isDebugged(key)) {
			if (logger != null) {
				logger.info(msg);
			} else {
				DEFAULT_LOGGER.info(msg);
			}
		}
	}
	
	public static void debug(@Nullable Logger logger, @NotNull String key, @NotNull String msg) {
		debug(logger, null, key, msg);
	}
	
	public static void debug(@NotNull String key, @NotNull String msg) {
		debug(null, key, msg);
	}
	
	public static void debug(@Nullable Logger logger, @NotNull String msg) {
		final StackTraceElement[] stackTrace = new Throwable().getStackTrace();
		StackTraceElement caller = stackTrace.length > 1 ? stackTrace[1] : stackTrace[0];
		if (stackTrace.length > 2
				&& DebugHandler.class.getName().equals(caller.getClassName())
				&& "debug".equals(caller.getMethodName())) {
			caller = stackTrace[2];
		}
		String callerClassName = caller.getClassName();
		String simpleCallerClassName = callerClassName.substring(callerClassName.lastIndexOf('.') + 1);
		String key = simpleCallerClassName + "_" + caller.getMethodName();
		debug(logger, key, msg);
	}
	
	public static void debug(@NotNull String msg) {
		debug((Logger) null, msg);
	}
}
