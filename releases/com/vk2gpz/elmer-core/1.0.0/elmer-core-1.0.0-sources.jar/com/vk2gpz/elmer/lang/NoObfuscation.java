/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.lang;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * EventPriorityHandler annotation to label event handlers.
 * @author vk2gpz
 */
@Retention(RetentionPolicy.CLASS)
public @interface NoObfuscation {
    String name() default "NoObfuscation";
}
