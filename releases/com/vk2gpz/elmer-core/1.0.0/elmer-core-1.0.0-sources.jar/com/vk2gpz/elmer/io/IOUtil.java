/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.io;

import com.vk2gpz.elmer.debug.DebugHandler;
import com.vk2gpz.elmer.logging.ColorConsoleLogger;

import java.io.*;
import java.math.BigInteger;
import java.net.URL;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Stream;

@SuppressWarnings("unused")
public class IOUtil {
	static class DigestInputStream extends FilterInputStream {
		private MessageDigest digest;
		private boolean state = true;
		
		DigestInputStream(InputStream stream, MessageDigest digest) {
			super(stream);
			this.digest = digest;
		}
		
		MessageDigest getMessageDigest() {
			return digest;
		}
		
		void setMessageDigest(MessageDigest digest) {
			this.digest = digest;
		}
		
		public int read() throws IOException {
			int temp = in.read();
			if (state && temp != -1)
				digest.update((byte) temp);
			return temp;
		}
		
		public int read(byte[] b, int off, int len) throws IOException {
			int temp = in.read(b, off, len);
			if (state && temp != -1)
				digest.update(b, off, temp);
			return temp;
		}
		
		void on(boolean on) {
			state = on;
		}
		
		public String toString() {
			return "[Input Stream] " + digest.toString();
		}
	}
	
	private String getSignature(Class<?> clazz) {
		try {
			URL location = clazz.getResource('/' + clazz.getName().replace('.', '/') + ".class");
			assert location != null;
			InputStream stream = location.openStream(); //clazz.getClassLoader().getResourceAsStream(path);
			DigestInputStream dstream = new DigestInputStream(stream, MessageDigest.getInstance("MD5"));
			
			byte[] buffer = new byte[65536];
			
			int read = stream.read(buffer);
			while (read >= 1)
				read = stream.read(buffer);
			dstream.close();
			//noinspection ResultOfMethodCallIgnored
			String.format("%1$032x", new BigInteger(1, dstream.getMessageDigest().digest()));
		} catch (NoSuchAlgorithmException | IOException ignore) {
		
		}
		
		return null;
	}
	
	public static void copyDir(String src, String dest, boolean overwrite) {
		try {
			try (Stream<Path> entries = Files.walk(Paths.get(src))) {
				entries.forEach(a -> {
					Path b = Paths.get(dest, a.toString().substring(src.length()));
					try {
						if (!a.toString().equals(src))
							Files.copy(a, b, overwrite ? new CopyOption[]{StandardCopyOption.REPLACE_EXISTING} : new CopyOption[]{});
					} catch (IOException e) {
						e.printStackTrace();
					}
				});
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void saveResourceFromJar(Class<?> klass, File dataFolder, String resourcePath, String targetPath, boolean replace) {
		if (resourcePath == null || resourcePath.equals("")) {
			throw new IllegalArgumentException("ResourcePath cannot be null or empty");
		}
		
		resourcePath = resourcePath.replace('\\', '/');
		InputStream in = getResourceFromJar(klass, resourcePath);
		if (in == null) {
			throw new IllegalArgumentException("The embedded resource '" + resourcePath + "' cannot be found in " + klass.getName() + "'s jarfile.");
		}
		
		File outFile = new File(dataFolder, targetPath);
		int lastIndex = resourcePath.lastIndexOf('/');
		File outDir = new File(dataFolder, resourcePath.substring(0, Math.max(lastIndex, 0)));
		
		if (!outDir.exists()) {
			//noinspection ResultOfMethodCallIgnored
			outDir.mkdirs();
		}
		
		if (!outFile.exists() || replace) {
			try (InputStream inStream = in;
				 OutputStream out = Files.newOutputStream(outFile.toPath())) {
				byte[] buf = new byte[8192];
				int len;
				while ((len = inStream.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
			} catch (IOException ex) {
				DebugHandler.getLogger("elmer").severe("Could not save " + outFile.getName() + " to " + outFile);
			}
		} else {
			try {
				in.close();
			} catch (IOException ignore) {}
			DebugHandler.getLogger("elmer").warning("Could not save " + outFile.getName() + " to " + outFile + " because " + outFile.getName() + " already exists.");
		}
	}
	
	public static InputStream getResourceFromJar(Class<?> klass, String filename, boolean recursive) {
		if (filename == null) {
			throw new IllegalArgumentException("Filename cannot be null");
		}
		
		try {
			URL url = klass.getProtectionDomain().getCodeSource().getLocation(); // this is url to jar file.
			if (url == null) {
				return null;
			}
			
			URL jarurl = new URL("jar:" + url.toURI() + "!/" + filename);
			return jarurl.openStream();
		} catch (Throwable ex) {
			//ex.printStackTrace();
			return null;
		}
	}
	
	public static InputStream getResourceFromJar(Class<?> klass, String filename) {
		return getResourceFromJar(klass, filename, false);
	}
	
	public static void saveResourcesFromJar(Class<?> klass, File dataFolder, String extension, boolean replace, String... exceptions) {
		List<String> exceptionList = Arrays.asList(exceptions);
		if (extension == null || extension.equals("")) {
			throw new IllegalArgumentException("Resource extension cannot be null or empty");
		}
		
		URL url = klass.getProtectionDomain().getCodeSource().getLocation(); // this is url to jar file.
		if (url == null) {
			throw new IllegalArgumentException("No .jar file found.");
		}
		
		try {
			JarFile jarfile = new JarFile(new File(url.toURI()));
			Enumeration<JarEntry> enumEntries = jarfile.entries();
			while (enumEntries.hasMoreElements()) {
				JarEntry file = enumEntries.nextElement();
				if (!file.getName().endsWith(extension) || exceptionList.contains(file.getName()))
					continue;
				
				File f = new File(dataFolder, file.getName());
				if (!f.exists() || replace) {
					InputStream in = jarfile.getInputStream(file);
					FileOutputStream out = new FileOutputStream(f);
					byte[] buf = new byte[1024];
					int len;
					while ((len = in.read(buf)) > 0) {
						out.write(buf, 0, len);
					}
					
					out.close();
					in.close();
				}
			}
			jarfile.close();
		} catch (Throwable ignore) {
			DebugHandler.getLogger("elmer").severe("Could not save resource files.");
		}
	}
}
