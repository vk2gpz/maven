/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.logging;

import java.util.logging.ConsoleHandler;
import java.util.logging.LogRecord;

/**
 * Console handler with coloured output.
 * <p>
 * When Log4j 2 is on the classpath (as on a Minecraft server), records are passed to Log4j so they
 * appear in the server log. Otherwise they are written to {@code System.err} like a normal
 * {@link ConsoleHandler}. Log4j is an optional dependency: nothing here loads a Log4j class unless
 * Log4j is present.
 */
public class ColorLogHandler extends ConsoleHandler {
	private static final boolean LOG4J_PRESENT = isLog4jPresent();

	private final Log4jBridge log4j = LOG4J_PRESENT ? new Log4jBridge() : null;

	public ColorLogHandler() {
		setFormatter(new ColorFormatter());
	}

	static boolean isLog4jPresent() {
		try {
			Class.forName("org.apache.logging.log4j.LogManager", false, ColorLogHandler.class.getClassLoader());
			return true;
		} catch (ClassNotFoundException | LinkageError e) {
			return false;
		}
	}

	/** @return true if records go to Log4j, false if they go to {@code System.err}. */
	public boolean usesLog4j() {
		return log4j != null;
	}

	@Override
	public void publish(final LogRecord record) {
		if (log4j != null) {
			// Log4j's own configuration decides which levels are shown.
			log4j.publish(record, getFormatter().format(record));
		} else {
			super.publish(record);  // ConsoleHandler: formats, writes to System.err and flushes
		}
	}

	@Override
	public void flush() {
		if (log4j == null) {
			super.flush();
		}
	}

	@Override
	public void close() throws SecurityException {
		flush();  // never close System.err
	}
}
