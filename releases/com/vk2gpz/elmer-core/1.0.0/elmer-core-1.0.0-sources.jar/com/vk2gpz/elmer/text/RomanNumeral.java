/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.text;

/*
  An object of type RomanNumeral is an integer between 1 and 3999.  It can
  be constructed either from an integer or from a string that represents
  a Roman numeral in this range.  The function toString() will return a
  standardized Roman numeral representation of the number.  The function
  toInt() will return the number as a value of type int.
*/

@SuppressWarnings("unused")
public class RomanNumeral {
	/* The following arrays are used by the function to construct
	   the standard Roman numeral representation of the number.  For each i,
	   the number numbers[i] is represented by the corresponding string,
	   letters[i].
	*/
	private static final int[] numbers = {1000, 900, 500, 400, 100, 90,
			50, 40, 10, 9, 5, 4, 1};
	private static final String[] letters = {"M", "CM", "D", "CD", "C", "XC",
			"L", "XL", "X", "IX", "V", "IV", "I"};

	private static int letterToNumber(char letter) {
		// Find the integer value of letter considered as a Roman numeral.  Return
		// -1 if letter is not a legal Roman numeral.  The letter must be upper case.
		switch (letter) {
			case 'I':
			case 'i':
				return 1;
			case 'V':
			case 'v':
				return 5;
			case 'X':
			case 'x':
				return 10;
			case 'L':
			case 'l':
				return 50;
			case 'C':
			case 'c':
				return 100;
			case 'D':
			case 'd':
				return 500;
			case 'M':
			case 'm':
				return 1000;
			default:
				return -1;
		}
	}

	public static String toRoman(int arabic, boolean useRoman) {
		return toRoman(arabic, useRoman, false);
	}

	public static String toRoman(int arabic, boolean useRoman, boolean tilmax) {
		StringBuilder roman = new StringBuilder();  // The roman numeral.

		//if (!TokenEnchantConfig.UseRomanNumeral || arabic < 1 || arabic > 3999) {
		if (!useRoman || arabic < 1 || arabic > ((tilmax) ? 3999 : 10)) {
			roman = new StringBuilder("" + arabic);
		} else {
			// Return the standard representation of this Roman numeral.
			int N = arabic;        // N represents the part of num that still has
			//   to be converted to Roman numeral representation.
			for (int i = 0; i < numbers.length; i++) {
				while (N >= numbers[i]) {
					roman.append(letters[i]);
					N -= numbers[i];
				}
			}
		}
		return roman.toString();
	}

	public static int toInt(String roman) {
		// For example, RomanNumeral("xvii") is 17.  If the parameter is not a
		// legal Roman numeral, a NumberFormatException is thrown.
		// Both upper and lower case letters are allowed.

		if (roman.length() == 0)
			throw new NumberFormatException("An empty string does not define a Roman numeral.");

		int arabic = 0;  // Arabic numeral equivalent of the part of the string that has been converted so far.

		try {
			// if this scceed, roman must be <0 or >3999
			arabic = Integer.parseInt(roman);
			return arabic;
		} catch (Exception e) {
			// ok, roman is not a arabic number, must be string
			// do the converstion!
		}

		// Process roman numeral - letterToNumber() handles both cases now
		int i = 0;       // A position in the string, roman;
		while (i < roman.length()) {
			char letter = roman.charAt(i);        // Letter at current position in string.
			int number = letterToNumber(letter);  // Numerical equivalent of letter.

			if (number < 0)
				throw new NumberFormatException("Illegal character \"" + letter + "\" in roman numeral.");

			i++;  // Move on to next position in the string

			if (i == roman.length()) {
				// There is no letter in the string following the one we have just processed.
				// So just add the number corresponding to the single letter to arabic.
				arabic += number;
			} else {
				// Look at the next letter in the string.  If it has a larger Roman numeral
				// equivalent than number, then the two letters are counted together as
				// a Roman numeral with value (nextNumber - number).
				int nextNumber = letterToNumber(roman.charAt(i));
				if (nextNumber > number) {
					// Combine the two letters to get one value, and move on to next position in string.
					arabic += (nextNumber - number);
					i++;
				} else {
					// Don't combine the letters.  Just add the value of the one letter onto the number.
					arabic += number;
				}
			}
		}  // end while

		if (arabic > 3999)
			throw new NumberFormatException("Roman numeral must have value 3999 or less.");

		return arabic;
	}
}
