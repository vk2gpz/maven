/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.debug;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * DebugLabel annotation to label debug scope.
 * @author vk2gpz
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface DebugLabel {
    /**
     * DebugLabelKey string indicating which Key (identifier) should be used for this debug scope.
     * @return a string indicating which Key (identifier) should be used for this debug scope.
     */
    String key() default "";
}
