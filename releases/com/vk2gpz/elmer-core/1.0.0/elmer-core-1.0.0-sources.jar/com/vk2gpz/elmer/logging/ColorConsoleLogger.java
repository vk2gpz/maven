/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.logging;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.ConsoleHandler;
import java.util.logging.Logger;

@SuppressWarnings("unused")
public class ColorConsoleLogger {
    private static final Map<String, Logger> LOGGER_CACHE = new ConcurrentHashMap<>();
    private static final ConsoleHandler SHARED_HANDLER = new ColorLogHandler();
    static {
        SHARED_HANDLER.setFormatter(new ColorFormatter());
    }
    
    public static Logger getLogger(String name) {
        return LOGGER_CACHE.computeIfAbsent(name, key -> {
            final Logger logger = Logger.getLogger(key);
            logger.setUseParentHandlers(false);
            logger.addHandler(SHARED_HANDLER);
            return logger;
        });
    }
    
    public static Logger initLogger(Logger logger) {
        if (logger == null) {
            logger = Logger.getAnonymousLogger();
        }
        logger.setUseParentHandlers(false);
        // Reuse shared handler instead of creating new one
        for (java.util.logging.Handler handler : logger.getHandlers()) {
            if (handler instanceof ColorLogHandler) {
                return logger;  // Already has ColorLogHandler
            }
        }
        logger.addHandler(SHARED_HANDLER);
        return logger;
    }
}
