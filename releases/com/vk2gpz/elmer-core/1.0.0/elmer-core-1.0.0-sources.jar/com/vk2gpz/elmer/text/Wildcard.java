/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/**
 * A compiled wildcard pattern, such as {@code "mine_*"} or {@code "arena_??"}, that checks whether a whole text
 * matches it. Wildcards are the simple patterns people type into config files and commands: easier to write than
 * regular expressions, and much faster to match.
 *
 * <h2>Pattern syntax</h2>
 * <table>
 *   <caption>What each character in a pattern means</caption>
 *   <tr><th>In the pattern</th><th>Matches</th></tr>
 *   <tr><td>{@code *}</td><td>any run of characters, including none</td></tr>
 *   <tr><td>{@code ?}</td><td>exactly one character</td></tr>
 *   <tr><td>anything else</td><td>itself; there is no escape character, and characters such as {@code .},
 *       {@code [}, {@code \} or {@code $} have no special meaning</td></tr>
 * </table>
 *
 * <h2>Examples</h2>
 * <table>
 *   <caption>Example patterns and texts</caption>
 *   <tr><th>Pattern</th><th>Matches</th><th>Does not match</th></tr>
 *   <tr><td>{@code mine_*}</td><td>{@code mine_}, {@code mine_a}, {@code mine_north_1}</td><td>{@code mine},
 *       {@code my_mine_a}</td></tr>
 *   <tr><td>{@code *_spawn}</td><td>{@code world_spawn}, {@code _spawn}</td><td>{@code spawn},
 *       {@code world_spawn_2}</td></tr>
 *   <tr><td>{@code *arena*}</td><td>{@code arena}, {@code pvp_arena_1}</td><td>{@code aren}</td></tr>
 *   <tr><td>{@code arena_??}</td><td>{@code arena_01}, {@code arena_ab}</td><td>{@code arena_1},
 *       {@code arena_123}</td></tr>
 *   <tr><td>{@code *.yml}</td><td>{@code config.yml}, {@code .yml}</td><td>{@code config.yaml}</td></tr>
 *   <tr><td>{@code *}</td><td>any text without a line break, including the empty text</td><td>a text that
 *       contains a line break</td></tr>
 *   <tr><td>(empty pattern)</td><td>only the empty text</td><td>anything else</td></tr>
 * </table>
 *
 * <h2>Exact rules</h2>
 * A case-sensitive match always gives the same result as compiling {@link WildcardUtil#wildcardToRegex(String)}
 * with {@link java.util.regex.Pattern} and calling {@code matches()}; tests check this on hundreds of thousands of
 * random patterns and texts. In detail:
 * <ul>
 *   <li><b>Whole text.</b> The pattern must match the entire text, not just a part of it. Use {@code *abc*} to
 *       find {@code abc} anywhere.</li>
 *   <li><b>Characters, not {@code char}s.</b> {@code ?} matches one Unicode code point. An emoji is stored by Java
 *       as two {@code char}s (a surrogate pair) but counts as one character here, and no match ever splits a
 *       pair.</li>
 *   <li><b>No line breaks.</b> {@code *} and {@code ?} never match a line terminator (line feed, carriage return,
 *       U+0085, U+2028 or U+2029), just like {@code .} in a regular expression. So {@code a*b} does not match
 *       {@code a}, line feed, {@code b}. A line terminator written in the pattern matches itself.</li>
 *   <li><b>Case.</b> Matching is case-sensitive by default. With {@code ignoreCase}, two letters are equal when
 *       converting each to upper case and then to lower case gives the same letter, for all of Unicode. So
 *       {@code ÄBC*} matches {@code äbc_1}, the Turkish dotless {@code ı} matches the dotted capital {@code İ}, and
 *       the Kelvin sign matches {@code k}. This is the rule {@code java.util.regex} uses for literal text with
 *       {@code CASE_INSENSITIVE | UNICODE_CASE}. (A regular expression treats a <em>single</em> literal character
 *       slightly differently: one without separate upper- and lower-case forms, such as {@code ß}, must then match
 *       exactly. Here the rule is the same everywhere, so {@code *ß} and {@code aß} both match a capital
 *       {@code ẞ}.)</li>
 *   <li><b>Nulls.</b> A null pattern or a null text is rejected with {@link IllegalArgumentException}.</li>
 * </ul>
 *
 * <h2>Using it</h2>
 * Compile a pattern once and reuse it. A {@code Wildcard} is also a {@link Predicate Predicate&lt;String&gt;}:
 * <pre>{@code
 * Wildcard mines = Wildcard.compile("mine_*");
 * if (mines.matches(regionName)) {
 *     // ...
 * }
 *
 * List<String> arenas = regionNames.stream()
 *         .filter(Wildcard.compile("*arena*", true))   // ignoring case
 *         .collect(Collectors.toList());
 * }</pre>
 * For a one-off check, {@link WildcardUtil#matches(String, String)} and
 * {@link WildcardUtil#matchesIgnoreCase(String, String)} match without compiling anything first.
 *
 * <h2>Performance</h2>
 * {@link #compile} looks at the pattern once:
 * <ul>
 *   <li>Common shapes get a shortcut that uses the JDK's own optimised string methods: {@code abc} uses
 *       {@code equals}, {@code abc*} uses {@code startsWith}, {@code *abc} uses {@code endsWith}, {@code *abc*}
 *       uses {@code indexOf}, and {@code *} only scans for line breaks.</li>
 *   <li>Any other pattern is split at its {@code *}s into a <em>head</em> (before the first {@code *}),
 *       <em>middle parts</em> and a <em>tail</em> (after the last {@code *}). {@link #matches} first rejects texts
 *       that are too short (or, without a {@code *}, too long) to match, then checks the head at the start and the
 *       tail backwards from the end of the text, and finally finds each middle part at its leftmost possible place,
 *       using {@link String#indexOf(String, int)} for parts without {@code ?}.</li>
 * </ul>
 * Taking the leftmost place for each middle part is always correct, because every {@code *} matches the same set of
 * strings: placing a part further right can only make the gaps longer. So a match takes about one pass over the text
 * and never backtracks; even a pattern like {@code *a*a*a*a*b}, which makes a regular expression backtrack heavily,
 * runs in linear time. Plain {@code char}s are compared directly, and Unicode code points are decoded only around
 * surrogate pairs.
 *
 * <h2>Thread safety</h2>
 * A {@code Wildcard} is immutable: one instance can be shared by any number of threads, and matching allocates
 * nothing and takes no locks.
 *
 * <h2>Compared with other pattern types</h2>
 * <ul>
 *   <li><b>Regular expressions</b> ({@link java.util.regex.Pattern}) can express much more, but are slower and
 *       need escaping for ordinary characters such as {@code .}. {@link WildcardUtil#wildcardToRegex(String)}
 *       converts a wildcard when a regular expression is needed.</li>
 *   <li><b>File-system globs</b> ({@link java.nio.file.FileSystem#getPathMatcher(String)}) give {@code /},
 *       {@code [...]} and <code>{a,b}</code> special meanings; here every character except {@code *} and {@code ?} is
 *       literal.</li>
 *   <li><b>SQL {@code LIKE}</b> uses {@code %} and {@code _}; {@link WildcardUtil#wildcardToSqlPattern(String)}
 *       converts a wildcard for use in a query.</li>
 * </ul>
 *
 * @see WildcardUtil
 */
public final class Wildcard implements Predicate<String> {

	/** The overall form of a pattern, chosen once by {@link #compile} so {@link #matches} can take a shortcut. */
	private enum Shape {
		/** No wildcard at all: the text must equal the pattern. */
		EXACT,
		/** Only {@code *}s: any text without a line terminator. */
		ANY,
		/** {@code literal*}: starts with the literal. */
		PREFIX,
		/** {@code *literal}: ends with the literal. */
		SUFFIX,
		/** {@code *literal*}: contains the literal. */
		CONTAINS,
		/** Anything else, or any pattern with {@code ignoreCase}: matched part by part. */
		GENERAL
	}

	/**
	 * A piece of the pattern without {@code *} (it may contain {@code ?}), with the facts the matcher needs about it.
	 */
	private static final class Part {
		/** The pattern characters of this part. */
		final String chars;
		/** True if the part contains {@code ?}; otherwise it can be searched for with {@code indexOf}. */
		final boolean hasQuestionMark;
		/** The fewest text {@code char}s the part can match: each {@code ?} matches at least one. */
		final int minLength;
		/** The most text {@code char}s the part can match: each {@code ?} may match a surrogate pair. */
		final int maxLength;
		/** The first pattern character, or -1 if it is {@code ?} or a surrogate (then it can't be used to skip ahead). */
		final int firstPlainChar;

		/**
		 * @param chars a non-empty piece of the pattern that contains no {@code *}
		 */
		Part(String chars) {
			this.chars = chars;
			int questionMarks = 0;
			for (int i = 0; i < chars.length(); i++) {
				if (chars.charAt(i) == '?') questionMarks++;
			}
			this.hasQuestionMark = questionMarks > 0;
			this.minLength = chars.length();
			this.maxLength = chars.length() + questionMarks;
			char first = chars.charAt(0);
			this.firstPlainChar = first == '?' || Character.isSurrogate(first) ? -1 : first;
		}
	}

	private final String pattern;
	private final boolean ignoreCase;
	private final Shape shape;
	/** The literal for EXACT, PREFIX, SUFFIX and CONTAINS; otherwise null. */
	private final String literal;
	/** GENERAL only: the part before the first {@code *} (the whole pattern if there is no {@code *}), or null. */
	private final Part head;
	/** GENERAL only: the parts between {@code *}s, in order; empty if there are none. */
	private final Part[] middle;
	/** GENERAL only: the part after the last {@code *}, or null if the pattern ends with {@code *} or has none. */
	private final Part tail;
	/** GENERAL only: whether the pattern contains {@code *}. */
	private final boolean hasStar;
	/** GENERAL only: the shortest text (in {@code char}s) that can match. */
	private final int minLength;
	/** GENERAL only: the longest text that can match, or {@code Integer.MAX_VALUE} if the pattern has a {@code *}. */
	private final int maxLength;

	/** Creates a matcher for one of the simple shapes; see {@link #compile}. */
	private Wildcard(String pattern, Shape shape, String literal) {
		this.pattern = pattern;
		this.ignoreCase = false;
		this.shape = shape;
		this.literal = literal;
		this.head = null;
		this.middle = new Part[0];
		this.tail = null;
		this.hasStar = shape != Shape.EXACT;
		this.minLength = literal.length();
		this.maxLength = hasStar ? Integer.MAX_VALUE : literal.length();
	}

	/** Creates a GENERAL matcher from the parts of the pattern; see {@link #compile}. */
	private Wildcard(String pattern, boolean ignoreCase, Part head, Part[] middle, Part tail, boolean hasStar) {
		this.pattern = pattern;
		this.ignoreCase = ignoreCase;
		this.shape = Shape.GENERAL;
		this.literal = null;
		this.head = head;
		this.middle = middle;
		this.tail = tail;
		this.hasStar = hasStar;
		int min = 0, max = 0;
		for (Part p : allParts(head, middle, tail)) {
			min += p.minLength;
			max += p.maxLength;
		}
		this.minLength = min;
		this.maxLength = hasStar ? Integer.MAX_VALUE : max;
	}

	/**
	 * Prepares a case-sensitive pattern; same as {@code compile(pattern, false)}.
	 *
	 * @param pattern the wildcard pattern, for example {@code "mine_*"}
	 * @return a reusable, thread-safe matcher
	 * @throws IllegalArgumentException if {@code pattern} is null
	 */
	public static Wildcard compile(String pattern) {
		return compile(pattern, false);
	}

	/**
	 * Prepares a pattern for repeated matching. This looks at the pattern once: it picks a shortcut for the common
	 * shapes, and otherwise splits the pattern at its {@code *}s (see the class description). Compile once and reuse
	 * the result when the same pattern is matched against many texts.
	 *
	 * @param pattern    the wildcard pattern, for example {@code "mine_*"}
	 * @param ignoreCase true to match letters regardless of case
	 * @return a reusable, thread-safe matcher
	 * @throws IllegalArgumentException if {@code pattern} is null
	 */
	public static Wildcard compile(String pattern, boolean ignoreCase) {
		if (pattern == null) {
			throw new IllegalArgumentException("Wildcard must not be null");
		}
		final int n = pattern.length();
		final boolean hasStar = pattern.indexOf('*') >= 0;
		if (!ignoreCase && pattern.indexOf('?') < 0) {
			if (!hasStar) {
				return new Wildcard(pattern, Shape.EXACT, pattern);
			}
			int lead = 0;
			while (lead < n && pattern.charAt(lead) == '*') lead++;
			if (lead == n) {
				return new Wildcard(pattern, Shape.ANY, "");
			}
			int trail = n;
			while (pattern.charAt(trail - 1) == '*') trail--;
			String inner = pattern.substring(lead, trail);
			if (inner.indexOf('*') < 0) {   // exactly one literal, with *s only at the ends
				if (lead == 0) return new Wildcard(pattern, Shape.PREFIX, inner);
				if (trail == n) return new Wildcard(pattern, Shape.SUFFIX, inner);
				// "*literal*": the text outside the literal must have no line terminator. The shortcut checks the whole
				// text, which is only right if the literal itself has none.
				if (!hasLineTerminator(inner, 0, inner.length())) return new Wildcard(pattern, Shape.CONTAINS, inner);
			}
		}
		// GENERAL: split at the *s
		List<Part> parts = new ArrayList<>();
		int start = 0;
		for (int i = 0; i <= n; i++) {
			if (i == n || pattern.charAt(i) == '*') {
				parts.add(i > start ? new Part(pattern.substring(start, i)) : null);
				start = i + 1;
			}
		}
		// parts[0] is before the first *, parts[last] after the last *; nulls are empty pieces between *s
		Part head = parts.get(0);
		Part tail = hasStar ? parts.get(parts.size() - 1) : null;
		List<Part> middle = new ArrayList<>();
		for (int i = 1; i < parts.size() - 1; i++) {
			if (parts.get(i) != null) middle.add(parts.get(i));
		}
		return new Wildcard(pattern, ignoreCase, head, middle.toArray(new Part[0]), tail, hasStar);
	}

	/**
	 * @return the pattern exactly as it was given to {@link #compile}
	 */
	public String pattern() {
		return pattern;
	}

	/**
	 * @return true if this pattern matches letters regardless of case
	 */
	public boolean isIgnoreCase() {
		return ignoreCase;
	}

	/**
	 * Checks whether the whole of {@code text} matches this pattern, following the rules in the class description.
	 *
	 * @param text the text to check
	 * @return true if it matches
	 * @throws IllegalArgumentException if {@code text} is null
	 */
	public boolean matches(String text) {
		if (text == null) {
			throw new IllegalArgumentException("Text must not be null");
		}
		final int n = text.length();
		switch (shape) {
			case EXACT:
				return text.equals(literal);
			case ANY:
				return !hasLineTerminator(text, 0, n);
			case PREFIX: {
				int len = literal.length();
				return text.startsWith(literal) && onBoundary(text, len) && !hasLineTerminator(text, len, n);
			}
			case SUFFIX: {
				int from = n - literal.length();
				return text.endsWith(literal) && onBoundary(text, from) && !hasLineTerminator(text, 0, from);
			}
			case CONTAINS:
				return !hasLineTerminator(text, 0, n) && containsOnBoundaries(text, literal);
			default:
				return matchesParts(text);
		}
	}

	/**
	 * Same as {@link #matches(String)}, so a {@code Wildcard} can be used wherever a {@code Predicate<String>} is
	 * expected, for example {@code names.stream().filter(wildcard)}.
	 *
	 * @param text the text to check
	 * @return true if it matches
	 * @throws IllegalArgumentException if {@code text} is null
	 */
	@Override
	public boolean test(String text) {
		return matches(text);
	}

	/**
	 * @return {@code Wildcard[pattern]}, with {@code , ignoreCase} added when that is set
	 */
	@Override
	public String toString() {
		return "Wildcard[" + pattern + (ignoreCase ? ", ignoreCase" : "") + "]";
	}

	/**
	 * Two wildcards are equal when they have the same pattern and the same {@code ignoreCase} setting.
	 *
	 * @param o the object to compare with
	 * @return true if {@code o} is an equal {@code Wildcard}
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Wildcard)) return false;
		Wildcard w = (Wildcard) o;
		return ignoreCase == w.ignoreCase && pattern.equals(w.pattern);
	}

	/**
	 * @return a hash code consistent with {@link #equals(Object)}
	 */
	@Override
	public int hashCode() {
		return pattern.hashCode() * 2 + (ignoreCase ? 1 : 0);
	}

	// ------------------------------------------------------------------------------------------------------------
	// GENERAL matching: head, middle parts, tail
	// ------------------------------------------------------------------------------------------------------------

	/**
	 * Matches {@code text} part by part: length check, head at the start, tail at the end, then each middle part at
	 * its leftmost place, making sure no gap covered by a {@code *} contains a line terminator.
	 *
	 * @param text the text to check, not null
	 * @return true if the whole text matches
	 */
	private boolean matchesParts(String text) {
		final int n = text.length();
		if (n < minLength || n > maxLength) {
			return false;
		}
		if (!hasStar) {
			return head == null ? n == 0 : matchForward(head, text, 0, n, ignoreCase) == n;
		}
		int pos = 0;
		if (head != null) {
			pos = matchForward(head, text, 0, n, ignoreCase);
			if (pos < 0) return false;
		}
		int end = n;
		if (tail != null) {
			end = matchBackward(tail, text, n, pos, ignoreCase);
			if (end < 0) return false;
		}
		for (Part part : middle) {
			pos = findLeftmost(part, text, pos, end, ignoreCase);
			if (pos < 0) return false;
		}
		return !hasLineTerminator(text, pos, end);
	}

	/**
	 * Matches {@code part} at exactly position {@code from} of {@code text}, going forwards.
	 *
	 * @param part       the pattern part (no {@code *})
	 * @param text       the text
	 * @param from       where the part must start; must not be in the middle of a surrogate pair
	 * @param limit      the part must end at or before this index
	 * @param ignoreCase whether letters match regardless of case
	 * @return the index just after the match, or -1 if the part doesn't match there
	 */
	private static int matchForward(Part part, String text, int from, int limit, boolean ignoreCase) {
		final String p = part.chars;
		final int pn = p.length(), tn = text.length();
		int i = from;
		for (int j = 0; j < pn; ) {
			if (i >= limit) return -1;
			char pc = p.charAt(j);
			char tc = text.charAt(i);
			if (pc == '?') {
				if (isLineTerminator(tc)) return -1;
				i += Character.isHighSurrogate(tc) && i + 1 < tn && Character.isLowSurrogate(text.charAt(i + 1)) ? 2 : 1;
				j++;
			} else if (!Character.isSurrogate(pc) && !Character.isSurrogate(tc)) {
				if (pc != tc && !(ignoreCase && sameIgnoringCase(pc, tc))) return -1;
				i++;
				j++;
			} else {   // a surrogate on either side: compare whole code points
				int pcp = p.codePointAt(j), tcp = text.codePointAt(i);
				if (pcp != tcp && !(ignoreCase && sameIgnoringCase(pcp, tcp))) return -1;
				i += Character.charCount(tcp);
				j += Character.charCount(pcp);
			}
		}
		return i <= limit ? i : -1;
	}

	/**
	 * Matches {@code part} so that it ends exactly at {@code end} of {@code text}, going backwards. Used for the
	 * tail, whose position is fixed by the end of the text.
	 *
	 * @param part       the pattern part (no {@code *})
	 * @param text       the text
	 * @param end        where the part must end; must not be in the middle of a surrogate pair
	 * @param lowLimit   the part must start at or after this index (so it doesn't overlap the head)
	 * @param ignoreCase whether letters match regardless of case
	 * @return the index where the match starts, or -1 if the part doesn't match there
	 */
	private static int matchBackward(Part part, String text, int end, int lowLimit, boolean ignoreCase) {
		final String p = part.chars;
		int i = end;
		for (int j = p.length(); j > 0; ) {
			if (i <= lowLimit) return -1;
			char pc = p.charAt(j - 1);
			char tc = text.charAt(i - 1);
			if (pc == '?') {
				if (isLineTerminator(tc)) return -1;
				i -= Character.isLowSurrogate(tc) && i - 2 >= 0 && Character.isHighSurrogate(text.charAt(i - 2)) ? 2 : 1;
				j--;
			} else if (!Character.isSurrogate(pc) && !Character.isSurrogate(tc)) {
				if (pc != tc && !(ignoreCase && sameIgnoringCase(pc, tc))) return -1;
				i--;
				j--;
			} else {   // a surrogate on either side: compare whole code points
				int pcp = p.codePointBefore(j), tcp = text.codePointBefore(i);
				if (pcp != tcp && !(ignoreCase && sameIgnoringCase(pcp, tcp))) return -1;
				i -= Character.charCount(tcp);
				j -= Character.charCount(pcp);
			}
		}
		return i >= lowLimit ? i : -1;
	}

	/**
	 * Finds the leftmost place at or after {@code from} where {@code part} matches and ends by {@code limit}, such that
	 * the gap between {@code from} and that place (covered by a {@code *}) has no line terminator. If the leftmost
	 * place leaves a line terminator in the gap, every later place does too, so the search stops there.
	 * <p>
	 * Plain case-sensitive parts are found with {@code String.indexOf}; others are tried at each position, skipping
	 * ahead to the part's first character with {@code indexOf(char)} when possible.
	 *
	 * @param part       the middle part to find
	 * @param text       the text
	 * @param from       where the search starts (just after the previous part)
	 * @param limit      the part must end at or before this index (the start of the tail)
	 * @param ignoreCase whether letters match regardless of case
	 * @return the index just after the found part, or -1 if it can't be placed
	 */
	private static int findLeftmost(Part part, String text, int from, int limit, boolean ignoreCase) {
		int checked = from;   // the gap [from, checked) is known to be free of line terminators
		if (!part.hasQuestionMark && !ignoreCase) {
			final String p = part.chars;
			final int len = p.length();
			for (int at = text.indexOf(p, from); at >= 0 && at + len <= limit; at = text.indexOf(p, at + 1)) {
				if (hasLineTerminator(text, checked, at)) return -1;
				checked = at;
				if (onBoundary(text, at) && onBoundary(text, at + len)) return at + len;
			}
			return -1;
		}
		final int skipChar = ignoreCase ? -1 : part.firstPlainChar;
		final int tn = text.length();
		int i = from;
		while (i + part.minLength <= limit) {
			if (skipChar >= 0) {
				int next = text.indexOf(skipChar, i);
				if (next < 0 || next + part.minLength > limit) return -1;
				i = next;
			}
			if (hasLineTerminator(text, checked, i)) return -1;
			checked = i;
			int e = matchForward(part, text, i, limit, ignoreCase);
			if (e >= 0) return e;
			char c = text.charAt(i);
			if (isLineTerminator(c)) return -1;   // the * before this part can't cover it
			i += Character.isHighSurrogate(c) && i + 1 < tn && Character.isLowSurrogate(text.charAt(i + 1)) ? 2 : 1;
			checked = i;
		}
		return -1;
	}

	/**
	 * Collects the non-null parts in pattern order.
	 *
	 * @return head, middle parts and tail, without nulls
	 */
	private static List<Part> allParts(Part head, Part[] middle, Part tail) {
		List<Part> all = new ArrayList<>();
		if (head != null) all.add(head);
		for (Part p : middle) all.add(p);
		if (tail != null) all.add(tail);
		return all;
	}

	// ------------------------------------------------------------------------------------------------------------
	// Matching without compiling first (used by WildcardUtil.matches and matchesIgnoreCase)
	// ------------------------------------------------------------------------------------------------------------

	/** Number of slots in each recent-pattern table; a power of two. */
	private static final int RECENT_SLOTS = 64;
	/** Recently seen case-sensitive patterns: a {@code String} after the first sighting, a {@code Wildcard} after the second. */
	private static final Object[] RECENT = new Object[RECENT_SLOTS];
	/** The same for patterns matched with {@code ignoreCase}. */
	private static final Object[] RECENT_IGNORE_CASE = new Object[RECENT_SLOTS];

	/**
	 * Matches without the caller compiling the pattern, but reuses a compiled {@code Wildcard} when the same pattern
	 * keeps coming back, as in a loop that checks many texts against a few patterns.
	 * <p>
	 * Each pattern hashes to one of {@value #RECENT_SLOTS} slots. The first time a pattern lands in its slot, only the
	 * pattern is remembered and the text is matched directly (so a pattern used once doesn't pay for compiling). The
	 * second time in a row, it is compiled and the compiled form is kept and reused. There are no locks: slots are
	 * read and written as plain array elements, which is safe because a {@code Wildcard} is immutable (all its fields
	 * are final) and strings are immutable. Two threads may occasionally compile the same pattern twice, and patterns
	 * that share a slot replace each other; neither affects the result.
	 *
	 * @param pattern    the wildcard pattern, not null
	 * @param text       the text, not null
	 * @param ignoreCase whether letters match regardless of case
	 * @return true if the whole text matches
	 */
	static boolean matchesRecent(String pattern, String text, boolean ignoreCase) {
		final Object[] table = ignoreCase ? RECENT_IGNORE_CASE : RECENT;
		int h = pattern.hashCode();
		final int slot = (h ^ (h >>> 16)) & (RECENT_SLOTS - 1);
		Object seen = table[slot];
		if (seen instanceof Wildcard) {
			Wildcard w = (Wildcard) seen;
			if (w.pattern.equals(pattern)) return w.matches(text);
		} else if (pattern.equals(seen)) {
			Wildcard w = compile(pattern, ignoreCase);
			table[slot] = w;
			return w.matches(text);
		}
		table[slot] = pattern;
		return matches(pattern, text, ignoreCase);
	}


	/**
	 * Matches {@code text} against {@code pattern} without preparing the pattern, for one-off checks. Greedy
	 * two-pointer search: on a mismatch it returns to the most recent {@code *} and lets it take one more character.
	 * That is enough for the same reason as in {@link #findLeftmost}: every {@code *} matches the same set of strings,
	 * so giving an earlier {@code *} more text never helps. Plain {@code char}s are compared directly; code points are
	 * decoded only for surrogates.
	 *
	 * @param pattern    the wildcard pattern, not null
	 * @param text       the text, not null
	 * @param ignoreCase whether letters match regardless of case
	 * @return true if the whole text matches
	 */
	static boolean matches(String pattern, String text, boolean ignoreCase) {
		final int pn = pattern.length(), tn = text.length();
		int pi = 0, ti = 0;
		int starP = -1, starT = -1;   // pattern index just after the last *, and how far that * reaches in the text
		while (ti < tn) {
			if (pi < pn) {
				char pc = pattern.charAt(pi);
				if (pc == '*') {
					do pi++; while (pi < pn && pattern.charAt(pi) == '*');
					if (pi == pn) {   // a trailing * takes the rest, if it has no line terminator
						return !hasLineTerminator(text, ti, tn);
					}
					starP = pi;
					starT = ti;
					continue;
				}
				char tc = text.charAt(ti);
				if (pc == '?') {
					if (!isLineTerminator(tc)) {
						pi++;
						ti += Character.isHighSurrogate(tc) && ti + 1 < tn && Character.isLowSurrogate(text.charAt(ti + 1)) ? 2 : 1;
						continue;
					}
				} else if (!Character.isSurrogate(pc) && !Character.isSurrogate(tc)) {
					if (pc == tc || (ignoreCase && sameIgnoringCase(pc, tc))) {
						pi++;
						ti++;
						continue;
					}
				} else {
					int pcp = pattern.codePointAt(pi), tcp = text.codePointAt(ti);
					if (pcp == tcp || (ignoreCase && sameIgnoringCase(pcp, tcp))) {
						pi += Character.charCount(pcp);
						ti += Character.charCount(tcp);
						continue;
					}
				}
			}
			// mismatch, or pattern used up: let the last * take one more character, if it may
			if (starP < 0) {
				return false;
			}
			char sc = text.charAt(starT);
			if (isLineTerminator(sc)) {
				return false;
			}
			starT += Character.isHighSurrogate(sc) && starT + 1 < tn && Character.isLowSurrogate(text.charAt(starT + 1)) ? 2 : 1;
			ti = starT;
			pi = starP;
		}
		while (pi < pn && pattern.charAt(pi) == '*') pi++;
		return pi == pn;
	}

	// ------------------------------------------------------------------------------------------------------------
	// Character helpers
	// ------------------------------------------------------------------------------------------------------------

	/**
	 * Compares two letters regardless of case: both are converted to upper case and then to lower case, and the
	 * results compared (the rule {@code java.util.regex} uses for literal text with {@code CASE_INSENSITIVE |
	 * UNICODE_CASE}). The two-step conversion is what makes, for example, the Turkish dotless {@code ı} match the
	 * dotted capital {@code İ} (both become {@code i}) and the Kelvin sign match {@code k}. When both are ASCII, it is
	 * a simple bit operation. Callers check plain equality first.
	 *
	 * @param a a code point from the pattern
	 * @param b a code point from the text
	 * @return true if they match regardless of case
	 */
	private static boolean sameIgnoringCase(int a, int b) {
		if ((a | b) < 0x80) {
			int la = a | 0x20;
			return la == (b | 0x20) && la >= 'a' && la <= 'z';
		}
		return Character.toLowerCase(Character.toUpperCase(a)) == Character.toLowerCase(Character.toUpperCase(b));
	}

	/**
	 * @param c a character or code point
	 * @return true for the characters that {@code .} doesn't match in a regular expression: line feed, carriage
	 * return, U+0085, U+2028 and U+2029
	 */
	static boolean isLineTerminator(int c) {
		return c <= '\r' ? c == '\n' || c == '\r' : c == '\u0085' || c == '\u2028' || c == '\u2029';
	}

	/**
	 * @param s    the text
	 * @param from first index to check
	 * @param to   index after the last one to check
	 * @return true if {@code s[from, to)} contains a line terminator
	 */
	private static boolean hasLineTerminator(String s, int from, int to) {
		for (int i = from; i < to; i++) {
			char c = s.charAt(i);
			if (c <= '\r' ? c == '\n' || c == '\r' : c >= '\u0085' && (c == '\u0085' || c == '\u2028' || c == '\u2029')) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param s     the text
	 * @param index an index from 0 to {@code s.length()}
	 * @return false if {@code index} falls between the two halves of a surrogate pair (the middle of one character)
	 */
	private static boolean onBoundary(String s, int index) {
		return index <= 0 || index >= s.length()
				|| !(Character.isLowSurrogate(s.charAt(index)) && Character.isHighSurrogate(s.charAt(index - 1)));
	}

	/**
	 * Like {@code text.contains(literal)}, but only counts an occurrence that starts and ends on character boundaries
	 * (not inside a surrogate pair). This only matters if the literal begins or ends with half a surrogate pair.
	 *
	 * @param text    the text
	 * @param literal the text to look for
	 * @return true if it occurs on character boundaries
	 */
	private static boolean containsOnBoundaries(String text, String literal) {
		final int len = literal.length();
		for (int at = text.indexOf(literal); at >= 0; at = text.indexOf(literal, at + 1)) {
			if (onBoundary(text, at) && onBoundary(text, at + len)) return true;
		}
		return false;
	}
}
