/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.reflection;

import com.vk2gpz.elmer.debug.DebugHandler;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.FilenameFilter;
import java.lang.reflect.*;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarInputStream;
import java.util.stream.Collectors;

public class ReflectionUtil {
	private static final Map<String, Class<?>> CLASS_CACHE = new HashMap<>();
	private static final Map<String, Set<Method>> METHOD_CACHE = new HashMap<>();
	private static final Map<String, Set<Constructor<?>>> CONSTRUCTORS_CACHE = new HashMap<>();
	private static final Map<Class<?>, List<Class<?>>> SUPERCLASS_HIERARCHY_CACHE = new HashMap<>();
	private static final Map<Class<?>, List<Class<?>>> INTERFACE_HIERARCHY_CACHE = new HashMap<>();
	private static final Map<String, Boolean> COMPATIBILITY_CACHE = new HashMap<>();
	private static final Map<Class<?>, Map<String, Field>> FIELD_LOOKUP_CACHE = new HashMap<>();


	public static boolean doesExist(String className) {
		try {
			Class.forName(className);
			return true;
		} catch (Throwable e) {
			return false;
		}
	}

	public static <T> @NotNull Class<T> getClass(String name) throws ClassNotFoundException {
		return getClass(ReflectionUtil.class.getClassLoader(), name);
	}

	public static <T> @NotNull Class<T> getClass(ClassLoader loader, String name) throws ClassNotFoundException {
		if (CLASS_CACHE.containsKey(name)) {
			return (Class<T>) CLASS_CACHE.get(name);
		}
		Class<T> clazz = (Class<T>) Class.forName(name, false, loader);
		CLASS_CACHE.put(name, clazz);
		return clazz;
	}

	/// Class<?> params
	// this is class_name + parameter_names because the method signature does not include the return type.
	private static @NotNull String toCacheKey(final @NotNull Class<?> klass, final Class<?>... params) {
		if (params == null || params.length == 0) {
			return klass.getName();
		}
		final StringBuilder sb = new StringBuilder(klass.getName());
		sb.ensureCapacity(klass.getName().length() + params.length * 20);
		for (Class<?> p : params) {
			sb.append('-').append(p == null ? "null" : p.getName());
		}
		return sb.toString();
	}

	private static boolean isCompatible(final @NotNull Class<?>[] subParams, final @NotNull Class<?>[] superParams) {
		if (subParams.length != superParams.length) {
			return false;
		}
		for (int i = 0; i < subParams.length; i++) {
			final Class<?> subP = subParams[i];
			final Class<?> superP = superParams[i];
			if (!superP.isAssignableFrom(subP)) {
				return false;
			}
		}
		return true;
	}

	private static boolean isCompatible(final @NotNull Constructor<?> constructor, final Class<?>... params) {
		assert constructor != null : "constructor must be non-null.";
		final Class<?>[] parameterTypes = constructor.getParameterTypes();
		return isCompatible(params, parameterTypes);
	}

	private static boolean isCompatible(final @NotNull Method method, final Class<?> returnType, final Class<?>... params) {
		assert method != null : "method must be non-null.";
		final Class<?>[] ptypes = method.getParameterTypes();
		final Class<?> rtype = method.getReturnType();
		boolean ret = isCompatible(params, ptypes);

		if (returnType != null) {
			ret &= rtype.isAssignableFrom(returnType);
		}
		return ret;
	}

	@Contract("null -> fail")
	public static @NotNull List<Class<?>> getSuperClasses(Class<?> klass) {
		assert klass != null : "klass must not non-null.";
		List<Class<?>> cached = SUPERCLASS_HIERARCHY_CACHE.get(klass);
		if (cached != null) {
			return cached;
		}
		List<Class<?>> classList = new ArrayList<>();
		Class<?> current = klass;
		while (current != null) {
			Class<?> superclass = current.getSuperclass();
			if (superclass != null) {
				classList.add(superclass);
			}
			current = superclass;
		}
		classList = Collections.unmodifiableList(classList);
		SUPERCLASS_HIERARCHY_CACHE.put(klass, classList);
		return classList;
	}

	public static @NotNull List<Class<?>> getInterfaces(@NotNull Class<?> klass) {
		assert klass != null : "klass must not non-null.";
		List<Class<?>> cached = INTERFACE_HIERARCHY_CACHE.get(klass);
		if (cached != null) {
			return cached;
		}
		List<Class<?>> interfaces = Collections.unmodifiableList(Arrays.asList(klass.getInterfaces()));
		INTERFACE_HIERARCHY_CACHE.put(klass, interfaces);
		return interfaces;
	}

	@Contract("_, _, null, _, _ -> fail")
	private static @NotNull Set<Method> getMatchingMethods(boolean all, boolean usecache, final Class<?> klass, final Class<?> returnType, final Class<?>... params) {
		assert klass != null : "klass must not be non-null.";
		final String cacheKey = methodCacheKey("types", all, returnType, toCacheKey(klass, params));
		Set<Method> methods = METHOD_CACHE.get(cacheKey);

		if (!usecache || methods == null) {
			Set<Method> tmpMethods = new HashSet<>();
			collectMatchingMethods(klass, returnType, params, tmpMethods, all);
			methods = Collections.unmodifiableSet(tmpMethods);
			METHOD_CACHE.put(cacheKey, methods);
		}

		return methods;
	}

	private static void collectMatchingMethods(Class<?> klass, Class<?> returnType, Class<?>[] params, Set<Method> result, boolean all) {
		for (final Method candidate : klass.getDeclaredMethods()) {
			if (isCompatible(candidate, returnType, params)) {
				result.add(candidate);
			}
		}
		if (all) {
			List<Class<?>> superclasses = getSuperClasses(klass);
			for (Class<?> superclass : superclasses) {
				for (final Method candidate : superclass.getDeclaredMethods()) {
					if (isCompatible(candidate, returnType, params)) {
						result.add(candidate);
					}
				}
			}
			List<Class<?>> interfaces = getInterfaces(klass);
			for (Class<?> iface : interfaces) {
				for (final Method candidate : iface.getDeclaredMethods()) {
					if (isCompatible(candidate, returnType, params)) {
						result.add(candidate);
					}
				}
			}
		}
	}

	@SuppressWarnings("SameParameterValue")
	private static @Nullable Method findMethod(boolean all, boolean usecache, Class<?> klass, Class<?> returnType, String methodName, Class<?>... params) {
		Set<Method> methods = getMatchingMethods(all, usecache, klass, returnType, params);

		if (methodName != null) {
			for (Method m : methods) {
				//System.out.println("checking method : " + m);
				if (m.getName().equalsIgnoreCase(methodName))
					return m;
			}
		} else {
			Iterator<Method> it = methods.iterator();
			return (it.hasNext()) ? it.next() : null;
		}
		return null;
	}

	public static Method getMethod(Class<?> klass, String methodName, Class<?>... params) {
		assert klass != null : "clazz parameter must be non-null.";
		return findMethod(true, true, klass, null, methodName, params);
	}

	// returns a list of methods whose argument types and return type match.
	@Contract("_, _, _ -> new")
	public static @NotNull List<Method> getMethods(Class<?> klass, Class<?> returnType, Class<?>... params) {
		return new ArrayList<>(getMatchingMethods(true, true, klass, returnType, params));
	}

	@Contract("_, _, null, _ -> fail")
	private static @NotNull Set<Constructor<?>> getMatchingConstructors(boolean all, boolean usecache, final Class<?> klass, final Class<?>... params) {
		assert klass != null : "klass must not be non-null.";
		final String cacheKey = methodCacheKey("ctor-types", all, null, toCacheKey(klass, params));
		Set<Constructor<?>> constructors = CONSTRUCTORS_CACHE.get(cacheKey);

		if (!usecache || constructors == null) {
			Set<Constructor<?>> tmpConstructors = new HashSet<>();
			collectMatchingConstructors(klass, params, tmpConstructors, all);
			constructors = Collections.unmodifiableSet(tmpConstructors);
			CONSTRUCTORS_CACHE.put(cacheKey, constructors);
		}

		return constructors;
	}

	private static void collectMatchingConstructors(Class<?> klass, Class<?>[] params, Set<Constructor<?>> result, boolean all) {
		for (final Constructor<?> candidate : klass.getDeclaredConstructors()) {
			if (isCompatible(candidate, params)) {
				result.add(candidate);
			}
		}
		if (all) {
			for (Class<?> superclass : getSuperClasses(klass)) {
				for (final Constructor<?> candidate : superclass.getDeclaredConstructors()) {
					if (isCompatible(candidate, params)) {
						result.add(candidate);
					}
				}
			}
		}
	}

	public static Constructor<?> getConstructor(Class<?> klass, Class<?>... params) {
		assert klass != null : "clazz parameter must be non-null.";
		Set<Constructor<?>> constructors = getMatchingConstructors(true, true, klass, params);
		Optional<Constructor<?>> ret = constructors.stream().findFirst();
		return ret.orElse(null);
	}


	// Lookups by parameter types and by argument values match differently (a Byte value fits a byte
	// parameter, Byte.class does not), and `all`/returnType change the result, so all of them go in the key.
	private static @NotNull String methodCacheKey(String kind, boolean all, Class<?> returnType, String key) {
		return kind + (all ? ":all:" : ":own:") + (returnType == null ? "*" : returnType.getName()) + ":" + key;
	}

	/// Object... args
	// The *ForArgs / *WithArgs methods below match argument VALUES (a Byte fits a byte parameter, null fits
	// any object parameter). The overloads above with Class<?>... match parameter TYPES.
	private static @NotNull String toCacheKey(final @NotNull Class<?> clazz, final Object... args) {
		final StringBuilder sb = new StringBuilder(clazz.getName());
		if (args != null) {
			for (final Object obj : args) {
				sb.append('-').append(obj == null ? "null" : obj.getClass().getName());
			}
		}
		return sb.toString();
	}

	private static boolean isWrapperTypeOf(final @NotNull Class<?> candidate, final Class<?> primitiveType) {
		//throws Exception {
		try {
			return !candidate.isPrimitive()
					&& candidate.getDeclaredField("TYPE").get(null).equals(primitiveType);
		} catch (final NoSuchFieldException | IllegalAccessException e) {
			return false;
		}
	}

	private static boolean isCompatibleArg(final Object object, final Class<?> paramType) {
		if (object == null) {
			return !paramType.isPrimitive();
		}
		if (paramType.isInstance(object)) {
			return true;
		}
		if (paramType.isPrimitive()) {
			return isWrapperTypeOf(object.getClass(), paramType);
		}
		return false;
	}

	private static boolean isCompatibleWithArgs(final @NotNull Constructor<?> constructor, final @NotNull Object... params) {
		final Class<?>[] parameterTypes = constructor.getParameterTypes();
		if (params.length != parameterTypes.length) {
			return false;
		}
		for (int i = 0; i < params.length; i++) {
			final Object object = params[i];
			final Class<?> paramType = parameterTypes[i];
			if (!isCompatibleArg(object, paramType)) {
				return false;
			}
		}
		return true;
	}

	@Contract("_, _, null, _ -> fail")
	private static @NotNull Set<Constructor<?>> getMatchingConstructorsForArgs(boolean all, boolean usecache, final Class<?> klass, final Object... args) {
		assert klass != null : "klass must not be non-null.";
		final String cacheKey = methodCacheKey("ctor-values", all, null, toCacheKey(klass, args));
		Set<Constructor<?>> constructors = CONSTRUCTORS_CACHE.get(cacheKey);

		if (!usecache || constructors == null) {
			Set<Constructor<?>> tmpConstructors = new HashSet<>();
			for (final Constructor<?> candidate : klass.getDeclaredConstructors()) {
				//System.out.println("checking : " + candidate);
				if (isCompatibleWithArgs(candidate, args)) {
					//System.out.println("found : " + candidate);
					tmpConstructors.add(candidate);
				}
			}
			if (all) {
				for (Class<?> superclass : getSuperClasses(klass)) {
					for (final Constructor<?> candidate : superclass.getDeclaredConstructors()) {
						if (isCompatibleWithArgs(candidate, args)) {
							tmpConstructors.add(candidate);
						}
					}
				}
			}
			constructors = Collections.unmodifiableSet(tmpConstructors);
			CONSTRUCTORS_CACHE.put(cacheKey, constructors);
		}

		return constructors;
	}

	public static Constructor<?> getConstructorForArgs(Class<?> klass, Object... params) {
		assert klass != null : "klass must be non-null.";

		Set<Constructor<?>> constructors = getMatchingConstructorsForArgs(true, true, klass, params);
		Optional<Constructor<?>> ret = constructors.stream().findFirst();
		return ret.orElse(null);
	}

	public static Constructor<?> getConstructorForArgs(ClassLoader loader, String className, Object... params) throws ClassNotFoundException {
		assert loader != null : "class loader must be non-null.";

		Class<?> klass = getClass(loader, className);
		return getConstructorForArgs(klass, params);
	}

	private static boolean isCompatibleWithArgs(final Object[] subArgs, final Class<?>[] superParams) {
		final Object[] args = subArgs == null ? new Object[0] : subArgs;
		if (args.length != superParams.length) {
			return false;
		}
		for (int i = 0; i < args.length; i++) {
			if (!isCompatibleArg(args[i], superParams[i])) {  // handles boxed primitives and null
				return false;
			}
		}
		return true;
	}

	public static boolean isCompatibleWithArgs(final Method method, final Class<?> returnType, final Object... params) {
		assert method != null : "method must be non-null.";
		final Class<?>[] ptypes = method.getParameterTypes();
		final Class<?> rtype = method.getReturnType();
		boolean ret = isCompatibleWithArgs(params, ptypes);
		if (returnType != null) {
			ret &= rtype.isAssignableFrom(returnType);
		}
		return ret;
	}

	public static Set<Method> getMatchingMethodsForArgs(boolean all, boolean usecache, final Class<?> klass, Class<?> returnType, final Object... args) {
		assert klass != null : "klass must not be non-null.";
		final String cacheKey = methodCacheKey("values", all, returnType, toCacheKey(klass, args));
		//System.out.println("cacheKey : " + cacheKey);
		Set<Method> methods = METHOD_CACHE.get(cacheKey);

		if (!usecache || methods == null) {
			Set<Method> tmpMethods = new HashSet<>();
			for (final Method candidate : klass.getDeclaredMethods()) {
				//System.out.println("checking : " + candidate);
				if (isCompatibleWithArgs(candidate, returnType, args)) {
					//System.out.println("found : " + candidate);
					tmpMethods.add(candidate);
				}
			}
			if (all) {
				for (Class<?> superclass : getSuperClasses(klass)) {
					for (final Method candidate : superclass.getDeclaredMethods()) {
						if (isCompatibleWithArgs(candidate, returnType, args)) {
							tmpMethods.add(candidate);
						}
					}
				}
				for (Class<?> iface : getInterfaces(klass)) {
					for (final Method candidate : iface.getDeclaredMethods()) {
						if (isCompatibleWithArgs(candidate, returnType, args)) {
							tmpMethods.add(candidate);
						}
					}
				}
			}
			methods = Collections.unmodifiableSet(tmpMethods);
			METHOD_CACHE.put(cacheKey, methods);
		}
		return methods;
	}

	@SuppressWarnings("SameParameterValue")
	private static Method findMethodForArgs(boolean all, boolean usecache, Class<?> klass, Class<?> returnType, String methodname, Object... args) {
		Set<Method> methods = getMatchingMethodsForArgs(all, usecache, klass, returnType, args);

		if (methodname != null) {
			for (Method m : methods) {
				if (m.getName().equalsIgnoreCase(methodname))
					return m;
			}
		} else {
			Iterator<Method> it = methods.iterator();
			return (it.hasNext()) ? it.next() : null;
		}
		return null;
	}

	public static <T> @NotNull Object newInstance(@NotNull Class<T> klass, Object... params) throws InvocationTargetException, InstantiationException, IllegalAccessException {
		Constructor<T> constructor = (Constructor<T>) getConstructorForArgs(klass, params);
		return constructor.newInstance(params);
	}

	public static <T> Object newInstance(ClassLoader loader, String className, Object... params) throws ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException {
		Object ret = null;

		Constructor<T> constructor = (Constructor<T>) getConstructorForArgs(loader, className, params);
		return constructor.newInstance(params);
	}

	public static Object newInstance(String className, Object... params) throws ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException {
		return newInstance(ReflectionUtil.class.getClassLoader(), className, params);
	}

	public static Object makePerform(Object obj, String methodname, Object... args) throws InvocationTargetException, NoSuchMethodException, IllegalAccessException {
		return makePerform(true, true, obj, methodname, args);
	}

	@SuppressWarnings("SameParameterValue")
	private static Object makePerform(boolean all, boolean usecache, Object obj, String methodname, Object... args) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
		Class<?> c = obj.getClass(); // get the Class object.

		Method m = findMethodForArgs(all, usecache, c, null, methodname, args);


		// System.out.println("Method : " + m);
		if (m == null) throw new NoSuchMethodException(methodname);
		if (args == null) {
			args = new Object[0]; // set up arguments.
		}

		m.setAccessible(true);
		return m.invoke(obj, args); // invoke the method.
	}

	public static Object makeClassPerform(Class<?> klass, String methodname, Object... args) throws InvocationTargetException, IllegalAccessException, NoSuchMethodException {
		return makeClassPerform(true, true, klass, methodname, args);
	}

	public static Object makeClassPerform(boolean all, boolean usecache, Class<?> klass, String methodname, Object[] args) throws InvocationTargetException, IllegalAccessException, NoSuchMethodException {
		Method m = findMethodForArgs(all, usecache, klass, null, methodname, args);
		if (m == null || !Modifier.isStatic(m.getModifiers())) {
			throw new NoSuchMethodException(methodname);
		}
		if (args == null) {
			args = new Object[0]; // set up arguments.
		}
		m.setAccessible(true);
		return m.invoke(null, args); // invoke the method.
	}


	public static Field getField(Class<?> klass, String fieldName, boolean declared) {
		boolean debug = DebugHandler.isDebugged("ReflectionUtil.getField");
		assert klass != null : "klass must not be non-null.";
		
		Map<String, Field> fieldMap = FIELD_LOOKUP_CACHE.computeIfAbsent(klass, k -> new HashMap<>());
		String cacheKey = fieldName + ":" + declared;
		
		if (fieldMap.containsKey(cacheKey)) {
			return fieldMap.get(cacheKey);
		}
		
		Field field = null;
		try {
			field = declared ? klass.getDeclaredField(fieldName) : klass.getField(fieldName);
			field.setAccessible(true);
			fieldMap.put(cacheKey, field);
			return field;
		} catch (Exception e) {
			if (debug)
				e.printStackTrace();
			fieldMap.put(cacheKey, null);
		}
		return null;
	}

	public static List<Field> getFields(Class<?> clazz, Class<?> type, boolean declared) {
		return getFields(clazz, type, new Class<?>[0], declared);
	}

	public static List<Field> getFields(Class<?> clazz, Class<?> type, Class<?>[] genericTypes,
	                                    boolean declared) {
		boolean debug = DebugHandler.isDebugged("ReflectionUtil.getFields");
		List<Field> results = new ArrayList<>();

		try {
			Field[] fields = declared ? clazz.getDeclaredFields() : clazz.getFields();
			String paramStr = null;
			if (genericTypes != null && genericTypes.length > 0) {
				paramStr = Arrays.stream(genericTypes)
						.map(Class::getTypeName)
						.collect(Collectors.joining(", "));
			}
			
			for (Field f : fields) {
				if (f.getType().equals(type)) {
					boolean match = true;
					if (paramStr != null && !f.getGenericType().getTypeName().contains(paramStr)) {
						match = false;
					}
					if (match) {
						f.setAccessible(true);
						results.add(f);
					}
				}
			}
		} catch (Exception e) {
			if (debug)
				e.printStackTrace();
		}

		return results;
	}

	public static List<Field> getFields(Class<?> clazz, Class<?>[] genericTypes, boolean declared) {
		boolean debug = DebugHandler.isDebugged("ReflectionUtil.getFields");
		List<Field> results = new ArrayList<>();

		try {
			Field[] fields = declared ? clazz.getDeclaredFields() : clazz.getFields();
			String paramStr = null;
			if (genericTypes != null && genericTypes.length > 0) {
				paramStr = Arrays.stream(genericTypes)
						.map(Class::getTypeName)
						.collect(Collectors.joining(", "));
			}
			
			for (Field f : fields) {
				boolean match = true;
				if (paramStr != null && !f.getGenericType().getTypeName().contains(paramStr)) {
					match = false;
				}
				if (match) {
					f.setAccessible(true);
					results.add(f);
				}
			}
		} catch (Exception e) {
			if (debug) e.printStackTrace();
		}

		return results;
	}

	public static Object getValue(Object instance, Class<?> clazz, String fieldName, boolean declared) {
		boolean debug = DebugHandler.isDebugged("ReflectionUtil.getValue");
		Object ret = null;

		try {
			Field field = getField(clazz, fieldName, declared);
			if (field != null) {
				field.setAccessible(true);
				ret = field.get(instance);
			}
		} catch (Exception e) {
			if (debug) e.printStackTrace();
		}
		return ret;
	}

	public static Object getValue(Object instance, String className, String fieldName, boolean declared) {
		return getValue(instance, fieldName, declared);
	}

	public static Object getValue(Object instance, String fieldName, boolean declared) {
		return getValue(instance, instance.getClass(), fieldName, declared);
	}

	public static Object getValue(Object instance, String fieldName) {
		return getValue(instance, fieldName, true);
	}

	public static Object getValue(Object instance, String... fieldNames) {
		Object result = getValue(true, instance, fieldNames);
		if (result == null) {
			result = getValue(false, instance, fieldNames);
		}
		return result;
	}

	public static Object getValue(boolean declared, Object instance, String... fieldNames) {
		Object result = null;
		for (String fieldName : fieldNames) {
			try {
				result = getValue(instance, fieldName, declared);
				if (result != null) {
					break;
				}
			} catch (Throwable ignore) {

			}
		}
		return result;
	}

	public static Object getValue(Class<?> type, Object instance, String... fieldNames) {
		Object result = getValue(true, type, instance, fieldNames);
		if (result == null) {
			result = getValue(false, type, instance, fieldNames);
		}
		return result;
	}

	public static Object getValue(boolean declared, Class<?> type, Object instance, String... fieldNames) {
		boolean debug = DebugHandler.isDebugged("ReflectionUtil.getValue");
		Object result = null;

		List<String> fieldnames = Arrays.asList(fieldNames);
		List<Field> fields = getFields(instance.getClass(), type, declared);
		Field f = null;
		for (Field field : fields) {
			if (fieldnames.contains(field.getName())) {
				f = field;
				break;
			}
		}
		if (f != null) {
			f.setAccessible(true);
			try {
				result = f.get(instance);
			} catch (Exception e) {
				// System.out.println(ERROR_MSG);
				if (debug) e.printStackTrace();
			}
		}
		return result;
	}

	public static void setValue(Object instance, Class<?> clazz, String fieldName, Object value, boolean declared) {
		setValue(instance, clazz, fieldName, value, declared, false);
	}

	public static void setValue(Object instance, Class<?> clazz, String fieldName, Object value, boolean declared,
	                            boolean forceFinal) {
		Field field = getField(clazz, fieldName, declared);
		if (field != null) {
			try {
				// Final instance fields are written too (Java allows this after setAccessible);
				// static final fields cannot be changed by reflection and throw IllegalAccessException.
				field.setAccessible(true);
				field.set(instance, value);
			} catch (Exception e) {
				// System.out.println(ERROR_MSG);
				e.printStackTrace();
			}
		} else {
			DebugHandler.getLogger("elmer").warning("Field " + fieldName + "is null for the class " + clazz.getName());
			throw new NullPointerException("Field " + fieldName + " is null.");
		}
	}


	public static void setValue(Object instance, String className, String fieldName, Object value, boolean declared) throws ClassNotFoundException {
		setValue(instance, getClass(className), fieldName, value, declared);
	}

	public static void setValue(Object instance, String fieldName, Object value, boolean declared) {
		setValue(instance, instance.getClass(), fieldName, value, declared);
	}

	public static void setValue(Object instance, String fieldName, Object value) {
		setValue(instance, fieldName, value, true);
	}

	// find all subclasses of kclass in the folder
	public static List<Class<?>> getSubClasses(Class<?> klass, Class<?> sklass) {
		return getSubClasses(klass.getClassLoader(), klass, sklass);
	}

	public static List<Class<?>> getSubClasses(ClassLoader loader, Class<?> klass, Class<?> sklass) {
		List<Class<?>> list = new ArrayList<>();
		try {
			CodeSource src = klass.getProtectionDomain().getCodeSource();

			// System.out.println("Src = " + src);
			if (src != null) {
				list = getSubClasses(loader, klass, sklass, src.getLocation(), list);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// find all subclasses of kclass in the folder
	public static List<Class<?>> getSubClasses(Class<?> klass, Class<?> sklass, File folder) {
		return getSubClasses(klass.getClassLoader(), klass, sklass, folder);
	}

	public static List<Class<?>> getSubClasses(ClassLoader loader, Class<?> klass, Class<?> sklass, File folder) {
		boolean debug = DebugHandler.isDebugged("ReflectionUtil.getSubClasses");
		List<Class<?>> list = new ArrayList<>();
		try {
			// next search in enchants folder
			if (!folder.exists()) {
				DebugHandler.getLogger("elmer").warning("Could not locate " + folder + " folder!");
				return list;
			}

			// create new filename filter
			FilenameFilter fileNameFilter =
					(dir, name) -> {
						if (name.lastIndexOf('.') > 0) {
							return name.substring(name.lastIndexOf('.')).equals(".jar");
						}
						return false;
					};

			File[] jars = folder.listFiles(fileNameFilter);
			assert jars != null;
			for (File f : jars) {
				if (debug)
					DebugHandler.getLogger("elmer").info("checking .jar file: " + f.getName());
				list = getSubClasses(loader, klass, sklass, f.toURI().toURL(), list);
			}
		} catch (Exception e) {
			if (debug) e.printStackTrace();
		}
		return list;
	}

	public static List<Class<?>> getSubClasses(ClassLoader loader, Class<?> klass, Class<?> sklass, URL
			location, List<Class<?>> list) {
		boolean debug = DebugHandler.isDebugged("ReflectionUtil.getSubClasses");
		if (list == null) list = new ArrayList<>();
		try {
			try (URLClassLoader cl = new URLClassLoader(new URL[]{location}, loader)) {
				Path jarPath = Paths.get(location.toURI());
				// Open the JAR file
				try (JarFile jarFile = new JarFile(jarPath.toFile())) {
					Enumeration<JarEntry> entries = jarFile.entries();

					while (entries.hasMoreElements()) {
						JarEntry j = entries.nextElement();
						if (j == null) break;
						String name = j.getName();
						if (name.endsWith(".class")
								&& !name.equals(klass.getSimpleName() + ".class")
								&& !name.equals(sklass.getSimpleName() + ".class")) {
							try {
								name = name.replace("/", ".");
								String cname = name.substring(0, name.lastIndexOf(".class"));
								Class<?> newklass = cl.loadClass(cname);
								if (debug) {
									DebugHandler.getLogger("elmer").info("checking " + newklass);
									DebugHandler.getLogger("elmer").info("subclass? " + sklass.isAssignableFrom(newklass));
								}
								if (newklass != sklass && sklass.isAssignableFrom(newklass)) list.add(newklass);
							} catch (Throwable ex) {
								if (debug)
									ex.printStackTrace();
							}
						}
					}
				}
			}
		} catch (Throwable e) {
			if (debug)
				e.printStackTrace();
		}
		return list;
	}

	public static List<Class<?>> getSubClasses(Class<?> klass) {
		return getSubClasses(klass.getClassLoader(), klass);
	}

	public static List<Class<?>> getSubClasses(ClassLoader loader, Class<?> klass) {
		boolean debug = DebugHandler.isDebugged("ReflectionUtil.getSubClasses");
		List<Class<?>> result = null;
		try {
			CodeSource src = klass.getProtectionDomain().getCodeSource();
			if (src != null) {
				result = getSubClasses(loader, klass, klass, src.getLocation(), result);
			}

			if (result != null)
				result.removeIf(test -> !klass.isAssignableFrom(test));
		} catch (Exception ex) {
			if (debug) ex.printStackTrace();
		}
		return result;
	}


	public static <T> T instantiate(final Class<? extends T> assignableClass, final String fqClassName,
	                                final Object... params) throws ClassCastException, ClassNotFoundException,
			InstantiationException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException {
		// Fetch internal class if it exists.
		Class<?> internalClass = Class.forName(fqClassName);
		if (!assignableClass.isAssignableFrom(internalClass)) {
			String message = String.format("Found class %s but cannot cast to %s!", internalClass.getName(), assignableClass.getName());
			DebugHandler.getLogger("elmer").warning(message);
			throw new IllegalStateException(message);
		}

		// Quick return: no parameters, no need to fiddle about finding the correct constructor.
		if (params.length == 0) {
			return assignableClass.cast(internalClass.getConstructor().newInstance());
		}

		// Search constructors for one matching the given parameters
		nextConstructor:
		for (Constructor<?> constructor : internalClass.getConstructors()) {
			Class<?>[] requiredClasses = constructor.getParameterTypes();
			if (requiredClasses.length != params.length) {
				continue;
			}
			for (int i = 0; i < params.length; ++i) {
				if (!requiredClasses[i].isAssignableFrom(params[i].getClass())) {
					continue nextConstructor;
				}
			}
			return assignableClass.cast(constructor.newInstance(params));
		}

		StringBuilder builder = new StringBuilder("Found class ").append(internalClass.getName())
				.append(" but cannot find any matching constructors for [");
		for (Object object : params) {
			builder.append(object.getClass().getName()).append(", ");
		}
		builder.delete(builder.length() - 2, builder.length());

		String message = builder.append(']').toString();
		DebugHandler.getLogger("elmer").warning(message);

		throw new IllegalArgumentException(message);
	}

	public static @NotNull List<Field> getAllFields(Class<?> clazz) {
		List<Field> fields = new ArrayList<>();
		while (clazz != null) {
			for (Field field : clazz.getDeclaredFields()) {
				fields.add(field);
			}
			clazz = clazz.getSuperclass();
		}
		return fields;
	}

	public static @NotNull List<Method> getAllMethods(Class<?> clazz) {
		List<Method> methods = new ArrayList<>();
		while (clazz != null) {
			for (Method method : clazz.getDeclaredMethods()) {
				methods.add(method);
			}
			clazz = clazz.getSuperclass();
		}
		return methods;
	}

	public static @NotNull List<Class> getAllClass(Class<?> clazz) {
		List<Class> classes = new ArrayList<>();
		while (clazz != null) {
			for (Class c : clazz.getDeclaredClasses()) {
				classes.add(c);
			}
			clazz = clazz.getSuperclass();
		}
		return classes;
	}
}
