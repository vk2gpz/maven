/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.text;

import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * String helpers that are not in the JDK or Apache Commons Lang.
 * <p>
 * For the general string operations ({@code leftPad}, {@code repeat}, {@code center}, {@code equalsAny} …) use
 * {@code org.apache.commons.lang3.StringUtils}, or the JDK ({@link String#strip()}, {@link String#repeat(int)} …).
 * Number formatting is in {@link NumberUtil}.
 */
public final class StringUtil {
	private static final Pattern SPECIAL_REGEX_CHARS = Pattern.compile("[<(\\[{\\\\^\\-=$!|\\]})?*+.>]");

	private StringUtil() {
	}

	/** @return true if {@code cs} is null or has length 0. */
	public static boolean isEmpty(final CharSequence cs) {
		return StringUtils.isEmpty(cs);
	}

	/**
	 * Splits {@code multiline} at line breaks, drops empty lines and puts {@code prefix} in front of each line.
	 */
	public static List<String> getMultiLines(String prefix, String multiline) {
		List<String> ret = new ArrayList<>();
		for (String line : multiline.split("\n")) {
			if (!line.isEmpty()) {
				ret.add(prefix + line);
			}
		}
		return ret;
	}

	/** @return a new list with duplicates removed, keeping the first occurrence of each. */
	public static List<String> removeDuplicates(List<String> list) {
		return list.stream().distinct().collect(Collectors.toList());
	}

	/** @return true if {@code str} starts with any of {@code tests}, ignoring case; null tests are skipped. */
	public static boolean startsWithIgnoreCase(String str, String... tests) {
		String s = str.toLowerCase();
		for (String t : tests) {
			if (t != null && s.startsWith(t.toLowerCase())) return true;
		}
		return false;
	}

	/** @return true if {@code str} ends with any of {@code tests}, ignoring case; null tests are skipped. */
	public static boolean endsWithIgnoreCase(String str, String... tests) {
		String s = str.toLowerCase();
		for (String t : tests) {
			if (t != null && s.endsWith(t.toLowerCase())) return true;
		}
		return false;
	}

	/** @return true if {@code str} equals any of {@code tests}, ignoring case; null tests are skipped. */
	public static boolean equalsWithIgnoreCase(String str, String... tests) {
		for (String t : tests) {
			if (t != null && str.equalsIgnoreCase(t)) return true;
		}
		return false;
	}

	/** @return a pattern that matches any string containing {@code text} literally. */
	public static Pattern toSafePattern(String text) {
		return Pattern.compile(".*" + escapeForRegex(text) + ".*");
	}

	/** Puts a backslash in front of every regex special character in {@code str}. */
	public static String escapeForRegex(String str) {
		return SPECIAL_REGEX_CHARS.matcher(str).replaceAll("\\\\$0");
	}
}
