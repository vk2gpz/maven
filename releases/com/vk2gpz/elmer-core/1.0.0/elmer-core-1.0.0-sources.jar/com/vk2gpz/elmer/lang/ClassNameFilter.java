/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
               Implementation of class ClassNameFilter                
====================================================================*/
/**
 * A filter for fully qualified class name.
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public interface ClassNameFilter {
    /**
     * Tests whether or not the specified fully qualified class name
	 * should be included in a class list.
     *
     * @param  className  The fully qualified class name to be tested
     * @return  <code>true</code> if and only if <code>classname</code>
     *          should be included
     */
	boolean accept(String className);
}

