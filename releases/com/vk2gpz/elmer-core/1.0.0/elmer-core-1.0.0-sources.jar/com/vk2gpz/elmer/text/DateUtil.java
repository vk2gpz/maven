/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.text;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.time.temporal.WeekFields;
import java.util.Calendar;
import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Durations written as text, such as {@code "1y2mo"}, {@code "3d 4h"} or {@code "10min 30s"}, and
 * "time until" descriptions such as {@code "2 days 3 hours"}.
 * <p>
 * Units (case-insensitive, any order, each at most once): {@code y}/{@code yr}/{@code year(s)},
 * {@code mo}/{@code month(s)}, {@code w}/{@code week(s)}, {@code d}/{@code day(s)}, {@code h}/{@code hr}/{@code hour(s)},
 * {@code m}/{@code min}/{@code minute(s)}, {@code s}/{@code sec}/{@code second(s)}. A number without a unit means seconds.
 * Spaces and commas between parts are allowed.
 */
public final class DateUtil {
	private DateUtil() {
	}

	private enum Unit {
		YEAR(ChronoUnit.YEARS, "year", "years"),
		MONTH(ChronoUnit.MONTHS, "month", "months"),
		WEEK(ChronoUnit.WEEKS, "week", "weeks"),
		DAY(ChronoUnit.DAYS, "day", "days"),
		HOUR(ChronoUnit.HOURS, "hour", "hours"),
		MINUTE(ChronoUnit.MINUTES, "minute", "minutes"),
		SECOND(ChronoUnit.SECONDS, "second", "seconds");

		final ChronoUnit chrono;
		final String singular, plural;

		Unit(ChronoUnit chrono, String singular, String plural) {
			this.chrono = chrono;
			this.singular = singular;
			this.plural = plural;
		}

		static Unit of(String word) {
			switch (word) {
				case "y": case "yr": case "yrs": case "year": case "years": return YEAR;
				case "mo": case "mon": case "month": case "months": return MONTH;
				case "w": case "wk": case "wks": case "week": case "weeks": return WEEK;
				case "d": case "day": case "days": return DAY;
				case "h": case "hr": case "hrs": case "hour": case "hours": return HOUR;
				case "m": case "min": case "mins": case "minute": case "minutes": return MINUTE;
				case "": case "s": case "sec": case "secs": case "second": case "seconds": return SECOND;
				default: return null;
			}
		}
	}

	private static final Pattern PART = Pattern.compile("(\\d+)\\s*([a-z]*)");
	private static final Pattern SEPARATORS = Pattern.compile("[\\s,]*");

	/** Splits {@code text} into unit amounts. @throws IllegalArgumentException if it is not a duration */
	private static Map<Unit, Long> parse(String text) {
		if (text == null) {
			throw new IllegalArgumentException("Illegal Date: null");
		}
		String s = text.trim().toLowerCase(Locale.ROOT);
		Map<Unit, Long> amounts = new EnumMap<>(Unit.class);
		Matcher m = PART.matcher(s);
		int pos = 0;
		while (m.find()) {
			if (!SEPARATORS.matcher(s.substring(pos, m.start())).matches()) break;
			Unit unit = Unit.of(m.group(2));
			if (unit == null || amounts.containsKey(unit)) {
				throw new IllegalArgumentException("Illegal Date: " + text);
			}
			amounts.put(unit, Long.parseLong(m.group(1)));
			pos = m.end();
		}
		if (amounts.isEmpty() || !SEPARATORS.matcher(s.substring(pos)).matches()) {
			throw new IllegalArgumentException("Illegal Date: " + text);
		}
		return amounts;
	}

	/**
	 * @return now plus ({@code future}) or minus the duration in {@code time}, in epoch milliseconds
	 * @throws IllegalArgumentException if {@code time} is not a duration
	 */
	public static long parseDateDiff(String time, boolean future) {
		ZonedDateTime t = ZonedDateTime.now();
		for (Map.Entry<Unit, Long> e : parse(time).entrySet()) {
			t = future ? t.plus(e.getValue(), e.getKey().chrono) : t.minus(e.getValue(), e.getKey().chrono);
		}
		return t.toInstant().toEpochMilli();
	}

	/** Same as {@code parseDateDiff(time, true)}, but returns 0 for text that is not a duration. */
	public static long getTimeStamp(String time) {
		try {
			return parseDateDiff(time, true);
		} catch (IllegalArgumentException e) {
			return 0;
		}
	}

	/**
	 * Sets fields of the current date and time and returns the result in epoch milliseconds. The units mean:
	 * year, month (1–12), week of the month, day of the week (1 = Monday … 7 = Sunday), hour, minute, second.
	 * For example {@code "17h 30m 0s"} is today at 17:30:00. Fields that are not given keep the current value.
	 * ({@code future} is not used; it is there for symmetry with {@link #parseDateDiff}.)
	 *
	 * @throws IllegalArgumentException if {@code time} is not valid
	 */
	public static long parseDate(String time, boolean future) {
		ZonedDateTime t = ZonedDateTime.now().withNano(0);
		for (Map.Entry<Unit, Long> e : parse(time).entrySet()) {
			int v = Math.toIntExact(e.getValue());
			switch (e.getKey()) {
				case YEAR: t = t.withYear(v); break;
				case MONTH: t = t.withMonth(v); break;
				case WEEK: t = t.with(WeekFields.of(Locale.getDefault()).weekOfMonth(), v); break;
				case DAY: t = t.with(ChronoField.DAY_OF_WEEK, v); break;   // same week
				case HOUR: t = t.withHour(v); break;
				case MINUTE: t = t.withMinute(v); break;
				case SECOND: t = t.withSecond(v); break;
			}
		}
		return t.toInstant().toEpochMilli();
	}

	/** Same as {@code parseDate(time, true)}, but returns 0 for invalid text. */
	public static long getTimeStampAt(String time) {
		try {
			return parseDate(time, true);
		} catch (RuntimeException e) {
			return 0;
		}
	}

	/** Describes the time from now until {@code date} (epoch ms), e.g. "2 days 3 hours"; "now" if it is not in the future. */
	public static String formatDateDiff(long date) {
		return formatDateDiff(null, null, null, date);
	}

	/**
	 * Same as {@link #formatDateDiff(long)} with words from an {@link I18n} bundle (keys: now, year, years, …).
	 * The bundle files are read once and kept; call {@link #reloadTranslations()} after editing them.
	 */
	public static String formatDateDiff(String resourceFolder, String bundleName, String locale, long date) {
		Calendar now = Calendar.getInstance();
		Calendar then = Calendar.getInstance();
		then.setTimeInMillis(date);
		return formatDateDiff(resourceFolder, bundleName, locale, now, then);
	}

	/** Describes the time from {@code fromDate} until {@code toDate}; "now" if {@code toDate} is not later. */
	public static String formatDateDiff(Calendar fromDate, Calendar toDate) {
		return formatDateDiff(null, null, null, fromDate, toDate);
	}

	/**
	 * Same as {@link #formatDateDiff(Calendar, Calendar)} with words from an {@link I18n} bundle
	 * (keys: now, year, years, month, months, day, days, hour, hours, minute, minutes, second, seconds).
	 * Missing words fall back to English. Weeks are not used (they are shown as days).
	 * <p>
	 * The bundle files are read the first time a folder, bundle and locale are used, and kept for later calls; call
	 * {@link #reloadTranslations()} after editing them.
	 *
	 * @param resourceFolder folder (on disk or on the class path) holding the bundle; null together with
	 *                       {@code bundleName} for plain English
	 * @param bundleName     bundle name; null for {@value I18n#DEFAULT_BUNDLE}
	 * @param locale         locale such as {@code "de_DE"}; null for the JVM's default
	 */
	public static String formatDateDiff(String resourceFolder, String bundleName, String locale,
	                                    Calendar fromDate, Calendar toDate) {
		I18n i18n = translations(resourceFolder, bundleName, locale);
		ZonedDateTime from = toZoned(fromDate);
		ZonedDateTime to = toZoned(toDate);
		if (!to.isAfter(from)) {
			return word(i18n, "now");
		}
		StringBuilder sb = new StringBuilder();
		ZonedDateTime cursor = from;
		for (Unit unit : Unit.values()) {
			if (unit == Unit.WEEK) continue;
			long n = unit.chrono.between(cursor, to);
			if (n > 0) {
				cursor = cursor.plus(n, unit.chrono);
				sb.append(' ').append(n).append(' ').append(word(i18n, n == 1 ? unit.singular : unit.plural));
			}
		}
		return sb.length() == 0 ? word(i18n, "now") : sb.substring(1);
	}

	/**
	 * Number of whole {@code type} units (a {@link Calendar} field such as {@code Calendar.DAY_OF_MONTH})
	 * from {@code fromDate} towards {@code toDate}. As a side effect, {@code fromDate} is moved by that many
	 * units, so repeated calls with smaller units give the remainder.
	 *
	 * @param future true to count forwards (toDate after fromDate), false backwards
	 */
	public static long dateDiff(int type, Calendar fromDate, Calendar toDate, boolean future) {
		ChronoUnit unit = toChronoUnit(type);
		ZonedDateTime from = toZoned(fromDate);
		ZonedDateTime to = toZoned(toDate);
		long n = future ? unit.between(from, to) : unit.between(to, from);
		if (n <= 0) {
			return 0;
		}
		fromDate.setTimeInMillis((future ? from.plus(n, unit) : from.minus(n, unit)).toInstant().toEpochMilli());
		return n;
	}

	private static ChronoUnit toChronoUnit(int calendarField) {
		switch (calendarField) {
			case Calendar.YEAR: return ChronoUnit.YEARS;
			case Calendar.MONTH: return ChronoUnit.MONTHS;
			case Calendar.WEEK_OF_YEAR: case Calendar.WEEK_OF_MONTH: return ChronoUnit.WEEKS;
			case Calendar.DAY_OF_MONTH: case Calendar.DAY_OF_YEAR: case Calendar.DAY_OF_WEEK: return ChronoUnit.DAYS;
			case Calendar.HOUR: case Calendar.HOUR_OF_DAY: return ChronoUnit.HOURS;
			case Calendar.MINUTE: return ChronoUnit.MINUTES;
			case Calendar.SECOND: return ChronoUnit.SECONDS;
			case Calendar.MILLISECOND: return ChronoUnit.MILLIS;
			default: throw new IllegalArgumentException("unsupported Calendar field: " + calendarField);
		}
	}

	private static ZonedDateTime toZoned(Calendar c) {
		ZoneId zone = c.getTimeZone() == null ? ZoneId.systemDefault() : c.getTimeZone().toZoneId();
		return Instant.ofEpochMilli(c.getTimeInMillis()).atZone(zone);
	}

	/** Translations for {@code formatDateDiff}, by folder, bundle and locale; see {@link #translations}. */
	private static final Map<String, I18n> TRANSLATIONS = new ConcurrentHashMap<>();
	/** Most cached translations; when exceeded the cache starts again, so unusual callers can't grow it forever. */
	private static final int MAX_TRANSLATIONS = 64;
	/** Separates the parts of a cache key; a character that can't appear in a path, bundle name or locale. */
	private static final char KEY_SEPARATOR = (char) 0;

	/**
	 * Returns the cached {@link I18n} for a folder, bundle and locale, reading the files the first time. Lookups are
	 * lock-free; two threads asking for a new combination at the same moment still get one shared instance.
	 *
	 * @param folder folder of the bundle, or null
	 * @param bundle bundle name, or null for the default bundle
	 * @param locale locale text, or null for the JVM's default
	 * @return the translations, or null if both {@code folder} and {@code bundle} are null (plain English)
	 */
	private static I18n translations(String folder, String bundle, String locale) {
		if (folder == null && bundle == null) {
			return null;
		}
		String key = folder + KEY_SEPARATOR + bundle + KEY_SEPARATOR + locale;
		I18n i18n = TRANSLATIONS.get(key);
		if (i18n == null) {
			if (TRANSLATIONS.size() >= MAX_TRANSLATIONS) {
				TRANSLATIONS.clear();
			}
			i18n = TRANSLATIONS.computeIfAbsent(key, k -> new I18n(folder, locale, bundle));
		}
		return i18n;
	}

	/**
	 * Forgets the translation files read by {@link #formatDateDiff(String, String, String, long)} and its variants,
	 * so the next call reads them again. Call it after editing the files, for example from a {@code /reload} command.
	 */
	public static void reloadTranslations() {
		TRANSLATIONS.clear();
	}

	private static String word(I18n i18n, String key) {
		String w = null;
		if (i18n != null) {
			try {
				w = i18n.translate(key);
			} catch (RuntimeException ignored) {
				// no bundle: use English
			}
		}
		return w == null || w.isEmpty() ? key : w;
	}
}
