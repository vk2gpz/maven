/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.text;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Translated messages from {@code .properties} files, for one language, with {@link MessageFormat} placeholders
 * such as <code>{0}</code>.
 *
 * <h2>Where messages come from</h2>
 * Messages are grouped in <em>bundles</em>; each bundle is a set of {@code .properties} files with the same base
 * name, one per language. For the bundle {@code messages} and the locale {@code de_DE}, these files are read, from
 * the most general to the most specific, and later files override earlier ones key by key:
 * <ol>
 *   <li>{@code messages.properties} (the default, usually English)</li>
 *   <li>{@code messages_de.properties}</li>
 *   <li>{@code messages_de_DE.properties}</li>
 *   <li>{@code messages_de_DE_<variant>.properties}, if the locale has a variant</li>
 * </ol>
 * So a German file only needs the keys it actually translates; anything it leaves out comes from the default file.
 * Each file is looked for first in the folder on disk ({@code folderPath}, for example a plugin's data folder) and,
 * if it isn't there, as a resource on the class path under the same path (for example inside the plugin's jar).
 * Missing files are skipped silently.
 * <p>
 * Files may be saved as UTF-8 (so Japanese, accented letters and so on can be typed directly) or in the traditional
 * ISO-8859-1 encoding with <code>&#92;uXXXX</code> escapes; a file that isn't valid UTF-8 is read as ISO-8859-1, as
 * {@link java.util.PropertyResourceBundle} does since Java 9.
 *
 * <h2>Example</h2>
 * With {@code plugins/MyPlugin/lang/messages.properties} containing
 * <pre>
 * greeting=Hello, {0}!
 * coins=You have {0,number,integer} coins.
 * </pre>
 * and {@code messages_de.properties} containing <code>greeting=Hallo, {0}!</code>:
 * <pre>{@code
 * I18n i18n = new I18n("plugins/MyPlugin/lang", "de_DE");
 * i18n.translate("greeting");                  // "Hallo, {0}!"   (raw text)
 * i18n.format("greeting", "Steve");            // "Hallo, Steve!"
 * i18n.format("coins", 1234567);               // "You have 1.234.567 coins."   (German number format)
 * i18n.translate("messages", "missing.key");   // null
 * }</pre>
 *
 * <h2>Formatting</h2>
 * With arguments, a message is a {@link MessageFormat} pattern, formatted for this object's locale (so numbers and
 * dates use German conventions for {@code de_DE}). Remember {@code MessageFormat}'s quoting rule: a single quote
 * starts quoted text, so write {@code ''} for an apostrophe, as in {@code don''t}. Without arguments, the message is
 * returned with {@code ''} turned back into {@code '}, so the same text works both ways.
 * <p>
 * A message that isn't a valid {@code MessageFormat} pattern is still shown rather than failing: named placeholders
 * such as <code>{player}</code> become {@code [player]}, and if the text is still invalid (for example an unmatched
 * brace) it is returned as written.
 *
 * <h2>Speed and threads</h2>
 * Each bundle is read once and kept as an immutable map, so {@link #translate(String)} is a plain hash lookup with
 * no locking. Messages are prepared once for formatting and cached. Simple messages (plain text with placeholders
 * like <code>{0}</code>) filled with text arguments, such as player names, are put together directly without
 * {@code MessageFormat}; numbers, dates and more complex patterns use a cached {@code MessageFormat}. Both give the
 * same result. An {@code I18n} can be shared by any number of threads; {@link #reload()} re-reads the files (for
 * example after a {@code /reload} command).
 *
 * @see MessageFormat
 */
public class I18n {
	/** The bundle used when none is named: {@code messages}. */
	public static final String DEFAULT_BUNDLE = "messages";
	/** Same as {@link #DEFAULT_BUNDLE}; kept for code written against earlier versions. */
	protected static final String DEFAULT_PROPERTY_NAME = DEFAULT_BUNDLE;
	/** The Unicode byte-order mark, which some editors put at the start of a UTF-8 file. */
	private static final char BYTE_ORDER_MARK = (char) 0xFEFF;

	private final ClassLoader loader;
	/** Folder on disk and path prefix on the class path; null or empty for none. */
	private final String folderPath;
	private final Locale locale;
	/** The first bundle name given to the constructor; used when a bundle name is null or empty. */
	private final String defaultBundle;
	/** The bundle names given to the constructor; they are read eagerly by the constructor and by {@link #reload()}. */
	private final String[] initialBundles;
	/** Loaded bundles: bundle name to an immutable map of key to message. */
	private final Map<String, Map<String, String>> bundles = new ConcurrentHashMap<>();
	/** Prepared messages for formatting, by message text. */
	private final Map<String, Template> formats = new ConcurrentHashMap<>();

	/**
	 * Creates translations for a locale given as text, such as {@code "de_DE"}, {@code "de-DE"} or {@code "ja"}.
	 *
	 * @param folderPath   folder on disk (and path on the class path) that holds the {@code .properties} files; null
	 *                     or empty for the working directory and the class-path root
	 * @param localeString the locale, as {@code language}, {@code language_COUNTRY} or
	 *                     {@code language_COUNTRY_variant} ({@code -} or {@code .} also work as separators); null or
	 *                     empty for the JVM's default locale
	 * @param bundleNames  the bundles to read now; the first one is used when no bundle is named. None given means
	 *                     {@value #DEFAULT_BUNDLE}
	 */
	public I18n(String folderPath, String localeString, String... bundleNames) {
		this(folderPath, parseLocale(localeString), bundleNames);
	}

	/**
	 * Creates translations for a locale, reading class-path resources through the thread's context class loader.
	 *
	 * @param folderPath  folder on disk (and path on the class path) that holds the {@code .properties} files; null or
	 *                    empty for the working directory and the class-path root
	 * @param locale      the locale; null for the JVM's default locale
	 * @param bundleNames the bundles to read now; the first one is used when no bundle is named. None given means
	 *                    {@value #DEFAULT_BUNDLE}
	 */
	public I18n(String folderPath, Locale locale, String... bundleNames) {
		this(null, folderPath, locale, bundleNames);
	}

	/**
	 * Creates translations for a locale, reading class-path resources through the given class loader (for example a
	 * plugin's own class loader, so files inside the plugin jar are found).
	 *
	 * @param loader      class loader for class-path resources; null for the thread's context class loader
	 * @param folderPath  folder on disk (and path on the class path) that holds the {@code .properties} files; null or
	 *                    empty for the working directory and the class-path root
	 * @param locale      the locale; null for the JVM's default locale
	 * @param bundleNames the bundles to read now; the first one is used when no bundle is named. None given means
	 *                    {@value #DEFAULT_BUNDLE}
	 */
	public I18n(ClassLoader loader, String folderPath, Locale locale, String... bundleNames) {
		ClassLoader l = loader != null ? loader : Thread.currentThread().getContextClassLoader();
		this.loader = l != null ? l : I18n.class.getClassLoader();
		this.folderPath = folderPath;
		this.locale = locale != null ? locale : Locale.getDefault();
		List<String> names = new ArrayList<>();
		if (bundleNames != null) {
			for (String name : bundleNames) {
				if (name != null && !name.isEmpty()) names.add(name);
			}
		}
		if (names.isEmpty()) names.add(DEFAULT_BUNDLE);
		this.initialBundles = names.toArray(new String[0]);
		this.defaultBundle = initialBundles[0];
		reload();
	}

	// ---- looking up messages ----

	/**
	 * Returns a message from the default bundle, as written in the file.
	 *
	 * @param key the message key
	 * @return the message, or null if no file has this key
	 */
	public @Nullable String translate(String key) {
		return bundle(null).get(key);
	}

	/**
	 * Returns a message from a bundle, as written in the file. A bundle that wasn't given to the constructor is read
	 * the first time it is asked for.
	 *
	 * @param bundleName the bundle; null or empty for the default bundle
	 * @param key        the message key
	 * @return the message, or null if no file of that bundle has this key
	 */
	public @Nullable String translate(String bundleName, String key) {
		return bundle(bundleName).get(key);
	}

	/**
	 * Returns a message from a bundle, formatted with arguments. Without arguments, the message is returned with
	 * {@code ''} turned into {@code '} (see the class description); with arguments, it is formatted as a
	 * {@link MessageFormat} for this object's locale.
	 *
	 * @param bundleName the bundle; null or empty for the default bundle
	 * @param key        the message key
	 * @param args       values for <code>{0}</code>, <code>{1}</code>, ...; none (or null) for none
	 * @return the finished message, or null if no file of that bundle has this key
	 */
	public @Nullable String translate(String bundleName, String key, Object... args) {
		String message = translate(bundleName, key);
		if (message == null) return null;
		if (args == null || args.length == 0) return unquote(message);
		Template template = formats.get(message);   // get first: Java 8's computeIfAbsent locks even when present
		if (template == null) template = formats.computeIfAbsent(message, m -> new Template(m, locale));
		return template.format(args);
	}

	/**
	 * Returns a message from the default bundle, formatted with arguments: the same as
	 * {@code translate(null, key, args)}. Use this instead of {@code translate(key, arg)}, which would read the
	 * argument as a key.
	 *
	 * @param key  the message key
	 * @param args values for <code>{0}</code>, <code>{1}</code>, ...
	 * @return the finished message, or null if the default bundle has no such key
	 */
	public @Nullable String format(String key, Object... args) {
		return translate(null, key, args);
	}

	/**
	 * Like {@link #format(String, Object...)}, but returns the key itself when the message is missing, which is
	 * handy for showing something useful to players instead of {@code null}.
	 *
	 * @param key  the message key
	 * @param args values for <code>{0}</code>, <code>{1}</code>, ...
	 * @return the finished message, or {@code key} if there is none
	 */
	public @NotNull String formatOrKey(String key, Object... args) {
		String s = format(key, args);
		return s != null ? s : key;
	}

	/**
	 * @param bundleName the bundle; null or empty for the default bundle
	 * @param key        the message key
	 * @return true if the bundle has a message for this key
	 */
	public boolean hasKey(String bundleName, String key) {
		return bundle(bundleName).containsKey(key);
	}

	/**
	 * @param bundleName the bundle; null or empty for the default bundle
	 * @return all messages of the bundle, as an unmodifiable map from key to message (empty if no file was found)
	 */
	public @NotNull Map<String, String> messages(String bundleName) {
		return bundle(bundleName);
	}

	/**
	 * @return the locale whose messages and number formats this object uses
	 */
	public @NotNull Locale getLocale() {
		return locale;
	}

	/**
	 * Re-reads all bundles from disk and the class path, for example after the files were edited. Bundles given to
	 * the constructor are read straight away; other bundles are read again when next used. A lookup running at the
	 * same time sees either the old or the new messages of a bundle, never a mix.
	 */
	public void reload() {
		Map<String, Map<String, String>> fresh = new HashMap<>();
		for (String name : initialBundles) {
			fresh.put(name, load(name));
		}
		bundles.keySet().retainAll(fresh.keySet());
		bundles.putAll(fresh);
		formats.clear();
	}

	// ---- loading ----

	/**
	 * @param bundleName the bundle; null or empty for the default bundle
	 * @return the bundle's messages, reading them first if needed
	 */
	private Map<String, String> bundle(String bundleName) {
		String name = bundleName == null || bundleName.isEmpty() ? defaultBundle : bundleName;
		Map<String, String> messages = bundles.get(name);
		return messages != null ? messages : bundles.computeIfAbsent(name, this::load);
	}

	/**
	 * Reads every file of a bundle for this locale, from the default file to the most specific one, each overriding
	 * the keys of the ones before.
	 *
	 * @param bundleName the bundle name
	 * @return an immutable map of all its messages (empty if no file was found)
	 */
	private Map<String, String> load(String bundleName) {
		Map<String, String> messages = new HashMap<>();
		for (String fileName : fileNames(bundleName, locale)) {
			Properties p = readProperties(fileName);
			if (p != null) {
				for (String key : p.stringPropertyNames()) {
					messages.put(key, p.getProperty(key));
				}
			}
		}
		return Collections.unmodifiableMap(messages);
	}

	/**
	 * Lists the file names to read for a bundle and locale, from the most general to the most specific. For
	 * {@code messages} and {@code de_DE_x}: {@code messages.properties}, {@code messages_de.properties},
	 * {@code messages_de_DE.properties}, {@code messages_de_DE_x.properties}. Parts the locale doesn't have are left
	 * out; a variant without a country gives {@code messages_de__x.properties}, as {@link Locale#toString()} does.
	 *
	 * @param bundleName the bundle name
	 * @param locale     the locale
	 * @return the file names, without folder
	 */
	static List<String> fileNames(String bundleName, Locale locale) {
		List<String> names = new ArrayList<>(4);
		names.add(bundleName + ".properties");
		String language = locale.getLanguage(), country = locale.getCountry(), variant = locale.getVariant();
		if (!language.isEmpty()) {
			names.add(bundleName + "_" + language + ".properties");
			if (!country.isEmpty()) names.add(bundleName + "_" + language + "_" + country + ".properties");
			if (!variant.isEmpty()) names.add(bundleName + "_" + language + "_" + country + "_" + variant + ".properties");
		}
		return names;
	}

	/**
	 * Reads one {@code .properties} file: from the folder on disk if it exists there, otherwise from the class path.
	 *
	 * @param fileName the file name, without folder
	 * @return its properties, or null if it exists in neither place or can't be read
	 */
	private Properties readProperties(String fileName) {
		boolean noFolder = folderPath == null || folderPath.isEmpty();
		Path file = noFolder ? Paths.get(fileName) : Paths.get(folderPath, fileName);
		if (Files.isRegularFile(file)) {
			try (InputStream in = Files.newInputStream(file)) {
				return parse(in);
			} catch (IOException e) {
				// unreadable: try the class path instead
			}
		}
		String resource = noFolder ? fileName : stripSlashes(folderPath) + "/" + fileName;
		try (InputStream in = loader.getResourceAsStream(resource)) {
			return in == null ? null : parse(in);
		} catch (IOException e) {
			return null;
		}
	}

	/**
	 * Parses {@code .properties} text, decoding it as UTF-8, or as ISO-8859-1 if it isn't valid UTF-8. A byte-order
	 * mark at the start is ignored.
	 *
	 * @param in the file's bytes
	 * @return the parsed properties
	 * @throws IOException if reading fails
	 */
	static Properties parse(InputStream in) throws IOException {
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		byte[] buffer = new byte[8192];
		for (int n; (n = in.read(buffer)) > 0; ) bytes.write(buffer, 0, n);
		byte[] data = bytes.toByteArray();
		String text;
		try {
			text = StandardCharsets.UTF_8.newDecoder()
					.onMalformedInput(CodingErrorAction.REPORT)
					.onUnmappableCharacter(CodingErrorAction.REPORT)
					.decode(ByteBuffer.wrap(data)).toString();
		} catch (CharacterCodingException e) {
			text = new String(data, StandardCharsets.ISO_8859_1);
		}
		if (!text.isEmpty() && text.charAt(0) == BYTE_ORDER_MARK) text = text.substring(1);
		Properties p = new Properties();
		p.load(new StringReader(text));
		return p;
	}

	/**
	 * @param path a folder path
	 * @return the path without leading or trailing {@code /}, as class-path resource names need
	 */
	private static String stripSlashes(String path) {
		int start = 0, end = path.length();
		while (start < end && path.charAt(start) == '/') start++;
		while (end > start && path.charAt(end - 1) == '/') end--;
		return path.substring(start, end);
	}

	// ---- formatting ----

	/**
	 * A message prepared for formatting. Most messages are simple, like <code>Hello, {0}!</code>: plain text and
	 * numbered placeholders, no quotes, no format types. For those, the text pieces are kept, and when every argument
	 * they use is something {@link MessageFormat} would print with {@code toString()} (text, booleans, enums, null,
	 * and so on), the result is put together directly, which is several times faster and needs no lock. Numbers and
	 * dates, which {@code MessageFormat} formats for the locale, and all other messages go through a
	 * {@code MessageFormat}, used inside {@code synchronized} because it isn't thread-safe.
	 */
	private static final class Template {
		/** The full formatter; always present, used whenever the fast path doesn't apply. */
		private final MessageFormat format;
		/** Simple messages only: the text before, between and after the placeholders; otherwise null. */
		private final String[] texts;
		/** Simple messages only: the argument number of each placeholder, in order. */
		private final int[] argIndex;

		/**
		 * @param message the message text
		 * @param locale  the locale for numbers and dates
		 */
		Template(String message, Locale locale) {
			this.format = newMessageFormat(message, locale);
			List<String> texts = new ArrayList<>();
			List<Integer> indexes = new ArrayList<>();
			boolean simple = message.indexOf('\'') < 0;
			int from = 0;
			while (simple) {
				int open = message.indexOf('{', from);
				if (open < 0) break;
				int close = message.indexOf('}', open + 1);
				int index = close < 0 ? -1 : parseIndex(message, open + 1, close);
				if (index < 0) {
					simple = false;
					break;
				}
				texts.add(message.substring(from, open));
				indexes.add(index);
				from = close + 1;
			}
			if (simple && message.indexOf('}', from) >= 0) simple = false;   // a stray } after the last placeholder
			if (simple) {
				texts.add(message.substring(from));
				this.texts = texts.toArray(new String[0]);
				this.argIndex = new int[indexes.size()];
				for (int i = 0; i < argIndex.length; i++) argIndex[i] = indexes.get(i);
			} else {
				this.texts = null;
				this.argIndex = null;
			}
		}

		/**
		 * @param args the arguments, not empty
		 * @return the formatted message
		 */
		String format(Object[] args) {
			if (texts != null && plainArguments(args)) {
				StringBuilder sb = new StringBuilder(64);
				for (int i = 0; i < argIndex.length; i++) {
					sb.append(texts[i]);
					int a = argIndex[i];
					if (a < args.length) {
						sb.append(args[a]);   // String.valueOf: "null" for null, as MessageFormat prints
					} else {
						sb.append('{').append(a).append('}');   // MessageFormat leaves a missing argument as {n}
					}
				}
				return sb.append(texts[argIndex.length]).toString();
			}
			synchronized (format) {
				return format.format(args);
			}
		}

		/**
		 * @param args the arguments
		 * @return true if every argument used by a placeholder prints the same with {@code toString()} as with
		 * {@link MessageFormat}, that is, none is a {@link Number} or a {@link java.util.Date}
		 */
		private boolean plainArguments(Object[] args) {
			for (int a : argIndex) {
				if (a < args.length) {
					Object o = args[a];
					if (o instanceof Number || o instanceof java.util.Date) return false;
				}
			}
			return true;
		}

		/**
		 * @param s    the message
		 * @param from index just after <code>{</code>
		 * @param to   index of <code>}</code>
		 * @return the placeholder's argument number if the placeholder is only digits (such as <code>{0}</code>), else -1
		 */
		private static int parseIndex(String s, int from, int to) {
			if (from >= to || to - from > 6) return -1;
			int n = 0;
			for (int i = from; i < to; i++) {
				char c = s.charAt(i);
				if (c < '0' || c > '9') return -1;
				n = n * 10 + (c - '0');
			}
			return n;
		}
	}

	/**
	 * Parses a message as a {@link MessageFormat} for a locale. If it isn't a valid pattern, named placeholders such
	 * as <code>{player}</code> are turned into {@code [player]} and it is parsed again; if it still isn't valid, the
	 * text is used as it is.
	 *
	 * @param message the message text
	 * @param locale  the locale for numbers and dates
	 * @return a format for it; never fails
	 */
	private static MessageFormat newMessageFormat(String message, Locale locale) {
		try {
			return new MessageFormat(message, locale);
		} catch (IllegalArgumentException e) {
			try {
				return new MessageFormat(bracketNamedPlaceholders(message), locale);
			} catch (IllegalArgumentException e2) {
				return new MessageFormat(quoteAll(message), locale);
			}
		}
	}

	/**
	 * Turns each <code>{name}</code> whose content contains no digit into {@code [name]}, leaving numbered placeholders
	 * such as <code>{0}</code> or <code>{0,number}</code> alone.
	 *
	 * @param s a message
	 * @return the message with named placeholders bracketed
	 */
	static String bracketNamedPlaceholders(String s) {
		StringBuilder sb = new StringBuilder(s.length());
		int i = 0;
		while (i < s.length()) {
			int open = s.indexOf('{', i);
			int close = open < 0 ? -1 : s.indexOf('}', open + 1);
			if (close < 0) {
				sb.append(s, i, s.length());
				break;
			}
			boolean hasDigit = false;
			for (int k = open + 1; k < close && !hasDigit; k++) hasDigit = Character.isDigit(s.charAt(k));
			sb.append(s, i, open);
			if (hasDigit) {
				sb.append(s, open, close + 1);
			} else {
				sb.append('[').append(s, open + 1, close).append(']');
			}
			i = close + 1;
		}
		return sb.toString();
	}

	/**
	 * @param s any text
	 * @return a {@link MessageFormat} pattern that prints {@code s} exactly: everything quoted, quotes doubled
	 */
	private static String quoteAll(String s) {
		return "'" + s.replace("'", "''") + "'";
	}

	/**
	 * Turns each {@code ''} into {@code '}, the way {@link MessageFormat} prints a doubled quote, so a message reads
	 * the same with and without arguments. Returns the same string, without copying, when there is nothing to change.
	 *
	 * @param s a message
	 * @return the message with doubled quotes made single
	 */
	static String unquote(String s) {
		int at = s.indexOf("''");
		if (at < 0) return s;
		StringBuilder sb = new StringBuilder(s.length() - 1);
		int from = 0;
		while (at >= 0) {
			sb.append(s, from, at + 1);
			from = at + 2;
			at = s.indexOf("''", from);
		}
		return sb.append(s, from, s.length()).toString();
	}

	// ---- locale parsing ----

	/**
	 * Parses {@code "de"}, {@code "de_DE"}, {@code "de-DE"}, {@code "de.DE"} or {@code "de_DE_variant"} into a locale.
	 *
	 * @param s the locale text
	 * @return the locale, or the JVM's default locale for null or empty text
	 */
	static Locale parseLocale(String s) {
		if (s == null || s.trim().isEmpty()) return Locale.getDefault();
		String[] parts = s.trim().split("[-_.]", 3);
		switch (parts.length) {
			case 1:
				return new Locale(parts[0]);
			case 2:
				return new Locale(parts[0], parts[1]);
			default:
				return new Locale(parts[0], parts[1], parts[2]);
		}
	}
}
