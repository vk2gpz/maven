/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.logging;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.LogRecord;

/**
 * The only class that refers to Log4j. {@link ColorLogHandler} creates it only when Log4j is on the
 * classpath, so elmer works without Log4j.
 */
final class Log4jBridge {
	private final Map<String, Logger> cachedLoggers = new ConcurrentHashMap<>();

	void publish(final LogRecord record, final String message) {
		final String name = record.getLoggerName() == null ? "" : record.getLoggerName();
		final Logger logger = cachedLoggers.computeIfAbsent(name, LogManager::getLogger);
		final Throwable exception = record.getThrown();
		final Level level = record.getLevel();

		if (level == Level.SEVERE) {
			logger.error(message, exception);
		} else if (level == Level.WARNING) {
			logger.warn(message, exception);
		} else if (level == Level.INFO) {
			logger.info(message, exception);
		} else if (level == Level.CONFIG) {
			logger.debug(message, exception);
		} else {
			logger.trace(message, exception);
		}
	}
}
