/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.lang;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;
import com.vk2gpz.elmer.debug.DebugHandler;

@SuppressWarnings("unused")
public class EnumUtil {
    // Cache: enumClass → (enumName → enumObject)
    // Thread-safe for concurrent lookups
    private static final Map<Class<?>, Map<String, Object>> ENUM_CACHE = new ConcurrentHashMap<>();
    
    /**
     * Gets an enum constant by name (case-insensitive).
     * Results are cached for repeated lookups on the same enum class.
     * 
     * @param enumClass the enum class to search in
     * @param name the enum constant name (case-insensitive)
     * @return the enum constant, or null if not found
     */
    @Nullable
    public static Object getEnumObject(@Nullable final Class<?> enumClass, @Nullable final String name) {
        if (enumClass == null || name == null) {
            return null;
        }
        
        final boolean debug = DebugHandler.isDebugged("EnumUtil.getEnumObject");
        
        // Get or create cache for this enum class
        final Map<String, Object> classCache = ENUM_CACHE.computeIfAbsent(enumClass, k -> {
            // Build cache on first access
            final Map<String, Object> cache = new ConcurrentHashMap<>();
            final Object[] constants = enumClass.getEnumConstants();
            if (constants != null) {
                for (final Object constant : constants) {
                    // Cache with uppercase key (O(1) lookup)
                    cache.put(constant.toString().toUpperCase(), constant);
                }
            }
            if (debug) {
                DebugHandler.getLogger("elmer").info("EnumUtil: Built cache for " + enumClass.getName() + " with " + cache.size() + " entries");
            }
            return cache;
        });
        
        // Fast O(1) lookup with cached normalized key
        final Object result = classCache.get(name.toUpperCase());
        if (debug && result != null) {
            DebugHandler.getLogger("elmer").info("EnumUtil: Cache hit for " + enumClass.getName() + "." + name);
        }
        return result;
    }
}
