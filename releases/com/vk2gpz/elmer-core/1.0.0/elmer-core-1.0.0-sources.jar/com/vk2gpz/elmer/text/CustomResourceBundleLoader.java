/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.text;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.ResourceBundle.Control;

public class CustomResourceBundleLoader {
	
	
	// Custom ResourceBundle.Control implementation
	static class CustomResourceBundleControl extends Control {
		private final String folderPath;
		
		public CustomResourceBundleControl(String folderPath) {
			this.folderPath = folderPath;
		}
		
		@Override
		public ResourceBundle newBundle(
				String baseName, Locale locale, String format, ClassLoader loader, boolean reload)
				throws IllegalAccessException, InstantiationException {
			
			// Construct the resource bundle name based on the folderPath, baseName, and locale
			String bundleName = toBundleName(baseName, locale);
			// Construct the full path to the resource bundle file
			String bundlePath = folderPath + "/" + bundleName.replace('.', '/') + ".properties";
			try {
				// Load the ResourceBundle using a custom ClassLoader
				
				return ResourceBundle.getBundle(
						bundlePath, locale, loader, new Utf8Control());
			} catch (MissingResourceException e) {
				System.out.println("Could not find : " + bundlePath);
				e.printStackTrace();
				return null; // ResourceBundle not found
			}
		}
	}
	
	// Custom ResourceBundle.Control implementation to support UTF-8 encoding
	static class Utf8Control extends Control {
		@Override
		public ResourceBundle newBundle(
				String baseName, Locale locale, String format, ClassLoader loader, boolean reload)
				throws IllegalAccessException, InstantiationException, IOException {
			
			String bundleName = toBundleName(baseName, locale);
			String resourceName = toResourceName(bundleName, "properties");
			
			try (InputStream stream = loader.getResourceAsStream(resourceName)) {
				if (stream != null) {
					try (InputStreamReader reader = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
						return new PropertyResourceBundle(reader);
					}
				}
			}
			
			return null; // ResourceBundle not found
		}
	}
}
