/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.lang;

import org.jetbrains.annotations.Nullable;
import com.vk2gpz.elmer.debug.DebugHandler;

@SuppressWarnings("unused")
public class DataType {
    private DataType() {
    }

    /**
     * Parses a string to boolean with case-insensitive comparison.
     * Recognizes: true, on, yes, ok, はい, 1 (and their case variations)
     * Performance: Uses equalsIgnoreCase() to avoid temporary string allocations.
     * 
     * @param str the string to parse
     * @return true if the string matches a truthy value, false otherwise
     */
    public static boolean parseBoolean(@Nullable final String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        
        final boolean debug = DebugHandler.isDebugged("DataType.parseBoolean");
        
        // Case-insensitive comparison without toLowerCase() allocation (O(n) vs O(2n))
        if (str.equalsIgnoreCase("true") ||
            str.equalsIgnoreCase("on") ||
            str.equalsIgnoreCase("yes") ||
            str.equalsIgnoreCase("ok") ||
            str.equals("はい") ||  // Exact match for Japanese (no case variation)
            str.equals("1")) {     // Exact match for "1"
            
            if (debug) {
                DebugHandler.getLogger("elmer").info("DataType.parseBoolean: Parsed '" + str + "' as true");
            }
            return true;
        }
        
        if (debug) {
            DebugHandler.getLogger("elmer").info("DataType.parseBoolean: Parsed '" + str + "' as false");
        }
        return false;
    }
}
