/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.lang;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Map;

/**
 * Argument checks. Every failed check throws {@link IllegalArgumentException}
 * (unlike {@link java.util.Objects#requireNonNull}, which throws {@code NullPointerException}).
 */
public final class Validate {
	private Validate() {
	}

	private static IllegalArgumentException fail(String message) {
		return new IllegalArgumentException(message);
	}

	// ---- isTrue ----

	@Contract("false, _, _ -> fail")
	public static void isTrue(boolean expression, @NotNull String message, @Nullable Object value) {
		if (!expression) throw fail(message + value);
	}

	@Contract("false, _, _ -> fail")
	public static void isTrue(boolean expression, @NotNull String message, long value) {
		if (!expression) throw fail(message + value);
	}

	@Contract("false, _, _ -> fail")
	public static void isTrue(boolean expression, @NotNull String message, double value) {
		if (!expression) throw fail(message + value);
	}

	@Contract("false, _ -> fail")
	public static void isTrue(boolean expression, @NotNull String message) {
		if (!expression) throw fail(message);
	}

	@Contract("false -> fail")
	public static void isTrue(boolean expression) {
		isTrue(expression, "Expression must be true");
	}

	// ---- notNull ----

	@Contract("null, _ -> fail")
	public static void notNull(@Nullable Object object, @NotNull String message) {
		if (object == null) throw fail(message);
	}

	@Contract("null -> fail")
	public static void notNull(@Nullable Object object) {
		notNull(object, "Value must not be null");
	}

	// ---- notEmpty ----

	@Contract("null, _ -> fail")
	public static void notEmpty(@Nullable Object[] array, @NotNull String message) {
		if (array == null || array.length == 0) throw fail(message);
	}

	@Contract("null -> fail")
	public static void notEmpty(@Nullable Object[] array) {
		notEmpty(array, "Array must not be null or empty");
	}

	@Contract("null, _ -> fail")
	public static void notEmpty(@Nullable Collection<?> collection, @NotNull String message) {
		if (collection == null || collection.isEmpty()) throw fail(message);
	}

	@Contract("null -> fail")
	public static void notEmpty(@Nullable Collection<?> collection) {
		notEmpty(collection, "Collection must not be null or empty");
	}

	@Contract("null, _ -> fail")
	public static void notEmpty(@Nullable Map<?, ?> map, @NotNull String message) {
		if (map == null || map.isEmpty()) throw fail(message);
	}

	@Contract("null -> fail")
	public static void notEmpty(@Nullable Map<?, ?> map) {
		notEmpty(map, "Map must not be null or empty");
	}

	@Contract("null, _ -> fail")
	public static void notEmpty(@Nullable String string, @NotNull String message) {
		if (string == null || string.isEmpty()) throw fail(message);
	}

	@Contract("null -> fail")
	public static void notEmpty(@Nullable String string) {
		notEmpty(string, "String must not be null or empty");
	}

	// ---- element checks ----

	public static void noNullElements(@Nullable Object[] array, @NotNull String message) {
		notNull(array);
		for (Object o : array) {
			if (o == null) throw fail(message);
		}
	}

	public static void noNullElements(@Nullable Object[] array) {
		notNull(array);
		for (int i = 0; i < array.length; i++) {
			if (array[i] == null) throw fail("Array has a null element at index " + i);
		}
	}

	public static void noNullElements(@Nullable Collection<?> collection, @NotNull String message) {
		notNull(collection);
		for (Object o : collection) {
			if (o == null) throw fail(message);
		}
	}

	public static void noNullElements(@Nullable Collection<?> collection) {
		notNull(collection);
		int i = 0;
		for (Object o : collection) {
			if (o == null) throw fail("Collection has a null element at index " + i);
			i++;
		}
	}

	public static void allElementsOfType(@Nullable Collection<?> collection, @NotNull Class<?> type, @NotNull String message) {
		notNull(collection);
		notNull(type);
		for (Object o : collection) {
			if (!type.isInstance(o)) throw fail(message);
		}
	}

	public static void allElementsOfType(@Nullable Collection<?> collection, @NotNull Class<?> type) {
		notNull(collection);
		notNull(type);
		int i = 0;
		for (Object o : collection) {
			if (!type.isInstance(o)) {
				throw fail("Collection element at index " + i + " is not a " + type.getName());
			}
			i++;
		}
	}
}
