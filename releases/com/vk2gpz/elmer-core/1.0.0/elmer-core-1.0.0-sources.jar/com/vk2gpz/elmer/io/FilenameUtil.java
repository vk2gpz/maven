/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.io;

import java.io.*;

/**
 * FilenameUtil defines several useful method to manipulate filename.
 *
 * @author vk2gpz (vk2gpz@gmail.com)
 * @version $Revision: 69 $
 */
@SuppressWarnings("unused")
public final class FilenameUtil {
	/**
	 * Constructs a new FilenameUtil object.
	 */
	private FilenameUtil() {
		super();
	}

	/**
	 * The system-dependent default name-separator character.  This field is
	 * initialized to contain the first character of the value of the system
	 * property <code>file.separator</code>.  On UNIX systems the value of this
	 * field is <code>'/'</code>; on Win32 systems it is <code>'\'</code>.
	 *
	 * @see System#getProperty(String)
	 */
	public static final char separatorChar = File.separatorChar;

	/**
	 * The system-dependent default name-separator character, represented as a
	 * string for convenience.  This string contains a single character, namely
	 * <code>{@link #separatorChar}</code>.
	 */
	public static final String separator = File.separator;

	/**
	 * The system-dependent path-separator character.  This field is
	 * initialized to contain the first character of the value of the system
	 * property <code>path.separator</code>.  This character is used to
	 * separate filenames in a sequence of files given as a <em>path list</em>.
	 * On UNIX systems, this character is <code>':'</code>; on Win32 systems it
	 * is <code>';'</code>.
	 *
	 * @see System#getProperty(String)
	 */
	public static final char pathSeparatorChar = File.pathSeparatorChar;

	/**
	 * The system-dependent path-separator character, represented as a string
	 * for convenience.  This string contains a single character, namely
	 * <code>{@link #pathSeparatorChar}</code>.
	 */
	public static final String pathSeparator = File.pathSeparator;

	/**
	 * Returns the name of the file or directory denoted by this abstract
	 * pathname.  This is just the last name in the pathname's name
	 * sequence.  If the pathname's name sequence is empty, then the empty
	 * string is returned.
	 *
	 * @return The name of the file or directory denoted by this abstract
	 * pathname, or the empty string if this pathname's name sequence
	 * is empty
	 */
	public  static String getName(String path) {
		return path.substring(path.lastIndexOf(separatorChar) + 1);
	}

	/**
	 * returns a suffix of the specified filename.
	 * <PRE>
	 * Example: String suffix = StringUtil.getSuffix(filename);
	 * </PRE>
	 *
	 * @param filename a filename.
	 * @return a suffix.
	 */
	public static String getSuffix(String filename) {
		return filename.substring(filename.lastIndexOf(".") + 1);
	}

	public static String getExtension(String filename) {
		return getSuffix(filename);
	}

	/**
	 * returns a filename without a suffix.
	 * <PRE>
	 * Example: String suffix = StringUtil.getBaseName(filename);
	 * </PRE>
	 *
	 * @param filename a filename.
	 * @return a base name.
	 */
	public static String getBaseName(String filename) {
		int dotIndex = filename.lastIndexOf(".");
		return dotIndex == -1 ? filename : filename.substring(0, dotIndex);
	}

	public static String changeSuffix(String filename, String suffix) {
		int index = filename.lastIndexOf(".");
		String result;
		if (index == -1) {
			result = filename + "." + suffix;
		} else {
			result = filename.substring(0, index + 1) + suffix;
		}
		return result;
	}

	public static String setSuffix(String filename, String suffix) {
		String sfx = (suffix.indexOf(".") == 0) ? suffix : ("." + suffix);
		int index = filename.lastIndexOf(sfx);
		String result = filename;

		if (index == -1) {        // suffix is not sfx!
			result = filename + sfx;
		}
		return result;
	}

	public static File setSuffix(File file, String suffix) {
		String filename = setSuffix(file.getAbsolutePath(), suffix);
		return new File(filename);
	}
} // FilenameUtil
