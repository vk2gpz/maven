/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.logging;

import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;

@SuppressWarnings("unused")
public class ColorFormatter extends Formatter {
	// ANSI escape code constants - cached for performance
	static final String ANSI_RESET = "\u001B[0m";
	static final String ANSI_BLACK = "\u001B[30m";
	static final String ANSI_RED = "\u001B[31m";
	static final String ANSI_GREEN = "\u001B[32m";
	static final String ANSI_YELLOW = "\u001B[33m";
	static final String ANSI_BLUE = "\u001B[34m";
	static final String ANSI_PURPLE = "\u001B[35m";
	static final String ANSI_CYAN = "\u001B[36m";
	static final String ANSI_WHITE = "\u001B[37m";

	// Level constants for faster comparison
	private static final Level LEVEL_SEVERE = Level.SEVERE;
	private static final Level LEVEL_WARNING = Level.WARNING;
	private static final Level LEVEL_INFO = Level.INFO;
	private static final Level LEVEL_CONFIG = Level.CONFIG;

	@Override
	public String format(LogRecord rec) {
		final String message = rec.getMessage();
		final Level level = rec.getLevel();
		
		// Fast level-to-color mapping using identity checks
		final String color;
		if (level == LEVEL_SEVERE) {
			color = ANSI_RED;
		} else if (level == LEVEL_WARNING) {
			color = ANSI_YELLOW;
		} else if (level == LEVEL_INFO) {
			color = ANSI_GREEN;
		} else if (level == LEVEL_CONFIG) {
			color = ANSI_BLUE;
		} else {
			color = ANSI_WHITE;
		}
		
		// Pre-allocate StringBuilder with expected capacity (color + message + reset)
		final int capacity = color.length() + message.length() + ANSI_RESET.length();
		final StringBuilder buf = new StringBuilder(capacity);
		buf.append(color).append(message).append(ANSI_RESET);
		
		return buf.toString();
	}
}


