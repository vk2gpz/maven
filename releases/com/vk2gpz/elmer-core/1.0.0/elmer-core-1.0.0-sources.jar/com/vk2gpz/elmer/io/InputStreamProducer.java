/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.io;

import java.io.*;

/**
 * An interface for producing an input stream on demand
 * <BR>
 * A null means that the resource is not (or no longer) available.
 * So, a one-shot producer may provide a value the first time but not
 * after that.
 */
public interface InputStreamProducer {
    InputStream getInputStream();
}
