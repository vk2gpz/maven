/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.io;

import java.io.*;
import java.util.*;

/**
 * The -string reader class allows an application to read tokens 
 * as well as single characters from a string. The tokenization method
 * is the same one used by <code>StringTokenizer</code>.
 * The <code>StringTokenReader</code> does not recognize identifiers, numbers,
 * quoted strings and skip comments. 
 * <p>
 * Delimiters can be set at creation time as well as on a per-token basis.
 * <p>
 * The <code>StringTokenReader</code> behaves in one of two ways
 * (same as java.util.StringTokenizer), depending
 * on whether it was created with the <code>returnTokens</code> flag
 * having the value <code>true</code>  or <code>false</code>: see more detail
 * in <code>java.util.StringTokenizer</code>.
 * <p>
 * The following is one example of the use of the string reader. The code:
 * <blockquote><pre>
 *     StringTokenReader sr = new StringTokenReader("this is a test 1 2 3.4");
 *     while (sr.hasMoreTokens()) {
 *         println(sr.nextToken());
 *     }
 * </pre></blockquote>
 * <p>
 * prints the following output:
 * <blockquote><pre>
 *     this
 *     is
 *     a
 *     test
 *	   1
 *	   2
 *	   3.4 
 * </pre></blockquote>
 * or
 * <blockquote><pre>
 *     StringTokenReader sr = new StringTokenReader("this is a test 1 2 3.4");
 *     println(sr.nextToken());
 *     println(sr.nextToken());
 *     println(sr.nextToken());
 *     println(sr.nextToken());
 *     println(sr.readInt());
 *     println(sr.readInt());
 *     println(sr.readFloat());   
 * </pre></blockquote>
 * <p>
 * prints the following output:
 * <blockquote><pre>
 *     this
 *     is
 *     a
 *     test
 *	   1
 *	   2
 *	   3.4 
 * </pre></blockquote>
 * 
 * @version $Revision: 69 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Reader
 * @see Enumeration
 */

@SuppressWarnings("unused")
public final class StringTokenReader extends Reader implements Enumeration<String> {
	private int currentPosition;
	private int maxPosition;
	private String str;
	private String delimiters;
	private boolean retTokens;
    private int mark;
	@SuppressWarnings({"FieldCanBeLocal", "unused"})
	private final String quotes;		// 1999-Oct-18
	private boolean[] isDelimiter;
	private char[] singleCharBuffer = new char[1];
	
	private void updateDelimiterArray() {
		this.isDelimiter = new boolean[Character.MAX_VALUE + 1];
		for (char c : this.delimiters.toCharArray()) {
			this.isDelimiter[c] = true;
		}
	}

	/**
     * Constructs a M-string reader for the specified string. The set of
	 * delimiters is specified in the <code>delim</code> argument.  
     * <p>
     * If the <code>returnTokens</code> flag is <code>true</code>, then 
     * the delimiter characters are also returned as tokens. 
     *
     * @param str            a string to be parsed.
     * @param delim          the delimiters.
     * @param quotes         quotation characters.// 1999-Oct-18
     * @param returnTokens   flag indicating whether to return the delimiters
     *                         as tokens.
     */
    public StringTokenReader(String str, String delim, String quotes, boolean returnTokens) {
		super();
		this.currentPosition = 0;
		this.str = str;
		this.maxPosition = (this.str !=null)?this.str.length():0;
		this.delimiters = (delim == null) ? " \t\n\r\f" : delim;
		this.quotes = quotes;	// 1999-Oct-18
		this.retTokens = returnTokens;
		this.mark = 0;
		updateDelimiterArray();
    }

	/**
     * Constructs a M-string reader for the specified string. The set of
	 * delimiters is specified in the <code>delim</code> argument.  
     * <p>
     * If the <code>returnTokens</code> flag is <code>true</code>, then 
     * the delimiter characters are also returned as tokens. 
     *
     * @param str            a string to be parsed.
     * @param delim          the delimiters.
     * @param returnTokens   flag indicating whether to return the delimiters
     *                         as tokens.
     */
    public StringTokenReader(String str, String delim, boolean returnTokens) {
		this(str, delim, "\"'", returnTokens);
    }

    /**
     * Constructs a M-string reader for the specified string. The set of
	 * delimiters is specified in the <code>delim</code> argument.  
     *
     * @param   str     a string to be parsed.
     * @param   delim   the delimiters.
     */
    public StringTokenReader(String str, String delim) {
		this(str, delim, false);
    }
	
    /**
     * Constructs a M-string reader for the specified string. The following
	 * characters are used as the default delimiter set:
	 * <code>"&#92;t&#92;n&#92;r&#92;f"</code>: the space character, the tab
     * character, the newline character, the carriage-return character,
     * and the form-feed character. 
     *
     * @param   str   a string to be parsed.
     */
    public StringTokenReader(String str) {
		this(str, " \t\n\r\f", false);
    }
	
    /**
     * Skips delimiters.
     */
    private void skipDelimiters() {
		if (!this.retTokens) {
			while ((this.currentPosition < this.maxPosition) &&
				   this.isDelimiter[this.str.charAt(this.currentPosition)]) {
				this.currentPosition++;
			}
		}
    }

    /**
     * Returns <code>true</code> if there are more tokens available. 
     * If this method returns <code>true</code>, then a subsequent call to 
     * <code>nextToken</code> or <code>readToken</code> with no argument will
	 * successfully return a token.
     *
     * @return  <code>true</code> if and only if there is at least one token 
     *          in the string after the current position; <code>false</code> 
     *          otherwise.
     */
    public boolean hasMoreTokens() {
		skipDelimiters();
		return (this.currentPosition < this.maxPosition);
    }
	
    /**
     * Returns the rest of tokens in the string.
     *
     * @return     the rest of tokens in the string.
     * @exception  NoSuchElementException if there are no more tokens.
     */
    public String restOfTokens() {
		skipDelimiters();		
		if (this.currentPosition >= this.maxPosition) {
			throw new NoSuchElementException();
		}
		return this.str.substring(this.currentPosition);
	}

    /**
     * Returns the next token.
     *
     * @return     the next token.
     * @exception  NoSuchElementException if there are no more tokens.
     */
    public String nextToken() {
		skipDelimiters();

		if (this.currentPosition >= this.maxPosition) {
			throw new NoSuchElementException();
		}
		
		int start = this.currentPosition;
		while ((this.currentPosition < this.maxPosition) && 
			   !this.isDelimiter[this.str.charAt(this.currentPosition)]) {
			this.currentPosition++;
		}
		if (this.retTokens && (start == this.currentPosition) &&
			this.isDelimiter[this.str.charAt(this.currentPosition)]) {
			this.currentPosition++;
		}
		return this.str.substring(start, this.currentPosition);
    }

    /**
     * Returns the next token.  First, delimiters specified by
	 * <code>delim</code> is set as the new delimiters.  Then the next token
	 * in the string after the current position is returned.
     * The new delimiter set remains the default after this call. 
     *
     * @param      delim   the new delimiters.
     * @return     the next token, after switching to the new delimiter set.
     * @exception  NoSuchElementException  if there are no more tokens.
     */
    public String nextToken(String delim) {
		this.delimiters = delim;
		updateDelimiterArray();
		return nextToken();
    }
	
    /**
     * Returns the same value as the <code>hasMoreTokens</code>
     * method. It exists so that this class can implement the
     * <code>Enumeration</code> interface. 
     *
     * @return  <code>true</code> if there are more tokens;
     *          <code>false</code> otherwise.
     * @see     #hasMoreTokens()
     */
    public boolean hasMoreElements() {
		return hasMoreTokens();
    }
	
    /**
     * Returns the same value as the <code>nextToken</code> method,
     * except that its declared return value is <code>Object</code> rather than
     * <code>String</code>. It exists so that this class can implement the
     * <code>Enumeration</code> interface. 
     *
     * @return     the next token in the string.
     * @exception  NoSuchElementException  if there are no more tokens in this
     *               tokenizer's string.
     * @see        #nextToken()
     */
    public String nextElement() {
		return nextToken();
    }
	
    /**
     * Calculates the number of tokens in the string.
	 * The current position is not advanced.
     *
     * @return  the number of tokens remaining in the string using the current
     *          delimiter set.
     */
    public int countTokens() {
		int count = 0;
		int currpos = this.currentPosition;
		
		while (currpos < this.maxPosition) {
			if (!this.retTokens) {	// skip delimiters.
				while ((currpos < this.maxPosition) &&
					   this.isDelimiter[this.str.charAt(currpos)]) {
					currpos++;
				}
			}
			
			if (currpos >= this.maxPosition) {
				break;
			}
			
			int start = currpos;
			while ((currpos < this.maxPosition) && 
				   !this.isDelimiter[this.str.charAt(currpos)]) {
				currpos++;
			}
			if (this.retTokens && (start == currpos) &&
				this.isDelimiter[this.str.charAt(currpos)]) {
				currpos++;
			}
			count++;
			
		}
		return count;
    }
	
	/**
     * Resets a M-string reader for the specified string. The set of
	 * delimiters is specified in the <code>delim</code> argument.  
     * <p>
     * If the <code>returnTokens</code> flag is <code>true</code>, then 
     * the delimiter characters are also returned as tokens. 
     *
     * @param   str            a string to be parsed.
     * @param   delim          the delimiters.
     * @param   returnTokens   flag indicating whether to return the delimiters
     *                         as tokens.
     */
    public void reset(String str, String delim, boolean returnTokens) {
		this.currentPosition = 0;
		this.str = str;
		this.maxPosition = (this.str !=null)?this.str.length():0;
		this.delimiters = delim;
		this.retTokens = returnTokens;
		updateDelimiterArray();
    }
	
    /**
     * Constructs a M-string reader for the specified string. The set of
	 * delimiters is specified in the <code>delim</code> argument.  
     *
     * @param   str     a string to be parsed.
     * @param   delim   the delimiters.
     */
    public void reset(String str, String delim) {
		reset(str, delim, false);
    }
	
    /**
     * Constructs a M-string reader for the specified string. The following
	 * characters are used as the default delimiter set:
	 * <code>"&#92;t&#92;n&#92;r&#92;f"</code>: the space character, the tab
     * character, the newline character, the carriage-return character,
     * and the form-feed character. 
     *
     * @param   str   a string to be parsed.
     */
    public void reset(String str) {
		reset(str, " \t\n\r\f", false);
    }
	
    /**
     * Read characters into a portion of an array.
     *
     * @param      cbuf  Destination buffer
     * @param      off   Offset at which to start writing characters
     * @param      len   Maximum number of characters to read
     * @return     The number of characters read, or -1 if the end of the
     *             stream has been reached
     *
	 */
    public int read(char[] cbuf, int off, int len) {
		skipDelimiters();
		
		if (this.currentPosition >= this.maxPosition) {
			return -1;			// the end of the stream has been reached.
			//  			throw new NoSuchElementException();
		}

		int n = Math.min(this.maxPosition - this.currentPosition, len);
		this.str.getChars(this.currentPosition, this.currentPosition + n, cbuf, off);
		this.currentPosition += n;
		return n;
	}
	
    /**
     * Read a single character.  This method will block until a character is
     * available, an I/O error occurs, or the end of the stream is reached.
     *
     * <p> Subclasses that intend to support efficient single-character input
     * should override this method.
     *
     * @return     The character read, as an integer in the range 0 to 16383
     *             (<code>0x00-0xffff</code>), or -1 if the end of the stream has
     *             been reached
     */
    public int read() {
		if (read(singleCharBuffer, 0, 1) == -1)
			return -1;
		else
			return singleCharBuffer[0];
    }

    /**
     * Read characters into an array.  This method will block until some input
     * is available, an I/O error occurs, or the end of the stream is reached.
     *
     * @param       cbuf  Destination buffer
     *
     * @return      The number of bytes read, or -1 if the end of the stream
     *              has been reached
     */
    public int read(char[] cbuf) {
		return read(cbuf, 0, cbuf.length);
    }

    /**
     * Tell whether this stream is ready to be read.  String readers are
     * always ready to be read.
     */
    public boolean ready() {
		return this.str != null;
    }

    /**
     * Tell whether this stream supports the mark() operation, which it does.
     */
    public boolean markSupported() {
		return true;
    }
	
    /**
     * Mark the present position in the stream.  Subsequent calls to reset()
     * will reposition the stream to this point.
     *
     * @param  readAheadLimit  Limit on the number of characters that may be
     *                         read while still preserving the mark.  Because
     *                         the stream's input comes from a string, there
     *                         is no actual limit, so this argument is ignored.
     *
	 */
    public void mark(int readAheadLimit) {
		this.mark = this.currentPosition;
    }

    /**
     * Reset the stream to the most recent mark, or to the beginning of the
     * string if it has never been marked.
     *
	 */
    public void reset() {
		this.currentPosition = this.mark;
    }

    /**
     * Close the stream.
     */
    public void close() {
		this.str = null;
    }

    /**
     * Read one token as a string.
     *
     * @return     A String containing the string, or null if the end of the
     *             stream has been reached.
     */
    public String readToken() {
		return nextToken();
    }

    /**
     * Returns the next token in this string tokenizer's string. First, 
     * the set of characters considered to be delimiters by this 
     * <code>StringTokenizer</code> object is changed to be the characters in 
     * the string <code>delim</code>. Then the next token in the string
     * after the current position is returned. The current position is 
     * advanced beyond the recognized token.  The new delimiter set 
     * remains the default after this call. 
     *
     * @param      delim   the new delimiters.
     * @return     the next token, after switching to the new delimiter set.
     * @exception  NoSuchElementException  if there are no more tokens in this
     *               tokenizer's string.
     */
    public String readToken(String delim) {
		return nextToken(delim);
    }
	
    /**
     * Reads a <code>boolean</code> from this data input stream. This 
     * method reads a single byte from the underlying input stream. A 
     * value of <code>0</code> represents <code>false</code>. Any other 
     * value represents <code>true</code>. This method blocks until 
     * either the byte is read, the end of the stream is detected, or an 
     * exception is thrown. 
     *
     * @return     the <code>boolean</code> value read.
     */
    public boolean readBoolean() {
		return Boolean.parseBoolean(nextToken());
    }

    /**
     * Reads a signed 8-bit value from this data input stream. This 
     * method reads a byte from the underlying input stream. If the byte 
     * read is <code>b</code>, where 
     * 0&nbsp;&lt;=&nbsp;<code>b</code>&nbsp;&lt;=&nbsp;255, then the 
     * result is:
     * <pre>
     *     (byte)(b)
     * </pre>
     * <p>
     * This method blocks until either the byte is read, the end of the 
     * stream is detected, or an exception is thrown. 
     *
     * @return     the next byte of this input stream as a signed 8-bit
     *             <code>byte</code>.
     */
    public byte readByte() {
		return Byte.parseByte(nextToken());
    }

    /**
     * Reads a signed 16-bit number from this data input stream. The 
     * method reads two bytes from the underlying input stream. If the two
     * bytes read, in order, are <code>b1</code> and <code>b2</code>, 
     * where each of the two values is between <code>0</code> and 
     * <code>255</code>, inclusive, then the result is equal to:
     * <pre>
     *     (short)((b1 &lt;&lt; 8) | b2)
     * </pre>
     * <p>
     * This method blocks until the two bytes are read, the end of the 
     * stream is detected, or an exception is thrown. 
     *
     * @return     the next two bytes of this input stream, interpreted as a
     *             signed 16-bit number.
     */
    public short readShort() {
		return Short.parseShort(nextToken());
    }

    /**
     * Reads a Unicode character from this data input stream. This 
     * method reads two bytes from the underlying input stream. If the 
     * bytes read, in order, are <code>b1</code> and <code>b2</code>, 
     * where 0&nbsp;&lt;=&nbsp;<code>b1</code>, 
     * <code>b1</code>&nbsp;&lt;=&nbsp;255, then the result is equal to:
     * <pre>
     *     (char)((b1 &lt;&lt; 8) | b2)
     * </pre>
     * <p>
     * This method blocks until either the two bytes are read, the end of 
     * the stream is detected, or an exception is thrown. 
     *
     * @return     the next two bytes of this input stream as a Unicode
     *             character.
     */
    public char readChar() {
		int ch1 = read();
		int ch2 = read();
		if ((ch1 | ch2) < 0)
			throw new NoSuchElementException();
		return (char)((ch1 << 8) + (ch2));
    }
    
    /**
     * Reads a signed 32-bit integer from this data input stream. This 
     * method reads four bytes from the underlying input stream. If the 
     * bytes read, in order, are <code>b1</code>, <code>b2</code>, 
     * <code>b3</code>, and <code>b4</code>, where 
     * 0&nbsp;&lt;=&nbsp;<code>b1</code>, <code>b2</code>, 
     * <code>b3</code>, <code>b4</code>&nbsp;&lt;=&nbsp;255, then the 
     * result is equal to:
     * <pre>
     *     (b1 &lt;&lt; 24) | (b2 &lt;&lt; 16) + (b3 &lt;&lt; 8) +b4
     * </pre>
     * <p>
     * This method blocks until the four bytes are read, the end of the 
     * stream is detected, or an exception is thrown. 
     *
     * @return     the next four bytes of this input stream, interpreted as an
     *             <code>int</code>.
     */
    public int readInt() {
		return Integer.parseInt(nextToken());
    }

    /**
     * Reads a signed 64-bit integer from this data input stream. This 
     * method reads eight bytes from the underlying input stream. If the 
     * bytes read, in order, are <code>b1</code>, <code>b2</code>, 
     * <code>b3</code>, <code>b4</code>, <code>b5</code>, 
     * <code>b6</code>, <code>b7</code>, and <code>b8</code>, where 
     * <pre>
     *     0 &lt;= b1, b2, b3, b4, b5, b6, b7, b8 &lt;= 255,
     * </pre>
     * <p>
     * then the result is equal to:
     * <p><blockquote><pre>
     *     ((long)b1 &lt;&lt; 56) + ((long)b2 &lt;&lt; 48) +
     *        ((long)b3 &lt;&lt; 40) + ((long)b4 &lt;&lt; 32) +
     *        ((long)b5 &lt;&lt; 24) + (b6 &lt;&lt; 16) +
     *        (b7 &lt;&lt; 8) + b8
     * </pre></blockquote>
     * <p>
     * This method blocks until the eight bytes are read, the end of the 
     * stream is detected, or an exception is thrown. 
     *
     * @return     the next eight bytes of this input stream, interpreted as a
     *             <code>long</code>.
     */
    public long readLong() {
		return Long.parseLong(nextToken());
    }

    /**
     * Reads a <code>float</code> from this data input stream. This 
     * method reads an <code>int</code> value as if by the 
     * <code>readInt</code> method and then converts that 
     * <code>int</code> to a <code>float</code> using the 
     * <code>intBitsToFloat</code> method in class <code>Float</code>. 
     * This method blocks until the four bytes are read, the end of the 
     * stream is detected, or an exception is thrown. 
     *
     * @return     the next four bytes of this input stream, interpreted as a
     *             <code>float</code>.
     */
    public float readFloat() {
		return Float.parseFloat(nextToken());
    }

    /**
     * Reads a <code>double</code> from this data input stream. This 
     * method reads a <code>long</code> value as if by the 
     * <code>readLong</code> method and then converts that 
     * <code>long</code> to a <code>double</code> using the 
     * <code>longBitsToDouble</code> method in class <code>Double</code>.
     * <p>
     * This method blocks until the eight bytes are read, the end of the 
     * stream is detected, or an exception is thrown. 
     *
     * @return     the next eight bytes of this input stream, interpreted as a
     *             <code>double</code>.
     */
    public double readDouble() {
		return Double.parseDouble(nextToken());
    }
}
