/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.text;

import org.apache.commons.lang3.math.NumberUtils;

import com.vk2gpz.elmer.debug.DebugHandler;
import com.vk2gpz.elmer.debug.DebugLabel;
import com.vk2gpz.elmer.logging.ColorConsoleLogger;
import org.jetbrains.annotations.NotNull;

import java.text.*;
import java.text.Format;
import java.util.regex.Pattern;

/**
 * Converts a number to a string in <a href="http://en.wikipedia.org/wiki/Metric_prefix">metric prefix</a> format.
 * For example, 7800000 will be formatted as '7.8M'. Numbers under 1000 will be unchanged. Refer to the tests for further examples.
 */
@SuppressWarnings("unused")
public class MetricPrefixFormat extends Format {
	static private MetricPrefixFormat instance;
	
	private final static String[] DEFAULT_METRIC_PREFIXES = {"", "k", "M", "B", "T", "Q", "P", "E", "Z", "Y"};
	private final static String DEFAULT_METRIC_PREFIXES_ONE = "kMBTQPEZY";
	private final static String[] DEFAULT_NEGATIVE_METRIC_PREFIXES = {"", "m", "u", "n", "p", "f", "a", "z", "y"};
	private String[] metricPrefixes = DEFAULT_METRIC_PREFIXES;
	private String[] negativeMetricPrefixes = DEFAULT_NEGATIVE_METRIC_PREFIXES;
	
	private Pattern trailingDecimalPoint;// = Pattern.compile("[0-9]+\\.[kMBTQPEZ]");
	private Pattern metricPrefixedNumber;// = Pattern.compile("\\-?[0-9]+(\\.[0-9])?[kMBTQPEZ]");
	@SuppressWarnings("FieldCanBeLocal")
	private int maxLength = 4;
	
	private static final String DefaultPatternStr = "##0E0";
	private String patternStr = DefaultPatternStr;
	
	private MetricPrefixFormat() {
	
	}
	
	public Pattern getTrailingDecimalPointPattern() {
		return this.trailingDecimalPoint;
	}
	
	public void setMetricPrefixes(String[] orderChars, String[] orderCharsNegative, String orderCharsOne) {
		metricPrefixes = orderChars;
		negativeMetricPrefixes = orderCharsNegative;
		trailingDecimalPoint = Pattern.compile("[0-9]+\\.[" + orderCharsOne + "]");
		metricPrefixedNumber = Pattern.compile("([+-]?[0-9]{1,3}(?:,?[0-9]{3})?+(\\.[0-9]{1,3})?[" + orderCharsOne + "]?)");
	}
	
	public void setMetricPrefixes(String[] orderChars, String orderCharsOne) {
		setMetricPrefixes(orderChars, negativeMetricPrefixes, orderCharsOne);
	}
	
	public static MetricPrefixFormat getInstance() {
		if (instance == null) {
			instance = new MetricPrefixFormat();
			instance.setMetricPrefixes(DEFAULT_METRIC_PREFIXES, DEFAULT_NEGATIVE_METRIC_PREFIXES, DEFAULT_METRIC_PREFIXES_ONE);
		}
		return instance;
	}
	
	public void setMaxLength(int max) {
		maxLength = max;
	}
	
	public void setPatternStr(String str) {
		patternStr = str;
	}
	
	@DebugLabel(key = "MetricPrefixFormat_format")
	@Override
	public StringBuffer format(Object obj, @NotNull StringBuffer output, @NotNull FieldPosition pos) {
		boolean debug = DebugHandler.isDebugged("MetricPrefixFormat_format");
		double number = Double.parseDouble(obj.toString());
		
		// if the number is negative, convert it to a positive number and add the minus sign to the output at the end
		boolean isNegative = number < 0;
		number = Math.abs(number);
		
		String result = new DecimalFormat(patternStr).format(number);
		String order = (result.indexOf("E") > 0) ? result.substring(result.indexOf("E") + 1)
				: result.substring(result.indexOf("e") + 1);
		int index = Integer.parseInt(order) / 3; //result.charAt(result.length() - 1)) / 3;
		if (index < metricPrefixes.length) {
			result = result.replaceAll("[eE]-?[0-9]+", (index > 0) ? metricPrefixes[index] : negativeMetricPrefixes[Math.abs(index)]);
			if (debug) {
				DebugHandler.getLogger("elmer").info("number = " + number);
				DebugHandler.getLogger("elmer").info("result = " + result);
				DebugHandler.getLogger("elmer").info("index = " + index);
				DebugHandler.getLogger("elmer").info("order = " + order);
			}
			
			/*
			while (result.length() > maxLength || trailingDecimalPoint.matcher(result).matches()) {
				int length = result.length();
				result = result.substring(0, length - 2) + result.substring(length - 1);
			}
			
			 */
			while (trailingDecimalPoint.matcher(result).matches()) {
				int length = result.length();
				result = result.substring(0, length - 2) + result.substring(length - 1);
			}
		}
		
		return output.append(isNegative ? "-" + result : result);
	}
	
	/**
	 * Convert a String produced by <code>format()</code> back to a number. This will generally not restore
	 * the original number because <code>format()</code> is a lossy operation, e.g.
	 * <p>
	 * <pre>
	 * {@code
	 * def formatter = new MetricPrefixFormat()
	 * Long number = 5821L
	 * String formattedNumber = formatter.format(number)
	 * assert formattedNumber == '5.8k'
	 *
	 * Long parsedNumber = formatter.parseObject(formattedNumber)
	 * assert parsedNumber == 5800
	 * assert parsedNumber != number
	 * }
	 * </pre>
	 *
	 * @param source a number that may have a metric prefix
	 * @param pos    if parsing succeeds, this should be updated to the index after the last parsed character
	 * @return a Number if the the string is a number without a metric prefix, or a Long if it has a metric prefix
	 */
	@Override
	public Object parseObject(String source, @NotNull ParsePosition pos) {
		if (NumberUtils.isCreatable(source)) {
			// if the value is a number (without a prefix) don't return it as a Long or we'll lose any decimals
			pos.setIndex(source.length());
			return toNumber(source);
			
		} else if (metricPrefixedNumber.matcher(source).matches()) {
			boolean isNegative = source.charAt(0) == '-';
			int length = source.length();
			
			String number = isNegative ? source.substring(1, length - 1) : source.substring(0, length - 1);
			String metricPrefix = Character.toString(source.charAt(length - 1));
			
			Number absoluteNumber = toNumber(number);
			
			int index = 0;
			
			for (; index < metricPrefixes.length; index++) {
				if (metricPrefixes[index].equals(metricPrefix)) {
					break;
				}
			}
			
			int exponent = 3 * index;
			Double factor = Math.pow(10, exponent);
			factor *= isNegative ? -1 : 1;
			
			pos.setIndex(source.length());
			Float result = absoluteNumber.floatValue() * factor.longValue();
			return result.longValue();
		}
		
		return null;
	}
	
	private static Number toNumber(String number) {
		return NumberUtils.createNumber(number);
	}
	
	public Number parseNumber(String source) {
		try {
			Object resultObject = parseObject(source);
			return (resultObject instanceof Number) ? (Number) resultObject : (byte)0;
		} catch (ParseException ignore) {
		}
		return (byte)0;
	}
}
