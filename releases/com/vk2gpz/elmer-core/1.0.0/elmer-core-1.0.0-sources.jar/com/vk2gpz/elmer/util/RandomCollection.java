/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.util;

import java.util.Map;
import java.util.NavigableMap;
import java.util.Random;
import java.util.TreeMap;

@SuppressWarnings("unused")
public class RandomCollection<T> {
	private final NavigableMap<Double, T> map = new TreeMap<>();
	private final Random random;
	private double total = 0.0D;

	public RandomCollection() {
		this(new Random());
	}

	public RandomCollection(Random rand) {
		this.random = (rand == null) ? new Random() : rand;
	}

	public void add(double chance, T value) {
		if (chance <= 0.0D)
			return;
		this.total += chance;
		this.map.put(this.total, value);
	}

	public T next() {
		double d = this.random.nextDouble() * this.total;
		Map.Entry<Double, T> entry = this.map.ceilingEntry(d);
		return entry != null ? entry.getValue() : null;
	}
}
