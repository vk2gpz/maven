/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.text;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * Number helpers that are not in Apache Commons Lang: rounding and formatting.
 * For metric prefixes ("1.5k") see {@link MetricPrefixFormat}.
 * <p>
 * For parsing and converting numbers ({@code toInt}, {@code createNumber}, {@code isCreatable} …) use
 * {@code org.apache.commons.lang3.math.NumberUtils}.
 */
public final class NumberUtil {
	private NumberUtil() {
	}

	/**
	 * Rounds {@code value} to the nearest multiple of {@code minUnit}, rounding halves up for positive values:
	 * {@code roundToMinUnit(1.26, 0.05)} is 1.25, {@code roundToMinUnit(1.275, 0.05)} is 1.3.
	 */
	public static double roundToMinUnit(double value, double minUnit) {
		BigDecimal bd = BigDecimal.valueOf(value);
		BigDecimal unit = BigDecimal.valueOf(minUnit);
		BigDecimal[] divRem = bd.divideAndRemainder(unit);
		BigDecimal half = unit.divide(BigDecimal.valueOf(2));
		BigDecimal rounded = divRem[1].compareTo(half) >= 0
				? divRem[0].add(BigDecimal.ONE).multiply(unit)
				: divRem[0].multiply(unit);
		return rounded.doubleValue();
	}

	/** Parses {@code svalue} with {@link MetricPrefixFormat} ("1.5k") and rounds it like {@link #roundToMinUnit(double, double)}. */
	public static double roundToMinUnit(String svalue, double minUnit) {
		return roundToMinUnit(MetricPrefixFormat.getInstance().parseNumber(svalue).doubleValue(), minUnit);
	}

	/** Formats {@code value} with the number format of {@code locale} (grouping, locale decimal separator). */
	public static String formatDouble(double value, Locale locale) {
		return NumberFormat.getInstance(locale).format(value);
	}

	/** Same as {@code formatDouble(value, Locale.ENGLISH)}: "1,234.5". */
	public static String formatDouble(double value) {
		return formatDouble(value, Locale.ENGLISH);
	}

	/** Formats with a metric prefix ("1.5k") if {@code beautify}, otherwise like {@link #formatDouble(double)}. */
	public static String format(double value, boolean beautify) {
		return beautify ? MetricPrefixFormat.getInstance().format(value) : formatDouble(value);
	}

	/** Writes {@code value} without an exponent and without rounding: 1.0E-7 → "0.0000001", 1.5E10 → "15000000000". */
	public static String toPlainString(double value) {
		return BigDecimal.valueOf(value).stripTrailingZeros().toPlainString();
	}
}
