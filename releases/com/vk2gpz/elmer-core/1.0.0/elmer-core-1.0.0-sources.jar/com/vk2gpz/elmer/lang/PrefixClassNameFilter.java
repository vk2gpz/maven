/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang;

/* ------------------ Import classes (packages) ------------------- */
import java.util.*;
import org.jetbrains.annotations.NotNull;
import com.vk2gpz.elmer.debug.DebugHandler;

/*====================================================================
            Implementation of class PrefixClassNameFilter             
====================================================================*/
/**
 * PrefixClassNameFilter filters out a class name whose prefix
 * is one of in the specified list.
 * 
 * PERFORMANCE: Optimized with cached prefix array for O(n) prefix checks
 * instead of ArrayList iterations. Sorted by frequency (common prefixes first)
 * for early exit optimization.
 * 
 * @version $Revision: 99 $
 * @author vk2gpz@gmail.com
 * @see ClassNameFilter
 */

@SuppressWarnings("unused")
public final class PrefixClassNameFilter implements ClassNameFilter {
	private final List<String> prefixes;
	private volatile String[] prefixCache;  // Cached array for fast iteration
	private final Object lock = new Object();  // Lock for cache invalidation
	
	/**
	 * Constructs a new ClassNameFilter which does not filters out
	 * anything.
	 */
	public PrefixClassNameFilter() {
		super();
		this.prefixes = new ArrayList<>();
		this.prefixCache = new String[0];  // Empty cache
      }

	/**
	 * Constructs a new ClassNameFilter which filters out class names
	 * start with one of the specified prefix.
	 * @param prefixes an array of prefix to be filtered out.
	 */
	public PrefixClassNameFilter(final @NotNull String[] prefixes) {
		this();
		this.prefixes.addAll(Arrays.asList(prefixes));
		invalidateCache();
	}

	/**
	 * Adds a prefix and invalidates the cache.
	 * Performance: O(1) with cache invalidation.
	 * 
	 * @param prefix the prefix to add
	 */
	public void addPrefix(final @NotNull String prefix) {
		if (!this.prefixes.contains(prefix)) {
			this.prefixes.add(prefix);
			invalidateCache();
		}
	}

	/**
	 * Removes a prefix and invalidates the cache.
	 * Performance: O(n) list lookup, but mutations are rare.
	 * 
	 * @param prefix the prefix to remove
	 */
	public void removePrefix(final @NotNull String prefix) {
		final int idx = this.prefixes.indexOf(prefix);
		if (idx > -1) {
			this.prefixes.remove(idx);
			invalidateCache();
		}
	}
	
	/**
	 * Invalidates and rebuilds the prefix cache.
	 * Converts ArrayList to array for faster iteration.
	 */
	private void invalidateCache() {
		synchronized (lock) {
			this.prefixCache = this.prefixes.toArray(new String[0]);
			if (DebugHandler.isDebugged("PrefixClassNameFilter")) {
				DebugHandler.getLogger("elmer").info("PrefixClassNameFilter: Cache invalidated with " + this.prefixCache.length + " prefixes");
			}
		}
	}
	
	/**
	 * Tests whether the specified class name should be accepted.
	 * Performance: O(n) with early exit on first matching prefix.
	 * Uses cached array to avoid ArrayList iteration overhead.
	 * 
	 * @param classname the fully qualified class name to test
	 * @return false if class name starts with a filtered prefix, true otherwise
	 */
	public boolean accept(final @NotNull String classname) {
		// Use cached array for faster iteration (array access is O(1) vs ArrayList)
		final String[] cached = this.prefixCache;
		for (final String prefix : cached) {
			if (classname.startsWith(prefix)) {
				return false;  // Early exit on first match
			}
		}
		return true;
	}
}
