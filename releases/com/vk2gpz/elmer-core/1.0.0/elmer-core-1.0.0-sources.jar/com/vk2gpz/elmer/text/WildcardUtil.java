/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.text;

import java.util.regex.Pattern;

/**
 * Wildcard patterns: {@code *} matches any run of characters (including none), {@code ?} matches exactly one
 * character, and every other character matches itself. See {@link Wildcard} for the exact rules.
 * <p>
 * {@link #matches(String, String)} needs no preparation: it matches directly, without regular expressions or locks,
 * and quietly reuses a compiled form for patterns that keep coming back. For the best speed in a hot loop,
 * {@link #compile(String)} the pattern yourself and reuse the {@link Wildcard}.
 */
public final class WildcardUtil {

	private WildcardUtil() {
		throw new IllegalStateException("WildcardUtil is a utility class, and can't be instantiated");
	}

	// ---- matching ----

	/**
	 * @return true if the whole of {@code text} matches {@code wildcard} (case-sensitive)
	 * @throws IllegalArgumentException if either argument is null
	 */
	public static boolean matches(String wildcard, String text) {
		check(wildcard, text);
		return Wildcard.matchesRecent(wildcard, text, false);
	}

	/**
	 * Like {@link #matches(String, String)}, but letters match regardless of case ({@code "Mine_*"} matches
	 * {@code "mine_a"}).
	 *
	 * @throws IllegalArgumentException if either argument is null
	 */
	public static boolean matchesIgnoreCase(String wildcard, String text) {
		check(wildcard, text);
		return Wildcard.matchesRecent(wildcard, text, true);
	}

	/** @return a prepared, reusable, thread-safe matcher for {@code wildcard} (case-sensitive) */
	public static Wildcard compile(String wildcard) {
		return Wildcard.compile(wildcard, false);
	}

	/** @return a prepared, reusable, thread-safe matcher for {@code wildcard} */
	public static Wildcard compile(String wildcard, boolean ignoreCase) {
		return Wildcard.compile(wildcard, ignoreCase);
	}

	/** @return true if {@code s} contains {@code *} or {@code ?}, i.e. is more than a plain name */
	public static boolean containsWildcard(String s) {
		return s != null && (s.indexOf('*') >= 0 || s.indexOf('?') >= 0);
	}

	private static void check(String wildcard, String text) {
		if (wildcard == null) {
			throw new IllegalArgumentException("Wildcard must not be null");
		}
		if (text == null) {
			throw new IllegalArgumentException("Text must not be null");
		}
	}

	// ---- conversion ----

	/** Same as {@code wildcardToRegex(wildcard, true)}: a regex for the whole text, {@code ^...$}. */
	public static String wildcardToRegex(String wildcard) {
		return wildcardToRegex(wildcard, true);
	}

	/**
	 * Converts a wildcard into a regular expression: {@code ?} becomes {@code .}, a run of {@code *} becomes
	 * {@code .*}, and everything else is quoted, so characters such as {@code .} or {@code $} match themselves.
	 *
	 * @param strict true to wrap the result in {@code ^} and {@code $}
	 * @throws IllegalArgumentException if {@code wildcard} is null
	 */
	public static String wildcardToRegex(String wildcard, boolean strict) {
		if (wildcard == null) {
			throw new IllegalArgumentException("Wildcard must not be null");
		}
		StringBuilder regex = new StringBuilder(wildcard.length() + 16);
		if (strict) regex.append('^');
		int n = wildcard.length();
		int literalStart = 0;
		for (int i = 0; i < n; i++) {
			char c = wildcard.charAt(i);
			if (c != '*' && c != '?') continue;
			if (i > literalStart) regex.append(Pattern.quote(wildcard.substring(literalStart, i)));
			if (c == '?') {
				regex.append('.');
			} else {
				regex.append(".*");
				while (i + 1 < n && wildcard.charAt(i + 1) == '*') i++;
			}
			literalStart = i + 1;
		}
		if (literalStart < n) regex.append(Pattern.quote(wildcard.substring(literalStart)));
		if (strict) regex.append('$');
		return regex.toString();
	}

	/**
	 * Converts a wildcard into a pattern for SQL {@code LIKE}, using {@code \} as the escape character:
	 * {@code *} becomes {@code %}, {@code ?} becomes {@code _}, and a literal {@code %}, {@code _} or {@code \} is
	 * escaped. MySQL, MariaDB and PostgreSQL use {@code \} by default; for SQLite add {@code ESCAPE '\'} to the query.
	 *
	 * @throws IllegalArgumentException if {@code wildcard} is null
	 */
	public static String wildcardToSqlPattern(String wildcard) {
		return wildcardToSqlPattern(wildcard, '\\');
	}

	/**
	 * Same as {@link #wildcardToSqlPattern(String)} with your own escape character; use it with
	 * {@code LIKE ? ESCAPE '<escape>'}.
	 *
	 * @throws IllegalArgumentException if {@code wildcard} is null, or {@code escape} is {@code %}, {@code _},
	 *                                  {@code *} or {@code ?}
	 */
	public static String wildcardToSqlPattern(String wildcard, char escape) {
		if (wildcard == null) {
			throw new IllegalArgumentException("Wildcard must not be null");
		}
		if (escape == '%' || escape == '_' || escape == '*' || escape == '?') {
			throw new IllegalArgumentException("Not usable as an escape character: " + escape);
		}
		StringBuilder sql = new StringBuilder(wildcard.length() + 8);
		for (int i = 0; i < wildcard.length(); i++) {
			char c = wildcard.charAt(i);
			if (c == '*') {
				sql.append('%');
			} else if (c == '?') {
				sql.append('_');
			} else {
				if (c == '%' || c == '_' || c == escape) sql.append(escape);
				sql.append(c);
			}
		}
		return sql.toString();
	}
}
