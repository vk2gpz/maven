/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.db.sql;

import com.vk2gpz.elmer.db.DatabaseConnector;
import com.vk2gpz.elmer.db.DatabaseException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Connector for a JDBC database. The driver class is loaded explicitly, because automatic driver
 * discovery does not work from every class loader (for example a Minecraft plugin's).
 */
public abstract class JdbcConnector extends DatabaseConnector<Connection> {

	protected JdbcConnector(String host, int port, String dbName, String[] credentials) {
		super(host, port, dbName, credentials);
	}

	/** @return the JDBC URL to connect to. */
	protected abstract String jdbcUrl();

	/** @return driver class names to try, in order; the first one found is used. */
	protected abstract String[] driverClassNames();

	@Override
	public Connection connect() throws ClassNotFoundException, DatabaseException {
		loadDriver();
		try {
			return user() == null
					? DriverManager.getConnection(jdbcUrl())
					: DriverManager.getConnection(jdbcUrl(), user(), password());
		} catch (SQLException e) {
			throw new DatabaseException("Cannot connect to " + jdbcUrl() + ": " + e.getMessage(), e);
		}
	}

	private void loadDriver() throws ClassNotFoundException {
		ClassNotFoundException missing = null;
		for (String name : driverClassNames()) {
			try {
				Class.forName(name);
				return;
			} catch (ClassNotFoundException e) {
				missing = e;
			}
		}
		throw missing != null ? missing : new ClassNotFoundException("no JDBC driver configured");
	}
}
