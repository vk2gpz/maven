/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.db;

/**
 * Knows how to open a connection of type {@code C} to one database.
 *
 * @param <C> the connection type, e.g. {@link java.sql.Connection} or a MongoDB client
 */
public abstract class DatabaseConnector<C> {
	protected final String host;
	protected final int port;
	protected final String dbName;
	/** {@code {user, password}}, or null when the database needs no login (e.g. SQLite). */
	protected final String[] credentials;

	protected DatabaseConnector(String host, int port, String dbName, String[] credentials) {
		this.host = host;
		this.port = port;
		this.dbName = dbName;
		this.credentials = credentials == null ? null : credentials.clone();
	}

	/**
	 * Opens a new connection.
	 *
	 * @throws ClassNotFoundException if the database driver is not on the classpath
	 * @throws DatabaseException      if the connection fails
	 */
	public abstract C connect() throws ClassNotFoundException, DatabaseException;

	public String getDatabaseName() {
		return dbName;
	}

	public String getHost() {
		return host;
	}

	public int getPort() {
		return port;
	}

	protected String user() {
		return credentials != null && credentials.length > 0 ? credentials[0] : null;
	}

	protected String password() {
		return credentials != null && credentials.length > 1 ? credentials[1] : null;
	}
}
