/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.db.sql;

import com.vk2gpz.elmer.db.DatabaseException;

import java.io.File;

/** Connections to SQLite database files. */
public class SQLiteManager extends JdbcManager<SQLite> {

	/**
	 * Opens (creating if needed) {@code dbvalue/dbName} and registers it as {@code dbName}.
	 *
	 * @param dbvalue the data folder, a {@link File} (null: the current directory); host, port, user and password are unused
	 */
	@Override
	public SQLite initDB(String host, int port, String dbName, String user, String password, Object dbvalue) {
		if (dbvalue != null && !(dbvalue instanceof File)) {
			throw new IllegalArgumentException("SQLite needs the data folder (a java.io.File) as dbvalue");
		}
		File folder = dbvalue == null ? new File(".") : (File) dbvalue;
		return register(dbName, new SQLite(folder, dbName));
	}

	/** Registers an already created connector. @throws DatabaseException if it cannot connect */
	public void registerConnection(String name, SQLite db) throws DatabaseException {
		registerDatabase(name, db);
	}
}
