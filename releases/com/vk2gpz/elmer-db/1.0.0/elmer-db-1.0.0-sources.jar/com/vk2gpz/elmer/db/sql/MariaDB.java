/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.db.sql;

/** MariaDB server: {@code jdbc:mariadb://host:port/dbName}. Needs the MariaDB Connector/J driver. */
public class MariaDB extends MySQL {

	/** @param credentials {@code {user, password}} */
	public MariaDB(String host, int port, String dbName, String[] credentials) {
		super(host, port, dbName, credentials);
	}

	@Override
	protected String jdbcUrl() {
		return "jdbc:mariadb://" + host + ":" + port + "/" + dbName;
	}

	@Override
	protected String[] driverClassNames() {
		return new String[]{"org.mariadb.jdbc.Driver"};
	}
}
