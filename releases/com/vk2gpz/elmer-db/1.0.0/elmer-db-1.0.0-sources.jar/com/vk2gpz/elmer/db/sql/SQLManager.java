/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.db.sql;

/**
 * Connections to MySQL servers. ({@link MariaDB} is a {@link MySQL}, so it can be registered here too
 * with {@link #registerConnection}.)
 */
public class SQLManager extends JdbcManager<MySQL> {

	/** Connects to MySQL at {@code host:port} and registers it as {@code dbName}. {@code dbvalue} is unused. */
	@Override
	public MySQL initDB(String host, int port, String dbName, String user, String password, Object dbvalue) {
		return register(dbName, new MySQL(host, port, dbName, new String[]{user, password}));
	}

	/** Registers an already created connector, e.g. a {@link MariaDB}; failures are logged. */
	public MySQL registerConnection(String name, MySQL db) {
		return register(name, db);
	}
}
