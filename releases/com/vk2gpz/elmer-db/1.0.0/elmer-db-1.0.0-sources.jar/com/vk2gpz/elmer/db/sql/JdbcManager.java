/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.db.sql;

import com.vk2gpz.elmer.db.DatabaseManager;
import org.jetbrains.annotations.Nullable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Shared code of {@link SQLManager} and {@link SQLiteManager}. Every method that hands out a statement first
 * checks the connection and reconnects if it has gone stale. Errors are logged and give {@code null}/{@code false}.
 */
public abstract class JdbcManager<D extends JdbcConnector> extends DatabaseManager<Connection, D> {
	private static final int VALIDATION_TIMEOUT_SECONDS = 1;

	@Override
	protected boolean isAlive(Connection connection) {
		try {
			return !connection.isClosed() && connection.isValid(VALIDATION_TIMEOUT_SECONDS);
		} catch (SQLException e) {
			return false;
		}
	}

	@Override
	protected void close(Connection connection) throws SQLException {
		connection.close();
	}

	/** @return a new statement on {@code name}'s connection (close it after use), or null. */
	@Nullable
	public Statement getStatement(String name) {
		Connection c = getActiveConnection(name);
		if (c == null) {
			return null;
		}
		try {
			return c.createStatement();
		} catch (SQLException e) {
			LOGGER.severe("Cannot create a statement for '" + name + "': " + e.getMessage());
			return null;
		}
	}

	/** @return a new prepared statement for {@code sql} (close it after use), or null. */
	@Nullable
	public PreparedStatement getPreparedStatement(String name, String sql) {
		Connection c = getActiveConnection(name);
		if (c == null) {
			return null;
		}
		try {
			return c.prepareStatement(sql);
		} catch (SQLException e) {
			LOGGER.severe("Cannot prepare a statement for '" + name + "': " + e.getMessage());
			return null;
		}
	}

	/** Same as {@link #getPreparedStatement(String, String)} with a result set type and concurrency. */
	@Nullable
	public PreparedStatement getPreparedStatement(String name, String sql, int resultSetType, int resultSetConcurrency) {
		Connection c = getActiveConnection(name);
		if (c == null) {
			return null;
		}
		try {
			return c.prepareStatement(sql, resultSetType, resultSetConcurrency);
		} catch (SQLException e) {
			LOGGER.severe("Cannot prepare a statement for '" + name + "': " + e.getMessage());
			return null;
		}
	}

	/** Runs {@code CREATE TABLE IF NOT EXISTS tableName (columns) extra}. */
	public boolean createTable(String name, String tableName, String columns, String extra) {
		return createTable(name, "CREATE TABLE IF NOT EXISTS " + tableName + " (" + columns + ")"
				+ (extra == null || extra.trim().isEmpty() ? "" : " " + extra));
	}

	/** Runs a complete {@code CREATE TABLE ...} statement. @return true on success. */
	public boolean createTable(String name, String sql) {
		if (sql == null || sql.trim().isEmpty()) {
			return false;
		}
		try (Statement s = getStatement(name)) {
			if (s == null) {
				return false;
			}
			s.executeUpdate(sql);
			return true;
		} catch (SQLException e) {
			LOGGER.severe("Cannot create table in '" + name + "': " + e.getMessage());
			return false;
		}
	}
}
