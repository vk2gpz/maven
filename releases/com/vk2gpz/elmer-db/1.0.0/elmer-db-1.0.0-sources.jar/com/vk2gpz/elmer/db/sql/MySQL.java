/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.db.sql;

/** MySQL server: {@code jdbc:mysql://host:port/dbName}. Needs a MySQL Connector/J driver on the classpath. */
public class MySQL extends JdbcConnector {

	/** @param credentials {@code {user, password}} */
	public MySQL(String host, int port, String dbName, String[] credentials) {
		super(host, port, dbName, credentials);
	}

	@Override
	protected String jdbcUrl() {
		return "jdbc:mysql://" + host + ":" + port + "/" + dbName;
	}

	@Override
	protected String[] driverClassNames() {
		return new String[]{"com.mysql.cj.jdbc.Driver", "com.mysql.jdbc.Driver"};  // Connector/J 8+, then 5.x
	}
}
