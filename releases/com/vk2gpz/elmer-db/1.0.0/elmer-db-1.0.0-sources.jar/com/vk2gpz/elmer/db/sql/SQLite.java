/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.db.sql;

import com.vk2gpz.elmer.db.DatabaseException;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.Connection;

/** SQLite database file {@code dataFolder/fileName}. The folder and file are created if missing. */
public class SQLite extends JdbcConnector {
	protected final File dbFile;

	/**
	 * @param dataFolder folder that holds the database file (e.g. a plugin's data folder)
	 * @param fileName   file name, e.g. {@code "players.db"}; it is also the database name
	 */
	public SQLite(File dataFolder, String fileName) {
		super(null, 0, fileName, null);
		this.dbFile = new File(dataFolder, fileName);
	}

	public File getFile() {
		return dbFile;
	}

	@Override
	protected String jdbcUrl() {
		return "jdbc:sqlite:" + dbFile.getAbsolutePath();
	}

	@Override
	protected String[] driverClassNames() {
		return new String[]{"org.sqlite.JDBC"};
	}

	@Override
	public Connection connect() throws ClassNotFoundException, DatabaseException {
		try {
			Files.createDirectories(dbFile.getAbsoluteFile().getParentFile().toPath());
		} catch (IOException e) {
			throw new DatabaseException("Cannot create the folder for " + dbFile + ": " + e.getMessage(), e);
		}
		return super.connect();   // SQLite creates the file itself
	}
}
