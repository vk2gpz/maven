/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.db.sql;

import com.vk2gpz.elmer.logging.ColorConsoleLogger;
import org.jetbrains.annotations.Nullable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 * Small helpers for running SQL on one {@link Statement}.
 * <p>
 * The {@code queryXxx(sql)} methods read the first column of the first row; {@code queryXxx(sql, column)} read the
 * named column. When the query returns no row, or fails (the error is logged), they return {@code null},
 * {@code -1} or {@code false}. {@link #tableContains} passes the values as parameters, so they are safe to take
 * from users; table and column names must be plain identifiers.
 */
public class SQLQuery {
	private static final Logger LOGGER = ColorConsoleLogger.getLogger("elmer.db");
	private static final Pattern IDENTIFIER = Pattern.compile("[A-Za-z_][A-Za-z0-9_]*(\\.[A-Za-z_][A-Za-z0-9_]*)?");

	private final Statement statement;

	public SQLQuery(Statement statement) {
		this.statement = statement;
	}

	/** @return true for 1 (how booleans are often stored in SQL). */
	public boolean intToBoolean(int num) {
		return num == 1;
	}

	public int booleanToInt(boolean bool) {
		return bool ? 1 : 0;
	}

	/** Runs {@code CREATE TABLE IF NOT EXISTS tableName (columns) extra}. */
	public boolean createTable(String tableName, String columns, String extra) {
		String sql = "CREATE TABLE IF NOT EXISTS " + tableName + " (" + columns + ")"
				+ (extra == null || extra.trim().isEmpty() ? "" : " " + extra);
		return update(sql) >= 0;
	}

	/** @return the result set (the caller closes it), or null on error. */
	@Nullable
	public ResultSet query(String sql) {
		if (statement == null) {
			return null;
		}
		try {
			return statement.executeQuery(sql);
		} catch (SQLException e) {
			LOGGER.severe("Query failed: " + e.getMessage() + " [" + sql + "]");
			return null;
		}
	}

	/** @return the number of changed rows, or -1 on error. */
	public int update(String sql) {
		if (statement == null) {
			return -1;
		}
		try {
			return statement.executeUpdate(sql);
		} catch (SQLException e) {
			LOGGER.severe("Update failed: " + e.getMessage() + " [" + sql + "]");
			return -1;
		}
	}

	@FunctionalInterface
	private interface Reader<T> {
		T read(ResultSet rs) throws SQLException;
	}

	private <T> T firstRow(String sql, Reader<T> reader, T none) {
		try (ResultSet rs = query(sql)) {
			return rs != null && rs.next() ? reader.read(rs) : none;
		} catch (SQLException e) {
			LOGGER.severe("Query failed: " + e.getMessage() + " [" + sql + "]");
			return none;
		}
	}

	public String queryString(String sql) {
		return firstRow(sql, rs -> rs.getString(1), null);
	}

	public String queryString(String sql, String column) {
		return firstRow(sql, rs -> rs.getString(column), null);
	}

	public int queryInt(String sql) {
		return firstRow(sql, rs -> rs.getInt(1), -1);
	}

	public int queryInt(String sql, String column) {
		return firstRow(sql, rs -> rs.getInt(column), -1);
	}

	public long queryLong(String sql) {
		return firstRow(sql, rs -> rs.getLong(1), -1L);
	}

	public long queryLong(String sql, String column) {
		return firstRow(sql, rs -> rs.getLong(column), -1L);
	}

	public float queryFloat(String sql) {
		return firstRow(sql, rs -> rs.getFloat(1), -1F);
	}

	public float queryFloat(String sql, String column) {
		return firstRow(sql, rs -> rs.getFloat(column), -1F);
	}

	public boolean queryBoolean(String sql) {
		return firstRow(sql, rs -> rs.getBoolean(1), false);
	}

	public boolean queryBoolean(String sql, String column) {
		return firstRow(sql, rs -> rs.getBoolean(column), false);
	}

	/** @return {@code column} of every row (empty on error). */
	public List<String> queryStringList(String sql, String column) {
		List<String> values = new ArrayList<>();
		try (ResultSet rs = query(sql)) {
			while (rs != null && rs.next()) {
				values.add(rs.getString(column));
			}
		} catch (SQLException e) {
			LOGGER.severe("Query failed: " + e.getMessage() + " [" + sql + "]");
		}
		return values;
	}

	/** @return the number of rows in {@code table}, or -1 on error. */
	public int getRowsInTable(String table) {
		return queryInt("SELECT COUNT(*) FROM " + identifier(table));
	}

	public boolean tableContains(String table, String column, String value) {
		return tableContainsAll(table, column, value);
	}

	public boolean tableContains(String table, String column1, String value1, String column2, String value2) {
		return tableContainsAll(table, column1, value1, column2, value2);
	}

	public boolean tableContains(String table, String column1, String value1, String column2, String value2,
	                             String column3, String value3) {
		return tableContainsAll(table, column1, value1, column2, value2, column3, value3);
	}

	/**
	 * @param columnValuePairs column, value, column, value, …
	 * @return true if some row has all the given column values
	 */
	public boolean tableContainsAll(String table, String... columnValuePairs) {
		if (columnValuePairs.length == 0 || columnValuePairs.length % 2 != 0) {
			throw new IllegalArgumentException("expected column/value pairs");
		}
		StringBuilder sql = new StringBuilder("SELECT 1 FROM ").append(identifier(table)).append(" WHERE ");
		for (int i = 0; i < columnValuePairs.length; i += 2) {
			if (i > 0) sql.append(" AND ");
			sql.append(identifier(columnValuePairs[i])).append(" = ?");
		}
		sql.append(" LIMIT 1");
		if (statement == null) {
			return false;
		}
		try {
			Connection connection = statement.getConnection();
			try (PreparedStatement ps = connection.prepareStatement(sql.toString())) {
				for (int i = 1; i < columnValuePairs.length; i += 2) {
					ps.setString(i / 2 + 1, columnValuePairs[i]);
				}
				try (ResultSet rs = ps.executeQuery()) {
					return rs.next();
				}
			}
		} catch (SQLException e) {
			LOGGER.severe("Query failed: " + e.getMessage() + " [" + sql + "]");
			return false;
		}
	}

	private static String identifier(String name) {
		if (name == null || !IDENTIFIER.matcher(name).matches()) {
			throw new IllegalArgumentException("not a plain table/column name: " + name);
		}
		return name;
	}
}
