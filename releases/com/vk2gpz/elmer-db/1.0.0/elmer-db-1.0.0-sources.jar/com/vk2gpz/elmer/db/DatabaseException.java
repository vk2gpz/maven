/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.db;

/** A database could not be reached or used. */
public class DatabaseException extends Exception {
	public DatabaseException(String message, Exception cause) {
		super(message, cause);
	}
}
