/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.db;

import com.vk2gpz.elmer.logging.ColorConsoleLogger;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Keeps one open connection per named database and reopens it when it has gone stale.
 * Subclasses say how to create a connector ({@link #initDB}), how to test a connection ({@link #isAlive})
 * and how to close one ({@link #close}).
 *
 * @param <C> connection type
 * @param <D> connector type
 */
public abstract class DatabaseManager<C, D extends DatabaseConnector<C>> {
	protected static final Logger LOGGER = ColorConsoleLogger.getLogger("elmer.db");

	/** Connectors by name. */
	protected final Map<String, D> dbs = new ConcurrentHashMap<>();
	/** Open connections by name. */
	protected final Map<String, C> dbConnection = new ConcurrentHashMap<>();

	/**
	 * Creates the connector for {@code dbName}, connects and registers it under that name. Failures are logged;
	 * the connector is returned either way, and {@link #getConnection} returns null until a reconnect succeeds.
	 *
	 * @param dbvalue extra, type-specific setting (the data folder {@link java.io.File} for SQLite; otherwise unused)
	 */
	public abstract D initDB(String host, int port, String dbName, String user, String password, Object dbvalue);

	/** @return true if {@code connection} can still be used. */
	protected abstract boolean isAlive(C connection);

	/** Closes {@code connection}; may throw anything, which is logged. */
	protected abstract void close(C connection) throws Exception;

	/** Connects {@code db} and registers it under {@code name}. */
	protected void registerDatabase(String name, D db) throws DatabaseException {
		final C connection;
		try {
			connection = db.connect();
		} catch (Exception e) {
			throw new DatabaseException("Cannot connect to database '" + name + "': " + e.getMessage(), e);
		}
		dbs.put(name, db);
		C old = dbConnection.put(name, connection);
		if (old != null && old != connection) {
			closeQuietly(name, old);
		}
	}

	/** Like {@link #registerDatabase}, but logs a failure instead of throwing, and returns {@code db}. */
	protected D register(String name, D db) {
		try {
			registerDatabase(name, db);
		} catch (DatabaseException e) {
			LOGGER.severe(e.getMessage());
			dbs.put(name, db);   // keep the connector so reconnect() can try again later
		}
		return db;
	}

	@Nullable
	public D getDatabase(String name) {
		return dbs.get(name);
	}

	/** @return the current connection, without checking it; null if there is none. */
	@Nullable
	public C getConnection(String name) {
		return dbConnection.get(name);
	}

	/** @return the names of all registered databases. */
	public Set<String> getDatabaseNames() {
		return Collections.unmodifiableSet(new HashSet<>(dbs.keySet()));
	}

	/** Reconnects {@code name} if it has no connection or the connection is no longer usable. */
	public void checkConnection(String name) {
		C connection = dbConnection.get(name);
		boolean alive;
		try {
			alive = connection != null && isAlive(connection);
		} catch (RuntimeException e) {
			alive = false;
		}
		if (!alive) {
			reconnect(name);
		}
	}

	/** Closes the current connection of {@code name} (if any) and opens a new one. */
	public void reconnect(String name) {
		D db = dbs.get(name);
		if (db == null) {
			return;
		}
		shutdown(name);
		try {
			registerDatabase(name, db);
		} catch (DatabaseException e) {
			LOGGER.severe("Reconnect failed: " + e.getMessage());
		}
	}

	/** Closes the connection of {@code name}. The connector stays registered, so it can be reconnected. */
	public void shutdown(String name) {
		C connection = dbConnection.remove(name);
		if (connection != null) {
			closeQuietly(name, connection);
		}
	}

	/** Closes every connection. */
	public void shutdownAll() {
		for (String name : new ArrayList<>(dbConnection.keySet())) {
			shutdown(name);
		}
	}

	/** {@link #checkConnection} followed by {@link #getConnection}. */
	@Nullable
	protected C getActiveConnection(String name) {
		checkConnection(name);
		return dbConnection.get(name);
	}

	private void closeQuietly(String name, C connection) {
		try {
			close(connection);
		} catch (Exception e) {
			LOGGER.warning("Cannot close database '" + name + "': " + e.getMessage());
		}
	}
}
