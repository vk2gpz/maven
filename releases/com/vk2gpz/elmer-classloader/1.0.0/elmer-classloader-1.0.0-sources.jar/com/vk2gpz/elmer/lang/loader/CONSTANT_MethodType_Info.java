/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */

import java.io.DataInput;
import java.io.IOException;

/*====================================================================
              Implementation of class CONSTANT_MethodType_Info
====================================================================*/

/**
 * CONSTANT_MethodType_Info represents CONSTANT_MethodType_info
 * structure defined in VM Spec $4.4.9
 *
 * @version $Revision: 99 $
 * @author vk2gpz@gmail.com
 * @see CP_Info
 */

@SuppressWarnings("unused")
final class CONSTANT_MethodType_Info extends CP_Info {
	short descriptorIndex;

	/**
	 * Constructs a new CONSTANT_MethodType_Info object
	 */
	CONSTANT_MethodType_Info(DataInput datainput) throws IOException {
		super(ConstantPoolAnalyzer.CONSTANT_MethodType);
		this.descriptorIndex = datainput.readShort();
	}

	public String toString() {
		return super.toString() + ", _descriptor_index = " + this.descriptorIndex + "]";
	}
}
