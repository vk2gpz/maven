/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
              Implementation of class CustomClassLoader               
====================================================================*/
/**
 * This interface defines methods to find and load a bytecode of the specified
 * class.
 * 
 * @version $Revision: 99 $
 * @author vk2gpz@gmail.com
 */

public interface CustomClassLoader {
    Class<?> getClass(String s) throws ClassNotFoundException;
}
