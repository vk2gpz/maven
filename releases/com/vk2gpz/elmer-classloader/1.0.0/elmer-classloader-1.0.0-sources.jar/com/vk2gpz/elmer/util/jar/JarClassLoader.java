/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.util.jar;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;
import java.net.*;
import java.security.*;
import java.util.*;
import java.util.jar.Attributes.Name;

import com.vk2gpz.elmer.debug.DebugHandler;
import com.vk2gpz.elmer.net.CustomURLClassLoader;


/*====================================================================
                Implementation of class JarClassLoader                
====================================================================*/
/**
 * JarClassLoader loads classes from jar files using URLClassLoader.
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see URLClassLoader
 */

@SuppressWarnings("unused")
public class JarClassLoader extends CustomURLClassLoader {
	/**
	 * debug flag
	 */
	private static final boolean DEBUG = DebugHandler.isDebugged(JarClassLoader.class);

    public static final Name JAVA_BEAN = new Name("Java-Bean");
    public static final Name NAME = new Name("Name");

    private static JarClassLoader sLoader = null;

	/** */
	private PermissionCollection permissionCollection = null;

	private static final URL[] sDefaultURLs = new URL[] {};
// 	static {
// 		try {
// 			MtBeanClassLoader bcl = MtBeanClassLoader.getBeanClassLoader();
// 			sDefaultURLs = bcl.getClassPath();
// 		} catch (Exception e) {
// 			sDefaultURLs = new URL[] {};
// 		}
// 	}

// 	/**
// 	* This is a special null constructor for JBeans.
// 	* 
// 	* vk2gpz (vk2gpz@gmail.com)/2002-Sep-02
// 	*/
//     private JarClassLoader()  {
//         this(sDefaultURLs, MtBeanClassLoader.getBeanClassLoader());
//     }

    /**
	 * Creates a new JarClassLoader with the specified URL.
	 *
	 * @param url The URL of the jar file i.e. <a href="http://foo.foo1.foo2/jarfile.jar">...</a>
	 *            or file:c:\foo\foo1\foo2\jarfile.jar
	 */
    public JarClassLoader(URL url) {
        this(new URL[] { url }, null);
    }

	public JarClassLoader(URL url, ClassLoader parent) {
		this(new URL[] { url }, parent);
	}

	public JarClassLoader(URL[] urls, ClassLoader parent) {
		super(urls, parent);
	}

	public void setPermissionCollection(PermissionCollection permissionCollection) {
		this.permissionCollection = permissionCollection;
	}

    /**
	 * Adds the jar file with the specified URL to the class loader.
	 * URL can be a local or network resource.
	 *
	 * @param url The URL of the jar file i.e. <a href="http://foo.foo1.foo2/jarfile.jar">...</a>
	 *            or file:c:\foo\foo1\foo2\jarfile.jar
	 */
    public void addJarFile(URL url)  {
        addURL(url);
    }

    /** 
     * Adds a jar file from the specified filename to the jar loader list.
     * 
     * @param jarfile The full path to the jar file.
     */
    public void addJarFile(String jarfile)  {
        try {
            URL url = new URL("file:" + jarfile);
            addURL(url);
        } catch (IOException ex) {
			System.err.println("JarClassLoader.addJarFile() : invalid URL: " + jarfile);
        }
    }
    
    /** 
     * Returns the shared instance of the class loader.
     */
    public static JarClassLoader getJarClassLoader()  {
        return sLoader;
    }
    
    /** 
     * Sets the static instance of the class loader.
     */
    public static void setJarClassLoader(JarClassLoader cl)  {
        sLoader = cl;
    }

	private void addPermissionCollection(PermissionCollection permissioncollection, Enumeration<?> permissions) {
		while (permissions.hasMoreElements()) {
			permissioncollection.add((Permission) permissions.nextElement());
		}
	}
	
    protected PermissionCollection getPermissions(CodeSource codesource) {
        PermissionCollection permissioncollection = super.getPermissions(codesource);
		if (this.permissionCollection != null) {
			addPermissionCollection(permissioncollection,
									this.permissionCollection.elements());
		}
		
		return permissioncollection;
    }
}
