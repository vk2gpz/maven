/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.util.jar;

import com.vk2gpz.elmer.debug.DebugHandler;
import com.vk2gpz.elmer.debug.DebugLabel;
import com.vk2gpz.elmer.lang.ClassNameFilter;
import com.vk2gpz.elmer.lang.loader.*;
import com.vk2gpz.elmer.logging.ColorConsoleLogger;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarInputStream;
import java.util.jar.JarOutputStream;
import java.util.zip.ZipEntry;

@SuppressWarnings("unused")
public class JarUtil {
	static final String MANIFEST = "META-INF/MANIFEST.MF";
	static final char SEPARATOR = File.separatorChar;

	private File jarName;    // the name of the JarFile
	private File dirName;    // the name of the base directory
	private String beanName;    // the beanFileName
	private String[] fileNames;    // all file names

	private JarUtil() {
		super();
	}

	private static boolean contains(String name, String... list) {
		if (list.length <= 5) {
			// For small lists, linear search is faster than HashSet overhead
			for (String s : list) {
				if (name.equals(s))
					return true;
			}
		} else {
			// For larger lists, convert to HashSet for O(1) lookups
			Set<String> set = new HashSet<>(Arrays.asList(list));
			return set.contains(name);
		}
		return false;
	}

	public static void removeFilesFromJarFile(File srcJarFile, String targetPackage, String... filesToRemove) throws IOException {
		File tmpJarFile = File.createTempFile("tempJar", ".tmp");
		JarFile jarFile = new JarFile(srcJarFile);
		boolean jarUpdated = false;

		try {
			JarOutputStream tempJarOutputStream = new JarOutputStream(Files.newOutputStream(tmpJarFile.toPath()));
			try {

				//Copy original jar file to the temporary one.
				Enumeration<JarEntry> jarEntries = jarFile.entries();
				while (jarEntries.hasMoreElements()) {
					JarEntry entry = jarEntries.nextElement();
					if (contains(entry.getName(), filesToRemove))
						continue;
					InputStream entryInputStream = jarFile.getInputStream(entry);
					tempJarOutputStream.putNextEntry(entry);
					byte[] buffer = new byte[1024];
					int bytesRead;
					while ((bytesRead = entryInputStream.read(buffer)) != -1) {
						tempJarOutputStream.write(buffer, 0, bytesRead);
					}
				}

				jarUpdated = true;
			} catch (Exception ex) {
				ex.printStackTrace();
				tempJarOutputStream.putNextEntry(new JarEntry("stub"));
			} finally {
				tempJarOutputStream.close();
			}

		} finally {
			jarFile.close();
			//DebugHandler.getLogger("elmer").info(srcJarFile.getAbsolutePath() + " closed.");

			if (!jarUpdated) {
				//noinspection ResultOfMethodCallIgnored
				tmpJarFile.delete();
			}
		}

		if (jarUpdated) {
			//noinspection ResultOfMethodCallIgnored
			srcJarFile.delete();
			//noinspection ResultOfMethodCallIgnored
			tmpJarFile.renameTo(srcJarFile);
		}
	}

	static public String extractResourceFromJar(Class<?> klass, String fileName) throws Exception {
		InputStream stream = null;
		OutputStream resStreamOut = null;
		String jarFolder;

		try {
			stream = klass.getResourceAsStream(fileName);
			if (stream == null) {
				throw new FileNotFoundException("Cannot get resource \"" + fileName + "\" from Jar file.");
			}

			int readBytes;
			byte[] buffer = new byte[4096];
			jarFolder = new File(klass.getProtectionDomain().getCodeSource().getLocation().toURI().getPath()).getParentFile().getPath().replace('\\', '/');
			resStreamOut = Files.newOutputStream(Paths.get(jarFolder + fileName));
			while ((readBytes = stream.read(buffer)) > 0) {
				resStreamOut.write(buffer, 0, readBytes);
			}
		} finally {
			if (stream != null)
				stream.close();
			if (resStreamOut != null)
				resStreamOut.close();
		}

		return jarFolder + fileName;
	}

	static public String extractResourceFromJar(Class<?> klass, String fileName, String outputFileName) throws Exception {
		InputStream stream = null;
		OutputStream resStreamOut = null;
		String jarFolder;

		try {
			stream = klass.getResourceAsStream(fileName);
			if (stream == null) {
				throw new FileNotFoundException("Cannot get resource \"" + fileName + "\" from Jar file.");
			}

			int readBytes;
			byte[] buffer = new byte[4096];
			jarFolder = new File(klass.getProtectionDomain().getCodeSource().getLocation().toURI().getPath()).getParentFile().getPath().replace('\\', '/');
			resStreamOut = Files.newOutputStream(Paths.get(jarFolder + outputFileName));
			while ((readBytes = stream.read(buffer)) > 0) {
				resStreamOut.write(buffer, 0, readBytes);
			}
		} finally {
			if (stream != null)
				stream.close();
			if (resStreamOut != null)
				resStreamOut.close();
		}

		return jarFolder + fileName;
	}

	/**
	 * Create a new JAR file;
	 * Given a base directory, a beanfilename, and a set of files names,
	 * these two relative to the base directory
	 * <p>
	 * if baseDir is null, it means WD
	 * if beanFile is null, it means generate no MANIFEST
	 * <p>
	 * Generates a *non-signed* MANIFEST
	 */
	public static void create(OutputStream out, File baseDir, String beanFile, String[] files) throws IOException {
		int start = 0;
		if (beanFile != null) {
			start = 1;
		}
		JarEntrySource[] data = new JarEntrySource[files.length + start];
		if (beanFile != null) {
			data[0] = makeManifestEntry(beanFile, false);
		}
		for (int i = 0; i < files.length; i++) {
			data[i + start] = new JarEntrySource(entryName(files[i]),
					new File(baseDir, files[i]));
		}
		create(out, data);
	}

	/**
	 * Create a new JAR file;
	 * Given a base directory, a beanfilename, and a set of files names,
	 * these two relative to the base directory
	 * <p>
	 * if baseDir is null, it means WD
	 * if beanFile is null, it means generate no MANIFEST
	 * <p>
	 * Generates a *non-signed* MANIFEST
	 */
	@DebugLabel(key = "JarUtil_create")
	public static void create(OutputStream out, File baseDir, String[] files) throws IOException {
		boolean debug = DebugHandler.isDebugged("JarUtil_create");
		JarEntrySource[] data = new JarEntrySource[files.length];
		for (int i = 0; i < files.length; i++) {
			File f = new File(baseDir, files[i]);
			if (debug) {
				DebugHandler.getLogger("elmer").info("JarUtil (create) : f = " + f);
			}
			data[i] = new JarEntrySource(entryName(files[i]), f);
		}
		create(out, data);
	}

	/**
	 * Create a new JAR file;
	 * Given a base directory, a beanfilename, and a set of files names,
	 * these two relative to the base directory
	 * <p>
	 * if baseDir is null, it means WD
	 * if beanFile is null, it means generate no MANIFEST
	 * <p>
	 * Generates a *non-signed* MANIFEST
	 */
	public static void create(OutputStream out, String classpath, Class<?>[] classes) throws IOException {
		try {
			CustomClassFileLoader cfl = new JBeansClassFileLoader(classpath);
			JarEntrySource[] data = new JarEntrySource[classes.length];
			for (int i = 0; i < classes.length; i++) {
				String classname = classes[i].getName().replace('.', '/') + ".class";
				data[i] = new JarEntrySource(entryName(classname),
						cfl.getClass(classes[i].getName()));
			}
			create(out, data);
		} catch (ClassNotFoundException ex) {
			throw new IOException(ex.getMessage());
		}
	}

	/**
	 * Create a new JAR file;
	 * Given a base directory, a beanfilename, and a set of files names,
	 * these two relative to the base directory
	 * <p>
	 * if baseDir is null, it means WD
	 * if beanFile is null, it means generate no MANIFEST
	 * <p>
	 * Generates a *non-signed* MANIFEST
	 */
	public static void create(OutputStream out, File baseDir, String classpath, Class<?> clazz, String[] miscFiles, ClassNameFilter[] filters) throws IOException {
		create(out, baseDir, classpath, clazz, null, miscFiles, filters);
	}

	/**
	 * Create a new JAR file;
	 * Given a base directory, a beanfilename, and a set of files names,
	 * these two relative to the base directory
	 * <p>
	 * if baseDir is null, it means WD
	 * if beanFile is null, it means generate no MANIFEST
	 * <p>
	 * Generates a *non-signed* MANIFEST
	 */
	public static void create(OutputStream out, File baseDir, String classpath, Class<?> clazz, Class<?> beanInfo, String[] miscFiles, ClassNameFilter[] filters) throws IOException {
		create(out, baseDir, classpath, clazz, beanInfo, miscFiles, filters, false);
	}

	/**
	 * Create a new JAR file;
	 * Given a base directory, a beanfilename, and a set of files names,
	 * these two relative to the base directory
	 * <p>
	 * if baseDir is null, it means WD
	 * if beanFile is null, it means generate no MANIFEST
	 * <p>
	 * Generates a *non-signed* MANIFEST
	 */
	public static void create(OutputStream out, File baseDir, String classpath, Class<?> clazz, Class<?> beanInfo, String[] miscFiles, ClassNameFilter[] filters, boolean application) throws IOException {
		boolean debug = DebugHandler.isDebugged("JarUtil_create");
		if (clazz == null) {
			return;
		}
		try {
			CustomClassFileLoader cfl = new JBeansClassFileLoader(classpath);
			ClassDependency depend = new ClassDependency(clazz, filters);
			depend.setClassPath(classpath);
			// create a list
			depend.analyzeClass();

			// go through class list.
			Collection<?> classes = depend.getDependentClasses();
			Collection<?> resources = depend.getDependentResourceFiles();

			JarEntrySource[] data = new JarEntrySource[classes.size() +
					resources.size() +
					miscFiles.length +
					((beanInfo != null)
							? 2 : 1)];
			if (debug) {
				DebugHandler.getLogger("elmer").info("classes.size() = " + classes.size());
				DebugHandler.getLogger("elmer").info("resources.size() = " + resources.size());
				DebugHandler.getLogger("elmer").info("miscFiles.size() = " + miscFiles.length);
				DebugHandler.getLogger("elmer").info("beanInfo = " + ((beanInfo != null) ? 2 : 1));
			}

			int count = 0;
			data[count++] = makeManifestEntry(clazz.getName(), application);
			// if beaninfo is there include beaninfo...
			if (beanInfo != null) {
				String beaninfoname = beanInfo.getName().replace('.', '/') + ".class";
				data[count++] = new JarEntrySource(entryName(beaninfoname),
						cfl.getClass(beanInfo.getName()));
			}
			for (Object aClass : classes) {
				Class<?> c = (Class<?>) aClass;
				String classname = c.getName().replace('.', '/') + ".class";
				data[count++] = new JarEntrySource(entryName(classname), cfl.getClass(c.getName()));
			}

			// go through resource file list.
			HashMap<String, URL> map = depend.getResourceMap();
			for (Object resource : resources) {
				String filename = (String) resource;
				if (debug) {
					DebugHandler.getLogger("elmer").info("resource = " + filename);
				}
				URL url = map.get(filename);
				data[count++] = new JarEntrySource(entryName(filename), url.openStream());
			}

			for (String miscFile : miscFiles) {
				data[count++] = new JarEntrySource(entryName(miscFile),
						new File(baseDir, miscFile));
			}
			create(out, data);
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
			throw new IOException(ex.getMessage());
		}
	}

	/**
	 * Create a list of jar entry;
	 * Given a base directory, a beanfilename, and a set of files names,
	 * these two relative to the base directory
	 * <p>
	 * if baseDir is null, it means WD
	 * if beanFile is null, it means generate no MANIFEST
	 * <p>
	 * Generates a *non-signed* MANIFEST
	 */
	public static Map<String, JarEntrySource> createJarEntry(File baseDir, String classpath, Class<?> clazz, Class<?> beanInfo, String[] miscFiles, ClassNameFilter[] filters, boolean application, Map<String, JarEntrySource> destMap) throws IOException {
		boolean debug = DebugHandler.isDebugged("JarUtil_createJarEntry");
		if (destMap == null) {
			destMap = Collections.synchronizedMap(new HashMap<>());
		}

		if (clazz == null) {
			return destMap;
		}

		try {
			CustomClassFileLoader cfl = new JBeansClassFileLoader(classpath);
			ClassDependency depend = new ClassDependency(clazz, filters);
			depend.setClassPath(classpath);
			// create a list
			depend.analyzeClass();

			// go through class list.
			Collection<?> classes = depend.getDependentClasses();
			Collection<?> resources = depend.getDependentResourceFiles();

			JarEntrySource es = makeManifestEntry(clazz.getName(), application);
			destMap.put(es.getName(), es);

			// if beaninfo is there include beaninfo...
			if (beanInfo != null) {
				String beaninfoname = beanInfo.getName().replace('.', '/') + ".class";

				es = new JarEntrySource(entryName(beaninfoname),
						cfl.getClass(beanInfo.getName()));
				destMap.put(es.getName(), es);
			}
			for (Object aClass : classes) {
				Class<?> c = (Class<?>) aClass;
				String classname = c.getName().replace('.', '/') + ".class";
				es = new JarEntrySource(entryName(classname), cfl.getClass(c.getName()));
				destMap.put(es.getName(), es);
			}

			// go through resource file list.
			HashMap<String, URL> map = depend.getResourceMap();
			for (Object resource : resources) {
				String filename = (String) resource;
				if (debug) {
					DebugHandler.getLogger("elmer").info("resource = " + filename);
				}
				URL url = map.get(filename);
				es = new JarEntrySource(entryName(filename), url.openStream());
				destMap.put(es.getName(), es);
			}

			for (String miscFile : miscFiles) {
				es = new JarEntrySource(entryName(miscFile),
						new File(baseDir, miscFile));
				destMap.put(es.getName(), es);
			}
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
			throw new IOException(ex.getMessage());
		}
		return destMap;
	}

	/**
	 * An InputStream with the data about the Manifest
	 */
	public static JarEntrySource makeManifestEntry(String beanName, boolean application) {
		String s = "Manifest-Version: 1.0\n" + "\n" +
				"Name: " + beanName + "\n" +
				"Java-Bean: True\n" +
				"\n";

		/*
		 * use ByteArrayInputStream instead of StringBufferInputStream
		 *                                 vk2gpz/2000-Jan-21
		 */
		return new JarEntrySource(MANIFEST,
				new ByteArrayInputStream(s.getBytes()));

	}

	/**
	 * Creates a new ZIP file with a bunch of files
	 */
	public static void create(OutputStream out,
	                          String[] files) throws IOException {
		Set<String> sDirs = new HashSet<>();
		JarOutputStream jos = new JarOutputStream(out);
		for (String file : files) {
			addEntry(jos, new JarEntrySource(new File(file)), sDirs);
		}
		jos.close();
	}

	/**
	 * Creates a new ZIP file with a bunch of entries
	 */
	public static void create(OutputStream out,
	                          JarEntrySource[] entries) throws IOException {
		Set<String> sDirs = new HashSet<>();
		JarOutputStream jos = new JarOutputStream(out);
		for (JarEntrySource entry : entries) {
			if (entry != null) {
				addEntry(jos, entry, sDirs);
			}
		}
		jos.close();
	}

	/**
	 * Creates a new jar file with a bunch of entries
	 */
	public static void create(OutputStream out,
	                          HashMap<?, ?> entries) throws IOException {
		Set<String> sDirs = new HashSet<>();
		JarOutputStream jos = new JarOutputStream(out);
		Object[] objects = entries.values().toArray();

		for (Object obj : objects) {
			if (obj instanceof JarEntrySource) {
				addEntry(jos, (JarEntrySource) obj, sDirs);
			}
		}
		jos.close();
	}

	private static String entryName(String name) {
		name = name.replace(File.separatorChar, '/');
		// Use direct character checks instead of startsWith() for performance
		if (!name.isEmpty()) {
			if (name.charAt(0) == '/') {
				name = name.substring(1);
			} else if (name.length() > 1 && name.charAt(0) == '.' && name.charAt(1) == '/') {
				name = name.substring(2);
			}
		}
		return name;
	}

	/*
	 * Adds a new file entry to the ZIP output stream.
	 */
	private static void addEntry(JarOutputStream jos,
	                             JarEntrySource source, Set<String> sDirs) throws IOException {
		String name = source.getName();
		if (name.isEmpty() || name.equals(".")) {
			return;
		}
		//	long size = source.getLength();
		int lastSlash = name.lastIndexOf("/");
		if (lastSlash != -1) {
			String dir = name.substring(0, lastSlash + 1);
			if (!sDirs.contains(dir)) {
				ZipEntry ze = new ZipEntry(dir);
				jos.putNextEntry(ze);
				jos.closeEntry();
				sDirs.add(dir);
			}
		}

		ZipEntry e = new ZipEntry(name);
		e.setTime(source.getTime());
		boolean markOnly = source.isMarkOnly();

		if (markOnly) {
			e.setMethod(ZipEntry.STORED);
			e.setSize(0);
			e.setCrc(0);
		}
		jos.putNextEntry(e);
		if (!markOnly) {
			byte[] buf = new byte[1024];
			int len;
			InputStream is = new BufferedInputStream(source.getInputStream());
			while ((len = is.read(buf, 0, buf.length)) != -1) {
				jos.write(buf, 0, len);
			}
			is.close();
		}
		jos.closeEntry();
	}

	/*
	 * Extracts specified entries from JAR file.
	 */
	private static void extract(InputStream in, String[] files) throws IOException {
		JarInputStream jis = new JarInputStream(in);
		Set<String> fileSet = (files != null) ? new HashSet<>(Arrays.asList(files)) : null;
		ZipEntry e;
		while ((e = jis.getNextEntry()) != null) {
			if (fileSet == null) {
				extractFile(jis, e);
			} else {
				String name = e.getName().replace('/', File.separatorChar);
				// Check if entry starts with any of the target files
				for (String file : fileSet) {
					if (name.startsWith(file)) {
						extractFile(jis, e);
						break;
					}
				}
			}
		}
	}

	/*
	 * Extracts next entry from JAR file, creating directories as needed.
	 */
	private static void extractFile(JarInputStream jis, ZipEntry e) throws IOException {
		String entryPath = e.getName().replace('/', File.separatorChar);
		File f = new File(entryPath);
		if (e.isDirectory()) {
			if (!f.exists() && !f.mkdirs()) {
				throw new IOException(f + ": could not create directory");
			}
		} else {
			File parentDir = f.getParentFile();
			if (parentDir != null && !parentDir.exists() && !parentDir.mkdirs()) {
				throw new IOException(parentDir + ": could not create directory");
			}
			OutputStream os = Files.newOutputStream(f.toPath());
			byte[] b = new byte[512];
			int len;
			while ((len = jis.read(b, 0, b.length)) != -1) {
				os.write(b, 0, len);
			}
			jis.closeEntry();
			os.close();
		}
	}

	/*
	 * Lists contents of JAR file.
	 */
	private static void list(InputStream in, String[] files) throws IOException {
		JarInputStream jis = new JarInputStream(in);
		Set<String> fileSet = (files != null) ? new HashSet<>(Arrays.asList(files)) : null;
		ZipEntry e;
		while ((e = jis.getNextEntry()) != null) {
			String name = e.getName().replace('/', File.separatorChar);
			/*
			 * In the case of a compressed (deflated) entry, the entry size
			 * is stored immediately following the entry data and cannot be
			 * determined until the entry is fully read. Therefore, we close
			 * the entry first before printing out its attributes.
			 */
			jis.closeEntry();
			if (fileSet == null) {
				printEntry(e);
			} else {
				for (String file : fileSet) {
					if (name.startsWith(file)) {
						printEntry(e);
						break;
					}
				}
			}
		}
	}

	/*
	 * Prints entry information.
	 */
	private static void printEntry(ZipEntry e) {
		DebugHandler.getLogger("elmer").info(e.getName());
	}

	public static JarFile findJarFile(String jarFilename) {
		URL url = ClassLoader.getSystemResource(jarFilename);
		if (url == null) {
			File file = new File(jarFilename);
			try {
				url = (file.exists()) ? file.toURI().toURL() : null;
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}
		JarFile jarFile = null;
		try {
			assert url != null;
			jarFile = new JarFile(url.getFile());
		} catch (IOException | NullPointerException e) {
			e.printStackTrace();
		}
		return jarFile;
	}

	/**
	 * Create a Jar from parsed argument data
	 */
	private void createJarFile() {
		try {
			OutputStream out = Files.newOutputStream(this.jarName.toPath());
			if ((this.beanName == null) && (this.dirName == null)) {
				create(out, this.fileNames);
			} else {
				create(out, this.dirName, this.beanName, this.fileNames);
			}
		} catch (Exception ex) {
			System.err.println("caught exception: " + ex);
			ex.printStackTrace();
			System.exit(1);
		}
	}

	/**
	 * Parse the arguments
	 */
	private boolean parseArgs(String[] args) {
		int l = args.length;
		int i;
		for (i = 0; i < l; i++) {
			if (args[i].equals("-bean")) {
				if (i + 1 >= l) {
					DebugHandler.getLogger("elmer").info("-bean option needs to be followed by an argument");
					return false;
				}
				this.beanName = args[i + 1];
				i += 1;
			} else if (args[i].equals("-dir")) {
				if (i + 1 >= l) {
					DebugHandler.getLogger("elmer").info("-dir option needs to be followed by an argument");
					return false;
				}
				this.dirName = new File(args[i + 1]);
				i += 1;
			} else {
				break;
			}
		}
		if (i + 1 >= l) {
			DebugHandler.getLogger("elmer").info("not enough arguments");
			return false;
		}
		this.jarName = new File(args[i]);
		i += 1;
		this.fileNames = new String[l - i];
		if (l - i >= 0)
			System.arraycopy(args, i, this.fileNames, 0, l - i);
		return true;
	}

	/* ----------------------------- main ----------------------------- */
	static final String USAGE = "Usage: java net.jbeans.util.jar.JarUtil [-bean BeanFileName] [-dir Directory] jarFileName files...\n" +
			"Options:\n" +
			"  -bean  BeanFileName is the FileName of a Bean to be tagged\n" +
			"  -dir   Directory is the directory from where to interpret file names\n" +
			"         so the manifest will have relative names\n";

	/**
	 * A command line interface.
	 * Usage is:
	 * jar [-bean BeanFileName] [-dir Directory] JarName fileNames...
	 */
	public static void main(String[] args) {
		if (args.length <= 1) {
			System.err.println("not enough arguments");
			DebugHandler.getLogger("elmer").info(USAGE);
			System.exit(1);
		}
		JarUtil tool = new JarUtil();
		if (!tool.parseArgs(args)) {
			DebugHandler.getLogger("elmer").info(USAGE);
			System.exit(1);
		}
		tool.createJarFile();
	}
}
