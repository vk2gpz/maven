/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

/*====================================================================
             Implementation of class CONSTANT_String_Info             
====================================================================*/
/**
 * CONSTANT_String_Info represents CONSTANT_String_info structure
 * defined in VM Spec $4.4.3
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see CP_Info
 */

final class CONSTANT_String_Info extends CP_Info {
	short stringIndex;
	
	/**
	 * Constructs a new CONSTANT_String_info object
	 */
	CONSTANT_String_Info(DataInput datainput) throws IOException {
		super(ConstantPoolAnalyzer.CONSTANT_String);
		this.stringIndex = datainput.readShort();
	}
	
	public String toString() {
		return super.toString() + ", _string_index = " + this.stringIndex + "]";
	}
}
