/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */

import java.io.*;

/*====================================================================
           Implementation of class JBeansResourceFileLoader           
====================================================================*/
/**
 * JBeansResourceFileLoader is a resource file loader used in JBeans.
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see CustomResourceFileLoader
 */

@SuppressWarnings("unused")
public final class JBeansResourceFileLoader implements CustomResourceFileLoader {
	private static final String sClassPathProperty = "java.class.path";
    @SuppressWarnings("FieldCanBeLocal")
	private final String classPath;

    public JBeansResourceFileLoader() {
        this(System.getProperties().getProperty(sClassPathProperty));
    }
	
    public JBeansResourceFileLoader(String s) {
        this.classPath = s;
    }
	
    public byte[] getResourceFileForClassAsByteCode(Class<?> clazz, String s) throws IOException {
        InputStream inputstream = getResourceFileAsStreamForClass(clazz, s);
        ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
        int i;
        while((i = inputstream.read()) != -1)
            bytearrayoutputstream.write(i);

        return bytearrayoutputstream.toByteArray();
    }

	public InputStream getResourceFileForClass(Class<?> clazz, String resource) throws IOException {
		return getResourceFileAsStreamForClass(clazz, resource);
	}

    private InputStream getResourceFileAsStreamForClass(Class<?> clazz, String s) throws IOException {
		if (clazz == null) {	// use system.class loader.
			clazz = getClass();
		}
        InputStream is = clazz.getResourceAsStream(s);
		if (is == null) {
			throw new FileNotFoundException(s);
		}
		return is;
    }

    public boolean isJar(File file) {
        return file.getName().endsWith(".jar");
    }

    public boolean isZip(File file) {
        return file.getName().endsWith(".zip");
    }

	/* ------------------------- test method -------------------------- */
}
