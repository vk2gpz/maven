/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

/*====================================================================
             Implementation of class CONSTANT_Class_Info              
====================================================================*/
/**
 * CONSTANT_Class_Info represents CONSTANT_Class_info structure
 * defined in VM Spec $4.4.1
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see CP_Info
 */

final class CONSTANT_Class_Info extends CP_Info {
	/*
	 * tag has the value CONSTANT_Class
	 */
	
	/**
	 * the value of the name_index item must be a valid index into
	 * the constant_pool table. 
	 */
	short nameIndex;

	/**
	* Constructs a new CONSTANT_Class_Info object.
	*/
	CONSTANT_Class_Info(DataInput datainput) throws IOException {
		super(ConstantPoolAnalyzer.CONSTANT_Class);
		this.nameIndex = datainput.readShort();
	}
	
	public String toString() {
		return super.toString() + ", _name_index = " + this.nameIndex + "]";
	}
}

