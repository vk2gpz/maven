/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.util.jar;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;
import java.util.*;
import java.util.jar.*;

import com.vk2gpz.elmer.lang.ClassNameFilter;

/*====================================================================
              Implementation of class JarClassNameFilter              
====================================================================*/
/**
 * This class name filter filters out any fully qualified class name
 * which is already in the specified JAR file.
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see ClassNameFilter
 */

public final class JarClassNameFilter implements ClassNameFilter {
	private final HashSet<String> classnames = new HashSet<>();
	
	public JarClassNameFilter(String jarFile) throws IOException {

		// read all class names in the JAR.
		try (JarFile jarfile = new JarFile(jarFile)) {
			
			for (Enumeration<?> e = jarfile.entries(); e.hasMoreElements(); ) {
				JarEntry jarentry = (JarEntry) e.nextElement();
				if (jarentry.isDirectory()) {
					continue;
				}
				
				String classname = jarentry.getName();
				if (classname.endsWith(".class")) {
					// Remove .class extension (6 chars) and convert slashes
					classname = classname.substring(0, classname.length() - 6).replace('/', '.');
					this.classnames.add(classname);
				}
			}
		}
	}
	
	public boolean accept(String classname) {
		// Check whether the specified class is already in the JAR
		return (! this.classnames.contains(classname));
   }
}
