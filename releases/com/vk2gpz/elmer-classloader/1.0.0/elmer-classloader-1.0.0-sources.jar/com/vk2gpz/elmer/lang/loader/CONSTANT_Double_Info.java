/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

/*====================================================================
             Implementation of class CONSTANT_Double_Info             
====================================================================*/
/**
 * CONSTANT_Double_Info represents CONSTANT_Double_info structure
 * defined in VM Spec $4.4.5
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see CONSTANT_LD_Info
 */

final class CONSTANT_Double_Info extends CONSTANT_LD_Info {
	/**
	 * Constructs a new CONSTANT_Double_info object
	 */
	CONSTANT_Double_Info(DataInput datainput) throws IOException {
		super(ConstantPoolAnalyzer.CONSTANT_Double, datainput);
	}
}

