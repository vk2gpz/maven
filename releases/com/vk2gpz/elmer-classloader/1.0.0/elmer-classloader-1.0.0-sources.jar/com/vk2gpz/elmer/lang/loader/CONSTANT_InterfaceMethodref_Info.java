/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

/*====================================================================
       Implementation of class CONSTANT_InterfaceMethodref_Info       
====================================================================*/
/**
 * CONSTANT_InterfaceMethodref_Info represents
 * CONSTANT_InterfaceMethodref_info structure defined in VM Spec $4.4.2
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see CONSTANT_FMIRef_Info
 */

final class CONSTANT_InterfaceMethodref_Info extends CONSTANT_FMIRef_Info {
	/**
	 * Constructs a new CONSTANT_InterfaceMethodref_info object
	 */
	CONSTANT_InterfaceMethodref_Info(DataInput datainput) throws IOException {
		super(ConstantPoolAnalyzer.CONSTANT_InterfaceMethodref, datainput);
	}
}

