/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

/*====================================================================
             Implementation of class CONSTANT_FMIRef_Info             
====================================================================*/
/**
 * CONSTANT_FMIRef_Info is an abstract class for CONSTANT_Fieldref_info,
 * CONSTANT_Methodref_info and CONSTANT_InterfaceMethodref_info structure
 * defined in VM Spec $4.4.2
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see CP_Info
 */

class CONSTANT_FMIRef_Info extends CP_Info {
	short classIndex;
	short nameAndTypeIndex;

	/**
	 * Constructs a new CONSTANT_Fieldref_info object
	 */
	CONSTANT_FMIRef_Info(byte byte0, DataInput datainput) throws IOException {
		super(byte0);
		this.classIndex = datainput.readShort();
		this.nameAndTypeIndex = datainput.readShort();
	}
	
	public String toString() {
		return super.toString() + ", _class_index = " + this.classIndex + ", _name_and_type_index = " + this.nameAndTypeIndex + "]";
	}
}
