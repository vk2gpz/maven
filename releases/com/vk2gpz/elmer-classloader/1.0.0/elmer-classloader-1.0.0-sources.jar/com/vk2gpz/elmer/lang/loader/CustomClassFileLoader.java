/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

/*====================================================================
            Implementation of class CustomClassFileLoader             
====================================================================*/
/**
 * This interface defines methods to find and load a bytecode of the
 * specified class.
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public interface CustomClassFileLoader {
	/**
	 * Finds the ".class" or ".jar" file which contains the specified class,
	 * and returns an input stream which the class can be read from.
	 *
	 * @param s the name of the class.
	 * @exception ClassNotFoundException if the class is not found   
	 * @exception IOException if an I/O Exception occurs
	 */
	InputStream getClass(String s) throws IOException, ClassNotFoundException;
}
