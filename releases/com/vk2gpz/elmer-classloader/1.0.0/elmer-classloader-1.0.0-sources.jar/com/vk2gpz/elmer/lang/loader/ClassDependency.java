/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */

import com.vk2gpz.elmer.debug.DebugHandler;
import com.vk2gpz.elmer.debug.DebugLabel;
import com.vk2gpz.elmer.lang.ClassNameFilter;
import com.vk2gpz.elmer.lang.PrefixClassNameFilter;
import com.vk2gpz.elmer.logging.ColorConsoleLogger;
import com.vk2gpz.elmer.util.jar.JarClassNameFilter;
import com.vk2gpz.elmer.util.jar.JarUtil;

import java.io.*;
import java.lang.reflect.*;
import java.net.*;
import java.util.*;


/*====================================================================
               Implementation of class ClassDependency                
====================================================================*/

/**
 * ClassDependency finds all classes referenced from the specified class.
 *
 * @author vk2gpz (vk2gpz@gmail.com)
 * @version $Revision: 99 $
 */

@SuppressWarnings("unused")
public final class ClassDependency {
	private ClassNameFilter[] filters;
	private final Class<?> clazz;
	private final HashMap<String, Class<?>> classes;    // map to store classname-classobject pair
	private final HashMap<String, URL> resources;    // map to store urlname-url pair
	private final HashMap<String, URL> jars;        // map to store jar filename and url
	private boolean append;
	
	private ConstantPoolAnalyzer cpa;
	@SuppressWarnings("FieldCanBeLocal")
	private final JBeansResourceFileLoader rfl;
	
	private JBeansClassLoader cloader;
	
	public ClassDependency(String classname) throws ClassNotFoundException {
		this(classname, null);
	}
	
	public ClassDependency(Class<?> clazz) {
		this(clazz, null);
	}
	
	public ClassDependency(String classname, ClassNameFilter[] filters) throws ClassNotFoundException {
		this(Class.forName(classname), filters);
	}
	
	public ClassDependency(Class<?> clazz, ClassNameFilter[] filters) {
		this.filters = filters;
		this.clazz = clazz;
		this.classes = new HashMap<>();
		this.resources = new HashMap<>();
		this.jars = new HashMap<>();
		this.cpa = new ConstantPoolAnalyzer();
		this.rfl = new JBeansResourceFileLoader();
		this.append = false;
		this.cloader = new JBeansClassLoader(this.clazz.getClassLoader(), "ClassDependency", null);
	}
	
	public void setClassPath(String classpath) {
		this.cloader = new JBeansClassLoader(this.clazz.getClassLoader(), "ClassDependency", null);
		this.cloader.setClassPath(classpath);
		this.cpa = new ConstantPoolAnalyzer(classpath);
	}
	
	public ClassNameFilter[] getClassNameFilters() {
		return this.filters;
	}
	
	public void setClassNameFilters(ClassNameFilter[] filters) {
		this.filters = filters;
	}
	
	public void setAppend(boolean v) {
		this.append = v;
	}
	
	public boolean getAppend() {
		return this.append;
	}
	
	/**
	 * Returns fully qualified class names of all dependent classes.
	 *
	 * @return a Set of Strings each of which is a fully qualified class name.
	 */
	public Collection<String> getDependentClassNames() {
		return this.classes.keySet();
	}
	
	/**
	 * Returns a Collecion of all dependent classes.
	 *
	 * @return a Collection of all dependent classes.
	 */
	public Collection<Class<?>> getDependentClasses() {
		return this.classes.values();
	}
	
	public int countClasses() {
		return this.classes.size();
	}
	
	/**
	 * Returns resources.
	 *
	 * @return a Set of Strings each of which is a fully qualified class name.
	 */
	public HashMap<String, URL> getResourceMap() {
		return this.resources;
	}
	
	/**
	 * Returns a Collecion of all dependent resource files.
	 *
	 * @return a Collection of all dependent resource files.
	 */
	public Collection<String> getDependentResourceFiles() {
		return this.resources.keySet();
	}
	
	public int countResourceFiles() {
		return this.resources.size();
	}
	
	/**
	 * Returns jar files.
	 *
	 * @return a Set of Strings each of which is a jar file name.
	 */
	public HashMap<String, URL> getJarFileMap() {
		return this.jars;
	}
	
	/**
	 * Returns a Collecion of all dependent jar files.
	 *
	 * @return a Collection of all dependent jar files.
	 */
	public Collection<String> getDependentJarFiles() {
		return this.jars.keySet();
	}
	
	public int countJarFiles() {
		return this.jars.size();
	}
	
	/**
	 * Analyzes the specifiec class.
	 */
	public void analyzeClass() {
		addToList(this.clazz);
	}
	
	private void addToList(Class<?>[] classes) {
		for (Class<?> aClass : classes) {
			addToList(aClass);
		}
	}
	
	private void addToList(Field[] fields) {
		for (Field field : fields) {
			addToList(field.getType());
		}
	}
	
	private void addToList(Method[] methods) {
		for (Method method : methods) {
			addToList(method.getReturnType());
			addToList(method.getParameterTypes());
			addToList(method.getExceptionTypes());
		}
	}
	
	private boolean accept(String classname) {
		for (ClassNameFilter filter : this.filters) {
			if (!filter.accept(classname)) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Adds the specified class and all other classes the specifiec class
	 * depends on into the class list.
	 * This is done by analyzing the constant pool structure (defined in
	 * the VM Spec $4) in the class file (*.class).
	 */
	@DebugLabel(key = "ClassDependency_addToList")
	private void addToList(Class<?> c) {
		boolean debug = DebugHandler.isDebugged("ClassDependency_addToList");
		if (c.isPrimitive()) {    // we don't need to keep any primitive type.
			return;
		}
		
		String classname = c.getName();
		if ((!accept(classname)) || // check prefix and duplicate in the JAR
				(this.classes.containsKey(classname))) { // if it's already in the list.
			return;
		}
		
		if (c.isArray()) {        // if it's an array...
			addToList(c.getComponentType()); // add the component type.
			return;
		}
		
		if (debug) {
			DebugHandler.getLogger("elmer").info("adding " + classname);
		}
		this.classes.put(classname, c);    // add the specified class.
		
		// add all the public final classes and interfaces that are members of the specified class
		addToList(c.getClasses());
		
		// add all exceptions occur during the construction.
		Constructor<?>[] cn = c.getConstructors();
		for (Constructor<?> constructor : cn) {
			addToList(constructor.getExceptionTypes());
		}
		
		// add all declared classes and interfaces
		addToList(c.getDeclaredClasses());
		
		// add all declared fields.
		Field[] fields = c.getDeclaredFields();
		addToList(fields);
		
		// add all return and parameter classes in Methods.
		Method[] methods = c.getDeclaredMethods();
		addToList(methods);
		
		// add all implemented interfaces
		addToList(c.getInterfaces());
		
		// add super class
		if (c.getSuperclass() != null) {
			addToList(c.getSuperclass());
		}
		
		// add rest of dependent classes.
		addToList(getDependentClasses(c));
		
		// and add dependent resource files to the this.resources.
		addResourcesToList(c);
	}
	
	private Class<?>[] getDependentClasses(Class<?> c) {
		try {
			String[] classnames = this.cpa.getDependentClasses(c.getName());
			Class<?>[] classes = new Class<?>[classnames.length];
			for (int i = 0; i < classnames.length; i++) {
				classes[i] = Class.forName(classnames[i], false, this.clazz.getClassLoader());
			}
			return classes;
		} catch (Exception e) {
			System.err.println("ClassDependency <getDependentClasses(Class c)>: " + e.getMessage());
			e.printStackTrace();
			return new Class<?>[0];
		}
	}
	
	@DebugLabel(key = "ClassDependency_addResourcesToList")
	private void addResourcesToList(Class<?> c) {
		boolean debug = DebugHandler.isDebugged("ClassDependency_addResourcesToList");
		try {
			String base = c.getName();
			String[] filenames = this.cpa.getDependentResourceFiles(base);
			if (debug) {
				DebugHandler.getLogger("elmer").info("checking resource for " + base);
				DebugHandler.getLogger("elmer").info("filenames = " + filenames.length);
			}
			int index = base.lastIndexOf('.');
			base = base.substring(0, index + 1);
			if (debug) {
				DebugHandler.getLogger("elmer").info("index = " + index);
				DebugHandler.getLogger("elmer").info("base = " + base);
			}
			base = base.replace('.', '/');
			String urlStr;
			String protocol = null;
			for (String filename : filenames) {
				URL url = c.getResource(filename);
				if (debug) {
					DebugHandler.getLogger("elmer").info("checking resource : " + filename);
					DebugHandler.getLogger("elmer").info("checking resource's url : " + url);
				}
				if (url == null ||
						!readableURL(url)) {
					if (debug) {
						DebugHandler.getLogger("elmer").info("url not readable.");
					}
					continue;
				}
				urlStr = url.getFile();
				if ((new File(urlStr)).isDirectory()) {
					if (debug) {
						DebugHandler.getLogger("elmer").info("url seems to be a directory.");
					}
					continue;
				}
				if (debug) {
					DebugHandler.getLogger("elmer").info("urlStr = " + urlStr);
				}
				if (base.length() > 0) {
					index = urlStr.lastIndexOf(base);
					urlStr = urlStr.substring(index);
				} else {
					index = urlStr.lastIndexOf("/");
					urlStr = urlStr.substring(index + 1);
				}
				if (debug) {
					DebugHandler.getLogger("elmer").info("index = " + index);
					DebugHandler.getLogger("elmer").info("new urlStr = " + urlStr);
					DebugHandler.getLogger("elmer").info("adding resource : " + urlStr);
				}
				this.resources.put(urlStr, url);
			}
		} catch (Exception ioe) {
			// do nothing...
			if (debug) {
				DebugHandler.getLogger("elmer").warning(ioe.getMessage());
				ioe.printStackTrace();
			}
		}
	}
	
	/**
	 * checks whether url is readable or not.
	 */
	private boolean readableURL(URL url) {
		try {
			BufferedInputStream bis = new BufferedInputStream(url.openStream());
			if (!(bis.available() > 0)) {
				return false;
			}
		} catch (IOException ioe) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * Creates a JAR file for the specified class.
	 */
	public void createJar(String jarname) throws IOException {
		File file = new File(jarname);
		if (file.exists() && (!this.append)) {
			//noinspection ResultOfMethodCallIgnored
			file.delete();
		}
		OutputStream os = new FileOutputStream(jarname, this.append);
		Collection<Class<?>> classes = getDependentClasses();
		int count = 0;
		Class<?>[] clazzes = new Class[classes.size()];
		for (Class<?> aClass : classes) {
			clazzes[count++] = aClass;
			// find ".class" file
		}
		String pSep = File.pathSeparator;
		String path = System.getProperty("java.class.path");
		JarUtil.create(os, path, clazzes);
		os.close();
	}
	
	/**
	 * Creates a JAR file for the specified class.
	 */
	public void createJarFor(String classname, ClassNameFilter[] filters, String jarname) throws ClassNotFoundException, IOException {
		File file = new File(jarname);
		if (file.exists() && (!this.append)) {
			//noinspection ResultOfMethodCallIgnored
			file.delete();
		}
		OutputStream os = new FileOutputStream(jarname, this.append);
		String pSep = File.pathSeparator;
		String path = System.getProperty("java.class.path");
		String[] misc = new String[0];
		JarUtil.create(os, null, path, Class.forName(classname), null, misc, filters);
		os.close();
	}
	
	private void abort(String jarfile, OutputStream os) {
		try {
			os.close();
			//noinspection ResultOfMethodCallIgnored
			new File(jarfile).delete();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static String getDefaultBaseName(String classname) {
		if (classname.lastIndexOf(".") == -1) { // no need compute base name.
			return classname;
		}
		
		return classname.substring(classname.lastIndexOf(".") + 1);
	}
	
	/* ----------------------------- test ----------------------------- */
	private static final String usage = "Usage: java net.jbeans.util.jar.ClassDependency <fully qualified class name> [-jar jarfile] [-append] [-prefix excluded_prefix0 excluded_prefix1 ...]";
	
	public static void main(String[] args) {
		try {
			String jarname = null;
			boolean append = false;
			String[] prefixes = new String[0];
			
			if (args.length == 0) {
				System.out.println(usage);
				System.exit(0);
			}
			
			String classname = args[0];
			if (classname == null) {
				System.out.println(usage);
				System.exit(0);
			}
			
			for (int i = 1; i < args.length; i++) {
				if (args[i].startsWith("-")) {
					switch (args[i]) {
						case "-jar":
							jarname = args[++i];
							break;
						case "-append":
							append = true;
							break;
						case "-prefix":
							int count = args.length - (i + 1);
							prefixes = new String[count];
							int j = 0;
							for (i = (i + 1); i < args.length; i++) {
								prefixes[j++] = args[i];
							}
							break;
					}
				} else {
					System.out.println(usage);
					System.exit(0);
				}
			}
			
			if (jarname == null) {
				jarname = getDefaultBaseName(classname) + ".jar";
			}
			
			int filtercount = (append) ? 2 : 1;
			ClassNameFilter[] filters = new ClassNameFilter[filtercount];
			filters[0] = new PrefixClassNameFilter(prefixes);
			if (append) {
				filters[1] = new JarClassNameFilter(jarname);
			}
			
			
			ClassDependency ca = new ClassDependency(classname, filters);
			ca.createJarFor(classname, filters, jarname);
			
			
			// Set append flag
			ca.setAppend(append);
			
			// create a list
			ca.analyzeClass();
			
			if (append) {
				if (ca.countClasses() == 0) {
					System.out.println("Nothing to add.");
					return;
				}
			}
			
			// create a jar
			ca.createJar(jarname);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.exit(0); // Stop unwanted GUI threads
		}
	}
}
