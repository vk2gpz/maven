/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

/*====================================================================
          Implementation of class CONSTANT_NameAndType_Info           
====================================================================*/
/**
 * CONSTANT_NameAndType_Info represents CONSTANT_NameAndType_info
 * structure defined in VM Spec $4.4.6
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see CP_Info
 */

final class CONSTANT_NameAndType_Info extends CP_Info {
	short nameIndex;
	short descriptorIndex;
	
	/**
	 * Constructs a new CONSTANT_NameAndType_info object
	 */
	CONSTANT_NameAndType_Info(DataInput datainput) throws IOException {
		super(ConstantPoolAnalyzer.CONSTANT_NameAndType);
		this.nameIndex = datainput.readShort();
		this.descriptorIndex = datainput.readShort();
	}
	
	public String toString() {
		return super.toString() + ", _name_index = " + this.nameIndex + ", _descriptor_index = " + this.descriptorIndex + "]";
	}
}
