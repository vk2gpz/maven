/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */

import java.io.DataInput;
import java.io.IOException;

/*====================================================================
              Implementation of class CONSTANT_MethodHandler_Info
====================================================================*/

/**
 * CONSTANT_MethodHandler_Info represents CONSTANT_MethodHandler_info
 * structure defined in VM Spec $4.4.8
 *
 * @version $Revision: 99 $
 * @author vk2gpz@gmail.com
 * @see CP_Info
 */

@SuppressWarnings("unused")
final class CONSTANT_MethodHandle_Info extends CP_Info {
	byte referenceKind;
	short referenceIndex;

	/**
	 * Constructs a new CONSTANT_MethodHandler_Info object
	 */
	CONSTANT_MethodHandle_Info(DataInput datainput) throws IOException {
		super(ConstantPoolAnalyzer.CONSTANT_MethodHandle);
		this.referenceKind = datainput.readByte();
		this.referenceIndex = datainput.readShort();
	}

	public String toString() {
		return super.toString() + ", _reference_kind = " + this.referenceKind + ", _reference_index = " + this.referenceIndex + "]";
	}
}
