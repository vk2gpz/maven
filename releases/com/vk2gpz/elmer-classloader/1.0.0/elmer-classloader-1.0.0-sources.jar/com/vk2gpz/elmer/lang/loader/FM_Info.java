/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.debug.DebugHandler;

import java.io.*;

/*====================================================================
                   Implementation of class FM_Info                    
====================================================================*/
/**
 * FM_Info is an abstract class for field_info and
 * method_info structure defined in VM Spec $4.5 and $4.6
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

abstract class FM_Info {
	/**
	 * debug flag
	 */
	private static final boolean DEBUG = DebugHandler.isDebugged(FM_Info.class);
	short accessFlags;
	short nameIndex;
	short descriptorIndex;
	// _attribute_count  = _attributes.length;
	Attribute_Info[] attributes;

	/**
	* Constructs a new FM_Info object.
	*/
	FM_Info(DataInput datainput) throws IOException {
		this.accessFlags = datainput.readShort();
		this.nameIndex = datainput.readShort();
		this.descriptorIndex = datainput.readShort();

		if (DEBUG) {
			System.out.println("_access_flags = (" +
							   ConstantPoolAnalyzer.getAccessFlagAsString(this.accessFlags) +
							   ")," +
							   ConstantPoolAnalyzer.lineSeparator +
							   "_name_index = " +
							   this.nameIndex +
							   "," +
							   ConstantPoolAnalyzer.lineSeparator +
							   "_descriptor_index = " +
							   this.descriptorIndex);
		}
		short word0 = datainput.readShort();
		this.attributes = new Attribute_Info[word0];
		for (int i = 0; i < word0; i++) {
			this.attributes[i] = new Attribute_Info(datainput);
		}
	}
		
	public String toString() {
		StringBuilder stringbuffer = new StringBuilder();
		stringbuffer.append("_access_flags = (").append(ConstantPoolAnalyzer.getAccessFlagAsString(this.accessFlags)).append("),").append(ConstantPoolAnalyzer.lineSeparator).append("_name_index = ").append(this.nameIndex).append(",").append(ConstantPoolAnalyzer.lineSeparator).append("_descriptor_index = ").append(this.descriptorIndex);
		for (int i = 0; i < this.attributes.length; i++) {
			stringbuffer.append(ConstantPoolAnalyzer.lineSeparator);
			stringbuffer.append("attribute[").append(i).append("] = ");
			stringbuffer.append(this.attributes[i].toString());
		}

		return stringbuffer.toString();
	}
}
