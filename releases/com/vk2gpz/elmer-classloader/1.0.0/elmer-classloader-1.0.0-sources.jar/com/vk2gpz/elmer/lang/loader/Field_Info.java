/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

/*====================================================================
                  Implementation of class Field_Info                  
====================================================================*/
/**
 * Field_Info represents field_info structure defined in VM Spec $4.5.
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see FM_Info
 */

final class Field_Info extends FM_Info {
	/**
	* Constructs a new Field_Info object.
	*/
	Field_Info(DataInput datainput) throws IOException {
		super(datainput);
	}
	
	public String toString() {
		return "field_info : [" +
			ConstantPoolAnalyzer.lineSeparator +
			super.toString() +
			ConstantPoolAnalyzer.lineSeparator +				
			"]";
	}
}
