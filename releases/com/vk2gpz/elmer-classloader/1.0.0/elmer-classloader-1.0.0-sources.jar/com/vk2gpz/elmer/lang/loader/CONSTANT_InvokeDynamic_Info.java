/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */

import java.io.DataInput;
import java.io.IOException;

/*====================================================================
              Implementation of class CONSTANT_InfokeDynamic_Info
====================================================================*/

/**
 * CONSTANT_InvokeDynamic_Info represents CONSTANT_InvokeDynamic_info
 * structure defined in VM Spec $4.4.10
 *
 * @version $Revision: 99 $
 * @author vk2gpz@gmail.com
 * @see CP_Info
 */

@SuppressWarnings("unused")
final class CONSTANT_InvokeDynamic_Info extends CP_Info {
	short bootstrapMethodAttrIndex;
	short nameAndTypeIndex;

	/**
	 * Constructs a new CONSTANT_MethodType_Info object
	 */
	CONSTANT_InvokeDynamic_Info(DataInput datainput) throws IOException {
		super(ConstantPoolAnalyzer.CONSTANT_InvokeDynamic);
		this.bootstrapMethodAttrIndex = datainput.readShort();
		this.nameAndTypeIndex = datainput.readShort();
	}

	public String toString() {
		return super.toString() + ", _bootstrap_method_attr_index = " + this.bootstrapMethodAttrIndex + ", _name_and_type_index = " + this.nameAndTypeIndex + "]";
	}
}
