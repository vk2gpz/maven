/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.net;

/* ------------------ Import classes (packages) ------------------- */
import java.net.*;

import com.vk2gpz.elmer.lang.loader.CustomClassLoader;

/*====================================================================
             Implementation of class CustomURLClassLoader             
====================================================================*/
/**
 * CustomURLClassLoader loads classes and resources from a search
 * path of URLs referring to both JAR files and directories. Any URL that
 * ends with a '/' is assumed to refer to a directory. Otherwise, the URL
 * is assumed to refer to a JAR file which will be opened as needed.
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see URLClassLoader
 * @see CustomClassLoader
 */

@SuppressWarnings("unused")
public class CustomURLClassLoader extends URLClassLoader implements CustomClassLoader {

	public CustomURLClassLoader(URL[] urls, ClassLoader parent) {
		super(urls, parent);
	}

	public CustomURLClassLoader(URL[] urls) {
		super(urls);
	}

	public CustomURLClassLoader(URL[] urls, ClassLoader parent,
								URLStreamHandlerFactory factory) {
		super(urls, parent, factory);
	}

	/**
	 * Loads a class with the specified binary name, delegating to {@link #findClass(String)}.
	 * This method exposes the protected parent method for custom class loading.
	 *
	 * @param className the binary name of the class
	 * @return the Class object for the requested class
	 * @throws ClassNotFoundException if the class cannot be found
	 * @see URLClassLoader#findClass(String)
	 */
	@Override
	public final Class<?> getClass(String className) throws ClassNotFoundException {
		return findClass(className);
	}

	/**
	 * Appends the specified URL to the list of URLs to search for classes and resources.
	 * This exposes the protected {@link URLClassLoader#addURL(URL)} method for dynamic
	 * classpath modification at runtime.
	 *
	 * @param url the URL to be appended to the search path
	 */
	@Override
	public final void addURL(URL url) {
		super.addURL(url);
	}
}
