/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
                   Implementation of class CP_Info                    
====================================================================*/
/**
 * entry for constant_pool table.  Sett VM Spec $4.4
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

@SuppressWarnings("unused")
abstract class CP_Info {
	byte tag;
	
	/**
	 * Constructs a new CP_Info object
	 */
	CP_Info(byte byte0) {
		this.tag = byte0;
	}

	short getTag() {
		return this.tag;
	}
	
	String getTagName() {
		return ConstantPoolAnalyzer.getConstantTagAsString(this.tag);
	}
	
	public String toString() {
		return "[Tag = " + this.tag + " " +
			ConstantPoolAnalyzer.getConstantTagAsString(this.tag);
	}
}

