/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

/*====================================================================
                 Implementation of class Method_Info                  
====================================================================*/
/**
 * Method_Info represents method_info structure defined in VM Spec $4.6.
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see FM_Info
 */

final class Method_Info extends FM_Info {
	/**
	 * Constructs a new Method_Info object
	 */
	Method_Info(DataInput datainput) throws IOException {
		super(datainput);
	}
	
	public String toString() {
		return "mehtod_info : [" +
			ConstantPoolAnalyzer.lineSeparator +				
			super.toString() +
			ConstantPoolAnalyzer.lineSeparator +
			"]";
	}
}

