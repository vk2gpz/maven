/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

/*====================================================================
           Implementation of class CustomResourceFileLoader           
====================================================================*/
/**
 * This interface defines methods to find and load the specified file.
 * 
 * @version $Revision: 99 $
 * @author vk2gpz@gmail.com
 */

public interface CustomResourceFileLoader {
	/**
	 * Finds the specified resource file for the specified class,
	 * and returns an input stream which the file can be read from.
	 *
	 * @param clazz the name of the class file.
	 * @param resourcename the name of the resource file.	 
	 * @exception FileNotFoundException if the class is not found   
	 * @exception IOException if an I/O Exception occurs
	 */
	InputStream getResourceFileForClass(Class<?> clazz, String resourcename) throws IOException;
}
