/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

/*====================================================================
               Implementation of class CONSTANT_IF_Info               
====================================================================*/
/**
 * CONSTANT_IF_Info is an abstract class for CONSTANT_Integer_info and
 * CONSTANT_Float_info structure defined in VM Spec $4.4.4
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see CP_Info
 */

class CONSTANT_IF_Info extends CP_Info {
	int bytes;
	
	/**
	 * Constructs a new CONSTANT_IF_info object
	 */
	CONSTANT_IF_Info(byte byte0, DataInput datainput) throws IOException {
		super(byte0);
		this.bytes = datainput.readInt();
	}
	
	public String toString() {
		return super.toString() + ", _bytes = " + this.bytes + "]";
	}
}
