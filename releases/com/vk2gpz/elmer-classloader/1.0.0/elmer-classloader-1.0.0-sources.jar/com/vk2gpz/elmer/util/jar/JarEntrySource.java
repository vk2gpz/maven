/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.util.jar;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.debug.DebugHandler;

import java.io.*;
import java.nio.file.Files;

/*====================================================================
                Implementation of class JarEntrySource                
====================================================================*/
/**
 * Used to request creating Jars
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

@SuppressWarnings("unused")
final class JarEntrySource {
	/**
	 * debug flag
	 */
	private static final boolean DEBUG = DebugHandler.isDebugged(JarEntrySource.class);

    private final boolean markOnly;	// only mark in the ZIP
    private final String name;	// the name of this entry
    private InputStream is;	// the input stream for the entry
    private File file;		// if a file
    private long modifiedTime;	// if an inputstream

    JarEntrySource(File file) {
		this.markOnly = false;
		this.name = file.getPath().replace(File.separatorChar, '/');
		this.file = file;
    }

    JarEntrySource(String name, File file) {
		this.markOnly = false;
		this.name = name;
		this.file = file;
    }

    JarEntrySource(String name, InputStream is) {
		this.markOnly = false;
		this.name = name;
		this.is = is;
    }
	
    JarEntrySource(String name) {
		this.markOnly = true;
		this.name = name;
    }

    /**
     * Accessors
     */
	boolean isMarkOnly() {
		return this.markOnly;
    }

    long getTime() {
		if (this.file != null) {
			return this.file.lastModified();
		} else {
			return System.currentTimeMillis(); // return the current system time.
		}
    }

    long getLength() {
		if (this.file != null) {
			return this.file.length();
		} else {
			return 0;		// ??
		}
    }

    String getName() {
		return this.name;
    }

    InputStream getInputStream() {
		InputStream is = this.is;
		if (this.file != null) {
			try {
				is = Files.newInputStream(this.file.toPath());
			} catch (Exception ex) {
				is = null;
			}
		} 
		if (DEBUG) {
			System.out.println("_file = " + this.file);
			System.out.println("_is = " + this.is);
			System.out.println("is = " + is);			
		}
		return is;
    }
}
