/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

/*====================================================================
              Implementation of class CONSTANT_Utf8_Info              
====================================================================*/
/**
 * CONSTANT_Utf8_Info represents CONSTANT_Utf8_info
 * structure defined in VM Spec $4.4.7
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see CP_Info
 */

final class CONSTANT_Utf8_Info extends CP_Info {
	String utf;
	
	/**
	 * Constructs a new CONSTANT_Utf8_Info object
	 */
	CONSTANT_Utf8_Info(DataInput datainput) throws IOException {
		super(ConstantPoolAnalyzer.CONSTANT_Utf8);
		this.utf = datainput.readUTF();
	}
	
	String getBytesAsString() {
		return this.utf;
	}
	
	public String toString() {
		return super.toString() + ", _utf = \"" + this.utf + "\"]";
	}
}
