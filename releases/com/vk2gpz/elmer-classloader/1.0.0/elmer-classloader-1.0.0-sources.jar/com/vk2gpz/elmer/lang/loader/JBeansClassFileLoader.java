/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;
import java.nio.file.Files;
import java.util.*;
import java.util.jar.*;

import com.vk2gpz.elmer.debug.DebugHandler;
import com.vk2gpz.elmer.io.StringTokenReader;
import com.vk2gpz.elmer.util.jar.JarUtil;

/*====================================================================
            Implementation of class JBeansClassFileLoader             
====================================================================*/
/**
 * JBeansClassFileLoader is a Class file loader used in JBeans.
 * 
 * PERFORMANCE: Optimized with classpath caching, resource pooling, and bulk I/O.
 * 
 * @version $Revision: 197 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see CustomClassFileLoader
 */

@SuppressWarnings("unused")
public final class JBeansClassFileLoader implements CustomClassFileLoader {
	/**
	 * debug flag
	 */
	private static final boolean DEBUG = DebugHandler.isDebugged(JBeansClassFileLoader.class);

	private static final String JAR_CLASS_PATH = "Class-Path";

	private static final String CLASS_SUFFIX = ".class";
	private static final String CLASS_PATH_PROPERTY = "java.class.path";
	private static final String JAVA_HOME_PROPERTY = "java.home";
	private static final String JAVA_EXT_PROPERTY = "java.ext.dirs";
	private static final String JAVA_LIB_DIR = "lib";

    private final String classPath;
    
    // Cache for classpath directories - avoids repeated StringTokenizer parsing
    private volatile List<String> directoryCache;
    private final Object dirCacheLock = new Object();

    public JBeansClassFileLoader() {
        this(System.getProperties().getProperty(CLASS_PATH_PROPERTY));
    }

    public JBeansClassFileLoader(String s) {
        this.classPath = expandClassPath(s);
    }

	public static String expandClassPath(String classpath) {
		StringBuilder sb = new StringBuilder();
		boolean first = true;
		try (StringTokenReader sr = new StringTokenReader(classpath, File.pathSeparator)) {
			while (sr.hasMoreTokens()) {
				String candidate = sr.nextToken();
				if (first) {
					first = false;
				} else {
					sb.append(File.pathSeparator);
				}
				if (candidate.contains(".jar")
						|| candidate.contains(".JAR")) {
					candidate = extractClassPathFromJar(candidate);
					sb.append(candidate);
				} else {
					sb.append(candidate);
				}
			}
		}
		return sb.toString();
	}

	private static String extractClassPathFromJar(String jarfile) {
		StringBuilder sb = new StringBuilder();
		boolean first = true;
		
		try (JarFile jarFile = JarUtil.findJarFile(jarfile)) {
			if (jarFile != null) {
				try {
					Manifest manifest = jarFile.getManifest();
					if (manifest != null) {
						Attributes atts = manifest.getMainAttributes();
						String jarclasspath = atts.getValue(JAR_CLASS_PATH);
						try (StringTokenReader sr = new StringTokenReader(jarclasspath, " ")) {
							String jarFileName;
							while (sr.hasMoreTokens()) {
								jarFileName = sr.nextToken();
								File jar_File = new File(jarFileName);
								/* add the entry only if it exists */
								if (jar_File.exists()) {
									if (first) {
										first = false;
									} else {
										sb.append(File.pathSeparator);
									}
									sb.append(jarFileName);
									if (DEBUG) {
										System.out.println("JBeansClassFileLoader.extractClassPathFromJar() : adding " + jarFileName);
									}
								} else { /* otherwise skip it! */
									if (DEBUG) {
										System.out.println("JBeansClassFileLoader.extractClassPathFromJar() : skipping " + jarFileName);
									}
								}
							}
						}
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
				sb.append(File.pathSeparator);
				sb.append(jarfile);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return sb.toString();
	}
	
	/**
	* convert a class name to a string can be used to create JarEntry object.
	*/
    private String getNameForJarEntry(String s) {
        if (s.endsWith(CLASS_SUFFIX)) {
            return s;
		} else {
            return s.replace('.', '/') + CLASS_SUFFIX;
		}
    }

	/**
	 * convert a class name to a path.
	*/
    private String getPath(String s) {
        if (s.endsWith(CLASS_SUFFIX)) {
            return s;
		} else {
            return s.replace('.', File.separatorChar) + CLASS_SUFFIX;
		}
    }

    public File findClassFile(String s) throws IOException, ClassNotFoundException {
        try {
			// try standard java library first.
            return findClassFileIn(new File(System.getProperties().getProperty(JAVA_HOME_PROPERTY) + File.separator + JAVA_LIB_DIR), s, false);
        } catch(ClassNotFoundException _ex) {
			if (DEBUG) {
				System.out.println("JBeansClassFileLoader (findClassfile): not in the java standard library");
			}
		}

        List<String> dirList;
        try {
			// then, try java extension library.
            return findClassFileIn(new File(System.getProperties().getProperty(JAVA_EXT_PROPERTY)), s, true);
        } catch(ClassNotFoundException _ex) {
            dirList = getDirectoriesFromClasspath();
        }
		
		for (String s1 : dirList) {
            try {
				if (DEBUG) {
					System.out.println("JBeansClassFileLoader.findClassFile() : entry = " + s1);
				}
                File file = new File(s1);
                if (!s1.endsWith(".jar") && !s1.endsWith(".zip")) {
                    File file1 = getClassFile(file, s);
                    if (file1.exists()) {
                        return file1;
					}
                } else {
                    File[] afile = new File[1];
                    afile[0] = file;
                    return findJarDefinesClass(s, afile);
                }
            } catch(ClassNotFoundException _ex) {
				if (DEBUG) {
					System.out.println("JBeansClassFileLoader (findClassfile): coould not find it in anywhere");
				}
			}
		}
        throw new ClassNotFoundException(s);
    }

    public File findClassFileIn(File file, String s, boolean flag) throws IOException, ClassNotFoundException {
        if (!flag) {
            File file1 = getClassFile(file, s);
            if (file1.exists()) {
                return file1;
			}
        }
        return findJarDefinesClass(s, findJarsInDirectory(file));
    }
	
    /**
     * Gets directories from classpath with caching to avoid repeated StringTokenizer parsing.
     * PERFORMANCE: O(1) after first call (cached result).
     * 
     * @return list of classpath directories
     */
    private List<String> getDirectoriesFromClasspath() {
        // Double-checked locking for cache initialization
        if (directoryCache != null) {
            return directoryCache;
        }
        
        synchronized (dirCacheLock) {
            if (directoryCache != null) {
                return directoryCache;
            }
            
            if (DEBUG) {
                System.out.println("JBeansClassFileLoader.getDirectoriesFromClasspath() : this.classPath = " + this.classPath);
            }
            
            // Build cache on first access
            StringTokenizer stringtokenizer = new StringTokenizer(this.classPath, File.pathSeparator);
            List<String> list = new ArrayList<>();
            while (stringtokenizer.hasMoreElements()) {
                list.add((String) stringtokenizer.nextElement());
            }
            
            // Store as immutable list for thread safety
            directoryCache = Collections.unmodifiableList(list);
            return directoryCache;
        }
    }

    private File getClassFile(File file, String s) {
        return new File(file.getAbsolutePath() + File.separator + getPath(s));
    }

    public File[] findJarsInDirectory(File file) {
        if (!file.isDirectory()) {
            return new File[0];
		} else {
            return file.listFiles((file1, s) -> s.endsWith(".jar"));
		}
    }

    public File findJarDefinesClass(String s, File[] afile) throws IOException, ClassNotFoundException {
        for (int i = 0; i < afile.length;) {
            try {
                getClassInJarAsStream(s, afile[i]).close();
                return afile[i];
            } catch(ClassNotFoundException _ex) {
                i++;
            }
		}

        throw new ClassNotFoundException(s);
    }

    /**
     * Reads a class file from a JAR with resource cleanup and bulk I/O.
     * PERFORMANCE: Uses try-with-resources and bulk read instead of byte-by-byte reads.
     * 
     * @param s the class name
     * @param file the JAR file
     * @return input stream of class bytecode
     * @throws IOException if I/O error occurs
     * @throws ClassNotFoundException if class not found in JAR
     */
    private InputStream getClassInJarAsStream(String s, File file) throws IOException, ClassNotFoundException {
        if (DEBUG) {
            System.out.println("JBeansClassFileLoader.getClassInJarAsStream() : file = " + file.getAbsolutePath());
        }
        
        try (JarFile jarfile = new JarFile(file)) {
            String s1 = getNameForJarEntry(s);
            JarEntry jarentry = jarfile.getJarEntry(s1);
            if (jarentry == null) {
                throw new ClassNotFoundException(s);
            }
            
            if (jarentry.getSize() == -1L) {
                throw new RuntimeException("The uncompressed size of the entry unknown in JAR file " + file);
            }
            if ((long)(int)jarentry.getSize() != jarentry.getSize()) {
                throw new RuntimeException("Too large JarEntry " + s1);
            }

            // Use bulk read instead of byte-by-byte (Java 8 compatible)
            try (InputStream inputstream = jarfile.getInputStream(jarentry)) {
                byte[] abyte0 = new byte[(int)jarentry.getSize()];
                int bytesRead = inputstream.read(abyte0);  // Single read for most cases
                if (bytesRead != abyte0.length) {
                    // Handle partial reads (rare for small class files)
                    ByteArrayOutputStream baos = new ByteArrayOutputStream((int)jarentry.getSize());
                    baos.write(abyte0, 0, bytesRead);
                    int b;
                    while ((b = inputstream.read()) != -1) {
                        baos.write(b);
                    }
                    abyte0 = baos.toByteArray();
                }
                return new ByteArrayInputStream(abyte0);
            }
        }
    }

    /**
     * Gets bytecode for a class with bulk I/O.
     * PERFORMANCE: Uses bulk read instead of byte-by-byte reading.
     * 
     * @param s the class name
     * @return bytecode array
     * @throws IOException if I/O error occurs
     * @throws ClassNotFoundException if class not found
     */
    public byte[] getByteCode(String s) throws IOException, ClassNotFoundException {
        try (InputStream inputstream = getClassAsStream(s)) {
            // Pre-allocate ByteArrayOutputStream with expected size if possible
            ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream(8192);
            byte[] buffer = new byte[8192];  // 8KB buffer for bulk reads
            int bytesRead;
            while ((bytesRead = inputstream.read(buffer)) != -1) {
                bytearrayoutputstream.write(buffer, 0, bytesRead);
            }
            return bytearrayoutputstream.toByteArray();
        }
    }

	public InputStream getClass(String s) throws IOException, ClassNotFoundException {
		return getClassAsStream(s);
	}

    public InputStream getClassAsStream(String s) throws IOException, ClassNotFoundException {
        File file = findClassFile(s);
        if (!isJar(file) && !isZip(file)) {
            return Files.newInputStream(file.toPath());
		} else {
            return getClassInJarAsStream(s, file);
		}
    }

    public boolean isJar(File file) {
        return file.getName().endsWith(".jar");
    }

    public boolean isZip(File file) {
        return file.getName().endsWith(".zip");
    }

	/* ------------------------- test method -------------------------- */
}


