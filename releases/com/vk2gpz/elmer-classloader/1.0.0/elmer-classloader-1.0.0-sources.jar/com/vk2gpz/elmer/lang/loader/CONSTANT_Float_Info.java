/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

/*====================================================================
             Implementation of class CONSTANT_Float_Info              
====================================================================*/
/**
 * CONSTANT_Float_Info represents CONSTANT_Float_info structure
 * defined in VM Spec $4.4.4
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see CONSTANT_IF_Info
 */

final class CONSTANT_Float_Info extends CONSTANT_IF_Info {
	/**
	 * Constructs a new CONSTANT_Float_info object
	 */
	CONSTANT_Float_Info(DataInput datainput) throws IOException {
		super(ConstantPoolAnalyzer.CONSTANT_Float, datainput);
	}
}
