/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.lang.loader;

import java.io.*;
import java.util.*;

import com.vk2gpz.elmer.debug.DebugHandler;
import com.vk2gpz.elmer.debug.DebugLabel;
import com.vk2gpz.elmer.logging.ColorConsoleLogger;

/**
 * ClassFileStructure represents ClassFile structure defined in
 * VM Spec $4.1.
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

@SuppressWarnings("unused")
final class ClassFileStructure {
	private static final String JAVA_LANG_CLASS = "java/lang/Class";
	
	int magic;
	short minorVersion;
	short majorVersion;
	// constant_pool_count = constant_pool.length + 1;
	CP_Info[] constantPool;
	short accessFlags;
	short thisClass;
	short superClass;
	// interfaces_count = _interfaces.length;
	short[] interfaces;
	// fields_count = fields.length;
	Field_Info[] fields;
	// methods_count = _methods.length
	Method_Info[] methods;
	// attributes_count = _attributes.length
	Attribute_Info[] attributes;
	
	String className;		
	private int tagCount;

	/**
	 * Constructs a new ClassFileStructure object
	 */
	@DebugLabel(key = "ClassFileStructure")
	ClassFileStructure(String s, DataInputStream datainputstream) throws IOException, ClassFormatError {
		boolean debug = DebugHandler.isDebugged("ClassFileStructure");
		this.tagCount = 1;
		this.className = s;
		this.magic = ((DataInput) datainputstream).readInt();
		this.minorVersion = ((DataInput) datainputstream).readShort();
		this.majorVersion = ((DataInput) datainputstream).readShort();
		short word0 = ((DataInput) datainputstream).readShort();
		if (debug) {
			DebugHandler.getLogger("elmer").info( "_magic = " +
							   this.magic +
							   System.getProperties().getProperty("line.separator") +
							   "_minor_version = " +
							   this.minorVersion +
							   System.getProperties().getProperty("line.separator") +
							   "_major_version = " +
							   this.majorVersion +
							   System.getProperties().getProperty("line.separator") +
							   "_constant_pool_count = " +
							   word0);
		}
		this.constantPool = new CP_Info[word0];
		for (int i = 1; i < word0; i++) {
			this.constantPool[i] = getCP_Info(datainputstream);
			if ((this.constantPool[i] instanceof CONSTANT_Long_Info) ||
				(this.constantPool[i] instanceof CONSTANT_Double_Info)) {
				i++;
			}
		}

		this.accessFlags = ((DataInput) datainputstream).readShort();
		this.thisClass = ((DataInput) datainputstream).readShort();
		this.superClass = ((DataInput) datainputstream).readShort();
		if (debug) {
			DebugHandler.getLogger("elmer").info("_access_flags = " +
							   this.accessFlags +
							   System.getProperties().getProperty("line.separator") +
							   "_this_class = " +
							   this.thisClass +
							   System.getProperties().getProperty("line.separator") +
							   "_super_class = " +
							   this.superClass);
		}
		short word1 = ((DataInput) datainputstream).readShort();
		this.interfaces = new short[word1];
		for (int j = 0; j < word1; j++){
			this.interfaces[j] = ((DataInput) datainputstream).readShort();
		}

		short word2 = ((DataInput) datainputstream).readShort();
		this.fields = new Field_Info[word2];
		for (int k = 0; k < word2; k++) {
			this.fields[k] = new Field_Info(datainputstream);
		}

		short word3 = ((DataInput) datainputstream).readShort();
		this.methods = new Method_Info[word3];
		for (int l = 0; l < word3; l++) {
			this.methods[l] = new Method_Info(datainputstream);
		}

		short word4 = ((DataInput) datainputstream).readShort();
		this.attributes = new Attribute_Info[word4];
		for (int i1 = 0; i1 < word4; i1++) {
			this.attributes[i1] = new Attribute_Info(datainputstream);
		}

		((InputStream) datainputstream).close();
	}

	ClassFileStructure(String s, byte[] abyte0) throws IOException, ClassFormatError {
		this(s, new DataInputStream(new ByteArrayInputStream(abyte0, 0, abyte0.length)));
	}
		
	boolean isForClass() {
		CP_Info[] acp_info = getConstantByTag(ConstantPoolAnalyzer.CONSTANT_Class);
		int i = -1;
		for (CP_Info cp_info : acp_info) {
			String s = ((CONSTANT_Utf8_Info) this.constantPool[((CONSTANT_Class_Info) cp_info).nameIndex]).getBytesAsString();
			if (s.equals(JAVA_LANG_CLASS)) {
				for (int k = 0; k < this.constantPool.length; k++) {
					if ((this.constantPool[k] instanceof CONSTANT_Class_Info) &&
							((CONSTANT_Class_Info) this.constantPool[k]).nameIndex == ((CONSTANT_Class_Info) cp_info).nameIndex) {
						i = k;
					}
				}
			}
		}
			
		if (i != -1) {
			CP_Info[] acp_info1 = getConstantByTag(ConstantPoolAnalyzer.CONSTANT_Methodref);
			for (CP_Info cp_info : acp_info1) {
				if (((CONSTANT_Methodref_Info) cp_info).classIndex == i &&
						"forName".equals(((CONSTANT_Utf8_Info) this.constantPool[((CONSTANT_NameAndType_Info) this.constantPool[((CONSTANT_Methodref_Info) cp_info).nameAndTypeIndex]).nameIndex]).getBytesAsString()) &&
						"(Ljava/lang/String;)Ljava/lang/Class;".equals(((CONSTANT_Utf8_Info) this.constantPool[((CONSTANT_NameAndType_Info) this.constantPool[((CONSTANT_Methodref_Info) cp_info).nameAndTypeIndex]).descriptorIndex]).getBytesAsString())) {
					return true;
				}
			}
		}
		return false;
	}

	String getClassName() {
		return this.className;
	}

	private CP_Info[] getConstantByTag(short word0) {
		List<CP_Info> list = new ArrayList<>();
		for (int i = 1; i < this.constantPool.length; i++) {
			if (this.constantPool[i].tag == word0) {
				list.add(this.constantPool[i]);
			}
			if ((this.constantPool[i] instanceof CONSTANT_Long_Info) ||
				(this.constantPool[i] instanceof CONSTANT_Double_Info)) {
				i++;
			}
		}

		CP_Info[] acp_info = new CP_Info[list.size()];
		list.toArray(acp_info);
		return acp_info;
	}

	String[] getDependentClasses() {
		List<String> list = new ArrayList<>();
		CP_Info[] acp_info = getConstantByTag(ConstantPoolAnalyzer.CONSTANT_Class);
		for (CP_Info cp_info : acp_info) {
			list.add(((CONSTANT_Utf8_Info) this.constantPool[((CONSTANT_Class_Info) cp_info).nameIndex]).getBytesAsString());
		}

		String[] as = new String[list.size()];
		list.toArray(as);
		return as;
	}

	/**
	 * Finds all resource files used in the specified class.
	 *                                         vk2gpz/2000-Sep-08
	 */
	String[] getDependentResourceFiles() {
		List<String> list = new ArrayList<>();
		CP_Info[] acp_info = getConstantByTag(ConstantPoolAnalyzer.CONSTANT_String);
		for (CP_Info cp_info : acp_info) {
			list.add(((CONSTANT_Utf8_Info) this.constantPool[((CONSTANT_String_Info) cp_info).stringIndex]).getBytesAsString());
		}

		String[] as = new String[list.size()];
		list.toArray(as);
		return as;
	}
	
	@DebugLabel(key = "ClassFileStructure_getCP_Info")
	private CP_Info getCP_Info(DataInput datainput) throws IOException, ClassFormatError {
		boolean debug = DebugHandler.isDebugged("ClassFileStructure_getCP_Info");
		int i = datainput.readUnsignedByte();
		if (debug) {
			DebugHandler.getLogger("elmer").info(this.tagCount++ + " Tag: " + i + " -> ");
		}
		if (i == 0){
			System.out.println(" next = " + datainput.readUnsignedByte());
		}
		CP_Info obj;
		switch (i) {
		case ConstantPoolAnalyzer.CONSTANT_Class: // '\007'
			obj = new CONSTANT_Class_Info(datainput);
			break;

		case ConstantPoolAnalyzer.CONSTANT_Fieldref: // '\t'
			obj = new CONSTANT_Fieldref_Info(datainput);
			break;
		case ConstantPoolAnalyzer.CONSTANT_Methodref: // '\n'
			obj = new CONSTANT_Methodref_Info(datainput);
			break;
		case ConstantPoolAnalyzer.CONSTANT_InterfaceMethodref: // '\013'
			obj = new CONSTANT_InterfaceMethodref_Info(datainput);
			break;
		case ConstantPoolAnalyzer.CONSTANT_String: // '\b'
			obj = new CONSTANT_String_Info(datainput);
			break;
		case ConstantPoolAnalyzer.CONSTANT_Integer: // '\003'
			obj = new CONSTANT_Integer_Info(datainput);
			break;
		case ConstantPoolAnalyzer.CONSTANT_Float: // '\004'
			obj = new CONSTANT_Float_Info(datainput);
			break;
		case ConstantPoolAnalyzer.CONSTANT_Long: // '\005'
			obj = new CONSTANT_Long_Info(datainput);
			break;
		case ConstantPoolAnalyzer.CONSTANT_Double: // '\006'
			obj = new CONSTANT_Double_Info(datainput);
			break;
		case ConstantPoolAnalyzer.CONSTANT_NameAndType: // '\f'
			obj = new CONSTANT_NameAndType_Info(datainput);
			break;
		case ConstantPoolAnalyzer.CONSTANT_Utf8: // '\001'
			obj = new CONSTANT_Utf8_Info(datainput);
			break;
		case ConstantPoolAnalyzer.CONSTANT_UNKNOWN: // '\002'
		default:
			System.out.println("\nUnknown Constant Pool tag was found in class " + this.className + ". \"tagapparent value = " + i + "\")");
			throw new ClassFormatError();
		}
		if (debug) {
			DebugHandler.getLogger("elmer").info("obj: " + obj);
		}
		return obj;
	}

	public String toString() {
		StringBuilder stringbuffer = new StringBuilder();
		stringbuffer.append("_magic = ").append(this.magic).append(ConstantPoolAnalyzer.lineSeparator).append("_minor_version = ").append(this.minorVersion).append(ConstantPoolAnalyzer.lineSeparator).append("_major_version = ").append(this.majorVersion).append(ConstantPoolAnalyzer.lineSeparator);
		for (int i = 1; i < this.constantPool.length; i++) {
			stringbuffer.append("_constant_pool[").append(i).append("] = ").append(this.constantPool[i].toString());
			stringbuffer.append(ConstantPoolAnalyzer.lineSeparator);
			if ((this.constantPool[i] instanceof CONSTANT_Long_Info) ||
				(this.constantPool[i] instanceof CONSTANT_Double_Info)) {
				i++;
			}
		}

		stringbuffer.append("_access_flags = ").append(this.accessFlags).append(ConstantPoolAnalyzer.lineSeparator).append("_this_class = ").append(this.thisClass).append(ConstantPoolAnalyzer.lineSeparator).append("_super_class = ").append(this.superClass).append(ConstantPoolAnalyzer.lineSeparator);
		stringbuffer.append(this.interfaces.length).append(" interface(s)");
		stringbuffer.append(ConstantPoolAnalyzer.lineSeparator);
		for (int j = 0; j < this.interfaces.length; j++) {
			stringbuffer.append("_interfaces[").append(j).append("] = ").append(this.interfaces[j]);
			stringbuffer.append(ConstantPoolAnalyzer.lineSeparator);
		}

		stringbuffer.append(this.fields.length).append(" field(s)");
		stringbuffer.append(ConstantPoolAnalyzer.lineSeparator);
		for (int k = 0; k < this.fields.length; k++) {
			stringbuffer.append("_fields[").append(k).append("] = ").append(this.fields[k]);
			stringbuffer.append(ConstantPoolAnalyzer.lineSeparator);
		}

		stringbuffer.append(this.methods.length).append(" method(s)");
		stringbuffer.append(ConstantPoolAnalyzer.lineSeparator);
		for (int l = 0; l < this.methods.length; l++) {
			stringbuffer.append("_methods[").append(l).append("] = ").append(this.methods[l]);
			stringbuffer.append(ConstantPoolAnalyzer.lineSeparator);
		}

		stringbuffer.append(this.attributes.length).append(" attribute(s)");
		stringbuffer.append(ConstantPoolAnalyzer.lineSeparator);
		for (int i1 = 0; i1 < this.attributes.length; i1++) {
			stringbuffer.append("_attributes[").append(i1).append("] = ").append(this.attributes[i1]);
			stringbuffer.append(ConstantPoolAnalyzer.lineSeparator);
		}

		return stringbuffer.toString();
	}
}
