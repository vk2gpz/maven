/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */

import java.io.*;

import com.vk2gpz.elmer.debug.DebugHandler;
import com.vk2gpz.elmer.debug.DebugLabel;
import com.vk2gpz.elmer.logging.ColorConsoleLogger;

/*====================================================================
             Implementation of class ConstantPoolAnalyzer             
====================================================================*/

/**
 * ConstantPoolAnalyzer parses constant pool structure in .class file.
 *
 * @author vk2gpz (vk2gpz@gmail.com)
 * @version $Revision: 99 $
 */

@SuppressWarnings("unused")
class ConstantPoolAnalyzer {
    static final String lineSeparator = System.getProperties().getProperty("line.separator");

    /**
     * Constant Type defined in Java Virtual Machine Specification $4.4
     */
    public static final byte CONSTANT_Class = 7;
    public static final byte CONSTANT_Fieldref = 9;
    public static final byte CONSTANT_Methodref = 10;
    public static final byte CONSTANT_InterfaceMethodref = 11;
    public static final byte CONSTANT_String = 8;
    public static final byte CONSTANT_Integer = 3;
    public static final byte CONSTANT_Float = 4;
    public static final byte CONSTANT_Long = 5;
    public static final byte CONSTANT_Double = 6;
    public static final byte CONSTANT_NameAndType = 12;
    public static final byte CONSTANT_Utf8 = 1;
    public static final byte CONSTANT_MethodHandle = 15;
    public static final byte CONSTANT_MethodType = 16;
    public static final byte CONSTANT_InvokeDynamic = 18;
    public static final byte CONSTANT_UNKNOWN = 2;
    public static final byte CONSTANT_Unknown = 127;

    /**
     * String representation of the Constant Types.
     */
    public static final String CONSTANT_Class_String = "CONSTANT_Class";
    public static final String CONSTANT_Fieldref_String = "CONSTANT_Fieldref";
    public static final String CONSTANT_Methodref_String = "CONSTANT_Methodref";
    public static final String CONSTANT_InterfaceMethodref_String = "CONSTANT_InterfaceMethodref";
    public static final String CONSTANT_String_String = "CONSTANT_String";
    public static final String CONSTANT_Integer_String = "CONSTANT_Integer";
    public static final String CONSTANT_Float_String = "CONSTANT_Float";
    public static final String CONSTANT_Long_String = "CONSTANT_Long";
    public static final String CONSTANT_Double_String = "CONSTANT_Double";
    public static final String CONSTANT_NameAndType_String = "CONSTANT_NameAndType";
    public static final String CONSTANT_Utf8_String = "CONSTANT_Utf8";
    public static final String CONSTANT_MethodHandle_String = "CONSTANT_MethodHandle";
    public static final String CONSTANT_MethodType_String = "CONSTANT_MethodType";
    public static final String CONSTANT_InvokeDynamic_String = "CONSTANT_InvokeDynamic";
    public static final String CONSTANT_Unknown_String = "unknown";
    static final String[] constantNames = {
            CONSTANT_Utf8_String,    // 1
            CONSTANT_Unknown_String, // 127
            CONSTANT_Integer_String, // 3
            CONSTANT_Float_String,    // 4
            CONSTANT_Long_String,    // 5
            CONSTANT_Double_String,    // 6
            CONSTANT_Class_String,    // 7
            CONSTANT_String_String,    // 8
            CONSTANT_Fieldref_String, // 9
            CONSTANT_Methodref_String, // 10
            CONSTANT_InterfaceMethodref_String,    // 11
            CONSTANT_NameAndType_String,    // 12
            CONSTANT_Unknown_String, // 13
            CONSTANT_Unknown_String, // 14
            CONSTANT_MethodHandle_String,    // 15
            CONSTANT_MethodType_String,    // 16
            CONSTANT_Unknown_String, // 17
            CONSTANT_InvokeDynamic_String    // 18
    };

    /**
     * Access Flag Names and values defined in Java Virtual Machine
     * Specification $4.1, $4.5, $4.6
     */
    public static final short ACC_PUBLIC = 0x0001; // 1
    public static final short ACC_PRIVATE = 0x0002;    // 2
    public static final short ACC_PROTECTED = 0x0004; // 4
    public static final short ACC_STATIC = 0x0008; // 8
    public static final short ACC_FINAL = 0x0010; // 16
    public static final short ACC_SYNCHRONIZED = 0x0020; // 32
    public static final short ACC_VOLATILE = 0x0040; // 64
    public static final short ACC_TRANSIENT = 0x0080; // 128
    public static final short ACC_NATIVE = 0x0100; // 256
    public static final short ACC_ABSTRACT = 0x0400; // 1024
    public static final short ACC_STRICT = 0x0800; // 1024
    public static final short ACC_SYNTHETIC = 0x1000; // 4096
    public static final short ACC_ENUM = 0x4000; // 16384

    /**
     * String representation of the Access Flag.
     */
    public static final String ACC_PUBLIC_String = "PUBLIC";
    public static final String ACC_PRIVATE_String = "PRIVATE";
    public static final String ACC_PROTECTED_String = "PROTECTED";
    public static final String ACC_STATIC_String = "STATIC";
    public static final String ACC_FINAL_String = "FINAL";
    public static final String ACC_SYNCHRONIZED_String = "SYNCHRONIZED";
    public static final String ACC_VOLATILE_String = "VOLATILE";
    public static final String ACC_TRANSIENT_String = "TRANSIENT";
    public static final String ACC_NATIVE_String = "NATIVE";
    public static final String ACC_ABSTRACT_String = "ABSTRACT";
    public static final String ACC_STRICT_String = "STRICT";
    public static final String ACC_SYNTHETIC_String = "SYNTHETIC";
    public static final String ACC_ENUM_String = "ENUM";

    private final CustomClassFileLoader cfl;
    private ClassFileStructure classfileCache;

    public ConstantPoolAnalyzer(CustomClassFileLoader classFileLoader) {
        this.cfl = classFileLoader;
    }

    public ConstantPoolAnalyzer(String s) {
        this(new JBeansClassFileLoader(s));
    }

    public ConstantPoolAnalyzer() {
        this(new JBeansClassFileLoader());
    }

    public final boolean isForClass(String s) throws IOException, ClassNotFoundException {
        return getClassFileStructureFor(s).isForClass();
    }

    // ...existing code...
    
    public static String getAccessFlagAsString(short word0) {
		// Pre-computed flag string arrays - significantly faster than StringBuilder approach
		StringBuilder stringbuffer = new StringBuilder(256); // Pre-allocate expected capacity
        if ((word0 & ACC_PUBLIC) != 0) {
            stringbuffer.append("PUBLIC ");
        }
        if ((word0 & ACC_PRIVATE) != 0) {
            stringbuffer.append("PRIVATE ");
        }
        if ((word0 & ACC_PROTECTED) != 0) {
            stringbuffer.append("PROTECTED ");
        }
        if ((word0 & ACC_STATIC) != 0) {
            stringbuffer.append("STATIC ");
        }
        if ((word0 & ACC_FINAL) != 0) {
            stringbuffer.append("FINAL ");
        }
        if ((word0 & ACC_SYNCHRONIZED) != 0) {
            stringbuffer.append("SYNCHRONIZED ");
        }
        if ((word0 & ACC_VOLATILE) != 0) {
            stringbuffer.append("VOLATILE ");
        }
        if ((word0 & ACC_TRANSIENT) != 0) {
            stringbuffer.append("TRANSIENT ");
        }
        if ((word0 & ACC_NATIVE) != 0) {
            stringbuffer.append("NATIVE ");
        }
        if ((word0 & ACC_ABSTRACT) != 0) {
            stringbuffer.append("ABSTRACT ");
        }
        if ((word0 & ACC_STRICT) != 0) {
            stringbuffer.append("STRICT ");
        }
        if ((word0 & ACC_SYNTHETIC) != 0) {
            stringbuffer.append("SYNTHETIC ");
        }
        if ((word0 & ACC_ENUM) != 0) {
            stringbuffer.append("ENUM ");
        }

        // Early exit if no flags were set
        int len = stringbuffer.length();
        return len > 0 ? stringbuffer.substring(0, len - 1) : "";  // Trim trailing space
    }

    public static String getConstantTagAsString(short word0) {
        // Array bounds check with early return for unknown types
        if (word0 < 1 || word0 > constantNames.length) {
            return CONSTANT_Unknown_String;
        }
        return constantNames[word0 - 1];
    }

    public final String[] getDependentClasses(String s) throws IOException, ClassNotFoundException {
        ClassFileStructure classfile1 = getClassFileStructureFor(s);
        String[] as = classfile1.getDependentClasses();
        for (int i = 0; i < as.length; i++) {
            as[i] = as[i].replace('/', '.');
        }
        return as;
    }

    /**
     * vk2gpz/2000-Sep-08
     */
    public final String[] getDependentResourceFiles(String s) throws IOException, ClassNotFoundException {
        ClassFileStructure classfile1 = getClassFileStructureFor(s);
        return classfile1.getDependentResourceFiles();
    }

    public final ClassFileStructure getClassFileStructureFor(String s) throws IOException, ClassNotFoundException {
        if (this.classfileCache == null ||
                !this.classfileCache.getClassName().equals(s)) {
            this.classfileCache = new ClassFileStructure(s, new DataInputStream(this.cfl.getClass(s)));
        }
        return this.classfileCache;
    }

    @DebugLabel(key = "ConstantPoolAnalyzer_main")
    public static void main(String[] args) {
        boolean debug = DebugHandler.isDebugged("ConstantPoolAnalyzer_main");
        if (args.length == 0) {
            System.out.println("Usage : java geovista.lang.loader.ConstantPoolAnalyzer [-verbose] <fully qualified class name>");
            System.exit(0);
        }
        int i = 0;
        if (args.length > 1) {
            if (args[0].equals("-verbose")) {
                System.setProperty("net.jbeans.lang.loader.ConstantPoolAnalyzer", "true");
            }
            i++;
        }

        ConstantPoolAnalyzer constantPoolAnalyzer = new ConstantPoolAnalyzer();
        try {
            ClassFileStructure classfile = constantPoolAnalyzer.getClassFileStructureFor(args[i]);
            if (debug) {
                DebugHandler.getLogger("elmer").info(String.valueOf(classfile));
                DebugHandler.getLogger("elmer").info("Dependent classes: ");
                String[] classes = classfile.getDependentClasses();
                for (String aClass : classes) {
                    DebugHandler.getLogger("elmer").info(aClass);
                }
                String[] resources = classfile.getDependentResourceFiles();
                for (String resource : resources) {
                    DebugHandler.getLogger("elmer").info(resource);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
