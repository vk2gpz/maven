/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

/*====================================================================
               Implementation of class CONSTANT_LD_Info               
====================================================================*/
/**
 * CONSTANT_LD_Info is an abstract class for CONSTANT_Long_info and
 * CONSTANT_Double_info structure defined in VM Spec $4.4.5
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see CP_Info
 */

class CONSTANT_LD_Info extends CP_Info {
	int highBytes;
	int lowBytes;
	
	/**
	 * Constructs a new CONSTANT_LD_info object
	 */
	CONSTANT_LD_Info(byte byte0, DataInput datainput) throws IOException {
		super(byte0);
		this.highBytes = datainput.readInt();
		this.lowBytes = datainput.readInt();
	}
	
	public String toString() {
		return super.toString() + ", _high_bytes = " + this.highBytes + ", _low_bytes = " + this.lowBytes + "]";
	}
}
