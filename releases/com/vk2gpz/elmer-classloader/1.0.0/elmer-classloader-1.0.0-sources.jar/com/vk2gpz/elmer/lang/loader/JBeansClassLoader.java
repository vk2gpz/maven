/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */

import java.io.*;
import java.net.*;
import java.awt.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.util.*;
import java.util.List;
import java.util.jar.*;
import java.util.zip.*;

import com.vk2gpz.elmer.debug.DebugHandler;
import com.vk2gpz.elmer.io.FilenameUtil;
import com.vk2gpz.elmer.io.InputStreamProducer;
import com.vk2gpz.elmer.util.jar.JarClassLoader;

/*====================================================================
              Implementation of class JBeansClassLoader               
====================================================================*/

/**
 * This class is used to load classes and resources from:
 * 1) the system classes/resources (CLASSPATH)
 * 2) specific files
 * 3) JAR files
 *
 * @author vk2gpz (vk2gpz@gmail.com)
 * @version $Revision: 162 $
 * @see ClassLoader
 */

@SuppressWarnings("unused")
public class JBeansClassLoader extends ClassLoader {
	/**
	 * debug flag
	 */
	private static final boolean DEBUG = DebugHandler.isDebugged(JBeansClassLoader.class);
	
	/*
	 * The only JBeansClassLoader we actually instantiate
	 */
	public static JBeansClassLoader sLoader;
	
	public static final String URL_PREFIX = "JBeans";
	public static final String DEFAULT_COOKIE = "DEFAULT_LOADER";
	private static final boolean sKeepLoading = true; // aggresively load classes
	private String cookie;
	
	/*
	 * all instances, by cookie.  We really only instantiate one, see next, but
	 * we are leaving the machinery around in case we need it again later
	 */
	private static final Map<String, JBeansClassLoader> sLoaders = new HashMap<>();
	
	/**
	 * A hash table of AppletClassEntry's that define .class files in their
	 * raw form.  We <B>do not</B> define these classes immediately
	 * in defineClassFromBytecode(), instead the byte arrays are kept
	 * around and classes are defined lazily on demand, and the byte
	 * array is removed from the HashMap at that time.
	 * <BR>
	 * By defining classes lazily, we prevent the case where a
	 * derived class was found in a jar before its super class also
	 * in the jar.  The derived class cannot be defined before it's
	 * super class has even been loaded from the archive.
	 * <BR>
	 * classes are hashed by fully qualified name - "my.package.MyApplet"
	 */
	private HashMap<String, byte[]> bytecodes;
	
	/*
	 * Additional directory from where to look for resources...
	 * (after CLASSPATH and loaded JARs).
	 * -- currently unused --
	 */
	private String localResourceDirectory;
	
	/*
	 * Overrides for local resources
	 */
	private HashMap<String, InputStreamProducer> localOverrides;
	
	/**
	 * Resource and Mime Type HashTables
	 */
	private HashMap<String, Object> resourceHash;
	private HashMap<String, String> mimeHash;
	
	/**
	 * Classpath to search for class files.
	 */
	private HashMap<String, Object> classPath;
	
	/**
	 *
	 */
	private PermissionCollection permissionCollection;
	
	/*
	 * Initialization of statics
	 */
	static {
		// Add this protocol type to the http properties
		String protocolPathProp = "java.protocol.handler.pkgs";
		Properties newP = new Properties(System.getProperties());
		newP.put(protocolPathProp,
				newP.getProperty(protocolPathProp) + "|net.jbeans.lang.loader");
		System.setProperties(newP);
		
		// *The* loader instance
		sLoader = (JBeansClassLoader) createLoader(DEFAULT_COOKIE, null);
	}
	
	private JarClassLoader jarCl;
	
	/**
	 * Create a SipleClassLoader.  It is identified by a cookie string
	 */
	public JBeansClassLoader() {
		this(null);
	}
	
	/**
	 * Create a SipleClassLoader.  It is identified by a cookie string
	 */
	public JBeansClassLoader(ClassLoader parent) {
		super(parent);
		initialize();
	}
	
	/**
	 * Create a SipleClassLoader.  It is identified by a cookie string
	 */
	public JBeansClassLoader(String cookie, String dir) {
		this(null, cookie, dir);
	}
	
	public JBeansClassLoader(ClassLoader parent, String cookie, String dir) {
		this(parent, cookie, dir, null);
	}
	
	public JBeansClassLoader(ClassLoader parent, String cookie, String dir, PermissionCollection permissionCollection) {
		this(parent);
		this.cookie = cookie;
		if (DEBUG) {
			System.out.println("cookie = " + this.cookie);
		}
		this.localResourceDirectory = dir;
		this.localOverrides = new HashMap<>();
		this.resourceHash = new HashMap<>();
		this.mimeHash = new HashMap<>();
		this.bytecodes = new HashMap<>();
		sLoaders.remove(this.cookie);
		sLoaders.put(this.cookie, this);
		this.permissionCollection = permissionCollection;
	}
	
	private void initialize() {
		this.classPath = new HashMap<>();//Object[st.countTokens()];
		this.jarCl = null;
	}
	
	public void setClassPath(String classPath) {
		parseClassPath(classPath, true);
	}
	
	public void addClassPath(String classPath) {
		parseClassPath(classPath, false);
	}
	
	public URL[] getClassPath() {
		URL[] urls = new URL[]{};
		if (this.jarCl != null) {
			urls = this.jarCl.getURLs();
		}
		return urls;
	}
	
	private void resetJarClassLoader(boolean reset) {
		if (reset) {
			this.jarCl = null;
		} else {
			if (this.jarCl != null) {
				URL[] urls = this.jarCl.getURLs();
				this.jarCl = new JarClassLoader(urls, getParent());
				if (this.permissionCollection != null) {
					this.jarCl.setPermissionCollection(this.permissionCollection);
				}
			}
		}
	}
	
	/**
	 * Parse the specified classpath.  The classpath can contain
	 * directories and/or zip/jar-files.
	 *
	 * @param classPath The classpath to use for this loader.
	 */
	private void parseClassPath(String classPath, boolean reset) {
		/* each element of the classpath is delimited by the current
		   operating system's path separator
		*/
		StringTokenizer st = new StringTokenizer(classPath, System.getProperty("path.separator"));

		/* store the individual elements in a hashtable to speed things up
		   during loading
		*/
		if (reset) {
			this.classPath.clear();
			this.jarCl = null;
			if (DEBUG) {
				System.out.println("rsetting jar class loader.");
			}
			//resetJarClassLoader(reset);
		}
		if (DEBUG) {
			System.out.println("classPath = " + classPath);
		}
		int index = 0;
		String path;
		while (st.hasMoreTokens()) {
			path = st.nextToken();
			if (DEBUG) {
				System.out.println("new path: " + path);
			}
			if (!this.classPath.containsKey(path)) {
				Object pathObject = initPath(path);
				if (pathObject != null) {
					this.classPath.put(path, pathObject);
				}
				File file = null;
				if (pathObject instanceof ZipFile) {
					file = new File(path);
				} else if (pathObject instanceof File) {
					file = (File) pathObject;
				}
				if (file != null) {
					try {
						URL url = file.toURI().toURL();
						if (this.jarCl == null) {
							this.jarCl = new JarClassLoader(url, getParent());
							if (this.permissionCollection != null) {
								this.jarCl.setPermissionCollection(this.permissionCollection);
							}
						} else {
							this.jarCl.addJarFile(url);
						}
					} catch (Exception ex) {
						if (DEBUG) {
							ex.printStackTrace();
						}
						//NOP
					}
				}
			}
		}
	}
	
	/**
	 * Initializes a path entry.  Directories and zip/jar files are supported.
	 *
	 * @param name Path name of the entry.
	 * @return An Object representing a classpath entry.
	 */
	private Object initPath(String name) {
		// check if this entry is a zip-file
		String suffix = FilenameUtil.getExtension(name);
		if (DEBUG) {
			System.out.println("suffix = " + suffix);
		}
		if (suffix.equalsIgnoreCase("zip") || suffix.equalsIgnoreCase("jar")) {
			return initZipFile(name, suffix);
		} else { // if not, assume it is a directory
			return initDirectory(name);
		}
	}
	
	/**
	 * Initialize a directory accessible on the local filesystem.
	 *
	 * @param name Name of the directory.
	 * @return A File representing the directory.
	 */
	private File initDirectory(String name) {
		File dir = null;
		try {
			// open directory
			dir = new File(name);
			
			// ensure a directory was opened.
			if (!dir.isDirectory()) {
				throw new IOException();
			}
		} catch (IOException ignore) {
		
		}
		return dir;
	}
	
	/**
	 * Initialize a zip-file accessible on the local filesystem.
	 *
	 * @param name Name of the Zip-file
	 * @return A ZipFile representing the Zip classpath entry.
	 */
	private ZipFile initZipFile(String name, String suffix) {
		ZipFile zip = null;
		try {
			if (suffix.equalsIgnoreCase("jar")) {
				// open and return the requested zipfile
				zip = new JarFile(name);
			} else if (suffix.equalsIgnoreCase("zip")) {
				// open and return the requested zipfile
				zip = new ZipFile(name);
			}
		} catch (IOException ioe) {
			// null if the file could not be found
		}
		if (zip != null) {
			File file = new File(zip.getName());
			if (!file.exists()) {
				zip = null;
			}
		}
		return zip;
	}
	
	/**
	 * Set some bytecodes as a definition for a class.
	 * Do not actually define the class until later
	 */
	public void defineClassFromBytecode(String name, byte[] buf) {
		if (DEBUG) {
			System.out.println("new bytecode = (" + name + ", " + Arrays.toString(buf) + ")");
		}
		this.bytecodes.put(name, buf);
	}
	
	/**
	 * Define (& link) a class based on what was acquired previously in the
	 * JAR file. Should catch all exceptions and return non-null iff
	 * definition is valid
	 */
	@SuppressWarnings("SameParameterValue")
	private Class<?> applyDefinition(String name, boolean resolve) {
		byte[] buf = this.bytecodes.get(name);
		this.bytecodes.remove(name); // release the bytecodes...
		if (DEBUG) {
			System.out.println("JBeansClassLoader.applyDefinition(String, boolean): buf = " + Arrays.toString(buf));
		}
		if (buf == null) {
			return null;
		} else {
			Class<?> c;
			try {
				c = super.defineClass(null, buf, 0, buf.length, null);
				if (c != null && resolve) {
					resolveClass(c);
				}
			} catch (ClassFormatError e) {
				System.err.println("The definition for " + name + " in the JAR file");
				System.err.println("has a format error.");
				return null;
			} catch (NoClassDefFoundError e) {
				return null;
			}
			// Check that the loaded class has the name we expect
			assert c != null;
			if (!c.getName().equals(name)) {
				System.err.println("\nWARNING: file name versus class name mismatch");
				String fname = name.replace('.', '/') + ".class";
				System.err.println("    JAR entry \"" + fname + "\" was expected "
						+ "to contain class \"" + name + "\"");
				System.err.println("    but instead contained class \"" + c.getName() + "\"");
				System.err.println("    This may cause future class-loading problems.\n");
			}
			return c;
		}
	}
	
	/**
	 * Define a class from a file
	 */
	private static byte[] getByteArray(String fileName) throws IOException {
		File f = new File(fileName);
		int length = (int) f.length();
		byte[] buff = new byte[length];
		
		InputStream is = Files.newInputStream(Paths.get(fileName));
		int read = 0;
		while (read < length) {
			int r = is.read(buff, read, length - read);
			if (r < 0) {
				break;
			}
			read += r;
		}
		is.close();
		return buff;
	}
	
	/**
	 * Helper function; load a class from a file
	 */
	public Class<?> loadClassFromFile(String fileName) throws ClassNotFoundException {
		InputStream is;
		try {
			byte[] buf = getByteArray(fileName);
			Class<?> c = super.defineClass(null, buf, 0, buf.length, null);
			if (c != null) {
				resolveClass(c);
			}
			if (c == null) {
				throw new ClassNotFoundException(fileName);
			}
			return c;
		} catch (Exception ex) {
			if (DEBUG) {
				System.out.println("LoadFromFile/caught " + ex + " when loading from file " + fileName);
			}
			throw new ClassNotFoundException(fileName);
		}
	}
	
	protected Class<?> findClass(String name) throws ClassNotFoundException {
		Class<?> cl = null;
		if (DEBUG) {
			System.out.println("JBeansClassLoader.findClass(String):name = " + name);
		}
		if (this.bytecodes.get(name) != null) { // try to load the class from the JAR:
			cl = applyDefinition(name, true);
		} else {
			try {
				cl = findSystemClass(name); // try the system classloader:
			} catch (ClassNotFoundException ex) {
				//NOP..let go!
			}
		}
		
		// if the class is still not found, try to custom-load it
		if (cl == null) {
			// try each classpath entry
			if (this.jarCl != null) {
				cl = this.jarCl.loadClass(name);
			}
			if (cl != null) {
				return cl;
			}
		} else {
			return cl;
		}
		
		// failure
		throw new ClassNotFoundException("Cannot load class: " + name);
	}
	
	/**
	 * Interface to Beans.instantiate.
	 * Name is that of the bean.
	 * The stream producer provides the serialized representation of the bean
	 */
	public Object instantiate(String name, InputStreamProducer isp)
			throws ClassNotFoundException, IOException {
		String sname = name.replace('.', '/');
		Object back;
		try {
			setLocalResourceSource(sname + ".ser", isp);
			back = java.beans.Beans.instantiate(this, name);
		} finally {
			this.localOverrides.remove(sname + ".ser");
		}
		return back;
	}
	
	
	/* ---------------------- The resource stuff ---------------------- */
	
	/**
	 * Assign an InputStream as the source for a given property name
	 * This value comes first after the system resources
	 */
	// This method can be private
	public void setLocalResourceSource(String name, InputStreamProducer isp) {
		this.localOverrides.put(name, isp);
	}
	
	public void putClassResource(String name, String type) {
		this.resourceHash.put(name, "A CLASS FILE");
		this.mimeHash.put(name, type);
	}
	
	public void putLocalResource(String name, byte[] data, String type) {
		if (DEBUG) {
			System.out.println("adding: " + name + " to local resource");
		}
		this.resourceHash.put(name, data);
		this.mimeHash.put(name, type);
	}
	
	protected URL findResource(String name) {
		if (DEBUG) {
			System.out.println("findResource().trying to find: " + name);
		}
		URL back;
		back = super.findResource(name);
		if (back == null) {
			back = getLocalResource(name);
		}
		if (back == null) {
			// try each classpath entry
			if (this.jarCl != null) {
				back = this.jarCl.findResource(name);
			}
			if (back != null) {
				return back;
			}
		}
		
		return back;
	}
	
	/**
	 * Return a URL to the desired resource.
	 */
	private URL getLocalResource(String name) {
		if (DEBUG) {
			System.out.println("trying to find: " + name);
		}
		// Check if there is an override
		Object o;
		o = this.localOverrides.get(name);
		if (o == null) {
			// Check on the JAR objects
			o = this.resourceHash.get(name);
			
		}
		if (DEBUG) {
			System.out.println("I found : " + o);
		}
		if (o == null && this.localResourceDirectory != null) {
			// Try in _localResourceDirectory
			File f = new File(this.localResourceDirectory, name);
			if (f.exists()) {
				o = Integer.valueOf("1"); // anything will do
			}
		}
		if (o != null) {
			// Create a URL to refer to this resource
			try {
				return new URL("resource",
						"",
						"/" + URL_PREFIX +
								this.cookie + "/+/" + name);
			} catch (Exception e) {
				if (DEBUG) {
					System.out.println("Exception " + e + " while building a resource URL");
				}
				return null;
			}
		}
		return null;
	}
	
	public InputStream getResourceAsStream(String name) {
		InputStream back = super.getResourceAsStream(name);
		if (back != null) {
			return back;
		}
		return getLocalResourceAsStream(name);
	}
	
	private InputStream getLocalResourceAsStream(String name) {
		Object o;
		// Check if there is an override
		o = this.localOverrides.get(name);
		if (o != null) {
			return ((InputStreamProducer) o).getInputStream();
		}
		// Check data loaded from JAR
		o = this.resourceHash.get(name);
		
		if (o != null) {
			if (o instanceof String) {
				// This is a .class entry...
				// no access to .class files through getResource() in 1.1
				throw new SecurityException("No access through getResource() to .class in 1.1");
			}
			
			byte[] buf = (byte[]) o;
			return new ByteArrayInputStream(buf);
		}
		if (this.localResourceDirectory != null) {
			// Now try in _localResourceDirectory
			File f = new File(this.localResourceDirectory, name);
			try {
				return Files.newInputStream(f.toPath());
			} catch (Exception ex) {
				return null;
			}
		}
		return null;
	}
	
	public static ClassLoader createLoader(String cookie,
										   String dir) {
		JBeansClassLoader back = (JBeansClassLoader) getLoader(cookie);
		if (back != null) {
			if (!back.localResourceDirectory.equals(dir)) {
				throw new Error("internal error!");
			}
			return back;
		} else {
			return new JBeansClassLoader(cookie, dir);
		}
	}
	
	public static void removeLoader(String cookie) {
		sLoaders.remove(cookie);
	}
	
	public static ClassLoader getLoader(String cookie) {
		return sLoaders.get(cookie);
	}
	
	public static void setSharedLoader(JBeansClassLoader loader) {
		sLoader = loader;
	}
	
	public static ClassLoader getLoader() {
		if (sLoader == null) {
			sLoader = (JBeansClassLoader) getLoader(DEFAULT_COOKIE);
		}
		return sLoader;
	}
	
	// get the local resource object...
	public static Object getLocalResource(String cookie,
										  String name) {
		JBeansClassLoader cl = (JBeansClassLoader) getLoader(cookie);
		
		// Check if there is an override
		Object o = cl.localOverrides.get(name);
		if (o != null) {
			return ((InputStreamProducer) o).getInputStream();
		}
		// Check data loaded from JAR
		String type = cl.mimeHash.get(name);
		if (type != null) {
			// Came from JAR
			o = cl.resourceHash.get(name);
			
			if (o instanceof String) {
				// This is a .class entry...
				// no access to .class files through getResource() in 1.1
				throw new SecurityException("No access through getResource() to .class in 1.1");
			}
			
			byte[] buf = (byte[]) o;
			if (type.startsWith("image")) {
				return ((Toolkit.getDefaultToolkit()).createImage(buf)).getSource();
			} else {
				return new ByteArrayInputStream(buf);
			}
		}
		if (cl.localResourceDirectory != null) {
			// Check into _localResourceDirectory
			File f = new File(cl.localResourceDirectory, name);
			if (f.exists()) {
				try {
					URL url = new URL("file",
							"",
							f.getAbsolutePath());
					return url.getContent();
				} catch (Exception e) {
					throw new Error("no such resource"); // should it be a security error?
				}
			}
		}
		return null;
	}
	
	// REMIND - simplify the whole cookie thing.
	public static InputStream getLocalResourceAsStream(String cookie,
													   String name) {
		JBeansClassLoader cl = (JBeansClassLoader) getLoader(cookie);
		return cl.getLocalResourceAsStream(name);
	}
	
	/**
	 * Define a class from the bytecodes that were collected early...
	 * Will return false if there were problems applying the definitions
	 * <p>
	 * This is only invoked if we are defining classes up front.
	 * Code will be removed if we don't discover any problems in testing.
	 */
	public synchronized boolean applyDefinitions(List<String> classList) {
		// go through the bytecode arrays defininng.
		// NOTE: sometimes a forward reference forces a class
		// to get defined early; in that case, skip it!
		
		boolean back = true;
		for (String classname : classList) {
			Class<?> c = findLoadedClass(classname);
			if (c == null) {
				// Not yet defined, do so.
				c = applyDefinition(classname, true);
				if (c == null) {
					if (back) {
						System.err.println("NOTE: There are classes that cannot be defined in this JAR file");
						System.err.println("    Some of these classes will cause the failure of defining or linking ");
						System.err.println("    other classes that depend on them.");
						if (sKeepLoading) {
							System.err.println("NOTE: To simplify debugging JAR files, we will proceed loading classes");
							System.err.println("    although this may lead eventually to an UnknownError or the like");
							System.err.println();
						}
					}
					System.err.println("Class " + classname + " could not be defined from JAR file");
					back = false;
				}
			}
		}
		return back;
	}
}
