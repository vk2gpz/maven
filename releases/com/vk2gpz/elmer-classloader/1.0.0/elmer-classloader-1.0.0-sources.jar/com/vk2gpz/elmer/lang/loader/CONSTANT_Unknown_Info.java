/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
            Implementation of class CONSTANT_Unknown_Info             
====================================================================*/
/**
 * CONSTANT_Unknown_Info represents CONSTANT_unknown_info
 * structure which is not defined in VM Spec.
 * 
 * @version $Revision: 99 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see CP_Info
 */

@SuppressWarnings("unused")
final class CONSTANT_Unknown_Info extends CP_Info {
	/**
	 * Constructs a new CONSTANT_Unknown_Info object
	 */
	CONSTANT_Unknown_Info() {
		super(ConstantPoolAnalyzer.CONSTANT_Unknown);
	}
	
	public String toString() {
		return super.toString() + " (UNKNOWN)]";
	}
}

