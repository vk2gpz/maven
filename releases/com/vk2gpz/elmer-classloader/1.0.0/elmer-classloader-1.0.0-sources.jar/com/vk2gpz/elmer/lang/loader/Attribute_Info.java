/*
 * Copyright (c) 2002 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.lang.loader;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;
import java.util.Arrays;

/*====================================================================
                Implementation of class Attribute_Info                
====================================================================*/
/**
 * Attribute_Info represents attribute_info structure defined in
 * VM Spec $4.7.
 * 
 * @version $Revision: 99 $
 * @author vk2gpz@gmail.com
 */

final class Attribute_Info {
	short attributeNameIndex;
	// attribute_length = info.length
	byte[] info;
	
	/**
	* Constructs a new Attribute_Info object.
	*/
	Attribute_Info(DataInput datainput) throws IOException {
		this.attributeNameIndex = datainput.readShort();
		int i = datainput.readInt();
		this.info = new byte[i];
		//noinspection ResultOfMethodCallIgnored
		((DataInputStream)datainput).read(this.info);
	}
	
	public String toString() {
		return "_attribute_name_index = " +	this.attributeNameIndex +
			", _info = " + Arrays.toString(this.info);
	}
}
