/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp;

/* ------------------ Import classes (packages) ------------------- */

import com.vk2gpz.elmer.script.lisp.datatype.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

/*====================================================================
                    Implementation of class LReader                    
====================================================================*/

/**
 * generally describe LReader in here
 *
 * @author vk2gpz (vk2gpz@gmail.com)
 * @version $Revision: 1.1 $
 */

public final class LReader {
	static final int MAX_BUFF_SIZE = 256;
	
	SExpression nil;
	SExpression endOfRead;
	BufferedReader br = null;
	PrintWriter pw = null;
	boolean promptFlag = true;
	private String line = null;  // line string
	private char[] charBuff = null;
	private int lineLength = 0;
	private int indexOfLine = 0;
	
	public LReader() {
		this.line = "";
		this.charBuff = new char[MAX_BUFF_SIZE];
	}
	
	public void init(BufferedReader br, PrintWriter pw, boolean prompt) {
		this.lineLength = 0;
		this.indexOfLine = 0;
		this.br = br;
		this.pw = pw;
		this.promptFlag = prompt;
	}
	
	// reading method.
	public SExpression read() throws Exception {
		if (!skipSpace()) {
			return new Nil();
		}
		
		char ch = this.charBuff[this.indexOfLine];
		char ch2 = this.charBuff[this.indexOfLine + 1];
		char ch3 = this.charBuff[this.indexOfLine + 1 + 1];
		
		if (isEscape(ch)) {
			return escape();
		} else if (isDigit(ch, ch2, ch3)) {
			return makeNumber();
		} else if (ch == '"') {
			return makeString();
		} else         //if (isSymbol(ch))
			return makeSymbol();
		//    else
		//      return new Nil();
	}
	
	// skip spaces and obtain token.
	// process tasks like prompting and simple QUOTE as well
	private boolean skipSpace() throws IOException {
		char ch = 0;
		int i;
		
		for (; ; ) {
			// remove space char.
			for (i = this.indexOfLine; i < this.lineLength; i++) {
				ch = this.charBuff[i];
				// Use direct character check instead of Character.isWhitespace() for performance
				if (ch != ' ' && ch != '\t' && ch != '\n' && ch != '\r') {
					break;
				}
				this.indexOfLine++;
			}
			
			// if it is token return true;
			if (ch != '\0' && ch != ';') {
				return true;
			}
			
			// display a prompt and read a new line.
			if (this.promptFlag) {
				this.pw.write("JBeanLisp> ");
				this.pw.flush();
			}
			if ((this.line = this.br.readLine()) == null) {
				return false;
			}
			this.indexOfLine = 0;
			
			// convert to upper case and copy the line to the buffer.
			this.line = this.line.toUpperCase();
			checkComment(); // process comments.
			this.lineLength = this.line.length();
			this.line.getChars(0, this.lineLength, this.charBuff, 0);
			cutTailSpace(); // remove the traling spaces.
			this.charBuff[this.lineLength] = '\0';
		}
	}
	
	// skip the comment line.
	private void checkComment() {
		int index = this.line.indexOf(';');
		if (index >= 0) {
			// Only update line if comment found (avoid unnecessary substring when no comment)
			this.line = this.line.substring(0, index);
		}
	}
	
	// discard the spaces at the end.
	private void cutTailSpace() {
		char ch;
		for (int i = this.lineLength - 1; i >= 0; i--) {
			ch = this.charBuff[i];
			// Use direct character comparison instead of isWhitespace() call for tight loop
			if (ch != ' ' && ch != '\t' && ch != '\n' && ch != '\r') {
				this.lineLength = i + 1;
				return;
			}
		}
		this.lineLength = 0;
	}
	
	private static boolean isEscape(char ch) {
		switch (ch) {
			case ' ':
			case '#':
			case '.':
			case ';':
			case '(':
			case ')':
			case '[':
			case ']':
			case '\\':
			case '^':
			case ',':
			case '|':
			case '\'':
				return true;
			default:
				return false;
		}
	}
	
	private static boolean isDigit(char ch, char ch2, char ch3) {
		//System.out.println("ch, ch2, ch3 =" + ch +", "+ch2+", " +ch3);
		if (Character.isDigit(ch) &&
				(isEscape(ch2) || ch2 == '\0' || Character.isDigit(ch2))) {
			return true;
		}
		if (ch == '-' || ch == '+') {
			return Character.isDigit(ch2) &&
					(isEscape(ch3) || ch3 == '\0' || Character.isDigit(ch3));
		}
		return false;
	}
	
	private SExpression escape() throws Exception {
		char ch;
		ch = this.charBuff[this.indexOfLine++];
		switch (ch) {
			case '(':
			case '[':
				return makeList();
			case '\'':
				return makeQuote();   // process QUOTE
			case '\\':
			case '|':
			default:
				return new Nil();
			
			case '.':            // dotted list
				Nil dot = new Nil();
				char[] chs = {ch};
				dot.addDottedCdr(new Symbol(chs));
				return dot;
		}
	}
	
	private SExpression makeNumber() throws Exception {
		char ch = this.charBuff[this.indexOfLine++];
		boolean realType = false;
		
		StringBuilder str = new StringBuilder();
		do {
			str.append(ch);
			ch = this.charBuff[this.indexOfLine++];
		} while (Character.isDigit(ch));
		if (ch == '.') {
			realType = true;
			str.append(ch);
			ch = this.charBuff[this.indexOfLine++];
		}
		while (Character.isDigit(ch)) {
			str.append(ch);
			ch = this.charBuff[this.indexOfLine++];
		}
		this.indexOfLine--;
		
		if (!realType) {
			int val = Integer.parseInt(str.toString());
			return new LInteger(val);
		} else {
			double val = Double.parseDouble(str.toString());
			return new LReal(val);
		}
	}
	
	private SExpression makeSymbol() throws Exception {
		StringBuilder str = new StringBuilder();
		char ch;
		
		for (int i = this.indexOfLine; i < this.lineLength; i++) {
			ch = this.charBuff[i];
			if (Character.isWhitespace(ch) ||
					ch == ')') {
				break;
			}
			str.append(ch);
			this.indexOfLine++;
		}
		
		return new Symbol(str.toString());
	}
	
	private SExpression makeString() throws Exception {
		StringBuilder str = new StringBuilder();
		char ch;
		
		this.indexOfLine++;   // skip '"'
		for (int i = this.indexOfLine; i < this.lineLength; i++) {
			ch = this.charBuff[i];
			if (ch == '"') {
				this.indexOfLine++;    // skip '"'
				break;
			}
			str.append(ch);
			this.indexOfLine++;
		}
		return new LString(str.toString());
	}
	
	private SExpression makeList() throws Exception {
		Cons list = null;
		SExpression sexp = null;
		
		if (!skipSpace()) {
			throw new Exception("Error: EOF error");
		}
		if (this.charBuff[this.indexOfLine] == ')') {  // end of list
			this.indexOfLine++;
			return new Nil();
		}
		if (this.charBuff[this.indexOfLine] == '.') {
			throw new Exception("Error: bad S-Expression");
		}
		
		// get CAR
		list = getCar(list);
		if (!skipSpace()) {
			throw new Exception("Error: EOF error");
		}
		
		Cons last = list;
		// end of list
		while (this.charBuff[this.indexOfLine] != ')') {
			
			// get CDR
			last = getCar(last);
			if (!skipSpace()) {
				throw new Exception("Error: EOF error");
			}
		}
		this.indexOfLine++;
		return list;
	}
	
	// get CAR
	private Cons getCar(Cons list) throws Exception {
		SExpression sexp = read();
		if ((sexp instanceof Nil) && ((Nil) sexp).isDotted()) {
			if (!skipSpace()) {
				throw new Exception("Error: EOF error");
			}
			sexp = read();
			list = list.addDottedCdr(sexp);
		} else {
			if (list == null) {
				list = new Cons(sexp);
			} else {
				list = list.add(sexp);
			}
		}
		return list;
	}
	
	// get CDR
	private Cons getCdr(Cons list) throws Exception {
		SExpression sexp = read();
		if (list == null) {
			list = new Cons(sexp);
		} else {
			list = list.add(sexp);
		}
		if (!skipSpace()) {
			throw new Exception("Error: EOF error");
		}
		if (this.charBuff[this.indexOfLine] != ')') {
			throw new Exception("Error: bad S-Expression");
		}
		return list;
	}
	
	private SExpression makeQuote() throws Exception {
		Cons list = null;
		SExpression sexp = null;
		
		if (!skipSpace()) {
			throw new Exception("Error: EOF error");
		}
		if (this.charBuff[this.indexOfLine] == ')') {  // end of list
			this.indexOfLine++;
			return new Nil();
		}
		if (this.charBuff[this.indexOfLine] == '.') {
			throw new Exception("Error: bad S-Expression");
		}
		
		// get CAR
		Symbol sym = new Symbol("QUOTE");
		list = new Cons(sym);
		if (!skipSpace()) {
			throw new Exception("Error: EOF error");
		}
		
		// get CDR
		getCar(list);
		return list;
	}
	
	private String getName() {
		char ch = 0;
		boolean isEsc = false;
		StringBuilder str = new StringBuilder();
		
		for (int i = 0; i < this.lineLength; i++) {
			while (this.charBuff[this.indexOfLine] == '|') {
				isEsc = !isEsc;
				this.indexOfLine++;
			}
			if (!isEsc) {
				if (this.charBuff[this.indexOfLine] == '\\') {
					this.indexOfLine++;
				} else if (Character.isWhitespace(ch = this.charBuff[this.indexOfLine]) || (isEscape(ch))) {
					//          if (ch == ';')
					//            line.setCharAt(0);
					str.append('\0');
					return str.toString();
				}
			}
			if ((ch = this.charBuff[this.indexOfLine]) == '\n' || ch == '\0') {
				
			}
			str.append(this.charBuff[this.indexOfLine]);
			this.indexOfLine++;
		}
		str.append('\0');
		return str.toString();
	}
	
	private String getLine() {
		return this.line;
	}
}

