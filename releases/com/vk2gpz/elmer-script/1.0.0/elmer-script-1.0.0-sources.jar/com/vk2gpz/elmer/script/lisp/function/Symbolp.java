/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                   Implementation of class Symbolp                    
====================================================================*/
/**
 * generally describe Symbolp in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Symbolp extends NormalFunction {
	public Symbolp() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format... 1 arg.
		if (argNum < 1) {
			throw new Exception("Error-symbolp: too few arguments");
		}
		if (argNum > 1) {
			throw new Exception("Error-symbolp: too many arguments");
		}
		// procedure.
		SExpression se = arguments.getCar();
		if ((se instanceof Symbol) || (se instanceof T) || isVoidList(se)) {
			return new T();
		}
		return new Nil();
	}
}
