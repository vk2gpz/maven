/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.datatype;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

import com.vk2gpz.elmer.script.lisp.function.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                      Implementation of class T                       
====================================================================*/
/**
 * T represents "T".
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Atom
 */

public class T implements Atom {
	public T() {
		super();
	}
	
	public void print(PrintWriter pw) throws Exception {
		pw.print("T");
	}
	
	public String toString() {
		return "T";
	}
	
	public Function function(LPackage pack) throws Exception{
		throw new Exception("Error: bad function - " + this);
	}
	
	public SExpression eval(LPackage pack) throws Exception {
		return this;
	}
}
