/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                      Implementation of class If                      
====================================================================*/
/**
 * generally describe If in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see SpecialFunction
 */

public final class If extends SpecialFunction {
	public If() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...2 or 3 args.
		if (argNum < 2) {
			throw new Exception("Error-if: too few arguments");
		}
		if (argNum > 3) {
			throw new Exception("Error-if: too many arguments");
		}
		// procedure.
		// evaluate condition clouse.
		SExpression tested;
		tested = arguments.getCar().eval(environment);
		
		if (tested instanceof Nil) { // if condition is Nil			
			if (argNum == 2) {
				return new Nil();
			} else {
				return arguments.getCdr().getCdr().getCar().eval(environment);
			}
		} else {				// if condition is non-Nil
			return arguments.getCdr().getCar().eval(environment);
		}
	}
}
