/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.datatype;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

import com.vk2gpz.elmer.script.lisp.function.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                   Implementation of class LInteger                    
====================================================================*/
/**
 * LInteger represents integer number atom.
 * 
 * @version $Revision: 1.1 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see LNumber
 */

public class LInteger implements LNumber {
	private final int val;

	public LInteger() {
		this.val = 0;
	}
	
	public LInteger(int i) {
		this.val = i;
	}
	
	public int valueOf() {
		return this.val;
	}
	
	public boolean zerop(){
		return this.val == 0;
	}

	public boolean plusp() {
		return this.val > 0;
	}
	
	public boolean minusp() {
		return ! plusp();
	}

	public boolean evenp() {
		return this.val % 2 == 0;
	}

	public boolean oddp() {
		return ! evenp();
	}
	
	public SExpression add(SExpression se) throws Exception {
		if (se instanceof LInteger) {
			return new LInteger(this.val + ((LInteger)se).valueOf());
		} else if (se instanceof LReal) {
			return new LReal((double) this.val + ((LReal)se).valueOf());
		} else {
			throw new Exception("Error: not a number - " + se.toString());
		}
	}
	
	public SExpression subtract(SExpression se)  throws Exception {
		if (se instanceof LInteger) {
			return new LInteger(this.val - ((LInteger)se).valueOf());
		} else if (se instanceof LReal) {
			return new LReal((double) this.val - ((LReal)se).valueOf());
		} else {
			throw new Exception("Error: not a number - " + se.toString());
		}
	}

	public SExpression multiply(SExpression se)  throws Exception {
		if (se instanceof LInteger) {
			return new LInteger(this.val * ((LInteger)se).valueOf());
		} else if (se instanceof LReal) {
			return new LReal((double) this.val * ((LReal)se).valueOf());
		} else {
			throw new Exception("Error: not a number - " + se.toString());
		}
	}

	public SExpression divide(SExpression se)  throws Exception {
		if (se instanceof LInteger) {
			return new LInteger(this.val / ((LInteger)se).valueOf());
		} else if (se instanceof LReal) {
			return new LReal((double) this.val / ((LReal)se).valueOf());
		} else {
			throw new Exception("Error: not a number - " + se.toString());
		}
	}
	
	public void print(PrintWriter pw) throws Exception {
		pw.write(toString());
	}
	
	public String toString() {
		return "" + this.val;
	}
	
	public Function function(LPackage pack) throws Exception{
		throw new Exception("Error: bad function - " + this);
	}
	
	public SExpression eval(LPackage pack) throws Exception {
		return this;
	}
}

