/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.datatype;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

import com.vk2gpz.elmer.script.lisp.*;
import com.vk2gpz.elmer.script.lisp.function.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                    Implementation of class Symbol                    
====================================================================*/
/**
 * Symbol represents all string atom.
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Atom
 */

public class Symbol implements Atom {
	static Primitives sPrimitives = LispEngine.getPrimitives();
	
	protected String str = null;
	
	public Symbol() {
		super();
	}
	
	public Symbol(String s) {
		this.str = s;
	}
	
	public Symbol(char[] ca) {
		this.str = new String(ca);
	}
	
	public void print(PrintWriter pw) throws Exception {
		pw.write(this.str);
	}
	
	public String toString() {
		return this.str;
	}
	
	public Function function(LPackage pack) throws Exception{
		String symStr = toString(); // Cache toString() result to avoid repeated calls
		//if it is already defined, return the defined function object.
		Function f = Primitives.get(symStr);
		if (f != null) {
			return f;			
		} else if ("FUNCTION".equals(symStr)) {
			/*
			  single symbol such as "Function" and "Lambda"
			  will throw Exception.
			*/
			throw new Exception("#<function>");
		} else if ("LAMBDA".equals(symStr)) {
			throw new Exception("#<closure>");
		} else {
			/*
			  otherwise, return a function object from lambdaFrom, which is
			  defined (defun) by a user
			*/
			SExpression lambdaForm = (SExpression) pack.get(symStr);
			if (lambdaForm == null) {
				throw new Exception("Error: unbound function - "+ this);
			}
			return lambdaForm.function(pack);
		}
	}
	
	public SExpression eval(LPackage pack) throws Exception {
		// T and Nil are constant - use reference comparison for interned string literals
		String symStr = this.str;
		if ("T".equals(symStr)) {
			return new T();
		} else if ("NIL".equals(symStr)) {
			return new Nil();
		} else {
			// return bounded SExpression for other ordinarly variables.
			SExpression value = (SExpression) pack.get(toString());
			if (value != null) {
				return value;
			} else {
				throw new Exception("Error: unbound variable - "+ this);
			}
		}
	}
}


