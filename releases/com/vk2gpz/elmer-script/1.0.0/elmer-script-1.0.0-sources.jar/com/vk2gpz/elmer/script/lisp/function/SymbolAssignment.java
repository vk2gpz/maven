/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.script.lisp.function;

import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/**
 * Shared implementation of {@code SETF} and {@code SETQ}: {@code (setq symbol form)} evaluates
 * {@code form}, binds the result to {@code symbol} and returns it. This version takes exactly one
 * symbol/form pair, and {@code T} and {@code NIL} cannot be assigned.
 */
abstract class SymbolAssignment extends SpecialFunction {
	private final String name;

	SymbolAssignment(String name) {
		this.name = name;
	}

	public SExpression process(Cons arguments, LPackage environment) throws Exception {
		int argNum = arguments.size();
		if (argNum < 2) {
			throw new Exception("Error-" + name + ": too few arguments");
		}
		if (argNum > 2) {
			throw new Exception("Error-" + name + ": too many arguments");
		}
		if (!(arguments.getCar() instanceof Symbol)) {
			throw new Exception("Error-" + name + ": bad place form - " + arguments.getCar().toString());
		}
		String symbolName = arguments.getCar().toString();
		if (symbolName.equals("T") || symbolName.equals("NIL")) {
			throw new Exception("Error-" + name + ": cannot assign/bind to constant - " + symbolName);
		}
		SExpression symbolValue = arguments.getCdr().getCar().eval(environment);
		environment.put(symbolName, symbolValue);
		return (SExpression) environment.get(symbolName);
	}
}
