/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                     Implementation of class Endp                     
====================================================================*/
/**
 * generally describe Endp in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Endp extends NormalFunction {
	public Endp() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...1 arg and it's a list.
		if (argNum < 1) {
			throw new Exception("Error-endp: too few arguments");
		}
		if (argNum > 1) {
			throw new Exception("Error-endp: too many arguments");
		}
		if (!(arguments.getCar() instanceof Cons)) {
			throw new Exception("Error-endp: bad argument type - " + arguments.getCar().toString());
		}
		// procedure.
		if (isVoidList(arguments.getCar())) {
			return new T();
		}
		return new Nil();
	}
}
