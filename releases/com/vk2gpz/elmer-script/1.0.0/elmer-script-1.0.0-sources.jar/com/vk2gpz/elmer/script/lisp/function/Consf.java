/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                    Implementation of class Consf                     
====================================================================*/
/**
 * generally describe Consf in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Consf extends NormalFunction {
	public Consf() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...2 args and the 2nd is a list.
		if (argNum < 2) {
			throw new Exception("Error-cons: too few arguments");
		}
		if (argNum > 2) {
			throw new Exception("Error-cons: too many arguments");
		}
//    		if (!(arguments.getCdr().getCar() instanceof Cons)) {
//    			throw new Exception("Error-cons: bad argument type - " + ((SExpression)arguments.getCdr().getCar()).toString());
//    		}
		// procedure.
		Cons returnForm = new Cons();
		Cons last = returnForm;
		// add the 1st args as a head.
		last = last.add(arguments.getCar());

		if (arguments.getCdr().getCar() instanceof Cons) {
			arguments = (Cons) arguments.getCdr().getCar();
			for (; ; arguments = arguments.getCdr()) {
				if (arguments.isDotted()) {
					last = last.add(arguments.getCar());
					last.addDottedCdr(arguments.getDottedCdr());
					break;
				} else if (isVoidList(arguments)) {
					break;
				}
				last = last.add(arguments.getCar());
			}
		} else {				// dotted list
			last.addDottedCdr(arguments.getCdr().getCar());
		}
		return returnForm;
	}
}

