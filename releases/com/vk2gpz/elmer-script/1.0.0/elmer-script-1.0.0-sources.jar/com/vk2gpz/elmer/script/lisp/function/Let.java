/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                     Implementation of class Let                      
====================================================================*/
/**
 * generally describe Let in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see SpecialFunction
 */

public final class Let extends SpecialFunction {
	public Let() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		
		int argNum = arguments.size();
		/*
		  check format...
		  more than 1 args (list).
		  1st : parameter
		  2nd : body
		*/
		if (argNum < 1) {
			throw new Exception("Error-let: too few arguments");
		}
		if (!(arguments.getCar() instanceof Cons)) {
			throw new Exception("Error-let: bad argument type - " + arguments.getCar().toString());
		}
		// a new env.
		LPackage env = new LPackage();
		
		// store the parameter.
		Cons params =  (Cons) arguments.getCar();
		for (; !isVoidList(params); params = params.getCdr()) {
			// get parameter.
			if (!(params.getCar() instanceof Cons)) {
				throw new Exception("Error-let: bad parameter form - " + params.getCar().toString());
			}
			Cons param =  (Cons) params.getCar();
			// check parameter.
			if (param.size() < 2) {
				throw new Exception("Error-let: too few elements - parameter - " + param);
			}
			if (param.size() > 2) {
				throw new Exception("Error-let: too many elements - parameter - " + param);
			}
			if (!(param.getCar() instanceof Symbol)) {
				throw new Exception("Error-let: bad parameter - " + param.getCar().toString());
			}
			// bound parameter.
			String key = param.getCar().toString();
			SExpression binding = param.getCdr().getCar();
			// evaluate in other env first.
			SExpression value = binding.eval(environment);
			// then bound in the new env.
			env.put(key,value);
		}
		// include other env.
		env.setParent(environment);
		
		// eval Let body with the new env.
		SExpression rtn = new Nil();
		Cons arg = arguments.getCdr();
		for (; !isVoidList(arg); arg = arg.getCdr()) {
			// if more than 1 forms.
			rtn = arg.getCar().eval(env);
		}
		return rtn;  // return the last value.
	}		
}
