/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */

import com.vk2gpz.elmer.script.lisp.datatype.Cons;
import com.vk2gpz.elmer.script.lisp.datatype.SExpression;
import com.vk2gpz.elmer.script.lisp.environment.LPackage;

/*====================================================================
                     Implementation of class Cdr                      
====================================================================*/
/**
 * generally describe Cdr in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public class Cdr extends NormalFunction {
	public Cdr() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...only one arg and it's a list.
		if (argNum < 1) {
			throw new Exception("Error-cdr: too few arguments");
		}
		if (argNum > 1) {
			throw new Exception("Error-cdr: too many arguments");
		}
		if (!(arguments.getCar() instanceof Cons)) {
			throw new Exception("Error-cdr: bad argument type - " + arguments.getCar().toString());
		}
		// procedure.
		Cons returnForm = new Cons();
		Cons last = returnForm;
		Cons cdr = ((Cons) arguments.getCar()).getCdr();
		for (; !isVoidList(cdr); cdr = cdr.getCdr()) {
			last = last.add(cdr.getCar());
			if (cdr.isDotted()) {
				last = last.add(cdr.getDottedCdr());
			}
		}

		// return the rest of the list.
		return returnForm;
	}
}

