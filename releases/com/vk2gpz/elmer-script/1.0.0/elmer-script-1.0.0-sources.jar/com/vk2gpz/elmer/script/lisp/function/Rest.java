/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */


/*====================================================================
                     Implementation of class Rest                     
====================================================================*/
/**
 * generally describe Rest in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Cdr
 */

public final class Rest extends Cdr {
	public Rest() {
		super();
	}
}

