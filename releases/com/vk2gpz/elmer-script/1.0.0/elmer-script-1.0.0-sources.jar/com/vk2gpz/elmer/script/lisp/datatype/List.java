/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.datatype;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
                     Implementation of class List                     
====================================================================*/
/**
 * generally describe List in here
 * 
 * @version $Revision: 1.1.1.1 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Cons
 */

public class List extends Cons {
	public List() {
		super();
	}

	public List(SExpression se) {
		super(se);
	}
}
