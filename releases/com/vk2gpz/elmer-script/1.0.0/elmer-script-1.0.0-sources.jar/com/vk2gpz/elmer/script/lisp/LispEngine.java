/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.function.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                  Implementation of class LispEngine                  
====================================================================*/
/**
 * LispEngine processes all S-Expression.
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Runnable
 */

public class LispEngine implements Runnable {
	static final Primitives sPrimitives = new Primitives();    // Primitive
	
	transient private LReader reader = null;
	transient private LPackage myPackage = null;
	transient private boolean invokedStandalone = false;
	transient private BufferedReader in;
	transient private PrintWriter out;
	transient private boolean prompt;
    transient private Thread runner;
    transient private boolean running = false;
	
	/**
	 * Returns all pre-defined primitives.
	 */
	public static Primitives getPrimitives() {
		return sPrimitives;
	}

	/**
	 * null-constructor.
	 */
	LispEngine() {
		super();
		this.reader = new LReader();
		this.myPackage = new LPackage();
		this.in = null;
		this.out = null;
		this.prompt = false;
	}

	/**
	* Constructs a newly created lisp engine from the specified parameters.
	*/
	LispEngine(BufferedReader in, PrintWriter out, boolean prompt) {
		this();
		this.in = in;
		this.out = out;
		this.prompt = prompt;
		reader.init(this.in, this.out, this.prompt);
	}

	/**
	 * Sets the input source of the lisp engine.
	*/
	public void setReader(BufferedReader in) {
		this.in = in;
		if (this.out != null) {
			reader.init(this.in, this.out, this.prompt);
		}
	}

	/**
	 * Sets the output destination of the lisp engine.
	*/
	public void setWriter(PrintWriter out) {
		this.out = out;
		if (this.in != null) {
			reader.init(this.in, this.out, this.prompt);
		}
	}

	/**
	* This the prompt flag is "true", the lisp engine displays
	* the prompt.
	*/
	public void setPrompt(boolean prompt) {
		this.prompt = prompt;
		if (this.in != null && this.out != null) {
			reader.init(this.in, this.out, this.prompt);
		}
	}

	/**
	 * Starts the lisp engine's main loop.
	 */
    public void start() {
        if (this.runner == null) {
            this.runner = new Thread(this);
            this.runner.start();
        }
		this.running = true;
    }

	/**
	 * Stops the lisp engine's main loop.
	 */
    public void stop() {
		this.running = false;
		this.runner = null;
    }

	/**
	 * Returns the flag to indicate the Standalone mode.
	 */
	public boolean isStandalone() {
		return this.invokedStandalone;
	}
	
	/**
	 * Sets the flag to indicate the Standalone mode.
	 */
	public void setStandalone(boolean s) {
		this.invokedStandalone = s;
		if (s) {
			Primitives.sPrimitives.put("QUIT", new Quit());
		} else {
			Primitives.sPrimitives.remove("QUIT");
		}
	}
	
	/**
	 * main loop to process S-Expression.
	*/
	public void run() {
		// Hello!
		out.println("Hello! VKLisp Ver 1.0\n");

		while (true) {
			Thread.yield();
			if (!this.running) {
				break;
			}
			try {
				// read SExpression.
				SExpression form = this.reader.read();
				if (form instanceof Nil) {
					this.reader.init(this.in, this.out, true);
					continue;
				}
				//start
				try {
					// evaluate and print out.
					SExpression evaluatedForm = form.eval(myPackage);
					printer(evaluatedForm, this.out);
				} catch (Exception e) {
					this.out.write(e.getMessage());
					this.out.write('\n');
					this.out.flush();
				}
				//end
				
				this.out.write('\n');
				this.out.flush();
			} catch(Exception e) {
				this.out.write(e.getMessage());
				this.out.write('\n');
			}
		}
	}

	/**
	* The main method to text this engine.
	*/
	public static void main(String[] args) {
		// get stream and pass it to reader.
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		PrintWriter out = new PrintWriter(System.out);
		LispEngine vLisp = new LispEngine(in, out, true);
		vLisp.setStandalone(true);
		vLisp.start();
	}
	
	/**
	 * print method
	 * actual print task is delegated to each class.
	 */
	static void printer(SExpression se, PrintWriter pw) throws Exception {
		if (se == null) {
			return;
		}
		se.print(pw);
	}
}


