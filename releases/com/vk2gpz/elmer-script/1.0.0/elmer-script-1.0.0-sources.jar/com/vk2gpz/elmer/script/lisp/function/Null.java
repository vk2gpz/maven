/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                     Implementation of class Null                     
====================================================================*/
/**
 * generally describe Null in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Null extends NormalFunction {
	public Null() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...1 arg.
		if (argNum < 1) {
			throw new Exception("Error-null: too few arguments");
		}
		if (argNum > 1) {
			throw new Exception("Error-null: too many arguments");
		}
		// procedure.
		System.out.println("arg =" + arguments);
		
		if (isVoidList(arguments.getCar())) {
			return new T();
		}
		return new Nil();
	}
}
