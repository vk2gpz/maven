/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                    Implementation of class Length                    
====================================================================*/
/**
 * generally describe Length in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Length extends NormalFunction {
	public Length() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...one arg and it's a list.
		if (argNum < 1) {
			throw new Exception("Error-length: too few arguments");
		}
		if (argNum > 1) {
			throw new Exception("Error-length: too many arguments");
		}
		if (!(arguments.getCar() instanceof Cons)) {
			throw new Exception("Error-length: bad argument type - " + arguments.getCar().toString());
		}
		// procedure.
		int size = ((Cons) arguments.getCar()).size();
		return new LInteger(size);
    }
} 
