/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                    Implementation of class Lambda                    
====================================================================*/
/**
 * generally describe Lambda in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public class Lambda extends NormalFunction {
	Cons params = null;
	Cons body = null;
	boolean isBadForm = false;
	final String errorMsg = "";
	LPackage env = null;      // a new environment for args.
	
	public Lambda(Cons lambdaForm) throws Exception {
		/*
		  check the format... > 2 args
		  1st : a Lambda,
		  2nd : a list, 
		  2nd is the parameter and the rest is the body.
		*/
		if (lambdaForm.getCdr() == null) {
			this.isBadForm = true;
			this.errorMsg.concat("No argument list - " + lambdaForm);
		}
		if (!(lambdaForm.getCar() instanceof Symbol)) {
			this.isBadForm = true;
			this.errorMsg.concat("Not a symbol");
		}
		if (!(lambdaForm.getCdr().getCar() instanceof Cons)) {
			this.isBadForm = true;
			this.errorMsg.concat("Bad formal argument list");
		}
		// store the body of the Lambda.
		Cons cdr = lambdaForm.getCdr().getCdr();
		this.body = new Cons();
		Cons last = body;
		for (; !isVoidList(cdr); cdr = cdr.getCdr()) {
			last = last.add(cdr.getCar());
		}
		// create a new environment.
		this.env = new LPackage();
		// initialize parameters with Nil.
		cdr = (Cons) lambdaForm.getCdr().getCar();
		this.params = new Cons();
		last = this.params;
		for (; !isVoidList(cdr); cdr = cdr.getCdr()) {
			SExpression param = cdr.getCar();
			if (!(param instanceof Symbol)) {
				this.isBadForm = true;
				this.errorMsg.concat("Bad argument - " + param.toString());
			}
			last = last.add(param);
			this.env.put(param.toString(), new Nil());
		}
	}
	
	public SExpression process(Cons arguments, LPackage pack) throws Exception{
		if (this.isBadForm) {
			throw new Exception("Error-lambda: " + this.errorMsg);
		}
		int argNum = arguments.size();
		// check format...the number of tmp and real parameters should be the same.
		if (argNum < this.params.size()) {
			throw new Exception("Error-lambda: too few arguments");
		}
		if (argNum > this.params.size()){
			throw new Exception("Error-lambda: too many arguments");
		}
		// function.
		// set the actual parameter in the new environment.
		Cons param = this.params;
		Cons arg = arguments;
		for (; !isVoidList(param); param = param.getCdr(), arg = arguments.getCdr()) {
			this.env.put(param.getCar().toString(), arg.getCar());
		}
		// evaluate the body of the lambda.
		{
			SExpression rtn = new Nil();
			Cons body = this.body;
			for (; !isVoidList(body); body = body.getCdr()) {
				// if many forms are in the body.
				rtn = body.getCar().eval(this.env);
			}
			return rtn;  //return the last value.
		}
	}
}
