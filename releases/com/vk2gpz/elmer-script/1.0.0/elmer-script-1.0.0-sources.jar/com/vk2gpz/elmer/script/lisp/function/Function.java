/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                   Implementation of class Function                   
====================================================================*/
/**
 * generally describe Function in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public interface Function {
	SExpression apply(Cons arguments, LPackage pack) throws Exception;
	SExpression process(Cons arguments, LPackage pack) throws Exception;
}

