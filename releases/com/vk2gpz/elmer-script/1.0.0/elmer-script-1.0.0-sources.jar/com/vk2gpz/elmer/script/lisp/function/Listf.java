/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                    Implementation of class Listf                     
====================================================================*/
/**
 * generally describe Listf in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Listf extends NormalFunction {
	public Listf() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...none.
		// procedure.
		Cons returnForm = new Cons();
		Cons last = returnForm;
		for (; !isVoidList(arguments); arguments = arguments.getCdr()) {
			last = last.add(arguments.getCar());
		}
		return returnForm;
	}
}

