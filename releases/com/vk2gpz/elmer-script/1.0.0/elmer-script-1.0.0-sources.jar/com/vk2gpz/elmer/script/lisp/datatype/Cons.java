/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.datatype;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

import com.vk2gpz.elmer.script.lisp.function.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                     Implementation of class Cons                     
====================================================================*/
/**
 * generally describe Cons in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see SExpression
 */

public class Cons implements SExpression {
	protected SExpression car;
	private Cons cdr;
	private SExpression dcdr;	// cdr for a dotted list.
	
	public Cons() {
		this(null);
	}
	
	public Cons(SExpression se) {
		super();
		this.car = se;
		this.cdr = null;
		this.dcdr = null;
	}

	public SExpression getCar() {
		return (this.car != null) ? this.car : new Nil();
	}
	
	public Cons getCdr() {
		return (this.cdr != null) ? this.cdr : new Nil();
	}

	public Cons add(SExpression se) {
		Cons newCons = new Cons(se);
		return add(newCons);
	}
	
	private void copyFrom(Cons cons) {
		this.car = cons.car;
		this.cdr = cons.cdr;
	}

	private Cons add(Cons cons) {
		if (this.car == null) {	// Nil
			copyFrom(cons);
			return this;
		} 
		this.cdr = cons;
		return this.cdr;			
	}

	public Cons addDottedCdr(SExpression se) {
		this.dcdr = se;
		this.cdr = null;
		return this;
	}
	
	public SExpression getDottedCdr() {
		return this.dcdr;
	}

	public boolean isDotted() {
		return (this.dcdr != null);
	}
	
	public int size() {
		int cnt = 1;		
		if (this.car == null) {
			cnt--;
		}

		Cons cdr = this.cdr;
		for (; ; cdr = cdr.cdr) {
			if (cdr != null) {
				cnt++;
			} else if (this.dcdr != null) {
				cnt++;
			}
			if (cdr == null) {
				break;
			}
		}
		return cnt;
	}

	public void print(PrintWriter pw) throws Exception {
		pw.print(this);
	}
	
	public String toString() {
		try {
			if (size() == 0) {
				return "NIL";
			}
		} catch (Exception e) {
			// catch dotted list exception.
		}
		StringBuilder sb = new StringBuilder();
		if (this.cdr != null || this.dcdr != null) {		
			sb.append("(");
		}
		sb.append(this.car.toString());
		if (this.dcdr != null) { // dotted list.
			sb.append(" . ");
			sb.append(this.dcdr);
		} else {
			Cons cdr = this.cdr;
			for (;; cdr = cdr.cdr) {
				if (cdr == null) { // Nil
					break;
				}
				sb.append(" ");
				sb.append(cdr.car.toString());				
				if (cdr.isDotted()) { // dotted list.
					sb.append(" . ");
					sb.append(cdr.getDottedCdr().toString());
				}
			}
		}
		if (this.cdr != null || this.dcdr != null) {
			sb.append(")");
		}
		return sb.toString();
	}
	
	public Function function(LPackage pack) throws Exception{
		/*
		  if the number of elements is less than 1, it would not be
		  a form representing a function.
		*/
		if (this.cdr == null) {
			throw new Exception("Error: bad function - null form");
		} else if (this.car.toString().equals("FUNCTION") 
				   || this.car.toString().equals("QUOTE")) {
			/*
			  if it is Function statement, create a function object
			  from the second element.
			*/
			if (this.cdr.cdr != null) { //size() > 2) {
				throw new Exception("Error: bad function form - "+ this);
			}
			return this.cdr.getCar().function(pack);
		} else if (this.car.toString().equals("LAMBDA")) {
			/*
			  if it is Lambda statement, return Closure object.
			*/
			return new Closure(this, pack);
		} else {
			/*
			  other type of lists do not represnt a funciton.
			*/
			throw new Exception("Error: bad function - "+ this);
		}
	}
	
	public SExpression eval(LPackage pack) throws Exception{
		// get a function object from the head element of the list.
		Function f;
		f = getCar().function(pack);
		// use the rest of elements as argument.
		Cons arguments = getCdr();

//    		System.out.println("f =" + f);
//    		System.out.println("arg =" + arguments);		
		// apply the arguments to the function object.
		return f.apply(arguments, pack);
	}
}


