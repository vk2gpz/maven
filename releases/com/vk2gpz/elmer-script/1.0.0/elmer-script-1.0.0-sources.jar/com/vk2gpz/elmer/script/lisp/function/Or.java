/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                      Implementation of class Or                      
====================================================================*/
/**
 * generally describe Or in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see SpecialFunction
 */

public final class Or extends SpecialFunction {
	public Or() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...none.
		// procedure.
		SExpression tested = new Nil();
		Cons cdr = arguments;
		for (; !isVoidList(cdr); cdr = cdr.getCdr()) {
			tested = cdr.getCar().eval(environment);
			if (! (tested instanceof Nil)) {
				break;
			}
		}
		return tested;
	}
}

