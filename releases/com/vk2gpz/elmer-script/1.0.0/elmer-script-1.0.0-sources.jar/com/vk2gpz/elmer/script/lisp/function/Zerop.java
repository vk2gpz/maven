/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                    Implementation of class Zerop                     
====================================================================*/
/**
 * generally describe Zerop in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Zerop extends NormalFunction {
	public Zerop() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...1 arg and it's a number.
		if (argNum < 1) {
			throw new Exception("Error-zerop: too few arguments");
		}
		if (argNum > 1) {
			throw new Exception("Error-zerop: too many arguments");
		}
		SExpression se = arguments.getCar();
		if (!(se instanceof LNumber)) {
			throw new Exception("Error-zerop: bad argument type - " + se.toString());
		}
		// procedure.
		if (((LNumber) se).zerop()) {
			return new T();
		}
		return new Nil();
	}
}
