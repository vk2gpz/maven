/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                     Implementation of class Quit                     
====================================================================*/
/**
 * generally describe Quit in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Quit extends NormalFunction {
	public Quit() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format.
		if (argNum != 0) {
			throw new Exception("Error-quit: too many arguments");
		}
		
		System.out.println("Thank you for using JBeanLisp.\n");
		System.exit(0);
		
		return new Nil();
	}
} 
