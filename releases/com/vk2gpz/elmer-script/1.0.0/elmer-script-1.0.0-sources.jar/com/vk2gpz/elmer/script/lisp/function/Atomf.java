/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */

import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.LPackage;

/*====================================================================
                    Implementation of class Atomf                     
====================================================================*/
/**
 * generally describe Atomf in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Atomf extends NormalFunction {
	public Atomf() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = 0;
		try {
			argNum = arguments.size();
		} catch (Exception e) {
			return new Nil();
		}
		// check format...1 arg.
		if (argNum < 1) {
			throw new Exception("Error-atom: too few arguments");
		}
		if (argNum > 1) {
			throw new Exception("Error-atom: too many arguments");
		}
		// procedure.
		SExpression se = arguments.getCar();
		try {
			if ((se instanceof Atom) || (isVoidList(se))) {
				return new T();
			}
		} catch (Exception e) {
			return new Nil();
		}
		
		return new Nil();
	}
}
