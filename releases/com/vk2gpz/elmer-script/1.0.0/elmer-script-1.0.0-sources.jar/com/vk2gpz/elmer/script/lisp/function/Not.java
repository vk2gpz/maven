/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                     Implementation of class Not                      
====================================================================*/
/**
 * generally describe Not in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Not extends NormalFunction {
	public Not() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...only one arg.
		if (argNum < 1) {
			throw new Exception("Error-not: too few arguments");
		}
		if (argNum > 1) {
			throw new Exception("Error-not: too many arguments");
		}
		// procedure.
		if (isVoidList(arguments.getCar())) {
			return new T();
		}
		return new Nil();
	}
}
