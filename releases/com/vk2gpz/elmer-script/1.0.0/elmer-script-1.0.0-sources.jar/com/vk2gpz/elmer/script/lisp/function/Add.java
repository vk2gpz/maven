/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */

import com.vk2gpz.elmer.script.lisp.datatype.Cons;
import com.vk2gpz.elmer.script.lisp.datatype.LInteger;
import com.vk2gpz.elmer.script.lisp.datatype.LNumber;
import com.vk2gpz.elmer.script.lisp.datatype.SExpression;
import com.vk2gpz.elmer.script.lisp.environment.LPackage;

/*====================================================================
                     Implementation of class Add                      
====================================================================*/
/**
 * generally describe Add in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Add extends NormalFunction {
	public Add() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage pack) throws Exception{
		/*
		  check format...none (any number of args is allowed.
		  However, if arg is other than Number, it throws Exception.
		*/
		
		// initial value.
		SExpression sum = new LInteger(0);
		
		// procedure
		for(; !isVoidList(arguments); arguments = arguments.getCdr()) {
			SExpression se = arguments.getCar();
			sum = ((LNumber)sum).add(se);
		}
		return sum;
	}
}
