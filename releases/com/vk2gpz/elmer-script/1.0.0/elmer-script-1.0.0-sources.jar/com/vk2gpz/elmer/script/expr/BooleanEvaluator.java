/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.script.expr;

import com.fathzer.soft.javaluator.AbstractEvaluator;
import com.fathzer.soft.javaluator.BracketPair;
import com.fathzer.soft.javaluator.Operator;
import com.fathzer.soft.javaluator.Parameters;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Evaluates boolean expressions such as {@code "T && ( F || T )"}, built on
 * <a href="https://github.com/fathzer/javaluator">Javaluator</a>.
 * <p>
 * Literals are {@code T} and {@code F}; operators are {@code &&} and {@code ||}; parentheses group.
 * Each step is recorded as a string like {@code "(T && F)=false"} in the evaluation context,
 * so the full evaluation sequence can be inspected.
 */
public class BooleanEvaluator extends AbstractEvaluator<String> {
	/** The logical AND operator. */
	static final Operator AND = new Operator("&&", 2, Operator.Associativity.LEFT, 2);
	/** The logical OR operator. */
	static final Operator OR = new Operator("||", 2, Operator.Associativity.LEFT, 1);

	private static final Parameters PARAMETERS;

	static {
		PARAMETERS = new Parameters();
		PARAMETERS.add(AND);
		PARAMETERS.add(OR);
		PARAMETERS.addExpressionBracket(BracketPair.PARENTHESES);
	}

	public BooleanEvaluator() {
		super(PARAMETERS);
	}

	@Override
	protected String toValue(String literal, Object evaluationContext) {
		return literal;
	}

	private static boolean getValue(String literal) {
		if ("T".equals(literal) || literal.endsWith("=true"))
			return true;
		else if ("F".equals(literal) || literal.endsWith("=false"))
			return false;
		throw new IllegalArgumentException("Unknown literal : " + literal);
	}

	@Override
	@SuppressWarnings("unchecked")
	protected String evaluate(Operator operator, Iterator<String> operands, Object evaluationContext) {
		List<String> tree = (List<String>) evaluationContext;
		String o1 = operands.next();
		String o2 = operands.next();
		boolean result;
		if (operator == OR) {
			result = getValue(o1) || getValue(o2);
		} else if (operator == AND) {
			result = getValue(o1) && getValue(o2);
		} else {
			throw new IllegalArgumentException();
		}
		String eval = "(" + o1 + " " + operator.getSymbol() + " " + o2 + ")=" + result;
		tree.add(eval);
		return eval;
	}

	/**
	 * Evaluates {@code expression} and returns its value.
	 *
	 * @throws IllegalArgumentException if the expression contains an unknown literal
	 */
	public static boolean evaluateBoolean(BooleanEvaluator evaluator, String expression) {
		List<String> sequence = new ArrayList<>();
		evaluator.evaluate(expression, sequence);
		if (sequence.isEmpty())
			return getValue(expression.trim());
		String exp = sequence.get(sequence.size() - 1);
		return Boolean.parseBoolean(exp.substring(exp.lastIndexOf(")=") + 2));
	}
}
