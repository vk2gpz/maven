/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

import com.vk2gpz.elmer.script.lisp.*;
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                     Implementation of class Load                     
====================================================================*/
/**
 * generally describe Load in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see SpecialFunction
 */

public final class Load extends SpecialFunction {
	public Load() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception {
		int argNum = arguments.size();
		// check format...1 arg and it's a string.
		if (argNum < 1) {
			throw new Exception("Error-load: too few arguments");
		}
		if (argNum > 1) {
			throw new Exception("Error-load: too many arguments");
		}
		if (!(arguments.getCar() instanceof LString)) {
			throw new Exception("Error-load: bad argument type - " + arguments.getCar().toString());
		}
		
		LReader reader = new LReader();
		
		FileInputStream fin = null;
		BufferedReader in = null;
		PrintWriter out = null;
		
		try {
			String str = arguments.getCar().toString();
			fin = new FileInputStream(str);
			in = new BufferedReader(new InputStreamReader(fin));
			out = new PrintWriter(System.out);
		} catch (Exception e) {
			if (in != null) {
				in.close();
			}
			if (out != null) {
				out.close();
			}
			throw e;
		}
		reader.init(in, out, false);
		
		for(;;) {
			// read S-Expression.
			SExpression form = reader.read();
			if (form instanceof Nil) {
				return form;
			}
				/*
				  if (reader.getLine().equals("(QUIT)")) {
				  out.write("Bye Bye - QLisp\n"); out.flush();
				  System.exit(0);
				  }
				*/
			// evaluate it and print it out.
			SExpression evaluatedForm = form.eval(environment);
			evaluatedForm.print(out);
			
			out.write('\n');
			out.flush();
		}
	}
}
