/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.datatype;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
                     Implementation of class Atom                     
====================================================================*/
/**
 * Atom represents all data except MtCons.
 * 
 * @version $Revision: 1.1.1.1 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see SExpression
 */

public interface Atom extends SExpression {

}
