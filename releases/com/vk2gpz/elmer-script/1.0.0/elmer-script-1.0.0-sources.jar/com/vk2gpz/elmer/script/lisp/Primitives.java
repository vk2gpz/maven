/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp;

/* ------------------ Import classes (packages) ------------------- */
import java.util.*;

import com.vk2gpz.elmer.script.lisp.function.*;

/*====================================================================
                  Implementation of class Primitives                  
====================================================================*/
/**
 * Primitives holds all pre-defined lisp functions.
 * 
 * @version $Revision: 1.1.1.1 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public final class Primitives {
	// Use HashMap instead of Hashtable - HashMap is ~2x faster and sufficient for this use case
	static final Map<String, Function> sPrimitives = new HashMap<>();
	
	Primitives() {
		sPrimitives.put("AND",new And());		
		sPrimitives.put("APPEND",new Append());
		sPrimitives.put("APPLY",new Apply());
		sPrimitives.put("ATOM",new Atomf()); // f for function
  		sPrimitives.put("CAR",new Car());	//FIRST
		sPrimitives.put("CDR",new Cdr()); //REST
		sPrimitives.put("CONS",new Consf()); // f for function
		sPrimitives.put("DEFUN",new Defun());
		sPrimitives.put("DO",new Do());
  		sPrimitives.put("ENDP",new Endp());
		sPrimitives.put("EQUAL",new Equal());
		sPrimitives.put("FIRST",new First());	
		sPrimitives.put("IF",new If());
		sPrimitives.put("LENGTH",new Length());
		sPrimitives.put("LET",new Let());
		sPrimitives.put("LIST",new Listf()); // f for function.
		sPrimitives.put("LISTP",new Listp());
		sPrimitives.put("LOAD", new Load());		
		sPrimitives.put("NOT",new Not());
		sPrimitives.put("NULL",new Null());
		sPrimitives.put("NUMBERP",new Numberp());		
		sPrimitives.put("OR",new Or());
		sPrimitives.put("QUIT", new Quit());
		sPrimitives.put("QUOTE",new Quote());
		sPrimitives.put("REST",new Rest()); 
		sPrimitives.put("SETF",new Setf());
		sPrimitives.put("SETQ",new Setq());		
  		sPrimitives.put("SYMBOLP",new Symbolp());
		sPrimitives.put("ZEROP",new Zerop());
  		sPrimitives.put("+",new Add());
  		sPrimitives.put("-",new Subtract());
  		sPrimitives.put("*",new Multiply());
  		sPrimitives.put("/",new Divide());
  		sPrimitives.put("=",new EqualNum());
  		sPrimitives.put("<",new Bigger());
  		sPrimitives.put(">",new Smaller());

		// Graphics functions.
//  		sPrimitives.put("CREATEWINDOW", new CreateWindow());
//  		sPrimitives.put("CLOSEWINDOW", new CloseWindow());
//  		sPrimitives.put("LINE", new Line());
//  		sPrimitives.put("COLOR", new Color());
//  		sPrimitives.put("FILLPOLYGON", new FillPolygon());
	}

	public static Function get(String str) {
		return sPrimitives.get(str);
	}
}
