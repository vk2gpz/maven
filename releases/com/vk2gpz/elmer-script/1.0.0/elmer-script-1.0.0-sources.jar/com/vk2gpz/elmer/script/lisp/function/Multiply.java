/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                   Implementation of class Multiply                   
====================================================================*/
/**
 * generally describe Multiply in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Multiply extends NormalFunction {
	public Multiply() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		// check format...none.
		// init value.
		SExpression sum = new LInteger(1);
		// procedure
		for (; !isVoidList(arguments); arguments = arguments.getCdr()) {
			SExpression se = arguments.getCar();
			sum = ((LNumber)sum).multiply(se);
		}
		return sum;
	}
}
