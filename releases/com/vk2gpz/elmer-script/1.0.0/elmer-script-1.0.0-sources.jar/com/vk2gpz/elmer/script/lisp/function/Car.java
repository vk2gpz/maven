/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */

import com.vk2gpz.elmer.script.lisp.datatype.Cons;
import com.vk2gpz.elmer.script.lisp.datatype.SExpression;
import com.vk2gpz.elmer.script.lisp.environment.LPackage;

/*====================================================================
                     Implementation of class Car                      
====================================================================*/
/**
 * generally describe Car in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public class Car extends NormalFunction {
	public Car() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...only one arg and it's a list.
		if (argNum < 1) {
			throw new Exception("Error-car: too few arguments");
		}
		if (argNum > 1) {
			throw new Exception("Error-car: too many arguments");
		}
		if (!(arguments.getCar() instanceof Cons)) {
			throw new Exception("Error-car: bad argument type - " + arguments.getCar().toString());
		}
		// procedure.
		// return the first element.
		return ((Cons) arguments.getCar()).getCar();
	}
}
