/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.datatype;

/* ------------------ Import classes (packages) ------------------- */
// import foo.*;

/*====================================================================
                    Implementation of class LNumber                    
====================================================================*/
/**
 * LNumber represnts all numbers (integer and real).
 * 
 * @version $Revision: 1.1 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Atom
 */

public interface LNumber extends Atom {
	SExpression add(SExpression se) throws Exception;
	SExpression subtract(SExpression se) throws Exception;
	SExpression multiply(SExpression se) throws Exception;
	SExpression divide(SExpression se) throws Exception;
	boolean zerop();
	boolean plusp();
	boolean minusp();
	boolean evenp();
	boolean oddp();
}
