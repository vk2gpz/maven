/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                   Implementation of class Smaller                    
====================================================================*/
/**
 * generally describe Smaller in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Smaller extends NormalFunction {
	public Smaller() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format... 1> args and all numbers.
		if (argNum < 1) {
			throw new Exception("Error- >: too few arguments");
		}
		if (!(arguments.getCar() instanceof LNumber)) {
			throw new Exception("Error- >: bad argument type - " + arguments.getCar().toString());
		}
		
		// return T() if only one arg.
		if (argNum == 1) {
			return new T();
		}
		
		// init value.
		double val1;
		SExpression car = arguments.getCar();
		if (car instanceof LInteger) {
			val1 = ((LInteger) car).valueOf();
		} else {
			val1 = ((LReal) car).valueOf();
		}
		
		// keep comparing...
		Cons arg = arguments.getCdr();
		for (; !isVoidList(arg); arg = arg.getCdr()) {
			double val2;
			car = arg.getCar();
			if (!(car instanceof LNumber)) {
				throw new Exception("Error- >: bad argument type - " + car.toString());
			}
			if (car instanceof LInteger) {
				val2 = ((LInteger) car).valueOf();
			} else {
				val2 = ((LReal) car).valueOf();
			}
			
			if (!(val1 > val2)) {
				return new Nil();
			}
			val1 = val2;
		}
		return new T();
	}
}

