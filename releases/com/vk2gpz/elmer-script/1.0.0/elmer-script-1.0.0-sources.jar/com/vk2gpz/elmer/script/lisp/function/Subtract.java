/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                   Implementation of class Subtract                   
====================================================================*/
/**
 * generally describe Subtract in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Subtract extends NormalFunction {
	public Subtract() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		//check format...more than one arg and all number.
		if (argNum < 1) {
			throw new Exception("Error-subtract: too few arguments");
		}
		if (!(arguments.getCar() instanceof LNumber)) {
			throw new Exception("Error-subtract: bad argument type - " + arguments.getCar().toString());
		}
		//initial value.
		SExpression sum;
		Cons cdr = null;
		if (argNum == 1) { 
			sum = new LInteger(0);
			cdr = arguments;
		} else {
			sum = arguments.getCar();
			cdr = arguments.getCdr();
		}
		// procedure.
		for (; !isVoidList(cdr); cdr = cdr.getCdr()) {
			SExpression se = cdr.getCar();
			sum = ((LNumber)sum).subtract(se);
		}
		return sum;
	}
}
	
