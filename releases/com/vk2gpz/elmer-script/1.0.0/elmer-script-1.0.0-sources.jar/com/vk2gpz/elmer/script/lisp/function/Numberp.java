/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                   Implementation of class Numberp                    
====================================================================*/
/**
 * generally describe Numberp in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Numberp extends NormalFunction {
	public Numberp() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...1 arg.
		if (argNum < 1) {
			throw new Exception("Error-numberp: too few arguments");
		}
		if (argNum > 1) {
			throw new Exception("Error-numberp: too many arguments");
		}

		// procedure.
		if (arguments.getCar() instanceof LNumber) {
			return new T();
		} 
		return new Nil();
	}
}
