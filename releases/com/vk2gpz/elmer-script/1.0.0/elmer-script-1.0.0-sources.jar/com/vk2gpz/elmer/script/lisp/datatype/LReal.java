/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.datatype;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

import com.vk2gpz.elmer.script.lisp.function.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                     Implementation of class LReal                     
====================================================================*/
/**
 * LReal represents all real number atoms.
 * 
 * @version $Revision: 1.1 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see LNumber
 */

public class LReal implements LNumber {
	private final double val;

	public LReal() {
		this.val = 0;
	}
	
	public LReal(double i) {
		this.val = i;
	}
	
	public double valueOf() {
		return this.val;
	}
	
	public boolean zerop(){
		return this.val == 0.0;
	}

	public boolean plusp() {
		return this.val > 0.0;
	}
	
	public boolean minusp() {
		return ! plusp();
	}

	private double dmod(double x, double y) {
		double modp = x;
		
		if (y != 0.0) {
			int rmult = (int) (x / y);
			modp = x - y * rmult;
			if (modp < 0.0) {
				modp = modp + Math.abs(y);
			}
		}
		return modp;
	}

	public boolean evenp() {
		return dmod(this.val, 2.0) == 0.0;
	}

	public boolean oddp() {
		return ! evenp();
	}
	
	public SExpression add(SExpression se)  throws Exception {
		if (se instanceof LInteger) {
			return new LReal(this.val + (double)((LInteger)se).valueOf());
		} else if (se instanceof LReal) {
			return new LReal(this.val + ((LReal)se).valueOf());
		} else {
			throw new Exception("Error: not a number - " + se.toString());
		}
	}

	public SExpression subtract(SExpression se)  throws Exception {
		if (se instanceof LInteger) {
			return new LReal(this.val - (double)((LInteger)se).valueOf());
		} else if (se instanceof LReal) {
			return new LReal(this.val - ((LReal)se).valueOf());
		} else {
			throw new Exception("Error: not a number - " + se.toString());
		}
	}

	public SExpression multiply(SExpression se)  throws Exception {
		if (se instanceof LInteger) {
			return new LReal(this.val * (double)((LInteger)se).valueOf());
		} else if (se instanceof LReal) {
			return new LReal(this.val * ((LReal)se).valueOf());
		} else {
			throw new Exception("Error: not a number - " + se.toString());
		}
	}

	public SExpression divide(SExpression se)  throws Exception {
		if (se instanceof LInteger) {
			return new LReal(this.val / (double)((LInteger)se).valueOf());
		} else if (se instanceof LReal) {
			return new LReal(this.val / ((LReal)se).valueOf());
		} else {
			throw new Exception("Error: not a number - " + se.toString());
		}
	}
	
	public void print(PrintWriter pw) throws Exception {
		pw.write(toString());
	}
	
	public String toString() {
		return "" + val;
	}

	public Function function(LPackage pack) throws Exception{
		throw new Exception("Error: bad function - " + this);
	}
	
	public SExpression eval(LPackage pack) throws Exception {
		return this;
	}
} 
