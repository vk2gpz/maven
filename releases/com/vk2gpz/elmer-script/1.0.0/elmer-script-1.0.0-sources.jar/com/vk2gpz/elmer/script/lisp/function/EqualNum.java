/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                   Implementation of class EqualNum                   
====================================================================*/
/**
 * generally describe EqualNum in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public class EqualNum extends NormalFunction {
	public EqualNum() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...1 > args and all numbers.
		if (argNum < 1) {
			throw new Exception("Error- =: too few arguments");
		}
		if (!(arguments.getCar() instanceof LNumber)) {
			throw new Exception("Error- =: bad argument type - " + arguments.getCar().toString());
		}
		
		// return T() if only one arg.
		if (argNum == 1) {
			return new T();
		}
		
		// init value.
		double val1;
		if (arguments.getCar() instanceof LInteger) {
			val1 = ((LInteger)arguments.getCar()).valueOf();
		} else {
			val1 = ((LReal)arguments.getCar()).valueOf();
		}
		
		// keep compareing...
		Cons cdr = arguments.getCdr();
		for (; !isVoidList(cdr); cdr = cdr.getCdr()) {
			double val2;
			SExpression car = cdr.getCar();
			if (!(car instanceof LNumber)) {
				throw new Exception("Error- =: bad argument type - " + car.toString());
			}
			if (car instanceof LInteger) {
				val2 = ((LInteger) car).valueOf();
			} else {
				val2 = ((LReal) car).valueOf();
			}
			
			if (val1 != val2) { 
				return new Nil();
			}
			val1 = val2;
		}
		return new T();
	}
}

