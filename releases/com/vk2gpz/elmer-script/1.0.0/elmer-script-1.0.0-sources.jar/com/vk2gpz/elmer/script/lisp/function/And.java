/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */

import com.vk2gpz.elmer.script.lisp.datatype.Cons;
import com.vk2gpz.elmer.script.lisp.datatype.Nil;
import com.vk2gpz.elmer.script.lisp.datatype.SExpression;
import com.vk2gpz.elmer.script.lisp.datatype.T;
import com.vk2gpz.elmer.script.lisp.environment.LPackage;

/*====================================================================
                     Implementation of class And                      
====================================================================*/
/**
 * generally describe And in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see SpecialFunction
 */

public final class And extends SpecialFunction {
	public And() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...none.
		// procedure.
		SExpression tested = new T();
		for (; ! isVoidList(arguments); arguments = arguments.getCdr()) {
			tested = arguments.getCar().eval(environment);
			if (tested instanceof Nil) {
				break;
			}
		}
		return tested;
	}
}

