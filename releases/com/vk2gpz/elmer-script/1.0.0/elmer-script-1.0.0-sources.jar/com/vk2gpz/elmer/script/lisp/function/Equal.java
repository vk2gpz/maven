/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                    Implementation of class Equal                     
====================================================================*/
/**
 * generally describe Equal in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see EqualNum
 */

public final class Equal extends EqualNum {
	public Equal() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format... 2 args.
		if (argNum < 2) {
			throw new Exception("Error- equal: too few arguments");
		}
		if (argNum > 2) {
			throw new Exception("Error- equal: too many arguments");
		}
		
		// use superclass to check the numbers.
		try {
			SExpression se = super.process(arguments, environment);
			if (se  instanceof T) {
				return new T();
			}
		} catch (Exception e) {
			// NOP
		}
		
		// procedure.
		String str1 = arguments.getCar().toString();
		String str2 = arguments.getCdr().getCar().toString();

		if (str1.equals(str2)) {
			return new T();
		} 
		return new Nil();
	}
}

