/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                    Implementation of class Defun                     
====================================================================*/
/**
 * generally describe Defun in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see SpecialFunction
 */

public final class Defun extends SpecialFunction {
	public Defun() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		/*
		  check format...more than 2 args,
		  1st : symbol (name of function)
		  2nd : parameter
		  3rd : body
		*/
		if (argNum < 2) {
			throw new Exception("Error-defun: too few arguments");
		}
		if (! (arguments.getCar() instanceof Symbol)) {
			throw new Exception("Error-defun: bad argument type - " + arguments.getCar().toString());
		}
		if (!(arguments.getCdr() instanceof Cons)) {
			throw new Exception("error-defun: bad argument type - " + arguments.getCar().toString());
		}

		// procedure.
		Cons lambdaForm = new Cons(new Symbol("LAMBDA"));
		Cons last = lambdaForm;
		Cons cdr = arguments.getCdr();
		for (; !isVoidList(cdr); cdr = cdr.getCdr()) {
			last = last.add(cdr.getCar());
		}
		Cons quoteForm = new Cons(new Symbol("QUOTE"));
		quoteForm.add(lambdaForm);
		Cons newForm = new Cons(new Symbol("SETF"));
		last = newForm.add(arguments.getCar());
		last.add(quoteForm);  // (SETF function-name (LAMNBDA (...) .....))
		//System.out.println("defun = " + newForm.toString());
		newForm.eval(environment); // evaluate it.
		return arguments.getCar();	// return the function name.
	}
}
