/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.datatype;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

import com.vk2gpz.elmer.script.lisp.function.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                 Implementation of class SExpression                  
====================================================================*/
/**
 * SExpression is the superclass of all lisp objects.
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 */

public interface SExpression {
	void print(PrintWriter pw) throws Exception;
	String toString();
	Function function(LPackage pack) throws Exception;
	SExpression eval(LPackage pack) throws Exception;
}
