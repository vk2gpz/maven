/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.environment;

/* ------------------ Import classes (packages) ------------------- */
import java.util.*;


/*====================================================================
                   Implementation of class LPackage                    
====================================================================*/
/**
 * LPackage is a hashtable to store symbols and their corresponding
 * lisp objects.
 * 
 * @version $Revision: 1.1 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Hashtable
 */

public class LPackage extends Hashtable {
	protected LPackage parent = null;
	
	public LPackage() {
		super();
	}
	
	public LPackage(LPackage env) {
		this();
		setParent(env);
	}
	
	public void setParent(LPackage env) {
		this.parent = env;
	}
	
	public Object put(Object key, Object value) {
		if (containsKey(key) || (this.parent==null)) {
			return super.put(key, value);
		} else {
			return this.parent.put(key, value);
		}
	}
	
	public Object get(Object key) {
		Object ret = super.get(key);
		if (ret != null) {
			return  ret;
		} else if (this.parent != null) {
			return this.parent.get(key);
		} else {
			return null;
		}
	}
}
