/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */

import com.vk2gpz.elmer.script.lisp.datatype.Cons;
import com.vk2gpz.elmer.script.lisp.datatype.SExpression;
import com.vk2gpz.elmer.script.lisp.environment.LPackage;

/*====================================================================
                    Implementation of class Append                    
====================================================================*/
/**
 * generally describe Append in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Append extends NormalFunction {
	public Append() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...none
		// procedure.
		Cons returnForm = new Cons();
		Cons last = returnForm;
		SExpression dotted = null;
		for (; ! isVoidList(arguments); arguments = arguments.getCdr()) {
			if (dotted != null) {
				throw new Exception("Error-append: wrong type argument - " + dotted);
			}
			SExpression se = arguments.getCar();
			if (!(se instanceof Cons)) {
				throw new Exception("Error-append: bad argument type - " + se.toString());
			}
			Cons arg = (Cons) se;
			for (; (arg != null) && (arg.size() != 0); arg = arg.getCdr()) {
				last = last.add(arg.getCar());
				if (arg.isDotted()) {
					dotted = arg.getDottedCdr();
					last.addDottedCdr(dotted);
				}
			}
		}
		return returnForm;
	}
}

