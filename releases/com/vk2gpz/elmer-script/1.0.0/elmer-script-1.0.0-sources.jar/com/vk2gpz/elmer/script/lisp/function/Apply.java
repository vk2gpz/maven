/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */

import com.vk2gpz.elmer.script.lisp.datatype.Cons;
import com.vk2gpz.elmer.script.lisp.datatype.SExpression;
import com.vk2gpz.elmer.script.lisp.datatype.Symbol;
import com.vk2gpz.elmer.script.lisp.environment.LPackage;

/*====================================================================
                    Implementation of class Apply                     
====================================================================*/
/**
 * generally describe Apply in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see SpecialFunction
 */

public final class Apply extends SpecialFunction {
	public Apply() {
		super();
	}

	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		/*
		  check format...
		  2 args : both list
		  1st : Function statement
		  2nd : args for that function (only one arg list at this version.)
		*/
		if (argNum < 2) {
			throw new Exception("Error-apply: too few arguments");
		}
		if (argNum > 2) {
			throw new Exception("Error-apply: too many arguments");
		}
		if (!(arguments.getCar() instanceof Cons)) {
			throw new Exception("Error-apply: bad argument type - " + arguments.getCar().toString());
		}
		if (!(arguments.getCdr().getCar() instanceof Cons))
			throw new Exception("Error-apply: bad argument type - " + arguments.getCdr().getCar().toString());
		// procedure.
		// get procedure from FUNCTION statement.
		Function f;
		f = arguments.getCar().function(environment);
		// re-Quote the arg list.
		Cons argList = (Cons) arguments.getCdr().getCar().eval(environment);
		Cons newArguments = new Cons();
		for (; ! isVoidList(argList); argList = argList.getCdr()) {
			Cons quoteList = new Cons();
			quoteList.add(new Symbol("QUOTE"));
			quoteList.add(argList.getCar());
			newArguments.add(quoteList);
		}
		// apply the new arg.
		return f.apply(newArguments, environment);
	}
}
