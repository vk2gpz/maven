/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.datatype;

/* ------------------ Import classes (packages) ------------------- */
import java.io.*;

import com.vk2gpz.elmer.script.lisp.function.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                    Implementation of class LString                    
====================================================================*/
/**
 * LString represents "String" (different from string atom).
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Atom
 */

public class LString implements Atom {
	protected String str = "";
	
	public LString() {
		super();
	}
	
	public LString(String s) {
		this();
		this.str = s;
	}
	
	public LString(char[] ca) {
		this();
		this.str = new String(ca);
	}
	
	public void print(PrintWriter pw) throws Exception {
		pw.write(toString());
	}
	
	public String toString() {
		return this.str;
	}
	
	public Function function(LPackage pack) throws Exception{
		throw new Exception("Error: bad function - " + this);
	}
	
	public SExpression eval(LPackage pack) throws Exception {
		return this;
	}
}
