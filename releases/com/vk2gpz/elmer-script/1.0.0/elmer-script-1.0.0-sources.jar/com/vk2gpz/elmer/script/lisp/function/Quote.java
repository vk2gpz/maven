/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                    Implementation of class Quote                     
====================================================================*/
/**
 * generally describe Quote in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see SpecialFunction
 */

public final class Quote extends SpecialFunction {
	public Quote() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...only one arg.
		if (argNum < 1) {
			throw new Exception("Error-quote: too few arguments");
		}
		if (argNum > 1) {
			throw new Exception("Error-quote: too many arguments");
		}
		// procedure.
		return arguments.getCar();//just return the arg.
	}
}

