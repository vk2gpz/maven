/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                Implementation of class NormalFunction                
====================================================================*/
/**
 * generally describe NormalFunction in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Function
 */

public abstract class NormalFunction implements Function {
	public SExpression apply(Cons arguments, LPackage pack) throws Exception{
		Cons list = new Cons();
		Cons last = list;
		for (; ! isVoidList(arguments); arguments = arguments.getCdr()) {
			SExpression se = arguments.getCar().eval(pack);
			last = last.add(se);
		}
		return process(list, pack);
	}
	
	protected boolean isVoidList(Object se) throws Exception {
		boolean rtn = false;
		if (se instanceof Cons) {
			if( !((Cons) se).isDotted() && ((Cons) se).size() == 0) {
				rtn = true;
			}
		}
		return rtn;
	}
}

