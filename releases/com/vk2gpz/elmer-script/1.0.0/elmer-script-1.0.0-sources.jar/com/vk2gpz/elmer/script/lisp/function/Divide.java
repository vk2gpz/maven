/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                    Implementation of class Divide                    
====================================================================*/
/**
 * generally describe Divide in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see NormalFunction
 */

public final class Divide extends NormalFunction {
	public Divide() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		// check format...1> arg and all numbers.
		if (argNum < 1) {
			throw new Exception("Error-divide: too few arguments");
		}
		if (!(arguments.getCar() instanceof LNumber)) {
			throw new Exception("Error-divide: bad argument type - " + arguments.getCar().toString());
		}
		// init value.
		SExpression sum;
		Cons arg = null;
		if (argNum == 1) { 
			sum = new LInteger(1);
			arg = arguments;
		} else {
			sum = arguments.getCar();
			arg = arguments.getCdr();
		}
		// procedure.
		for (; !isVoidList(arg); arg = arg.getCdr()) {
			SExpression se = arg.getCar();
			sum = ((LNumber)sum).divide(se);
		}
		return sum;
	}
}
