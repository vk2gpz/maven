/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */

import com.vk2gpz.elmer.script.lisp.datatype.Cons;
import com.vk2gpz.elmer.script.lisp.environment.LPackage;

/*====================================================================
                   Implementation of class Closure                    
====================================================================*/
/**
 * generally describe Closure in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Lambda
 */

public class Closure extends Lambda {
	public Closure(Cons lambdaForm, LPackage parent) throws Exception {
		super(lambdaForm);      // create a Lambda object,
		this.env.setParent(parent);	//and store the specified environment.
	}
}

