/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.script.lisp.function;

/* ------------------ Import classes (packages) ------------------- */
import java.util.*;

import com.vk2gpz.elmer.script.lisp.datatype.*;
import com.vk2gpz.elmer.script.lisp.environment.*;

/*====================================================================
                      Implementation of class Do                      
====================================================================*/
/**
 * generally describe Do in here
 * 
 * @version $Revision: 1.2 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see SpecialFunction
 */

public final class Do extends SpecialFunction {
	public Do() {
		super();
	}
	
	public SExpression process(Cons arguments, LPackage environment) throws Exception{
		int argNum = arguments.size();
		/*
		  check format...more than 2 args (both list).
		  1st : parameter
		  2nd : end condition
		  3rd : body
		*/
		if (argNum < 2) {
			throw new Exception("Error-do: too few arguments");
		}
		if (!(arguments.getCar() instanceof Cons)) {
			throw new Exception("Error-do: bad argument type - " + arguments.getCar().toString());
		}
		if (!(arguments.getCdr().getCar() instanceof Cons)) {
			throw new Exception("Error-do: bad argument type - " + arguments.getCdr().getCar().toString());
		}
		
		Hashtable updates = new Hashtable(); 
		
		// new env.
		LPackage env = new LPackage();
		
		//bound initial values of params.
		Cons params =  (Cons) arguments.getCar();
		for (; !isVoidList(params); params = params.getCdr()) {
			// get param.
			if (!(params.getCar() instanceof Cons)) {
				throw new Exception("Error-do: bad parameter form - " + params.getCar().toString());
			}
			Cons param =  (Cons) params.getCar();
			// check param.
			if (param.size() < 2) {
				throw new Exception("Error-do: too few elements - parameter - " + param);
			}
			if (param.size() > 3) {
				throw new Exception("Error-do: too many elements - parameter - " + param);
			}
			if (!(param.getCar() instanceof Symbol)) {
				throw new Exception("Error-do: bad parameter - " + param.getCar().toString());
			}
			//boudn param's init value.
			String key = param.getCar().toString();
			SExpression binding = param.getCdr().getCar();
			// evaluate with other env.
			SExpression value = binding.eval(environment);
			// then add to the new env.
			env.put(key, value);
			// if there is a update form, keep in a hash.
			if (param.size() == 3) {
				updates.put(key, param.getCdr().getCdr().getCar());
			}
		}
		
		// include other env.
		env.setParent(environment);
		
		// save "end chek form" and chek it.
		Cons judgeForm = (Cons) arguments.getCdr().getCar();
		if (judgeForm.size() < 1) {
			throw new Exception("Error-do: bad judgement form - " + judgeForm);
		}
		
		// evaluate Do statement with the new env.
		SExpression rtn = new Nil();
		
		while (true) {
			// check "end"
			Cons jform = judgeForm;
			if (!isVoidList(jform.getCar().eval(env))) { // if other than Nil
				jform = jform.getCdr();
				for (; !isVoidList(jform); jform = jform.getCdr()) {
					rtn = jform.getCar().eval(env);
				}
				break;   
			}
				
			// evaluate body.
			Cons arg = arguments.getCdr().getCdr();
			for (; !isVoidList(arg); arg = arg.getCdr()) {
				arg.getCar().eval(env);
			}
			
			// update parameter.
			for (Enumeration enm = updates.keys(); enm.hasMoreElements();) {
				String key = (String)enm.nextElement();
				SExpression binding = (SExpression)updates.get(key);
				SExpression value = binding.eval(env);
				env.put(key,value);
			}
		}
		
		return rtn;
	}
}
