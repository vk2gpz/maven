/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.discord;

/*
import discord4j.core.DiscordClient;
import discord4j.core.DiscordClientBuilder;
import discord4j.core.object.entity.*;

import reactor.core.publisher.*;
import discord4j.core.object.util.Snowflake;
*/

@SuppressWarnings("unused")
public class DiscordUtil {
	// Constants for use throughout the bot
	static String BOT_PREFIX = "/";
	
	// Handles the creation and getting of a IDiscordClient object for a token
	/*
	public static DiscordClient buildDiscordClient(String token) {
		
		// The ClientBuilder object is where you will attach your params for configuring the instance of your bot.
		// Such as withToken, setDaemon etc
		return new DiscordClientBuilder(token)
				.build();
	}
	

	// Helper functions to make certain aspects of the bot easier to use.
	public static void sendMessage(Channel channel, String message) {
		// This might look weird but it'll be explained in another page.
		RequestBuffer.request(() -> {
			try {
				channel.sendMessage(message);
			} catch (DiscordException e) {
				System.err.println("Message could not be sent with error: ");
				e.printStackTrace();
			}
		});
	}
	
	
	public static boolean hasRole(User user, Guild guild, String rolename) {
		Mono<Member> member = user.asMember(guild.getId());
		Set<Snowflake> roles = member.block().getRoleIds();
		Mono<Role> role = guild.getRoleById(Snowflake.of(rolename));
		return roles.contains(role.block().getId());
	}
	
	public static Role assignRole(User user, Guild guild, String rolename) {
		Mono<Member> member = user.asMember(guild.getId());
		Mono<Role> role = guild.getRoleById(Snowflake.of(rolename));
		member.block().addRole(role.block().getId());
		
		return role.block();
	}
	
	 */
}
