/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.db.mongo;

import com.mongodb.MongoClient;
import com.vk2gpz.elmer.db.DatabaseException;
import com.vk2gpz.elmer.db.DatabaseManager;

/**
 * Connections to MongoDB servers. The client manages its own connection pool, so a registered client
 * counts as alive until it is shut down.
 */
public class MongoManager extends DatabaseManager<MongoClient, MongoDB> {

	/** Connects to {@code host:port} and registers it as {@code dbName}. {@code dbvalue} is unused. */
	@Override
	public MongoDB initDB(String host, int port, String dbName, String user, String password, Object dbvalue) {
		return register(dbName, new MongoDB(host, port, dbName, new String[]{user, password}));
	}

	@Override
	protected boolean isAlive(MongoClient client) {
		return true;
	}

	@Override
	protected void close(MongoClient client) {
		client.close();
	}

	/** Registers an already created connector. @throws DatabaseException if it cannot connect */
	protected void registerConnection(String name, MongoDB db) throws DatabaseException {
		registerDatabase(name, db);
	}

	/** @return helpers for the client registered as {@code name}, or null if it has no connection. */
	public MongoQuery query(String name) {
		MongoClient client = getActiveConnection(name);
		return client == null ? null : new MongoQuery(client);
	}
}
