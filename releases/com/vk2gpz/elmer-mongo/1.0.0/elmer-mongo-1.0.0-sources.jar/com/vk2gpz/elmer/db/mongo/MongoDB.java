/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.db.mongo;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.MongoException;
import com.mongodb.ServerAddress;
import com.vk2gpz.elmer.db.DatabaseConnector;
import com.vk2gpz.elmer.db.DatabaseException;

/**
 * MongoDB server at {@code host:port}. With a user name, it logs in to {@code dbName} with that user and
 * password; without one (null or empty), it connects without logging in.
 */
public class MongoDB extends DatabaseConnector<MongoClient> {

	/** @param credentials {@code {user, password}}, or null */
	public MongoDB(String host, int port, String dbName, String[] credentials) {
		super(host, port, dbName, credentials);
	}

	@Override
	public MongoClient connect() throws DatabaseException {
		ServerAddress address = new ServerAddress(host, port);
		MongoClientOptions options = MongoClientOptions.builder().build();
		try {
			String user = user();
			if (user == null || user.isEmpty()) {
				return new MongoClient(address, options);
			}
			String pw = password() == null ? "" : password();
			MongoCredential credential = MongoCredential.createCredential(user, dbName, pw.toCharArray());
			return new MongoClient(address, credential, options);
		} catch (MongoException | IllegalArgumentException e) {
			throw new DatabaseException("Cannot connect to MongoDB at " + host + ":" + port + ": " + e.getMessage(), e);
		}
	}
}
