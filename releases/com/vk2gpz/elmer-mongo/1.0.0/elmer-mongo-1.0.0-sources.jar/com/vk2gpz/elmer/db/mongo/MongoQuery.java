/*
 * Copyright (c) vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

package com.vk2gpz.elmer.db.mongo;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
import org.bson.Document;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Shortcuts for common MongoDB operations, addressed by database and collection name. */
public class MongoQuery {
	private final MongoClient client;

	public MongoQuery(MongoClient client) {
		this.client = client;
	}

	public MongoDatabase getDatabase(String dbName) {
		return client.getDatabase(dbName);
	}

	public MongoCollection<Document> getCollection(String dbName, String collectionName) {
		return getDatabase(dbName).getCollection(collectionName);
	}

	/** @deprecated use {@link #getDatabaseNames()} */
	@Deprecated
	public List<String> getDatabases() {
		return getDatabaseNames().into(new ArrayList<>());
	}

	public MongoIterable<String> getDatabaseNames() {
		return client.listDatabaseNames();
	}

	public void dropDatabase(String dbName) {
		getDatabase(dbName).drop();
	}

	public MongoIterable<String> getCollections(String dbName) {
		return getDatabase(dbName).listCollectionNames();
	}

	public void insertDocument(String dbName, String collectionName, Document doc) {
		getCollection(dbName, collectionName).insertOne(doc);
	}

	/** @return {@code {key: value}} */
	public Document createDocument(String key, Object value) {
		return new Document(key, value);
	}

	/** @return a document with {@code keys[i]: values[i]}; extra keys or values are ignored. */
	public Document createDocument(String[] keys, Object[] values) {
		Document doc = new Document();
		for (int i = 0; i < Math.min(keys.length, values.length); i++) {
			doc.append(keys[i], values[i]);
		}
		return doc;
	}

	/** @return {@code {key: [values...]}} */
	public Document createDocument(String key, Object[] values) {
		return new Document(key, Arrays.asList(values));
	}

	public Long count(String dbName, String collectionName) {
		return getCollection(dbName, collectionName).countDocuments();
	}

	public MongoCursor<Document> getDocuments(String dbName, String collectionName) {
		return getCollection(dbName, collectionName).find().iterator();
	}

	public MongoCursor<Document> getDocuments(String dbName, String collectionName, Document query) {
		return getCollection(dbName, collectionName).find(query).iterator();
	}

	/** @return the first document matching {@code query}, or null. */
	public Document getOne(String dbName, String collectionName, Document query) {
		return getCollection(dbName, collectionName).find(query).first();
	}

	/** Applies {@code update} (e.g. {@code {"$set": {...}}}) to the first document matching {@code query}. */
	public void updateOne(String dbName, String collectionName, Document query, Document update) {
		getCollection(dbName, collectionName).updateOne(query, update);
	}

	/**
	 * @param sort  sort order, or null
	 * @param limit maximum number of documents; 0 or less means no limit
	 */
	public MongoCursor<Document> getAll(String dbName, String collectionName, Document query, Document sort, int limit) {
		FindIterable<Document> found = getCollection(dbName, collectionName).find(query == null ? new Document() : query);
		if (sort != null) found = found.sort(sort);
		if (limit > 0) found = found.limit(limit);
		return found.iterator();
	}

	public MongoCursor<Document> getAll(String dbName, String collectionName) {
		return getAll(dbName, collectionName, null, null, 0);
	}

	public MongoCursor<Document> getAll(String dbName, String collectionName, Document query) {
		return getAll(dbName, collectionName, query, null, 0);
	}
}
