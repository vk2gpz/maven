/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.desktop;

/* ------------------ Import classes (packages) ------------------- */
import java.awt.event.*;
import java.io.*;
import java.text.*;
import javax.swing.event.*;

/*====================================================================
                   Implementation of class Constant                   
====================================================================*/
/**
 * Constant is a bean representing a constant value.
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Serializable
 */

public final class Constant implements Serializable {
	/* -------------------------- serialized -------------------------- */
    private String constant;
    private final EventListenerList listenerList = new EventListenerList();
	
    public Constant() {
		super();
		this.constant = "0";
    }

    public String getConstant() {
        return this.constant;
    }
	
    public void setConstant(String s) {
		NumberFormat nf = NumberFormat.getNumberInstance();
		try {
			nf.parse(s);		// chech whether it is number or not.
		} catch (ParseException e) {
			String lower = s.toLowerCase();
			if ((! lower.equals("true")) && (! lower.equals("false"))) {
				s = "0";
			}
		}
        this.constant = s;
    }

	public void trigger() {
		fireActionPerformed();
	}
	
    /**
     * adds an ActionListener to the button
     */
    public void addConstantListener(ActionListener l) {
        this.listenerList.add(ActionListener.class, l);
    }
 
    /**
     * removes an ActionListener from the button
     */
    public void removeConstantListener(ActionListener l) {
        this.listenerList.remove(ActionListener.class, l);
    }

    /**
     * Notify all listeners that have registered interest for
     * notification on this event type. The event instance
     * is lazily created using the parameters passed into
     * the fire method.
     */
    private void fireActionPerformed() {
        // Guaranteed to return a non-null array
        Object[] listeners = this.listenerList.getListenerList();
		String command = "constant produced";
        ActionEvent e = null;
        // Process the listeners last to first, notifying
        // those that are interested in this event
        for (int i = listeners.length-2; i>=0; i-=2) {
            if (listeners[i]==ActionListener.class) {
                // Lazily create the event:
                if (e == null) {
                    e = new ActionEvent(this,
                                        ActionEvent.ACTION_PERFORMED,
                                        command);
                }
                ((ActionListener)listeners[i+1]).actionPerformed(e);
            }
        }
    }
}
