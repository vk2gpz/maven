/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.desktop;

import com.vk2gpz.elmer.script.lisp.*;

/* ------------------ Import classes (packages) ------------------- */
import java.awt.*;

import javax.swing.*;

/*====================================================================
                     Implementation of class Lisp                     
====================================================================*/
/**
 * Lisp provides a very simple GUI to use LispEngine.
 * 
 * @version $Revision: 1.1.1.1 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see JPanel
 */

public class Lisp extends JPanel {
	/**
	* The lisp engine.
	*/
	private LispEngine engine;
	
	/**
	 * null-constructor.
	*/
	public Lisp() {
		super();

		// create UI
		add(createTextArea());
		// create in/out

		// create lisp engine.
//  		this.engine = new LispEngine(in, out, true);

		// run engine
		//this.engine.start();
	}

	/**
	* create a GUI to display texts.
	*/
	private JPanel createTextArea() {
		JPanel panel = new JPanel();
        panel.setSize(300, 200);
        Font font = new Font("Helvetica", 0, 18);
        JTextArea textarea = new JTextArea();
        textarea.setFont(font);
        panel.setLayout(new BorderLayout(5, 5));
        panel.add("Center", textarea);

		return panel;
	}

	/**
	* The main method for a standalone application.
	*/
	public static void main(String[] args) {
		Lisp vLisp = new Lisp();
		JFrame frame = new JFrame();
		
		frame.getContentPane().add(vLisp);
		frame.pack();
		frame.setVisible(true);
	}
}


