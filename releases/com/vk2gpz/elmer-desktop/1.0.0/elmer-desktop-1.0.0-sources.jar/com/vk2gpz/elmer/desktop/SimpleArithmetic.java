/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.desktop;

/* ------------------ Import classes (packages) ------------------- */
import java.awt.event.*;
import java.io.*;

import javax.swing.event.*;

/*====================================================================
               Implementation of class SimpleArithmetic               
====================================================================*/
/**
 * generally describe SimpleArithmetic in here
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Serializable
 */

public final class SimpleArithmetic implements Serializable {
    public static final int ADD = 0; // +
    public static final int SUBTRACT = 1; // -
    public static final int MULTIPLY = 2; // *
    public static final int DIVIDE = 3;	// /
    public static final int REMAINDER = 4; // %

    transient private EventListenerList arithListeners = new EventListenerList();
	
	/* ------------------------ not serialized ------------------------ */
    transient private boolean lhsDefined;
    transient private boolean rhsDefined;
	transient private double evalResult = 0.0D;
    transient private double left;

	/* -------------------------- serialized -------------------------- */
    private int function;
    private boolean rhsConstant;
    private double right;	

    public SimpleArithmetic() {
        this.lhsDefined = false;
        this.rhsDefined = false;
        this.rhsConstant = false;
        this.function = ADD;
    }

	private void initialize() {
		this.arithListeners = new EventListenerList();
		this.evalResult = 0.0D;
	}

    /**
     * Serialization methods
     */
    private void readObject(ObjectInputStream s) throws ClassNotFoundException, IOException {
		s.defaultReadObject();
		
		initialize();
    }
	
    public int getFunction() {
        return this.function;
    }

    public void setFunction(int func) {
		this.function = (func < ADD || func > REMAINDER) ? ADD : func;
    }

	public void setLeftHandSideValue(double obj) {
		this.left = obj;
		this.lhsDefined = true;
        if (this.lhsDefined && this.rhsDefined) {
            this.lhsDefined = false;
            this.rhsDefined = this.rhsConstant;
            sendResult();
        }
    }
	
    public double getLeftHandSideValue() {
        return this.left;
    }
	
	public void setRightHandSideValue(double obj) {
		this.right = obj;
		this.rhsDefined = true;
        if (this.lhsDefined && this.rhsDefined) {
            this.lhsDefined = false;
            this.rhsDefined = this.rhsConstant;
            sendResult();
        }
    }

    public double getRightHandSideValue() {
        return this.right;
    }
	
    public boolean getRightHandSideConstant() {
        return this.rhsConstant;
    }

    public void setRightHandSideConstant(boolean rhsCons) {
        this.rhsDefined = this.rhsConstant = rhsCons;
    }
	
    private void sendResult() {
        this.evalResult = evaluate();
		fireActionPerformed();
    }

	public double getResult() {
		return this.evalResult;
	}
	
    private double evaluate() {
        final int func = this.function;
        final double l = this.left;
        final double r = this.right;
        
        switch(func) {
        case ADD:
            return l + r;
        case SUBTRACT:
            return l - r;
        case MULTIPLY:
            return l * r;
        case DIVIDE:
            return l / r;
        case REMAINDER:
            return (int)l % (int)r;
        }
        return 0.0D;
    }

    /**
     * adds an ActionListener to the button
     */
    public void addArithListener(ActionListener l) {
        this.arithListeners.add(ActionListener.class, l);
    }
 
    /**
     * removes an ActionListener from the button
     */
    public void removeArithListener(ActionListener l) {
        this.arithListeners.remove(ActionListener.class, l);
    }

    /**
     * Notify all listeners that have registered interest for
     * notification on this event type. The event instance
     * is lazily created using the parameters passed into
     * the fire method.
     */
    private void fireActionPerformed() {
        // Guaranteed to return a non-null array
        Object[] listeners = this.arithListeners.getListenerList();
		String command = "arith evaluated";
        ActionEvent e = null;
        // Process the listeners last to first, notifying
        // those that are interested in this event
        for (int i = listeners.length-2; i>=0; i-=2) {
            if (listeners[i]==ActionListener.class) {
                // Lazily create the event:
                if (e == null) {
                    e = new ActionEvent(this,
                                        ActionEvent.ACTION_PERFORMED,
                                        command);
                }
                ((ActionListener)listeners[i+1]).actionPerformed(e);
            }
        }
    }
}
