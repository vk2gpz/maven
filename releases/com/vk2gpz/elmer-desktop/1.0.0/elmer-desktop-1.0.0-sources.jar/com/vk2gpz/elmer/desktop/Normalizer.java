/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.desktop;

import com.vk2gpz.elmer.math.VecMath;

/* ------------------ Import classes (packages) ------------------- */
import java.awt.event.*;
import java.io.*;
import javax.swing.event.*;

import com.vk2gpz.elmer.debug.DebugHandler;

/*====================================================================
                  Implementation of class Normalizer                  
====================================================================*/
/**
 * generally describe Normalizer in here
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Serializable
 */

public class Normalizer implements Serializable {
	private static final boolean DEBUG = DebugHandler.isDebugged(Normalizer.class);

	public static final int LENGTH = 0;
	public static final int RANGE = 1;
	
	/* ------------------------ not serialized ------------------------ */
    final transient private EventListenerList listenerList = new EventListenerList();
	transient private ActionEvent myEvent;
	transient private double[] normalizedData;
	
	/* -------------------------- serialized -------------------------- */
	private int mode;
	private double minimum;
	private double maximum;
	
    public Normalizer() {
		super();
		initialize();
    }

	private void initialize() {
		this.mode = RANGE;
		this.minimum = 0.0;
		this.maximum = 1.0;
	}

	public void setMode(int mode) {
		this.mode = mode;
	}

	public int getMode() {
		return this.mode;
	}
	
	public void setMinimum(double min) {
		this.minimum = min;
	}

	public double getMinimum() {
		return this.minimum;
	}

	public void setMaximum(double max) {
		this.maximum = max;
	}

	public double getMaximum() {
		return this.maximum;
	}
	
	public void setData(double[] values) {
		int size = values.length;
		this.normalizedData = new double[size];
		switch (this.mode) {
		case LENGTH:
		default:
			normalizeLength(values, this.normalizedData);
			break;
		case RANGE:
			normalizeRange(values, this.normalizedData,
						   this.minimum, this.maximum);
			break;
		}
		fireNormalizerChanged();
	}

	private void normalizeLength(double[] values, double[] result) {
		System.arraycopy(values, 0, result, 0, values.length);
		VecMath.normalize(result);
	}

	private void normalizeRange(double[] values, double[] result, double min, double max) {
		double range = max - min;
		double lmin = Double.MAX_VALUE;
		double lmax = -Double.MAX_VALUE;
		for (double value : values) {
			if (value < lmin) {
				lmin = value;
			}
			if (value > lmax) {
				lmax = value;
			}
		}
		double lrange = lmax - lmin;
		double ratio = range / lrange;
		for (int i = 0; i < values.length; i++) {
			result[i] = min + (values[i] - lmin) * ratio;
		}
	}
	
	public double[] getNormalizedData() {
		return this.normalizedData;
	}

	/**
     * adds an NormalizerListener to the shape
     */
    public void addNormalizerListener(ActionListener l) {
        this.listenerList.add(ActionListener.class, l);
    }

    /**
     * removes an GeometryListener from the shape.
     */
    public void removeNormalizerListener(ActionListener l) {
		this.listenerList.remove(ActionListener.class, l);
    }

    /**
     * Notify all listeners that have registered interest for
     * notification on this event type.
     */
    public void fireNormalizerChanged() {
        Object[] listeners = this.listenerList.getListenerList();
        // Process the listeners last to first, notifying
        // those that are interested in this event
		String command = "normalized";
        for (int i = listeners.length - 2; i >= 0; i -= 2) {
            if (listeners[i]==ActionListener.class) {
                // Lazily create the event:
                if (this.myEvent == null) {
                    this.myEvent = new ActionEvent(this,
                                        ActionEvent.ACTION_PERFORMED,
                                        command);
                }
                ((ActionListener)listeners[i+1]).actionPerformed(this.myEvent);
            }
        }
    }
}
