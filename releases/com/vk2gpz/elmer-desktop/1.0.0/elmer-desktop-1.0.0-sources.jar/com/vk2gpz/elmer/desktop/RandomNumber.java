/*
 * Copyright (c) 2003 vk2gpz
 * SPDX-License-Identifier: Apache-2.0
 */

/* --------------------------- Package ---------------------------- */
package com.vk2gpz.elmer.desktop;

import com.vk2gpz.elmer.math.RandomUtil;

/* ------------------ Import classes (packages) ------------------- */
import java.awt.event.*;
import java.io.*;

import javax.swing.event.*;

/*====================================================================
                 Implementation of class RandomNumber                 
====================================================================*/
/**
 * RandomNumber is a random number generator that supports various
 * types of random number (Gaussian, Gamma, Beta, Poisson,...).
 * 
 * @version $Revision: 1.3 $
 * @author vk2gpz (vk2gpz@gmail.com)
 * @see Serializable
 */

public class RandomNumber implements Serializable {
	public static final int STANDARD = 0;
	public static final int GAUSSIAN = 1;
	public static final int GAMMA = 2;
	public static final int BETA = 3;
	public static final int POISSON = 4;
	public static final int WEIBULL = 5;
	public static final int CHISQUARE = 6;
	public static final int T = 7;
	public static final int F = 8;
	public static final int LOGISTIC = 9;
	public static final int POWER = 10;
	public static final int BINORMAL = 11;
	public static final int BINOMIAL = 12;
	public static final int UNITSPHERE = 14;
	public static final int EXPONENTIAL = 15;
	public static final int GEOMETRIC = 16;
	public static final int CAUCHY = 17;
	public static final int TRIANGULAR = 18;
	
	/* ------------------------ not serialized ------------------------ */
    transient private EventListenerList eventListeners;
	transient private double[] randomNumbers;
	
	/* -------------------------- serialized -------------------------- */
    private int type;
    private int numberOfValues;
	private double gaussianStd = 1.0;
	private double gammaP = 1.0;
	private double betaP = 1.0;
	private double betaQ = 1.0;
	private double poissonN = 1.0;		
	private double weibullAlpha = 1.0;
	private double chiSquareN = 1.0;
	private double tN = 1.0;
	private double fN1 = 1.0;
	private double fN2 = 1.0;
	private int powerN = 1;
	private double binormalCorrelationCoeff = 1.0;
	private int binomialN = 1;
	private double binomialP = 1.0;
	private int unitSphereN = 1;
	private double exponentialM = 1.0;
	private double geometricP = 1.0;		
		
    public RandomNumber() {
		initialize();
    }

	private void initialize() {
		this.type = STANDARD;
		this.numberOfValues = 1;
	}

    /**
     * Serialization methods
     */
    private void readObject(ObjectInputStream s) throws ClassNotFoundException, IOException {
		s.defaultReadObject();
		
		initialize();
    }

	public void setNumberOfValues(int n) {
		this.numberOfValues = n;
	}

	public int getNumberOfValues() {
		return this.numberOfValues;
	}
	
    public int getType() {
        return this.type;
    }

	public void setType(int type) {
		this.type = type;
	}
	
	public double getRandomNumber() {
		return this.randomNumbers[0];
	}

	public double[] getRandomNumbers() {
		return this.randomNumbers;
	}
	
	private void checkArray() {
		final int numValues = this.numberOfValues;
		final int randLen = (this.randomNumbers == null) ? 0 : this.randomNumbers.length;
		
		if (randLen != numValues) {
			final int arraySize;
			switch (this.type) {
				case BINORMAL:
					arraySize = numValues << 1;  // numValues * 2 (faster)
					break;
				case UNITSPHERE:
					arraySize = numValues * this.unitSphereN;
					break;
				default:
					arraySize = numValues;
			}
			this.randomNumbers = new double[arraySize];
		}
	}

	private void generateStandard() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = Math.random();
		}
	}

	private void generateGaussian() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.gaussianRandom(this.gaussianStd);
		}
	}

	private void generateGamma() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.gammaRandom(this.gammaP);
		}
	}

	private void generateBeta() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.betaRandom(this.betaP, this.betaQ);
		}
	}

	private void generatePoisson() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.poissonRandom(this.poissonN);
		}
	}

	private void generateWeibull() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.weibullRandom(this.weibullAlpha);
		}
	}

	private void generateChiSquare() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.chiSquareRandom(this.chiSquareN);
		}
	}

	private void generateT() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.tRandom(this.tN);
		}
	}

	private void generateF() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.fRandom(this.fN1, this.fN2);
		}
	}

	private void generateLogistic() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.logisticRandom();
		}
	}

	private void generatePower() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.powerRandom(this.powerN);
		}
	}

	private void generateBinormal() {
		for (int i = 0; i < this.numberOfValues; i++) {
			double[] xy = RandomUtil.binormalRandom(this.binormalCorrelationCoeff);
			this.randomNumbers[i] = xy[0];
			this.randomNumbers[i++] = xy[1];			
		}
	}

	private void generateBinomial() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.binomialRandom(this.binomialN, this.binomialP);
		}
	}

	private void generateUnitSphere() {
		for (int i = 0; i < this.numberOfValues; i++) {
			double[] v = RandomUtil.unitSphereRandom(this.unitSphereN);
			for (double value : v) {
				this.randomNumbers[i++] = value;
			}
		}
	}

	private void generateExponential() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.exponentialRandom(this.exponentialM);
		}
	}

	private void generateGeometric() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.geometricRandom(this.geometricP);
		}
	}

	private void generateCauchy() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.cauchyRandom();
		}
	}

	private void generateTriangular() {
		for (int i = 0; i < this.numberOfValues; i++) {
			this.randomNumbers[i] = RandomUtil.triangularRandom();
		}
	}
	
	public void generate() {
		checkArray();
		switch (this.type) {
		case STANDARD:
		default:
			generateStandard();
			break;
		case GAUSSIAN:
			generateGaussian();
			break;
		case GAMMA:
			generateGamma();
			break;
		case BETA:
			generateBeta();
			break;
		case POISSON:
			generatePoisson();
			break;
		case WEIBULL:
			generateWeibull();
			break;
		case CHISQUARE:
			generateChiSquare();
			break;
		case T:
			generateT();
			break;
		case F:
			generateF();
			break;
		case LOGISTIC:
			generateLogistic();
			break;
		case POWER:
			generatePower();
			break;
		case BINORMAL:
			generateBinormal();
			break;
		case BINOMIAL:
			generateBinomial();
			break;
		case UNITSPHERE:
			generateUnitSphere();
			break;
		case EXPONENTIAL:
			generateExponential();
			break;
		case GEOMETRIC:
			generateGeometric();
			break;
		case CAUCHY:
			generateCauchy();
			break;
		case TRIANGULAR:
			generateTriangular();
			break;
		}
		fireActionPerformed();
	}

	private void checkListener() {
		if (this.eventListeners == null) {
			this.eventListeners = new EventListenerList();
		}
	}
	
    /**
     * adds an ActionListener to the button
     */
    public void addActionListener(ActionListener l) {
		checkListener();
        this.eventListeners.add(ActionListener.class, l);
    }
 
    /**
     * removes an ActionListener from the button
     */
    public void removeActionListener(ActionListener l) {
		checkListener();
        this.eventListeners.remove(ActionListener.class, l);
    }

    /**
     * Notify all listeners that have registered interest for
     * notification on this event type. The event instance
     * is lazily created using the parameters passed into
     * the fire method.
     */
    private void fireActionPerformed() {
		checkListener();
        // Guaranteed to return a non-null array
        Object[] listeners = this.eventListeners.getListenerList();
		String command = "arith evaluated";
        ActionEvent e = null;
        // Process the listeners last to first, notifying
        // those that are interested in this event
        for (int i = listeners.length-2; i>=0; i-=2) {
            if (listeners[i]==ActionListener.class) {
                // Lazily create the event:
                if (e == null) {
                    e = new ActionEvent(this, ActionEvent.ACTION_PERFORMED,
                                        command);
                }
                ((ActionListener)listeners[i+1]).actionPerformed(e);
            }
        }
    }

	public void setGaussianStd(double std) {
		this.gaussianStd = std;
	}

	public double getGaussianStd() {
		return this.gaussianStd;
	}

	public void setGammaP(double p) {
		this.gammaP = p;
	}
	
	public double getGammaP() {
		return this.gammaP;
	}

	public void setBetaP(double p) {
		this.betaP = p;
	}

	public double getBetaP() {
		return this.betaP;
	}

	public void setBetaQ(double q) {
		this.betaQ = q;
	}

	public double getBetaQ() {
		return this.betaQ;
	}

	public void setPoissonN(double n) {
		this.poissonN = n;
	}

	public double getPoissonN() {
		return this.poissonN;
	}

	public void setWeibullAlpha(double alpha) {
		this.weibullAlpha = alpha;
	}

	public double getWeibullAlpha() {
		return this.weibullAlpha;
	}

	public void setChiSquareN(double n) {
		this.chiSquareN = n;
	}

	public double getChiSquareN() {
		return this.chiSquareN;
	}

	public void setTN(double n) {
		this.tN = n;
	}

	public double getTN() {
		return this.tN;
	}

	public void setFN1(double n1) {
		this.fN1 = n1;
	}

	public double getFN1() {
		return this.fN1;
	}
	
	public void setFN2(double n2) {
		this.fN2 = n2;
	}

	public double getFN2() {
		return this.fN2;
	}

	public void setPowerN(int n) {
		this.powerN = n;
	}

	public int getPowerN() {
		return this.powerN;
	}

	public void setBinormalCorrelationCoeff(double c) {
		this.binormalCorrelationCoeff = c;
	}

	public double getBinormalCorrelationCoeff() {
		return this.binormalCorrelationCoeff;
	}

	public void setBinomialN(int n) {
		this.binomialN = n;
	}

	public int getBinomialN() {
		return this.binomialN;
	}

	public void setBinomialP(double p) {
		this.binomialP = p;
	}

	public double getBinomialP() {
		return this.binomialP;
	}

	public void setUnitSphereN(int n) {
		this.unitSphereN = n;
	}

	public int getUnitSphereN() {
		return this.unitSphereN;
	}

	public void setExponentialM(double m) {
		this.exponentialM = m;
	}

	public double getExponentialM() {
		return this.exponentialM;
	}

	public void setGeometricP(double p) {
		this.geometricP = p;
	}

	public double getGeometricP() {
		return this.geometricP;
	}
}
